package com.ebay.printorder.pojo.sme;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class SpendAmount {
    private Amount from;
    private Amount to;
}
