package com.ebay.printorder.pojo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import lombok.Getter;
import lombok.Setter;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class SendCouponResponse {
	
	private String couponId;
	private BuyersStatus buyersStatus;
	
	private ModuleFragments moduleFragments;
	private List<Messages> messages;
	private Meta meta;

	public Meta getMeta() {
		return meta;
	}

	public void setMeta(Meta meta) {
		this.meta = meta;
	}
	
	@Getter
	public static class BuyersStatus {
		private String buyerId;
		private String statusCode;
		private String status;
		
	}
	
	@Getter
	public static class Meta {
		private String pageTitle;
		private RequestParameters requestParameters;
	}
	
	@Getter
	public static class RequestParameters {
		private String deviceType;
	}
	
	@Getter
	public static class ModuleFragments {
		private CouponModuleFragment couponModuleFragment;
		private ModuleMessage moduleMessage;
	}
	
	@Getter
	public static class CouponModuleFragment {
		private String _type;
		private List<SubSectionFragment> subSectionFragment;
	}
	
	@Getter
	public static class SubSectionFragment {
		private String fieldId;
		private Synopsis synopsis;
	}
	
	@Getter
	public static class Synopsis {
		private TextualDisplay title;
	     private TextualDisplay synopsis;
	     private TextualDisplay editAction;
	     private List<TextualDisplay> selectionSummary;
	     private String accessibilityText;
	}
	/*
	 @Getter
	    public static class EditAction{
	        private String _type;
	        private TextualDisplay editAction;
	        private Action action;
	    }
	 */
	 @Getter
		public static class ModuleMessage {
			private String _type;
			
		}
	 
	 @Getter
		public static class Messages {
			private String messageType;
			private List<Content> content;
			private String fieldId;
			private String key;
			private String text;
			private String type;
		}
	
	 @Getter
		public static class Content {
			private List<TextualDisplay> message;
		}
	 
}
