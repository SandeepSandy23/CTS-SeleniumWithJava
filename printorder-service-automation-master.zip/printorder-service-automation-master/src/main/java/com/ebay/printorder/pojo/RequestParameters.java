package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestParameters {
	private String deviceType;

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

}
