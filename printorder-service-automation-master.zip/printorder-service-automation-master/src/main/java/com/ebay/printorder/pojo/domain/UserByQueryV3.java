package com.ebay.printorder.pojo.domain;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserByQueryV3 {
	private List<User> user;

}
