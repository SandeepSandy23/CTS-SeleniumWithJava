package com.ebay.printorder.pojo.sme;

import lombok.Getter;
import lombok.Setter;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class SMEResponse {
    private String lastUpdatedVersionId;
    private String promotionId;
    private String message;
    private String priority;
    private String name;
    private String status;
    private String type;
    private String subType;
    private String description;
//    private SMEStartDate startDate;
    private CouponValidDate startDate;
    private CouponValidDate endDate;
//    private SMEEndDate endDate;
    private List<Attribute> attributes;
    private List<URL> url;
    private boolean draftOnly;
    private String couponCode;
    private List<Rule> rule;
    private List<Inventory> inventory;
    private Integer maxCouponRedemptionPerUser;
    private MaxCouponDiscountAmount maxCouponDiscountAmount;
}
