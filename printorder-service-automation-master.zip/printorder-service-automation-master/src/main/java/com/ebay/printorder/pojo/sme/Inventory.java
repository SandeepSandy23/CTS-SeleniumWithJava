package com.ebay.printorder.pojo.sme;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class Inventory {
    private String inventoryType;
    private String inventorySubType;
    private List<InventoryAttribute> inventoryAttribute;
}
