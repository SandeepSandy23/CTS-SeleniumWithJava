package com.ebay.printorder.pojo.sme;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.ebay.printorder.pojo.TextualDisplay;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class CampaignDetails {
	private String _type;
	private TextualDisplay heading;
	private String selectionType;
	private List<Field> entries;
	private boolean disabled;
	private boolean lockable;
	private boolean selected;
	private boolean defaultChoice;
}
