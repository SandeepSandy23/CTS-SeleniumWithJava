package com.ebay.printorder.util;

import org.json.JSONObject;

import com.ebay.testinfrastructure.reporter_generator.ReportLogger;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class CommonUtil {
	
	private static ReportLogger breezeReport = new ReportLogger();
	
	public static <T> T fromJson(JSONObject input, Class<T> objClass) {
		if(input == null){
			return null;
		}
		try {
			Gson gson = new Gson();
			JsonParser jsonParser = new JsonParser();
		    JsonObject gsonObject = (JsonObject)jsonParser.parse(input.toString());
			return gson.fromJson(gsonObject, objClass);
		} catch (Exception e) {
			breezeReport.logWarningStep("Exception parsing JSONObject:" + e);
			return null;
		}
	}
	
	public static <T> T fromJson(String input, Class<T> objClass) {
		if(input == null){
			return null;
		}
		try {
			Gson gson = new Gson();
			return gson.fromJson(input, objClass);
		} catch (Exception e) {
			breezeReport.logWarningStep("Exception parsing String:"+input);
			return null;
		}
	}
	
	public static String toJSON(Object entity) {
		if(entity == null){
			return null;
		}
		try {
			Gson gson = new Gson();
		  	StringBuilder sb = new StringBuilder();
			return sb.append(gson.toJson(entity)).toString();
		} catch (Exception e) {
			breezeReport.logWarningStep("Exception converting to json String:"+entity.toString());
			return null;
		}
	}

}
