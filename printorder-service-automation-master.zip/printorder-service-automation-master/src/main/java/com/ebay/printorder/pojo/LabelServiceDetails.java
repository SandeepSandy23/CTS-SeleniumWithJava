package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class LabelServiceDetails {
  private List<String> orderIds;
  private Address to;
  private Address from;
}
