package com.ebay.printorder.util;

import java.net.URL;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.printorder.deserializer.RestCallDeserializer;
import com.ebay.printorder.pojo.domain.GetAddressResponse;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.serviceautil.apidriver.RestClient;

public class AddressBookSvcUtil extends BaseSvcUtil {
	
	public JSONObject getSellerDetails( String sellerName, String site) throws Exception {
        site = overrideSite(site);
        String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
        //Get list of orders info here, not just a single order.
        String addressBookPlatformSvcURL = (TestParams.TestEnv.customparam.get("addressBookPlatformSvcURL"))
                + "?filter=preference:PRIMARY&filter=purpose:SHIPPING_FROM&fieldgroups=SUMMARY&limit=1&offset=0";
        String bearer_token = "Bearer " + getAppToken("core@user");
        Reporter.log("AddressBook Endpoint URL" + addressBookPlatformSvcURL);

        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName + "%2CorigAcctId%3D" + sellerId);
        URL url = new URL(addressBookPlatformSvcURL);
        client.get(url);
        if (client.getResponseCode() != 200) {
            client.get(url);
        }
        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());
        return responseObject;
    }
    public GetAddressResponse getAddressBookSvcResponse(String sellerName, String site) throws Exception {
    	RestCallDeserializer deserializer = new RestCallDeserializer();       
        JSONObject resp = getSellerDetails(sellerName, site);
        GetAddressResponse adressBookSvcResponse = deserializer.deserializeGetAddressResponse(resp.toString());
        return adressBookSvcResponse;
    }

}
