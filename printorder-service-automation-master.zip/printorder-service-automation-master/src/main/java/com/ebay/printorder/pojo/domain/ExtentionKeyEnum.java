package com.ebay.printorder.pojo.domain;

import java.util.Arrays;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public enum ExtentionKeyEnum {
	SPS_TOP_RATED_SELLER_GLOBAL("SPS_TOP_RATED_SELLER_GLOBAL"),
	SPS_TOP_RATED_SELLER_US("SPS_TOP_RATED_SELLER_US"),
	SPS_TOP_RATED_SELLER_UK ("SPS_TOP_RATED_SELLER_UK"),
	SPS_TOP_RATED_SELLER_DE ("SPS_TOP_RATED_SELLER_DE");

	private final String name;

	ExtentionKeyEnum(String name) {
		this.name = name;
	}
	public static List<ExtentionKeyEnum> getAll() {
		return Arrays.asList(ExtentionKeyEnum.values());
	}
}
