package com.ebay.printorder.domain.executors;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.testng.Reporter;

import com.ebay.common.infra.executor.BaseExecutor;
import com.ebay.common.infra.obj.Action;
import com.ebay.common.infra.obj.BaseKeyNode;
import com.ebay.common.infra.obj.Param;
import com.ebay.common.infra.obj.orders.OrdersInfo;
import com.ebay.common.infra.obj.orders.OrdersScopeEnum;
import com.ebay.printorder.pojo.*;
import com.ebay.qi.autobot.util.Console;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.reporter_generator.ReportLogger;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public class PrintOrderDomainSvcExecutor extends BaseExecutor {
    ReportLogger breezeReport = new ReportLogger();
    String site = null;
    String propFile = null;
    
	public PrintOrderDomainSvcExecutor() throws Exception {
    	super();
    }

	@Override
	public Class<? extends Enum<?>> getActionsTypeEnumClass() {
		return PrintOrderDomainSvcActionEnum.class;
	}

	@Override
	protected void execute() throws Exception {
		site = TestParams.CommonTestEnv.site.get();
		propFile = TestParams.get("propFile");
		executeActions();
	}

	private void executeActions() throws Exception {
        List<BaseKeyNode> nodes = getNodesWithActions(OrdersScopeEnum.ORDERSINFO);
        Console.log(" #####[Print Order Domain Svc Executor] Total # of Nodes  = " + nodes.size());
        String sellerName = null;
        String validate = null;
        String errFlow = null;
        for (int i = 0; i < nodes.size(); i++) {
            OrdersInfo ordersInfo = (OrdersInfo) nodes.get(i);
            Action eachAction = ordersInfo.getActionsList().get(i);
            PrintOrderDomainSvcActionEnum action = (PrintOrderDomainSvcActionEnum) eachAction
                    .getActionEnum();
            ArrayList<Param> paramList = eachAction.getParamList();
            Console.log(action.name().toLowerCase() +" action params count = " + paramList.size());
            List<String> orders = null;
            List<String> labels = null;
            for (Param p : paramList) {
            	PrintOrderDomainSvcActionParamEnum pEnum = (PrintOrderDomainSvcActionParamEnum) p.getParamEnum();
                switch (pEnum) {
                    case ORDERS:
                        Reporter.log("Orders value = " + p.getValue());
                        orders = Arrays.asList(p.getValue().split(","));
                        break;
                    case LABELS:
                        Reporter.log("Labels value = " + p.getValue());
                        labels = Arrays.asList(p.getValue().split(","));
                        break;
                    case SELLER_NAME:
                        Reporter.log("Seller Name value = " + p.getValue());
                        sellerName = p.getValue();
                        break;
                    case SITE:
                		Reporter.log("Site value = " + p.getValue());
                		site = p.getValue();
                        break;
                    case VALIDATE:
                        Reporter.log("Validate value = " + p.getValue());
                        validate = p.getValue();
                        break;
                    case ERROR_FLOW:
                        Reporter.log("ErrorFlow value = " + p.getValue());
                        errFlow = p.getValue();
                        break;
                    default:
                        Reporter.log("Incorrect Parameter action input" + pEnum);
                        Assert.fail();
                        break;
                }
            }
            
            if(sellerName == null && ordersInfo.getOrderInfo() != null && !ordersInfo.getOrderInfo().isEmpty()) {
            	sellerName = ordersInfo.getOrderInfo().get(0).getSellerID();
            }
            
            ValidateInput input = new ValidateInput();
            input.setOrders(orders);
            input.setLabels(labels);
            input.setSellerName(sellerName);
            input.setSite(site);
            input.setPropFile(propFile);
            input.setOrdersInfo(ordersInfo);
            input.setErrorFlow(errFlow);
            input.setValidate(ValidateEnum.getEnum(validate));
           
            //ValidateInput
            validateInput(input);
            // Action processing starts here
            breezeReport.logWithColor("***** "+action.name()+" action Start *****", "blue");
            Console.log(action.name());
            //validate
            action.getValidator().validate(input);
            breezeReport.logWithColor("***** "+action.name()+" action End *****", "blue");
        }
	}
	
	private void validateInput(ValidateInput input) {
		//SellerName Validation
        if (input.getSellerName() == null) {
        	Reporter.log("Please provide seller name");
            Assert.fail();
        }
        
        //Site Validation
        if (input.getSite() == null) {
        	Reporter.log("Please provide site");
            Assert.fail();
        } 
	}
}
