package com.ebay.printorder.pojo.domain;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class SellerAddressDetail {
	  private String addressLine1;
	  private String addressLine2;
	  private String city;
	  private String stateOrProvince;
	  private String postalCode;
	  private String country;
}
