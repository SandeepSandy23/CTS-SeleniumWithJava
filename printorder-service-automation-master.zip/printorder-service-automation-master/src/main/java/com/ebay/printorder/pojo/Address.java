package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {
  private String fullName;
  private String addressLine1;
  private String city;
  private String stateOrProvince;
  private String postalCode;
  private String country;
}

