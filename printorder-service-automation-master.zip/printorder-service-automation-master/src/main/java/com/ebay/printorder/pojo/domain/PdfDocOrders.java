package com.ebay.printorder.pojo.domain;

import java.util.List;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;


@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PdfDocOrders {
	private String orderId;
	  private List<AddressDetail> shipToAddress;
	  private String scheduledShipDate;
	  private String shippingMethod;
	  private String orderDate;
	  private String buyerNotesToSeller;
	  private List<ItemInfo> items;
	  private String subTotal;
	  private String totalTax;
	  private String shippingAndHandlingCharges;
	  private String orderTotal;
	  private String paymentMethod;
	  private String paymentDate;
	  private String gspReferenceId;
	  private String shippedOnDate;
	  private String paymentState;
	  private List<Attribute> priceLines;
	  private Map<String,String> attributes;
	  private boolean pickListEligible;
	  private String invoiceNumber;
	  private String sellerVatId;
}
