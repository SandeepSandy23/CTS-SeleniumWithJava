package com.ebay.printorder.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentSelections {
	private boolean packingSlip;
	
	private boolean orderReceipt;
	
	private boolean pickList;

	private boolean coupon;
	
	private boolean addressLabel;

	private boolean genericCoupon;

	public boolean isPackingSlip() {
		return packingSlip;
	}

	public void setPackingSlip(boolean packingSlip) {
		this.packingSlip = packingSlip;
	}

	public boolean isOrderReceipt() {
		return orderReceipt;
	}

	public void setOrderReceipt(boolean orderReceipt) {
		this.orderReceipt = orderReceipt;
	}

	public boolean isPickList() {
		return pickList;
	}

	public void setPickList(boolean pickList) {
		this.pickList = pickList;
	}

	public boolean isCoupon() {
		return coupon;
	}

	public void setCoupon(boolean coupon) {
		this.coupon = coupon;
	}

	public boolean isAddressLabel() {
		return addressLabel;
	}

	public void setAddressLabel(boolean addressLabel) {
		this.addressLabel = addressLabel;
	}

	public boolean isGenericCoupon() {
		return genericCoupon;
	}

	public void setGenericCoupon(boolean genericCoupon) {
		this.genericCoupon = genericCoupon;
	}
}
