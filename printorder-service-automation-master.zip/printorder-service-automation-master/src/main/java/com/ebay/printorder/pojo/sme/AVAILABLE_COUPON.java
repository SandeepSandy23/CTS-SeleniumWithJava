package com.ebay.printorder.pojo.sme;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class AVAILABLE_COUPON {
	private String _type;
	private CouponPickerModel couponPickerModel;
}
