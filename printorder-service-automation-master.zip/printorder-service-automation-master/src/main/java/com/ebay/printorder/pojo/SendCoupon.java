package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)

public class SendCoupon {

	private String id;
	private String template;
	private String personalNote;
	private Integer countPerSheet;
}