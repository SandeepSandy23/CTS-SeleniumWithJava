package com.ebay.printorder.pojo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class SendSelectionData {
    private List<String> orderIds;
//  private SendPreferenceSelections sendPreferenceSelections;
    private String couponId;
    private String messageToBuyer;
    private List<String> buyerIds;
}