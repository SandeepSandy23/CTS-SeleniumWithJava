package com.ebay.printorder.pojo.domain;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ShipmentInfo {
    private String shipmentInstructions;
    private String shippingCarrier;
    private String trackingNum;
}
