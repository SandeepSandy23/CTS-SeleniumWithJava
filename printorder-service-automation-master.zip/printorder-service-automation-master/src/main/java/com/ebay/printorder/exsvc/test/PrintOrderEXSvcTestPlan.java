package com.ebay.printorder.exsvc.test;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.ITestContext;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.xml.XmlSuite;

import com.ebay.common.infra.executor.ActionsXMLRequests;
import com.ebay.common.util.TestFilterUtil;
import com.ebay.printorder.exsvc.flow.PrintOrderEXSvcFlow;
import com.ebay.quality.testdataautil.common.EasyFilter;
import com.ebay.quality.testdataautil.common.SpreadSheetUtil;
import com.ebay.quality.testdataautil.type.TestObject;
import com.ebay.testinfrastructure.serviceautil.testdriver.ServiceBaseTest;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public class PrintOrderEXSvcTestPlan extends ServiceBaseTest {
    private Map<String, String> allParameters;

    @BeforeSuite(groups = "PrintOrder_EX_svc")
    public void loadContext(ITestContext context) {
    	XmlSuite xmlSuite = context.getSuite().getXmlSuite();
    	allParameters = xmlSuite.getAllParameters();
	
		for (Map.Entry<String, String> e : allParameters.entrySet()) {
		    context.setAttribute(e.getKey(), e.getValue());
		}
    }
    
    @DataProvider(name = "PrintOrder_EX_Data_Provider", parallel = true)
    public static Iterator<Object[]> getData(Method m,
        ITestContext testContex) throws Exception {
	    EasyFilter filter = EasyFilter.equalsIgnoreCase(TestObject.TEST_METHOD, m.getName());
	    filter = TestFilterUtil.addFilter(filter, testContex);
	    LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
	    entityClazzMap.put("TestObject", TestObject.class);
	    entityClazzMap.put("ActionsXMLRequests", ActionsXMLRequests.class);
	    
	    return SpreadSheetUtil.getEntitiesFromSpreadsheet(PrintOrderEXSvcTestPlan.class, entityClazzMap,
	        "PrintOrderEXSvcData.xls","Test Data", -1, null, filter);
    }

	@Test(groups = "testPrintOrderEXSvc", dataProvider = "PrintOrder_EX_Data_Provider")
	public void runPrintOrderEXSvcTest(String testFilterType,
									   TestObject object, ActionsXMLRequests xmlrequests) throws Exception {
		runTest(testFilterType, object, xmlrequests);
	}
	
    private void runTest(String testFilterType, TestObject object,
	    ActionsXMLRequests xmlrequests) throws Exception {
    		PrintOrderEXSvcFlow flow = new PrintOrderEXSvcFlow();
    		flow.executeProcess(xmlrequests);
    }
}
