package com.ebay.printorder.util;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public enum RespCodeEnum {
  
  RESP_200(200),
  
  RESP_204(204),
  
  RESP_400(400),
  
  RESP_404(404),
  
  RESP_500(500);
  
  
  private int code=0;

  public int getCode() {
    return code;
  }

  public void setCode(int code) {
    this.code = code;
  }
  
  
  private RespCodeEnum(int code) {
    this.code = code;
  }
  
  
  public RespCodeEnum  getCode(int code) {
    RespCodeEnum resp = null;
    
    switch(code) {
    
    case 200:  resp = RESP_200;
           break;
    case 400:  resp = RESP_400;
       break;
    case 404:  resp = RESP_404;
       break;
    case 500:  resp = RESP_500;
       break;
    
    
    }
    
    return resp;
  }
}
