package com.ebay.printorder.exsvc.validators;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.globalenv.SiteEnum;
import com.ebay.orders.list.cosmos.pojo.*;
import com.ebay.printorder.pojo.Address;
import com.ebay.printorder.pojo.*;
import com.ebay.printorder.pojo.PreferenceInfo;
import com.ebay.printorder.pojo.Selections.Entries;
import com.ebay.printorder.pojo.SellerVatResponse.VatRecord;
import com.ebay.printorder.pojo.domain.ItemInfo;
import com.ebay.printorder.pojo.domain.*;
import com.ebay.printorder.pojo.sme.FormatResponse;
import com.ebay.printorder.pojo.sme.SMEResponse;
import com.ebay.printorder.util.*;
import com.ebay.sellerhub.orders.details.executors.CountryCodeEnum;
import com.ebay.testinfrastructure.dbautil.dbdriver.TokenMismatch;
import com.ebay.testinfrastructure.l10nautil.L10n;
import com.ebay.testinfrastructure.params.TestParams;
import com.mongodb.util.Hash;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.json.JSONObject;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.ebay.orders.details.xs.spdservice.pojo.SpdResponse;
import com.ebay.sellerhub.orders.details.executors.SPDSvcUtil;
import com.ebay.sellerhub.orders.common.CommonDataInfo;

import com.ebay.orders.details.deserializer.OrderDetailsDeserializer;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Collections;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;

public class ModuleProviderValidator extends BaseValidator {
    private static final String storeAddress = "STORE_ADDRESS";
    private static final String buyerShippingAddress = "BUYER_SHIPPING_ADDRESS";
    private static final String wareHouseAddress = "WAREHOUSE_ADDRESS";
    private static final String globalShippingCenter = "c/o GLOBAL SHIPPING CENTER";
    private static final String TRUE = "true";
    static String globalShippingProgram = "GLOBAL_SHIPPING_PROGRAM";
    static String refundedAmtForPackingSlip = "REFUNDED_AMT_FOR_PACKING_SLIP";
    static String refundedAmtForOrderReceipt = "REFUNDED_AMT_FOR_ORDER_RECEIPT";
    static String packingSlipShippingCost = "PACKING_SLIP_SHIPPING_COST";
    static String importCharges = "IMPORT_CHARGES";
    static String itemCost = "ITEM_COST";
    static String orderReceiptShippingCost = "ORDER_RECEIPT_SHIPPING_COST";
    static String packingSlipTotal = "PACKING_SLIP_TOTAL";
    static String orderReceiptTotal = "ORDER_RECEIPT_TOTAL";
    static String discount = "DISCOUNT";
    static String psa = "PSA";
    private SiteEnum siteEnum;
	private SPDSvcUtil spdSvcUtil = new SPDSvcUtil();
	OrderDetailsDeserializer orderDetailsDeserializer = new OrderDetailsDeserializer();
	private String expItemSubTotal = null; private String expShippingCost = null; private String expItemTax = null; 
	private String expShippingTax = null; private String expShippingDiscount = null; private String expImportCharges = null;
	private String actPackingSlip_ShipCost = null; private String actItemCost = null; private String actSalesTaxEbayCollected = null;
	private String actOrderReceipt_Shipcost = null; private String actPackingSlip_Total = null; private String actOrderReceipt_Total = null;
	private String actDiscount = null; private String actImportCharges = null; private String actSalesTax = null;
	private String actOrderReceipt_OrderCancelled = null; private String actPackingSlip_OrderCancelled = null;
	private String actOrderReceipt_RefundAmt = null; private String actPackingSlip_RefundAmt = null;
	private String expRefundAmt = "0.00"; private String expTotAfterRefundCancel = "0.00"; private String expSalesTax = "0.00";
	private String actVAT = null; private double expImportTax = 0.00; private double expShippingImportTax = 0.00;
	private String expVAT = "0.00"; private String expPromotion = null;
 	boolean isGSP = false, isPSA = false, isExports = false, isCancelRefund = false, isPartialRefund = false, isVat = false, hasPromotion = false, 
 			isAddressLabelOnPackingSlip = false, isSellerVatId = false, isOrderGreater90Days = false;
 	Set<String> sellerVatId = new HashSet<String>();
 		
    @Override
    public void validateFlow(ValidateInput input) throws Exception {
        softAssert = new SoftAssert();
        FormatResponse expectedPackingSlipSMEResp = null, expectedStandaloneCouponSMEResp = null, expectedCouponModuleSMEResp = null,
                expectedAvailableCouponModuleSMEResp = null;
        String sellerName = input.getSellerName();
        String site = input.getSite();
        String propFile = input.getPropFile();
//        int documentsNumber = input.getDocuments().split(",").length;
        ValidateEnum module = input.getValidate();
        SendCouponModuleValidator sendCouponModuleValidator = new SendCouponModuleValidator();
        String pageTitle = null;
        String deviceType = null;

        if (module.equals(ValidateEnum.ERROR_CASE)) {
            breezeReport.logWithColor("Module provider call for error case", "brown");
            ModuleProviderRequest request = buildRequest(input);
            printOrderUtil.getModuleProviderResponseForErrorCase(sellerName, CommonUtil.toJSON(request), site, input);
        } else {
            PrintDocumentsValidator printDocumentsValidator = new PrintDocumentsValidator();
            //To validate Message to buyer - ParamValue in SelectionGroup
            if (input.isValidateCoupon() && input.getDocuments().contains("coupon")) {
                if (!input.getCouponIds().isEmpty())
                    printDocumentsValidator.validateFlow(input);
            }
            //module provider call
            breezeReport.logWithColor("Module provider call", "brown");
            ModuleProviderRequest request = buildRequest(input);
            PrintOrderModule printOrderModule = new PrintOrderModule();
            CosmosResponse expectedCosmosResp = new CosmosResponse();
            PdfDocGenRawDataModule pdfDocGenRawDataModule = new PdfDocGenRawDataModule();
            GetAddressResponse expectedAddressBookResp = new GetAddressResponse();
            UserPuidInfo expectedPuIdResp = new UserPuidInfo();
            Store expectedStoreServiceResp = new Store();
            GetUserRequest userRequest = new GetUserRequest();
            GetUserResponse expectedUserReadSvcResp = new GetUserResponse();
            Modules sendCouponModules = new Modules();
            
            CommonDataInfo commonDataInfo = new CommonDataInfo();
            SpdResponse spdResponse = new SpdResponse();
            
            ModuleProviderResponse actualResponse = 
            			printOrderUtil.getModuleProviderResponse(sellerName, CommonUtil.toJSON(request), site, input);

            LabelServiceResponse expectedLabelServiceResp;
            //String sellerId = DBSelectQueryUtil.getOracleId(sellerName);

            if (module.equals(ValidateEnum.SEND_COUPON_MODULE)) {
                sendCouponModules = actualResponse.getModules();
                if (actualResponse.getMeta() != null) {
                    pageTitle = actualResponse.getMeta().getPageTitle();
                    Reporter.log("Page Title is: " + pageTitle);
                    softAssert.assertEquals(pageTitle, L10n.content(propFile, "Page_Title"), "Page Title is not correct");
                    breezeReport.logWithColor("Page Title validation complete", "blue");
                }

                deviceType = actualResponse.getMeta().getRequestParameters().getDeviceType();
                Reporter.log("Current deviceType is: " + deviceType);
                softAssert.assertEquals(deviceType, input.getDeviceType(), "device type is not correct");

                //label service call
                breezeReport.logWithColor("LabelService call", "brown");
                expectedLabelServiceResp = getLabelServiceResponse(input);

                //cosmos call
                breezeReport.logWithColor("Cosmos call", "brown");
                expectedCosmosResp = getCOSMOSResponse(input, expectedLabelServiceResp);

                MembersC cosmosOrder = expectedCosmosResp.getMembers().get(0);
                //user info call
                breezeReport.logWithColor("User info call", "brown");
                String buyerName = (cosmosOrder.getOrder() != null ? 
                		cosmosOrder.getOrder().getBuyer().getUserIdentifier().getUserName() :
                		cosmosOrder.getProformaOrder().getBuyer().getUserIdentifier().getUserName());
                String buyID = DBSelectQueryUtil.getOracleId(buyerName);
                userRequest = buildUserRequest(input, buyID, false);
                expectedUserReadSvcResp = getUserReadSvcResponse(input, buyerName, userRequest, false);
                
                //SPD Analytics - Repeat Buyer Indicator check
                breezeReport.logWithColor("SPD Analytics - Repeat Buyer Insights Call", "brown");
                commonDataInfo.setSellerOracleId(cosmosOrder.getOrder() != null ?
                		cosmosOrder.getOrder().getSeller().getUserIdentifier().getUserId() :
                		cosmosOrder.getProformaOrder().getSeller().getUserIdentifier().getUserId());
                
                commonDataInfo.setSellerName(cosmosOrder.getOrder() != null ?
                		cosmosOrder.getOrder().getSeller().getUserIdentifier().getUserName() :
                		cosmosOrder.getProformaOrder().getSeller().getUserIdentifier().getUserName());
                
                JSONObject spdResponseObject = spdSvcUtil.getSPDServiceResponse(expectedCosmosResp.getMembers().get(0), commonDataInfo);
			    spdResponse = orderDetailsDeserializer.deserializeSPDResponseResponse(spdResponseObject.toString());

            } else {
                printOrderModule = actualResponse.getModules().getPrintOrderModule();
                pdfDocGenRawDataModule = actualResponse.getModules().getPdfDocGenRawDataModule();

                deviceType = actualResponse.getMeta().getRequestParameters().getDeviceType();
                Reporter.log("Current deviceType is: " + deviceType);
                softAssert.assertEquals(deviceType, input.getDeviceType(), "device type is not correct");

                //label service call
                breezeReport.logWithColor("LabelService call", "brown");
                expectedLabelServiceResp = getLabelServiceResponse(input);

                //cosmos call
                breezeReport.logWithColor("Cosmos call", "brown");
                expectedCosmosResp = getCOSMOSResponse(input, expectedLabelServiceResp);

                //addressbook call
                breezeReport.logWithColor("Addressbook call", "brown");
                expectedAddressBookResp = getAddressBookSvcResponse(input);

                //store call
                breezeReport.logWithColor("Store call", "brown");
                expectedPuIdResp = getStorePuIdResponse(input);
                expectedStoreServiceResp = getStoreDetailsResponse(input, expectedPuIdResp);

                //user info call
                breezeReport.logWithColor("User info call", "brown");
                String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
                userRequest = buildUserRequest(input, sellerId, false);
                expectedUserReadSvcResp = getUserReadSvcResponse(input, input.getSellerName(), userRequest, false);
            }

            if (input.isValidateCoupon()
                    && !(input.getSellerType().equals("Non_Store_seller")
                    || input.getSellerType().equals("No_Coupon_seller"))) {
                //SME call for coupon
                String packingSlipCouponId = input.getCouponIds().get("packingSlipCouponId");
                String standaloneCouponId = input.getCouponIds().get("standaloneCouponId");
                String couponModuleCouponId = input.getCouponIds().get("couponModuleCouponId");
//	        String sendCouponModuleCouponId = input.getCouponIds().get("sendCouponModuleCouponId");

                if (module == ValidateEnum.PRINT_ORDER_MODULE) {
                    breezeReport.logWithColor("SME call for packing slip section", "brown");
                    expectedPackingSlipSMEResp = getSMEResponse(input, packingSlipCouponId);

                    breezeReport.logWithColor("SME call for standalone coupon section", "brown");
                    expectedStandaloneCouponSMEResp = getSMEResponse(input, standaloneCouponId);
                } else if (module == ValidateEnum.COUPON_MODULE) {
                    breezeReport.logWithColor("SME call for coupon module", "brown");
                    expectedCouponModuleSMEResp = getSMEResponse(input, couponModuleCouponId);
                } else if (module == ValidateEnum.SEND_COUPON_MODULE) {
                    breezeReport.logWithColor("SME call for Available Coupon Module", "blue");
                    String sendCouponModuleCouponId = null;
                    if (sendCouponModules != null && sendCouponModules.getSendCouponModule() != null
                            && sendCouponModules.getSendCouponModule().getSendSelectionData() != null
                            && sendCouponModules.getSendCouponModule().getSendSelectionData().getCouponId() != null) {
                        sendCouponModuleCouponId = sendCouponModules.getSendCouponModule().getSendSelectionData().getCouponId();
                        expectedAvailableCouponModuleSMEResp = getSMEResponse(input, sendCouponModuleCouponId);
                    }
                }
            }

        /*
      	Things to validate for DWeb/MWeb:
      	1. validateOrders
      	2. validate PrintSummaryTitle
      	3. validate selectionGroup
      	4. validate pdfInfo (Not for MWeb)
      	5. validate featureSurveyLink
      	6. validate printSelectionData
      	7. validate messageBundle (part of message for MWeb)
       */

            if (module.equals(ValidateEnum.SEND_COUPON_MODULE))
                sendCouponModuleValidator.validateSendCoupon(sendCouponModules, expectedCosmosResp, request, 
                		expectedAvailableCouponModuleSMEResp, propFile, input, expectedUserReadSvcResp, pageTitle, spdResponse);
            else if (module.equals(ValidateEnum.GENERIC_COUPON_MODULE)) {
                validateGenericCouponModule(actualResponse);
            } else if (module.equals(ValidateEnum.COMPLETE_DOCUMENT_MODULE)) {
                validateCompleteDocumentModule(actualResponse);
            } else {
            	if(printOrderModule.getOrders() != null)
                validateOrders(printOrderModule.getOrders(), request, propFile, sellerName, site, deviceType, expectedLabelServiceResp);
                if (module == ValidateEnum.PRINT_ORDER_MODULE)
                    validatePrintSummaryTitle(printOrderModule.getPrintSummaryTitle(), propFile, site);
                else if (module != ValidateEnum.COUPON_MODULE)
                    validateDescription(printOrderModule.getDescription(), module, propFile);

                if(input.getMode() == null)
                validateSelectionGroup(printOrderModule.getSelectionGroup(), module, input, propFile, expectedPackingSlipSMEResp,
                        expectedStandaloneCouponSMEResp, expectedCouponModuleSMEResp, request);

                if (deviceType.equals("DWEB")) {
                    validatePdfInfo(printOrderModule.getPdfInfo(), module, propFile, request, expectedLabelServiceResp, site);
                }
                
                if(printOrderModule.getFeatureSurveyLink() != null) {
                validateFeatureSurveyLink(printOrderModule.getFeatureSurveyLink(), propFile, site);
                }
                validatePrintAction(printOrderModule.getPrintAction(), propFile, site);
                validateCancelAction(printOrderModule.getCancelAction(), propFile);
                validatePrintSelectionData(printOrderModule.getPrintSelectionData(), request, propFile, input);
                validateMessageBundle(printOrderModule.getMessageBundle(), propFile, input.getSite(), input.getMode());

                if (null != pdfDocGenRawDataModule) {
                    validatePdfDocGenRawDataModule(pdfDocGenRawDataModule.getRequest(), request, expectedAddressBookResp,
                            expectedCosmosResp, expectedStoreServiceResp, expectedUserReadSvcResp, sellerName, site, input, expectedPackingSlipSMEResp,
                            expectedStandaloneCouponSMEResp, expectedCouponModuleSMEResp, propFile, expectedLabelServiceResp);
                }
            }
            softAssert.assertAll();
        }
    }

    private LabelServiceResponse getLabelServiceResponse(ValidateInput input) {
        if (CollectionUtils.isEmpty(input.getLabels())) {
            return null;
        }
        try {
            return new LabelServiceUtil().getDataFromLabelService(input.getLabels(), input.getSellerName());
        } catch (Exception e) {
            softAssert.assertAll();
            return null;
        }
    }

    private FormatResponse getSMEResponse(ValidateInput input, String packingSlipCouponId) {
        FormatResponse fresp = null;
        try {
            SMEUtil smeUtil = new SMEUtil();
            SMEResponse resp = smeUtil.getSmeResponse(input.getSellerName(), input.getSite(), packingSlipCouponId);
            fresp = smeUtil.reformatValidDate(resp);
        } catch (Exception e) {
            breezeReport.logWithColor("Exception while making SME call" + e, "brown");
        }
        return fresp;
    }

    private CosmosResponse getCOSMOSResponse(ValidateInput input, LabelServiceResponse dataFromLabelService) {
        CosmosResponse resp = null;
        try {
            CosmosUtil cosmosUtil = new CosmosUtil();
            List<String> allOrderIds = allOrders(dataFromLabelService, input.getOrders());
            resp = cosmosUtil.getCosmosResponse(allOrderIds, input.getSellerName(), input.getSite());
        } catch (Exception e) {
            softAssert.assertAll();
        }
        return resp;
    }

    private List<String> allOrders(LabelServiceResponse dataFromLabelService, List<String> orders) {
        return Stream.of(getOrderIdsFromLabelService(dataFromLabelService), orders)
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .distinct()
                .collect(toList());
    }

    private GetAddressResponse getAddressBookSvcResponse(ValidateInput input) {
        GetAddressResponse response = null;
        try {
            AddressBookSvcUtil addressBookSvcUtil = new AddressBookSvcUtil();
            response = addressBookSvcUtil.getAddressBookSvcResponse(input.getSellerName(), input.getSite());
        } catch (Exception e) {
            softAssert.assertAll();
        }
        return response;
    }

    private UserPuidInfo getStorePuIdResponse(ValidateInput input) {
        UserPuidInfo puidResponse = null;
        try {
            StoreServiceUtil storeSvcUtil = new StoreServiceUtil();
            puidResponse = storeSvcUtil.getStorePuIdResponse(input.getSellerName(), input.getSite());
        } catch (Exception e) {
            softAssert.assertAll();
        }
        return puidResponse;
    }

    private Store getStoreDetailsResponse(ValidateInput input, UserPuidInfo expectedPuIdResp) {
        Store storeSvcresponse = null;
        Store storeSvcresponse1 = new Store();
        storeSvcresponse1.setDescription("Exception");
      
        try {
            StoreServiceUtil storeSvcUtil = new StoreServiceUtil();
            storeSvcresponse = storeSvcUtil.getStoreDetailsResponse(input.getSellerName(), input.getSite(), expectedPuIdResp.getPublic_user_id());
        } catch (Exception e) {
        	return storeSvcresponse1;
        }
        return storeSvcresponse;
    }

    private GetUserResponse getUserReadSvcResponse(ValidateInput input, String sellerName, GetUserRequest userRequest, boolean taxIdentity) {
        GetUserResponse userSvcresponse = null;
        try {
            UserReadSvcUtil userReadSvcUtil = new UserReadSvcUtil();
            if(!taxIdentity)
            	userSvcresponse = userReadSvcUtil.getUserReadSvcResponse(sellerName, input.getSite(), userRequest.getQuery(), taxIdentity);
            else
            	userSvcresponse = userReadSvcUtil.getUserReadSvcResponse(sellerName, input.getSite(), userRequest.getTaxQuery(), taxIdentity);
        } catch (Exception e) {
            softAssert.assertAll();
        }
        return userSvcresponse;
    }

    public GetUserRequest buildUserRequest(ValidateInput input, String sellerId, boolean taxIdentity) throws TokenMismatch {
        GetUserRequest userRequest = new GetUserRequest();
        String getUserRequest = null;
        //String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
        if(!taxIdentity) {
            getUserRequest = String.format(userRequest.getQuery(), sellerId);
            userRequest.setQuery(getUserRequest);
        } else {
            getUserRequest = String.format(userRequest.getTaxQuery(), sellerId);
            userRequest.setTaxQuery(getUserRequest);
        }
        return userRequest;
    }

    /*
     *  Validating orders
     */
    private void validateOrders(Orders orders, ModuleProviderRequest request, String propFile, String sellerName, String site, String deviceType, LabelServiceResponse dataFromLabelService) throws Exception {
        breezeReport.logWithColor("Validating Orders", "blue");

        validateOrderInfo(orders, request, propFile, dataFromLabelService, site);

        validateViewOrdersAction(orders, request, propFile, dataFromLabelService, site);

        validateOrdersSummary(orders, request, propFile, sellerName, site, deviceType, dataFromLabelService);

        breezeReport.logWithColor("----- ValidateOrders Done -----", "green");
    }

    private void validateOrderInfo(Orders orders, ModuleProviderRequest request, String propFile, LabelServiceResponse dataFromLabelService, String site) {
        breezeReport.logWithColor("Validating OrderInfo", "blue");
        String orderText;
        List<String> allOrders = allOrders(dataFromLabelService, request.getOrderIds());

        if (allOrders.size() > 1) {
            orderText = L10n.content(propFile, "Order_Info_Text");
        } else {
        	 if (!site.equalsIgnoreCase("DE"))
        		 orderText = L10n.content(propFile, "Order_Info_Text_Single");
        	 else
                orderText = L10n.content(propFile, "Order_Info_Text_Single_DE");
        }

        String actualOrderInfoText = orders.getOrderInfo().getTextSpans().get(0).getText();
        String expectedOrderInfoText = allOrders.size() + " " + orderText;

        breezeReport.logStep("Actual order info text: " + actualOrderInfoText);
        breezeReport.logStep("Expected order info text: " + expectedOrderInfoText);
        softAssert.assertEquals(actualOrderInfoText, expectedOrderInfoText, "Order info text is not correct");
    }

    private List<String> getOrderIdsFromLabelService(LabelServiceResponse dataFromLabelService) {
        if (dataFromLabelService == null) {
            return Collections.emptyList();
        }
        return dataFromLabelService.getDetails()
                .stream()
                .map(LabelServiceDetails::getOrderIds)
                .flatMap(Collection::stream)
                .collect(toList());
    }

    private void validateViewOrdersAction(Orders orders, ModuleProviderRequest request, String propFile, LabelServiceResponse dataFromLabelService, String site) {
        breezeReport.logWithColor("Validating viewOrdersAction", "blue");

        String viewOrderText;
        List<String> allOrders = allOrders(dataFromLabelService, request.getOrderIds());
        if (allOrders.size() > 1) {
            viewOrderText = L10n.content(propFile, "View_Order_Text");
        } else {
        	 if (!site.equalsIgnoreCase("DE"))
        		 viewOrderText = L10n.content(propFile, "View_Order_Single") + " " + allOrders.get(0);
        	 else
        		 viewOrderText = L10n.content(propFile, "View_Order_Single_DE") + " " + allOrders.get(0);
        }

        String actualViewOrderText = orders.getViewOrdersAction().getTextSpans().get(0).getText();
        String expectedViewOrderText = viewOrderText;

        breezeReport.logStep("Actual order info text: " + actualViewOrderText);
        breezeReport.logStep("Expected order info text: " + expectedViewOrderText);

        softAssert.assertEquals(actualViewOrderText, expectedViewOrderText, "ViewOrderAction text is not correct");
        softAssert.assertEquals(orders.getViewOrdersAction().getAction().getType().toString(), "OPERATION", "ViewOrderAction action type is not correct");
    }

    private void validateOrdersSummary(Orders orders, ModuleProviderRequest request, String propFile, String sellerName, String site, String deviceType, LabelServiceResponse dataFromLabelService) throws Exception {
        breezeReport.logWithColor("Validating OrderSummary", "blue");

        if (deviceType.equals("DWEB")) {
            String summaryTitle = orders.getOrdersSummary().getSummaryTitle().getTextSpans().get(0).getText();
            if (!site.equalsIgnoreCase("DE"))
            	softAssert.assertEquals(summaryTitle, L10n.content(propFile, "Orders"), "OrderSummaryTitle text is not correct");
            else
            	softAssert.assertEquals(summaryTitle, L10n.content(propFile, "Orders_DE"), "OrderSummaryTitle text is not correct");
        }

        List<String> allOrders = allOrders(dataFromLabelService, request.getOrderIds());

        if (deviceType.equals("MWEB")) {
            String selectOrderText;
            String orderInfoText;
            if (allOrders.size() > 1) {
                orderInfoText = L10n.content(propFile, "Order_Info_Text");
            } else {
                orderInfoText = L10n.content(propFile, "Order_Info_Text_Single");
            }
            selectOrderText = allOrders.size() + " " + orderInfoText;
            String summaryTitle = orders.getOrdersSummary().getSummaryTitle().getTextSpans().get(0).getText();
            softAssert.assertEquals(summaryTitle, selectOrderText, "OrderSummaryTitle text is not correct");
        }


        String doneActionText = orders.getOrdersSummary().getDoneAction().getTextSpans().get(0).getText();
        if (!site.equalsIgnoreCase("DE"))
        	softAssert.assertEquals(doneActionText, L10n.content(propFile, "Done"), "OrderSummaryDoneAction text is not correct");
        else
        	softAssert.assertEquals(doneActionText, L10n.content(propFile, "Done_DE"), "OrderSummaryDoneAction text is not correct");

        softAssert.assertEquals(orders.getOrdersSummary().getDoneAction().getAction().getType().toString(), "OPERATION", "doneAction action type is not correct");

        softAssert.assertEquals(orders.getOrdersSummary().getMembers().size(), allOrders.size(), "Number of orders in orderSummary is not correct");

        /*
        1. for single item order: we will show the item name
        2. for multi-item order: we will show order id as name
         */
        CosmosUtil cosmosUtil = new CosmosUtil();
        for (int i = 0; i < orders.getOrdersSummary().getMembers().size(); i++) {
            Member order = orders.getOrdersSummary().getMembers().get(i);
            String orderId = allOrders.get(i);
            if (StringUtils.countMatches(orderId, '-') == 1) {
                break;
            }
            if (cosmosUtil.isMultiItemOrder(orderId, sellerName, site)) {
                String orderIdText = order.getOrderTitle().getTextSpans().get(0).getText();
                String expectedOrderIdText = null;
                if (!site.equalsIgnoreCase("DE"))
                	expectedOrderIdText = L10n.content(propFile, "Order_ID") + " " + orderId;
                else
                	expectedOrderIdText = L10n.content(propFile, "Order_ID_DE") + " " + orderId;
                breezeReport.logStep("Actual order Id text: " + orderIdText);
                breezeReport.logStep("Expected order Id text: " + expectedOrderIdText);
                softAssert.assertEquals(orderIdText, expectedOrderIdText, "orderInfo in OrdersSummary is not correct");
            } else {
                String orderIdText = order.getOrderSubTitle().getTextSpans().get(0).getText();
                String expectedOrderIdText = L10n.content(propFile, "Order_ID") + " " + orderId;
                breezeReport.logStep("Actual order Id text: " + orderIdText);
                breezeReport.logStep("Expected order Id text: " + expectedOrderIdText);
                softAssert.assertEquals(orderIdText, expectedOrderIdText, "orderInfo in OrdersSummary is not correct");
            }
        }
    }

    private void validatePrintSummaryTitle(TextualDisplay printSummaryTitle, String propFile, String site) {
        breezeReport.logWithColor("Validating PrintSummaryTitle", "blue");
        String summaryTitle = printSummaryTitle.getTextSpans().get(0).getText();
        if (!site.equalsIgnoreCase("DE"))
        	softAssert.assertEquals(summaryTitle, L10n.content(propFile, "Select_Documents_To_Print"), "printSummaryTitle text is not correct");
        else
        	softAssert.assertEquals(summaryTitle, L10n.content(propFile, "Select_Documents_To_Print_DE"), "printSummaryTitle text is not correct");
        breezeReport.logWithColor("----- validatePrintSummaryTitle Done -----", "green");
    }

    private void validateCouponSetting(Selections selections, String propFile, FormatResponse expectedCouponModuleSMEResp) {
        String actualCouponModuleTitle = selections.getTitle().getTextSpans().get(0).getText();
        softAssert.assertEquals(actualCouponModuleTitle, L10n.content(propFile, "Coupon_Module_Title"), "coupon module titles do not match");

        Subsection couponModuleSubsection = selections.getSubSection().get(0);
        String actualCouponModuleFieldId = couponModuleSubsection.getFieldId();
        softAssert.assertEquals(actualCouponModuleFieldId, "documentSelections.standaloneCoupon", "coupon module fieldids do not match");

        Subsection.Synopsis couponModuleSynopsis = couponModuleSubsection.getSynopsis();
        String actualCouponModuleSubtitle = couponModuleSynopsis.getTitle().getTextSpans().get(0).getText();
        softAssert.assertEquals(actualCouponModuleSubtitle, L10n.content(propFile, "Coupon_Module_Subtitle"), "coupon module subtitles do not match");

        String actualCouponModuleMessage = couponModuleSynopsis.getEditAction().getTextSpans().get(0).getText();
        String couponId = expectedCouponModuleSMEResp.getSmeResponse().getPromotionId();

        if (couponId == null || couponId == "") {
            softAssert.assertEquals(actualCouponModuleMessage, L10n.content(propFile, "Coupon_unselected_default_message"), "coupon module (unselected) messages do not match");
        } else if (couponModuleSynopsis != null && couponModuleSynopsis.getSynopsis() != null && couponModuleSynopsis.getSelectionSummary() != null) {
            softAssert.assertEquals(actualCouponModuleMessage, expectedCouponModuleSMEResp.getSmeResponse().getMessage(), "coupon module message does not match");

            String actualCouponModuleCouponCode = couponModuleSynopsis.getSynopsis().getTextSpans().get(0).getText();
            String expectedCouponModuleCouponCode = expectedCouponModuleSMEResp.getSmeResponse().getCouponCode();
            softAssert.assertEquals(actualCouponModuleCouponCode, expectedCouponModuleCouponCode, "Coupon module coupon code does not match");

            String actualCouponModuleValidDate = couponModuleSynopsis.getSelectionSummary().get(0).getTextSpans().get(0).getText();
            String expectedCouponModuleValidDate = expectedCouponModuleSMEResp.getFormatValidDate();
            softAssert.assertEquals(actualCouponModuleValidDate, expectedCouponModuleValidDate, "coupon module valid date does not match");

            String actualCouponModuleCouponSubType = couponModuleSynopsis.getSelectionSummary().get(1).getTextSpans().get(0).getText();
            String expectedCouponModuleCouponSubType = expectedCouponModuleSMEResp.getSmeResponse().getSubType().equals("PUBLIC_SINGLE_SELLER_COUPON") ?
                    "Public coupon" : "Private coupon";
            softAssert.assertEquals(actualCouponModuleCouponSubType, expectedCouponModuleCouponSubType, "coupon module coupon subtype does not match");

            String actualCouponModuleMaxSaving = couponModuleSynopsis.getSelectionSummary().get(2).getTextSpans().get(0).getText();
            DecimalFormat decimalFormat = new DecimalFormat("#.00");
            decimalFormat.setMinimumFractionDigits(2);
            String expectedCouponModuleMaxSaving = decimalFormat.format(expectedCouponModuleSMEResp.getSmeResponse().getMaxCouponDiscountAmount().getValue());
            String expectedCouponModuleMaxSavingStr = "Maximum savings of $" + expectedCouponModuleMaxSaving + " per coupon";
            softAssert.assertEquals(actualCouponModuleMaxSaving, expectedCouponModuleMaxSavingStr, "coupon module max saving does not match");

            String actualCouponModuleMaxCouponUsed = couponModuleSynopsis.getSelectionSummary().get(3).getTextSpans().get(0).getText();
            int expectedCouponModuleMaxCouponRedemptionPerUser = expectedCouponModuleSMEResp.getSmeResponse().getMaxCouponRedemptionPerUser();
            String expectedCouponModuleMaxCouponUsed = null;
            if (expectedCouponModuleMaxCouponRedemptionPerUser == 100000)
                expectedCouponModuleMaxCouponUsed = L10n.content(propFile, "Coupon_Module_Max_Coupon_Used");
            else
                expectedCouponModuleMaxCouponUsed = "Limited to " + expectedCouponModuleMaxCouponRedemptionPerUser + " uses per coupon per buyer";
            softAssert.assertEquals(actualCouponModuleMaxCouponUsed, expectedCouponModuleMaxCouponUsed, "coupon module max coupon redemption per user does not match");
        }

        Subsection secondCouponModuleSubsection = selections.getSubSection().get(1);
        softAssert.assertEquals(secondCouponModuleSubsection.getFieldId(), "documentSelections.standaloneCouponPrintSetting", "coupon module fieldId does not match");
        Subsection.Synopsis secondCouponModuleSynopsis = secondCouponModuleSubsection.getSynopsis();
        softAssert.assertEquals(secondCouponModuleSynopsis.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_Template_Title"), "coupon module template title does not match");
        softAssert.assertEquals(secondCouponModuleSynopsis.getEditAction().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_Template_Subtitle"), "coupon module template subtitle does not match");
        softAssert.assertEquals(secondCouponModuleSynopsis.getSynopsis().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_Num_Per_Sheet"), "coupon module num per sheet does not match");

        Subsection.SelectionDetails secondCouponModuleSelectionDetails = secondCouponModuleSubsection.getSelectionDetails();
        softAssert.assertEquals(secondCouponModuleSelectionDetails.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_Selection_Detail_Title"), "coupon module selection detail title does not match");

        Selections firstCouponModuleSelectionDetailsSelectionGroup = secondCouponModuleSelectionDetails.getSelectionGroup().get(0);
        softAssert.assertEquals(firstCouponModuleSelectionDetailsSelectionGroup.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_First_Selection_Detail_Subtitle"), "coupon module selection detail first subtitle does not match");
        softAssert.assertEquals(firstCouponModuleSelectionDetailsSelectionGroup.getSelection().get(0).getFieldId(),
                "preferenceSelections.standaloneCoupon.template", "coupon module selection detail first fieldId does not match");

        Selections secondCouponModuleSelectionDetailsSelectionGroup = secondCouponModuleSelectionDetails.getSelectionGroup().get(1);
        softAssert.assertEquals(secondCouponModuleSelectionDetailsSelectionGroup.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_Second_Selection_Detail_Subtitle"), "coupon module selection detail second subtitle does not match");
        softAssert.assertEquals(secondCouponModuleSelectionDetailsSelectionGroup.getSelection().get(0).getFieldId(),
                "preferenceSelections.standaloneCoupon.personalNote", "coupon module selection detail second fieldId does not match");

        List<Entries> selectionEntries = secondCouponModuleSelectionDetailsSelectionGroup.getSelection().get(0).getEntries();
        if (selectionEntries.get(0).getParamValue() != null) {
            breezeReport.logWithColor("Message to Buyer - paramValue Validatoin ", "blue");
            if (selectionEntries.get(0).get_type().equals(L10n.content(propFile, "SelectionEntries_ParamValue_Type"))) {
                String actualParamValue = selectionEntries.get(0).getParamValue().toString();
                String expectedParamValue = L10n.content(propFile, "SelectionEntries_Msg_ToBuyer");
                breezeReport.logStep("Actual Selection Entries Standalone Coupon paramValue : " + actualParamValue);
                breezeReport.logStep("Expected Selection Entries Standalone Coupon paramValue " + expectedParamValue);
                softAssert.assertEquals(actualParamValue, expectedParamValue, "Selection Entries Standalone Coupon paramValue is not correct");
            }
        } else
            breezeReport.logStep("No text entered for - Message to Buyer ");
    }

    private void validateCouponSettingWithNonStoreSeller(Selections selections, String propFile) {
        softAssert.assertEquals(selections.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_Non_Store_Seller_Title"), "coupon module non store seller title does not match");
        softAssert.assertEquals(selections.getDescription().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_Non_Store_Seller_Description"), "coupon module non store seller description does not match");
        softAssert.assertEquals(selections.getNavAction().getText(),
                L10n.content(propFile, "Coupon_Module_Non_Store_Seller_Nav_Action"), "coupon module non store seller nav action text does not match");
        softAssert.assertEquals(selections.getNavAction().getAction().getURL(),
                "https://www.qa.ebay.com/help/selling/ebay-stores/opening-ebay-store?id=4092", "coupon module non store seller nav action url does not match");
    }

    private void validateCouponSettingWithNoCouponSeller(Selections selections, String propFile) {
        softAssert.assertEquals(selections.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_No_Coupon_Title"), "coupon module with no coupon title does not match");
        softAssert.assertEquals(selections.getDescription().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Coupon_Module_No_Coupon_Description"), "coupon module with no coupon description does not match");
        softAssert.assertEquals(selections.getNavAction().getText(),
                L10n.content(propFile, "Coupon_Module_No_Coupon_Nav_Action"), "coupon module with no coupon nav action text does not match");
        softAssert.assertEquals(selections.getNavAction().getAction().getURL(),
                L10n.content(propFile, "Coded_Coupon_Url"), "coupon module with no coupon nav action url does not match");
    }

    private void validateDescription(TextualDisplay description, ValidateEnum module, String propFile) {
        String text = description.getTextSpans().get(0).getText();

        switch (module) {
            case PACKING_SLIP_MODULE:
                softAssert.assertEquals(text, L10n.content(propFile, "Packing_Slip_Description"), "packing slip module description text is not correct.");
                break;
            case ORDER_RECEIPT_MODULE:
                softAssert.assertEquals(text, L10n.content(propFile, "Order_Receipt_Description"), "order receipt module description text is not correct.");
                break;
        }
    }

    private void validateSelectionGroup(List<Selections> selectionsGroup,
                                        ValidateEnum module,
                                        ValidateInput input,
                                        String propFile,
                                        FormatResponse expectedPackingSlipSMEResp,
                                        FormatResponse expectedStandaloneCouponSMEResp,
                                        FormatResponse expectedCouponModuleSMEResp,
                                        ModuleProviderRequest request) throws Exception {
        breezeReport.logWithColor("Validating SelectionGroup", "blue");

        //the document order should be fixed: packingSlip, orderReceipt, packList, and coupon
        // verify first selection group - all docs
        if (module == ValidateEnum.PRINT_ORDER_MODULE) {
            for (int i = 0; i < selectionsGroup.size(); i++) {
                String SelectionLabelText = selectionsGroup.get(i).getSelection().get(0).getLabel().getTextSpans().get(0).getText();
                if (SelectionLabelText.equals("Packing slip")  || SelectionLabelText.equals("Invoice/Packing slip"))
                    validatePackingSlipSelectionGroup(selectionsGroup.get(i), input, expectedPackingSlipSMEResp, propFile, request);
                else if (SelectionLabelText.equals("Order receipt"))
                    validateOrderReceiptSelectionGroup(selectionsGroup.get(i), propFile, request);
                else if (SelectionLabelText.equals("Address label"))
                    validateAddressLabelSelectionGroup(selectionsGroup.get(i), propFile, request);
                else if (SelectionLabelText.equals("Pick list"))
                    validatePickListSelectionGroup(selectionsGroup.get(i), input.isPicklistEligible(), propFile, request);
                else if (SelectionLabelText.equals("Coupon")) {
                    if (input.isValidateCoupon()) { // not required if pref call works
                        if (!(input.getSellerType().equals("Non_Store_seller")
                                || input.getSellerType().equals("No_Coupon_seller"))) {
                            validateStandaloneCouponSelectionGroup(selectionsGroup.get(i), propFile, expectedStandaloneCouponSMEResp, request);
                        }
                    }
                }
         /* validatePackingSlipSelectionGroup(selectionsGroup.get(0), input, expectedPackingSlipSMEResp, propFile, request);
            validateOrderReceiptSelectionGroup(selectionsGroup.get(1), propFile, request);
            validatePickListSelectionGroup(selectionsGroup.get(3), input.isPicklistEligible(), propFile, request);
            validateAddressLabelSelectionGroup(selectionsGroup.get(2), propFile, request);

            if(input.isValidateCoupon()) { // not required if pref call works
            	if (!(input.getSellerType().equals("Non_Store_seller")
                		|| input.getSellerType().equals("No_Coupon_seller"))) {

            		validateStandaloneCouponSelectionGroup(selectionsGroup.get(3), propFile, expectedStandaloneCouponSMEResp, request);
            	} else {
                    softAssert.assertEquals(selectionsGroup.size(), 3, "selection group size does not match");
                }*/
            }
        }

        //verify second selection group - only packing slip
        if (module == ValidateEnum.PACKING_SLIP_MODULE) {
            validatePackingSlipSelectionDetails(selectionsGroup, propFile, input);
        }

        //verify second selection group - only order receipt
        if (module == ValidateEnum.ORDER_RECEIPT_MODULE) {
            String title = selectionsGroup.get(0).getTitle().getTextSpans().get(0).getText();
            softAssert.assertEquals(title, L10n.content(propFile, "Order_Receipt"),
                    "order receipt selectionDetails order info title is not correct");
            validateOrderReceiptSelectionDetails(selectionsGroup.get(0).getSelection(), propFile);
        }

        //verify second selection group - only coupon
        if (module == ValidateEnum.COUPON_MODULE) {
            if (!(input.getSellerType().equals("Non_Store_seller")
                    || input.getSellerType().equals("No_Coupon_seller"))) {
                validateCouponSetting(selectionsGroup.get(0), propFile, expectedCouponModuleSMEResp);
            } else {
                if (input.getSellerType().equals("Non_Store_seller")) {
                    validateCouponSettingWithNonStoreSeller(selectionsGroup.get(0), propFile);
                } else if (input.getSellerType().equals("No_Coupon_seller")) {
                    validateCouponSettingWithNoCouponSeller(selectionsGroup.get(0), propFile);
                }
            }
        }

        breezeReport.logWithColor("----- validateSelectionGroup Done -----", "green");
    }

    private void validateAddressLabelSelectionGroup(Selections selections, String propFile, ModuleProviderRequest request) {
        Selections.SingleSelection secondSelectionGroup = selections.getSelection().get(0);
        if (secondSelectionGroup.isSelected()) {
            softAssert.assertEquals(request.getDocumentSelections().isAddressLabel(), secondSelectionGroup.isSelected(), "Address Label checkbox flags do not match");
            breezeReport.logWithColor("Address Label Checkbox Selected", "blue");
        } else
            breezeReport.logWithColor("Address Label Checkbox Not Selected", "blue");
        softAssert.assertEquals(secondSelectionGroup.getFieldId(), "documentSelections.addressLabel", "selection type is not correct");
        softAssert.assertEquals(secondSelectionGroup.getLabel().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Address_Label"), "Selection group label is not correct");
        breezeReport.logWithColor("Address Label Validation Complete", "blue");
    }

    private void validateStandaloneCouponSelectionGroup(Selections selections, String propFile, FormatResponse expectedStandaloneCouponSMEResp, ModuleProviderRequest request) {
        Selections.SingleSelection fourthSelectionGroup = selections.getSelection().get(0);
        softAssert.assertEquals(fourthSelectionGroup.isSelected(),request.getDocumentSelections().isCoupon(), "standalone coupon checkbox flags do not match");
        softAssert.assertEquals(fourthSelectionGroup.getFieldId(), "documentSelections.coupon", "document selection coupon type is not correct");
        softAssert.assertEquals(fourthSelectionGroup.getLabel().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon"), "standalone coupon label is not correct");

        //verify help
        Selections.Help helpBubble = selections.getHelp();
        softAssert.assertEquals(helpBubble.getMessageText().get(0).getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon_Bubble_Text"), "standalone coupon bubble text is not correct");

        //verify the first subsection
        Subsection firstSubsection = selections.getSubSection().get(0);
        softAssert.assertEquals(firstSubsection.getFieldId(), "documentSelections.standaloneCoupon", "standalone coupon fieldId is not correct");
        Subsection.Synopsis firstSubsectionSynopsis = firstSubsection.getSynopsis();
        softAssert.assertEquals(firstSubsectionSynopsis.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon"));

        String actualStandaloneCouponMessage = firstSubsectionSynopsis.getEditAction().getTextSpans().get(0).getText();
        String expectedStandaloneCouponMessage = null;

        if (firstSubsectionSynopsis.getSynopsis() != null && expectedStandaloneCouponSMEResp != null) {
            breezeReport.logRedStep("expectedStandaloneCouponSMEResp " + expectedStandaloneCouponSMEResp);
            breezeReport.logRedStep("expectedStandaloneCouponSMEResp.getSmeResponse() " + expectedStandaloneCouponSMEResp.getSmeResponse());
            expectedStandaloneCouponMessage = expectedStandaloneCouponSMEResp.getSmeResponse().getMessage();
            softAssert.assertEquals(actualStandaloneCouponMessage, expectedStandaloneCouponMessage, "standalone coupon messages do not match");

            String actualStandaloneCouponCode = firstSubsectionSynopsis.getSynopsis().getTextSpans().get(0).getText();
            String expectedStandaloneCouponCode = expectedStandaloneCouponSMEResp.getSmeResponse().getCouponCode();
            softAssert.assertEquals(actualStandaloneCouponCode, expectedStandaloneCouponCode, "standalone coupon code do not match");

            String actualStandaloneValidDate = firstSubsectionSynopsis.getSelectionSummary().get(0).getTextSpans().get(0).getText();
            String expectedStandaloneValidDate = expectedStandaloneCouponSMEResp.getFormatValidDate();
            softAssert.assertEquals(actualStandaloneValidDate, expectedStandaloneValidDate, "standalone coupon valid dates do not match");

            String actualStandaloneSubType = firstSubsectionSynopsis.getSelectionSummary().get(1).getTextSpans().get(0).getText();
            String expectedStandaloneSubType = expectedStandaloneCouponSMEResp.getSmeResponse().getSubType().equals("PUBLIC_SINGLE_SELLER_COUPON") ?
                    "Public coupon" : "Private coupon";
            softAssert.assertEquals(actualStandaloneSubType, expectedStandaloneSubType, "standalone coupon subtypes do not match");

            String actualCouponModuleMaxSaving = firstSubsectionSynopsis.getSelectionSummary().get(2).getTextSpans().get(0).getText();
            DecimalFormat decimalFormat = new DecimalFormat("#.00");
            decimalFormat.setMinimumFractionDigits(2);
            String expectedCouponModuleMaxSaving = decimalFormat.format(expectedStandaloneCouponSMEResp.getSmeResponse().getMaxCouponDiscountAmount().getValue());
            String expectedCouponModuleMaxSavingStr = "Maximum savings of $" + expectedCouponModuleMaxSaving + " per coupon";
            softAssert.assertEquals(actualCouponModuleMaxSaving, expectedCouponModuleMaxSavingStr, "standalone max saving does not match");

            String actualStandaloneMaxCouponUsed = firstSubsectionSynopsis.getSelectionSummary().get(3).getTextSpans().get(0).getText();
            int expectedStandaloneMaxCouponRedemptionPerUser = expectedStandaloneCouponSMEResp.getSmeResponse().getMaxCouponRedemptionPerUser();
            String expectedStandaloneMaxCouponUsed = null;
            if (expectedStandaloneMaxCouponRedemptionPerUser == 100000)
                expectedStandaloneMaxCouponUsed = L10n.content(propFile, "Coupon_Module_Max_Coupon_Used");
            else
                expectedStandaloneMaxCouponUsed = "Limited to " + expectedStandaloneMaxCouponRedemptionPerUser + " uses per coupon per buyer";
            softAssert.assertEquals(actualStandaloneMaxCouponUsed, expectedStandaloneMaxCouponUsed, "standalone max coupon redemptions per user do not match");
        }

        //verify the second subsection
        Subsection secondSubsection = selections.getSubSection().get(1);
        softAssert.assertEquals(secondSubsection.getFieldId(), "documentSelections.standaloneCouponPrintSetting", "standalone coupon print setting fieldId is not correct");

        Subsection.Synopsis secondSubsectionSynopsis = secondSubsection.getSynopsis();
        softAssert.assertEquals(secondSubsectionSynopsis.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon_Template_Title"), "standalone coupon template title does not match");
        softAssert.assertEquals(secondSubsectionSynopsis.getEditAction().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon_Template_Subtitle"), "standalone coupon template subtitle does not match");
        softAssert.assertEquals(secondSubsectionSynopsis.getSynopsis().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon_Num_Per_Sheet"), "standalone coupon num per sheet does not match");

        Subsection.SelectionDetails secondSubsectionSelectionDetail = secondSubsection.getSelectionDetails();
        softAssert.assertEquals(secondSubsectionSelectionDetail.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon_Selection_Detail_Title"), "standalone coupon selection detail title does not match");

        Selections firstSelectionGroup = secondSubsectionSelectionDetail.getSelectionGroup().get(0);
        softAssert.assertEquals(firstSelectionGroup.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon_First_Selection_Detail_Subtitle"), "standalone coupon first selection detail subtitle does not match");
        softAssert.assertEquals(firstSelectionGroup.getSelection().get(0).getFieldId(),
                "preferenceSelections.standaloneCoupon.template", "standalone coupon first selection group fieldId does not match");

        Selections secondSelectionGroup = secondSubsectionSelectionDetail.getSelectionGroup().get(1);
        softAssert.assertEquals(secondSelectionGroup.getTitle().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Standalone_Coupon_Second_Selection_Detail_Subtitle"), "standalone coupon second selection detail subtitle does not match");
        softAssert.assertEquals(secondSelectionGroup.getSelection().get(0).getFieldId(),
                "preferenceSelections.standaloneCoupon.personalNote", "standalone coupon second selection detail fieldId does not match");

        List<Entries> selectionEntries = secondSelectionGroup.getSelection().get(0).getEntries();
        if (selectionEntries.get(0).getParamValue() != null) {
            breezeReport.logWithColor("Message to Buyer - paramValue Validatoin ", "blue");
            if (selectionEntries.get(0).get_type().equals(L10n.content(propFile, "SelectionEntries_ParamValue_Type"))) {
                String actualParamValue = selectionEntries.get(0).getParamValue().toString();
                String expectedParamValue = L10n.content(propFile, "SelectionEntries_Msg_ToBuyer");
                breezeReport.logStep("Actual Selection Entries Standalone Coupon paramValue : " + actualParamValue);
                breezeReport.logStep("Expected Selection Entries Standalone Coupon paramValue " + expectedParamValue);
                softAssert.assertEquals(actualParamValue, expectedParamValue, "Selection Entries Standalone Coupon paramValue is not correct");
            } else
                breezeReport.logStep("No text entered for - Message to Buyer ");
        }
    }

    private void validatePackingSlipSelectionGroup(Selections selections, ValidateInput input, FormatResponse expectedPackingSlipSMEResp, String propFile, ModuleProviderRequest request) throws Exception {

        Selections.SingleSelection firstSelectionGroup = selections.getSelection().get(0);
        softAssert.assertEquals(request.getDocumentSelections().isPackingSlip(), firstSelectionGroup.isSelected(), "packing slip checkbox flags do not match");
        softAssert.assertEquals(firstSelectionGroup.getFieldId(), "documentSelections.packingSlip", "selection type is not correct");
        String expPackingSlipText = L10n.content(propFile, "Packing_Slip");
        if(input.getSite().equalsIgnoreCase("GB"))
        	expPackingSlipText = L10n.content(propFile, "Packing_Slip_GB");
        softAssert.assertEquals(firstSelectionGroup.getLabel().getTextSpans().get(0).getText(),
        		expPackingSlipText, "selection group label is not correct");

        //verify info bubble
        Selections.Help helpBubble = selections.getHelp();
        softAssert.assertEquals(helpBubble.get_type(), "BubbleHelp", "helpBubble type is not correct");
        String expInfoBubbleText =  L10n.content(propFile, "Packing_Slip_Info_Bubble_Text");
        if(input.getSite().equalsIgnoreCase("GB"))
        	expInfoBubbleText = L10n.content(propFile, "Packing_Slip_Info_Bubble_Text_GB");
        softAssert.assertEquals(helpBubble.getMessageText().get(0).getTextSpans().get(0).getText(),
        		expInfoBubbleText, "packing slip info bubble text is not correct");

        //verify first subsection
        Subsection firstSubSection = selections.getSubSection().get(0);
        softAssert.assertEquals(firstSubSection.getFieldId(), "documentSelections.packingSlipOrderInfo", "packing slip order info type is not correct");

        Subsection.Synopsis firstSubSectionSynopsis = firstSubSection.getSynopsis();
        String expSubSecTitle = L10n.content(propFile, "Order_And_eBay_store_info");
        if(input.getSite().equalsIgnoreCase("GB")) {
        	expSubSecTitle = L10n.content(propFile, "Order_And_eBay_store_info_GB");
            softAssert.assertEquals(firstSubSectionSynopsis.getTitle().getTextSpans().get(0).getText(), expSubSecTitle, "packling slip order info title is not correct");
            softAssert.assertEquals(firstSubSectionSynopsis.getEditAction().getTextSpans().get(0).getText(), L10n.content(propFile, "Customise_GB"));
        } else {
        	softAssert.assertEquals(firstSubSectionSynopsis.getTitle().getTextSpans().get(0).getText(), expSubSecTitle, "packling slip order info title is not correct");
            softAssert.assertEquals(firstSubSectionSynopsis.getEditAction().getTextSpans().get(0).getText(), L10n.content(propFile, "Customize"));
        }
        
        //TODO validate packing slip Synopsis if pref call works

        //verify packing slip selection details
        Subsection.SelectionDetails selectionDetails = selections.getSubSection().get(0).getSelectionDetails();
        softAssert.assertEquals(selectionDetails.getTitle().getTextSpans().get(0).getText(), expPackingSlipText,
                "packing slip selectionDetails title is not correct");
        String expSelectionDesc =  L10n.content(propFile, "Packing_Slip_Selection_Details_Description");
        if (input.getSite().equalsIgnoreCase("GB"))
        	expSelectionDesc = L10n.content(propFile, "Packing_Slip_Selection_Details_Description_GB");
        softAssert.assertEquals(selectionDetails.getDescription().getTextSpans().get(0).getText(),
        		expSelectionDesc, "packing slip selectionDetails description text not correct");

        validatePackingSlipSelectionDetails(selectionDetails.getSelectionGroup(), propFile, input);

        if (input.isValidateCoupon()) {
            if (!(input.getSellerType().equals("Non_Store_seller")
                    || input.getSellerType().equals("No_Coupon_seller"))) {
                //verify the second subsection
                Subsection secondSubSection = selections.getSubSection().get(1);
                softAssert.assertEquals(secondSubSection.getFieldId(), "documentSelections.packingSlipCoupon", "packing slip coupon type is not correct");

                Subsection.Synopsis secondSubSectionSynopsis = secondSubSection.getSynopsis();
                softAssert.assertEquals(secondSubSectionSynopsis.getTitle().getTextSpans().get(0).getText(), L10n.content(propFile, "Packing_Slip_Coupon"), "packing slip coupon label is not correct");
                softAssert.assertEquals(secondSubSectionSynopsis.getTitle().getTextSpans().get(1).getText(), L10n.content(propFile, "Packing_Slip_Coupon_Optional"), "packing slip coupon optional label is not correct");

                if (secondSubSectionSynopsis.getSynopsis() != null && expectedPackingSlipSMEResp != null) {
                    String actualPackingSlipCouponMessage = secondSubSectionSynopsis.getEditAction().getTextSpans().get(0).getText();
                    String expectedPackingSlipCouponMessage = expectedPackingSlipSMEResp.getSmeResponse().getMessage();
                    softAssert.assertEquals(actualPackingSlipCouponMessage, expectedPackingSlipCouponMessage, "packing slip coupon messages do not match");
                    String actualPackingSlipCouponCode = secondSubSectionSynopsis.getSynopsis().getTextSpans().get(0).getText();
                    String expectedPackingSlipCouponCode = expectedPackingSlipSMEResp.getSmeResponse().getCouponCode();
                    softAssert.assertEquals(actualPackingSlipCouponCode, expectedPackingSlipCouponCode, "packing slip coupon codes do not match");

                    String actualPackingSlipCouponValidDate = secondSubSectionSynopsis.getSelectionSummary().get(0).getTextSpans().get(0).getText();
                    String expectedPackingSlipCouponValidDate = expectedPackingSlipSMEResp.getFormatValidDate();
                    softAssert.assertEquals(actualPackingSlipCouponValidDate, expectedPackingSlipCouponValidDate, "packing slip coupon offer valid dates do not match");

                    String actualPackingSlipSubType = secondSubSectionSynopsis.getSelectionSummary().get(1).getTextSpans().get(0).getText();
                    String expectedPackingSlipSubType = expectedPackingSlipSMEResp.getSmeResponse().getSubType().equals("PUBLIC_SINGLE_SELLER_COUPON") ?
                            "Public coupon" : "Private coupon";
                    softAssert.assertEquals(actualPackingSlipSubType, expectedPackingSlipSubType, "packing slip subtypes do not match");

                    String actualCouponModuleMaxSaving = secondSubSectionSynopsis.getSelectionSummary().get(2).getTextSpans().get(0).getText();
                    DecimalFormat decimalFormat = new DecimalFormat("#.00");
                    decimalFormat.setMinimumFractionDigits(2);
                    String expectedCouponModuleMaxSaving = decimalFormat.format(expectedPackingSlipSMEResp.getSmeResponse().getMaxCouponDiscountAmount().getValue());
                    String expectedCouponModuleMaxSavingStr = "Maximum savings of $" + expectedCouponModuleMaxSaving + " per coupon";
                    softAssert.assertEquals(actualCouponModuleMaxSaving, expectedCouponModuleMaxSavingStr, "standalone max saving does not match");

                    String actualPackingSlipMaxCouponUsed = secondSubSectionSynopsis.getSelectionSummary().get(3).getTextSpans().get(0).getText();
                    int expectedPackingSlipMaxCouponRedemptionPerUser = expectedPackingSlipSMEResp.getSmeResponse().getMaxCouponRedemptionPerUser();
                    String expectedPackingSlipMaxCouponUsed = null;
                    if (expectedPackingSlipMaxCouponRedemptionPerUser == 100000)
                        expectedPackingSlipMaxCouponUsed = L10n.content(propFile, "Coupon_Module_Max_Coupon_Used");
                    else
                        expectedPackingSlipMaxCouponUsed = "Limited to " + expectedPackingSlipMaxCouponRedemptionPerUser + " uses per coupon per buyer";
                    softAssert.assertEquals(actualPackingSlipMaxCouponUsed, expectedPackingSlipMaxCouponUsed, "packing slip max coupon redemptions per user do not match");
                }
            } else {
                softAssert.assertEquals(selections.getSubSection().size(), 1, "packing slip subsection size does not match");
            }
        }
    }

    private void validatePackingSlipSelectionDetails(List<Selections> selectionGroupDetail, String propFile, ValidateInput input) throws Exception {
        //verify packing slip selection Details - Order info
        Selections detailSelectionOrder = selectionGroupDetail.get(0);
        softAssert.assertEquals(detailSelectionOrder.getTitle().getTextSpans().get(0).getText(), L10n.content(propFile, "Order_info"),
                "packing slip selectionDetails order info title is not correct");
        softAssert.assertEquals(detailSelectionOrder.getSelection().size(), 8, "packing slip selectionDetails orderInfo selectionGroup size is not correct");

        validatePackingSlipOrderInfoSelectionGroup(detailSelectionOrder.getSelection(), propFile, input);

        Selections detailSelectionStore = new Selections();
        String expStoreInfo = L10n.content(propFile, "Store_Info");
        String expStoreLogoText = L10n.content(propFile, "Store_Logo_Text");
        String expStoreUrl =  L10n.content(propFile, "Store_Url");
        String expStoreQRCodeText = L10n.content(propFile, "Store_QRCode_Text");
        if (input.getSite().equalsIgnoreCase("GB")) {
        	validatePreferenceSelectionTaxInfo(selectionGroupDetail.get(1), propFile, input);
        	detailSelectionStore = selectionGroupDetail.get(2);
        	expStoreInfo = L10n.content(propFile, "Store_Info_GB");
        	expStoreLogoText = L10n.content(propFile, "Store_Logo_Text_GB");
            expStoreUrl =  L10n.content(propFile, "Store_Url_GB");
            expStoreQRCodeText = L10n.content(propFile, "Store_QRCode_Text_GB");
        }
        else 
        	detailSelectionStore = selectionGroupDetail.get(1);
        	
    	validatePackingSlipEbayStoreInfoSelectionGroup(detailSelectionStore, propFile, expStoreInfo, expStoreLogoText,
    			expStoreUrl, expStoreQRCodeText);

    }

    private void validatePackingSlipEbayStoreInfoSelectionGroup(Selections detailSelectionStore, String propFile, String expStoreInfo, 
    		String expStoreLogoText, String expStoreUrl, String expStoreQRCodeText) {
   
    	//verify packing slip selection Details - eBay store Info
        softAssert.assertEquals(detailSelectionStore.getTitle().getTextSpans().get(0).getText(), expStoreInfo,
                "packing slip selectionDetails ebay store info title is not correct");
        softAssert.assertEquals(detailSelectionStore.getSelection().size(), 3, "packing slip selectionDetails store info selectionGroup size is not correct");

        String storeLogoText = detailSelectionStore.getSelection().get(0).getLabel().getTextSpans().get(0).getText();
        String storeUrl = detailSelectionStore.getSelection().get(1).getLabel().getTextSpans().get(0).getText();
        String storeQRCodeText = detailSelectionStore.getSelection().get(2).getLabel().getTextSpans().get(0).getText();

        softAssert.assertEquals(storeLogoText, expStoreLogoText,
                "packing slip selectionDetails store info - store logo text is not correct");
        softAssert.assertEquals(storeUrl, expStoreUrl,
                "packing slip selectionDetails store info - store url is not correct");
        softAssert.assertEquals(storeQRCodeText, expStoreQRCodeText,
                "packing slip selectionDetails store info - store QR code text is not correct");

		
	}

	private void validatePreferenceSelectionTaxInfo(Selections selections, String propFile, ValidateInput input) throws Exception {
		
		breezeReport.logWithColor("Seller VAT Call", "brown");
		isSellerVatId = false;
		SellerVatResponse sellerVatResp = printOrderUtil.getSellerVatResponse(input);
		
		for (VatRecord record : sellerVatResp.getVatRecords()) {
			if (record.getStatus().equalsIgnoreCase("VERIFIED")) {
				sellerVatId.add(record.getVatRegion() + ' ' + record.getVatId());
				isSellerVatId = true;
			}
		}
		if (!isSellerVatId)
			breezeReport.logWithColor("** VERIFIED Seller VAT ID not available **", "brown");
		
		//validate PackingSlip/OrderReceipt PreferenceSelection - Tax Info
		softAssert.assertEquals(selections.getTitle().getTextSpans().get(0).getText(), L10n.content(propFile, "Tax_Info"),
                "SelectionDetails Tax Info title is not correct");
		
        String labelText = selections.getSelection().get(0).getLabel().getTextSpans().get(0).getText();
        String secLabelText = selections.getSelection().get(0).getSecondaryLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(labelText, L10n.content(propFile, "VAT_Details"), "Vat Details selection Label text is not correct.");
        softAssert.assertEquals(secLabelText, L10n.content(propFile, "VAT_Details_SecLabel"), "Vat Details selection Secondary Label text is not correct.");
		
        String InvNumberlabelText = selections.getSelection().get(1).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(InvNumberlabelText, L10n.content(propFile, "Invoice_Number"), "Invoice Number Label text is not correct.");
        softAssert.assertEquals(selections.getSelection().get(1).getHelp().getBubbleIcon().getName(), 
        		L10n.content(propFile, "BubbleIcon_Name"), "Invoice Number BubbleIcon Name is not correct");
        softAssert.assertEquals(selections.getSelection().get(1).getHelp().getBubbleIcon().getAccessibilityText(), 
        		L10n.content(propFile, "BubbleIcon_AccessibilityText"), "Invoice Number BubbleIcon AccessibilityText is not correct");
        softAssert.assertEquals(selections.getSelection().get(1).getHelp().getMessageText().get(0).getTextSpans().get(0).getText(), 
        		L10n.content(propFile, "Invoice_Number_ToolTip"), "Invoice Number ToolTip is not correct");
        softAssert.assertEquals(selections.getSelection().get(1).getEntries().get(0).getEntries().get(0).getLabel().getTextSpans().get(0).getText(), 
        		L10n.content(propFile, "InvoicePrefix_Label"), "Invoice Prefix Label is not correct");
        softAssert.assertEquals(selections.getSelection().get(1).getEntries().get(0).getEntries().get(1).getLabel().getTextSpans().get(0).getText(), 
        		L10n.content(propFile, "InvoiceCounter_Label"), "Invoice Counter Label is not correct");
        
        if (!sellerVatId.isEmpty()) {
			softAssert.assertEquals(selections.getSelection().size(), 3, "SelectionDetails Tax Info selectionGroup size is not correct");
        	softAssert.assertEquals(selections.getSelection().get(2).getLabel().getTextSpans().get(0).getText(), 
            		L10n.content(propFile, "VAT_ID"), "VAT ID Label is not correct");
        	 List<Entries> entries = selections.getSelection().get(2).getEntries().get(0).getEntries();
        	for (Entries entry : entries) {
        		String actSellerVat = (String) entry.getParamKey();
        		for (String expSellerVat : sellerVatId) {
        			if (actSellerVat.equals(expSellerVat))
            			assertLog(actSellerVat, expSellerVat, "SellerVatID");
        		}
        	}
        }
		else
			softAssert.assertEquals(selections.getSelection().size(), 2, "SelectionDetails Tax Info selectionGroup size is not correct");
		
	}

	private void validatePackingSlipOrderInfoSelectionGroup(List<Selections.SingleSelection> selection, String propFile, ValidateInput input) {

    	String addressLabel = selection.get(0).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(addressLabel, L10n.content(propFile, "Address_Label"), "Address Label selection text is not correct.");
    	if (selection.get(0).isSelected())
    		isAddressLabelOnPackingSlip = true;
    	
        String giftText = selection.get(1).getLabel().getTextSpans().get(0).getText();
        String giftInfoText = selection.get(1).getSecondaryLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(giftText, L10n.content(propFile, "Gift_Text"), "gift selection text is not correct.");
        softAssert.assertEquals(giftInfoText, L10n.content(propFile, "Gift_Secondary_Text"), "gift secondary selection text is not correct.");

        String shipFrom = selection.get(2).getLabel().getTextSpans().get(0).getText();
        String expshipFrom = L10n.content(propFile, "Ship_From");
        if (input.getSite().equalsIgnoreCase("GB"))
        	expshipFrom = L10n.content(propFile, "Ship_From_GB");
        softAssert.assertEquals(shipFrom, expshipFrom, "Ship from address selection text is not correct.");

        String listPhoto = selection.get(3).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(listPhoto, L10n.content(propFile, "List_Photo"), "List photo selection text is not correct.");

        String returnPolicy = selection.get(4).getLabel().getTextSpans().get(0).getText();
        String expreturnPolicy = L10n.content(propFile, "Return_Policy");
        if (input.getSite().equalsIgnoreCase("GB"))
        	expreturnPolicy = L10n.content(propFile, "Return_Policy_GB");
        softAssert.assertEquals(returnPolicy, expreturnPolicy, "Return policy selection text is not correct.");

        String sellerRating = selection.get(5).getLabel().getTextSpans().get(0).getText();
        String sellerRatingText = selection.get(5).getSecondaryLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(sellerRating, L10n.content(propFile, "Seller_Rating"), "seller rating text is not correct.");
        String expsellerRatingText = L10n.content(propFile, "Seller_Rating_Text");
        if (input.getSite().equalsIgnoreCase("GB"))
        	expsellerRatingText = L10n.content(propFile, "Seller_Rating_Text_GB");
        softAssert.assertEquals(sellerRatingText, expsellerRatingText, "seller rating info text is not correct.");

        String noteForBuyer = selection.get(6).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(noteForBuyer, L10n.content(propFile, "Note_For_Buyer"), "note for buyer selection text is not correct.");

        String customLabel = selection.get(7).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(customLabel, L10n.content(propFile, "Custom_Label"), "custom label selection text is not correct.");
    }

    private void validateOrderReceiptSelectionGroup(Selections selections, String propFile, ModuleProviderRequest request) {
        Selections.SingleSelection secondSelectionGroup = selections.getSelection().get(0);
        softAssert.assertEquals(request.getDocumentSelections().isOrderReceipt(), secondSelectionGroup.isSelected(), "Order Receipt checkbox flags do not match");
        softAssert.assertEquals(secondSelectionGroup.getFieldId(), "documentSelections.orderReceipt", "selection type is not correct");
        softAssert.assertEquals(secondSelectionGroup.getLabel().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Order_Receipt"), "selection group label is not correct");

        //verify help info bubble
        Selections.Help helpBubble = selections.getHelp();
        softAssert.assertEquals(helpBubble.getMessageText().get(0).getTextSpans().get(0).getText(),
                L10n.content(propFile, "Order_Receipt_Bubble_Text"), "order receipt info bubble text is not correct");

        //verify order receipt selection details
        Subsection.SelectionDetails selectionDetails = selections.getSubSection().get(0).getSelectionDetails();
        softAssert.assertEquals(selectionDetails.getTitle().getTextSpans().get(0).getText(), L10n.content(propFile, "Order_Receipt"),
                "order receipt selectionDetails title is not correct");
        softAssert.assertEquals(selectionDetails.getDescription().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Order_Receipt_Description"), "order receipt selectionDetails description text not correct");

        softAssert.assertEquals(selectionDetails.getSelectionGroup().get(0).getSelection().size(), 7, "order receipt selectionDetails selectionGroup size is not correct");
        validateOrderReceiptSelectionDetails(selectionDetails.getSelectionGroup().get(0).getSelection(), propFile);
    }

    private void validateOrderReceiptSelectionDetails(List<Selections.SingleSelection> selection, String propFile) {

        String shipFrom = selection.get(0).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(shipFrom, L10n.content(propFile, "Ship_From"), "Ship from address selection text is not correct.");

        String listingPhoto = selection.get(1).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(listingPhoto, L10n.content(propFile, "List_Photo"), "Listing photo selection text is not correct.");

        String shippingInfo = selection.get(2).getLabel().getTextSpans().get(0).getText();
        String shippingInfoText = selection.get(2).getSecondaryLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(shippingInfo, L10n.content(propFile, "Shipping_Info"), "shipping info text is not correct.");
        softAssert.assertEquals(shippingInfoText, L10n.content(propFile, "Shipping_Info_Text"), "shipping info secondary text is not correct.");

        String paymentInfo = selection.get(3).getLabel().getTextSpans().get(0).getText();
        String paymentInfoText = selection.get(3).getSecondaryLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(paymentInfo, L10n.content(propFile, "Payment_Info"), "payment info text is not correct.");
        softAssert.assertEquals(paymentInfoText, L10n.content(propFile, "Payment_Info_Text"), "payment info secondary text is not correct.");

        String myNoteText = selection.get(4).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(myNoteText, L10n.content(propFile, "My_Note"), "my note selection text is not correct.");

        String buyerNoteText = selection.get(5).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(buyerNoteText, L10n.content(propFile, "Buyer_Note"), "buyer note selection text is not correct.");

        String customLabelText = selection.get(6).getLabel().getTextSpans().get(0).getText();
        softAssert.assertEquals(customLabelText, L10n.content(propFile, "Custom_Label"), "custom label selection text is not correct.");
    }

    private void validatePickListSelectionGroup(Selections selections, boolean isPicklistEligible, String propFile, ModuleProviderRequest request) {
        Selections.SingleSelection thirdSelectionGroup = selections.getSelection().get(0);
        softAssert.assertEquals(request.getDocumentSelections().isPickList(), thirdSelectionGroup.isSelected(), "picking list checkbox flags do not match");
        softAssert.assertEquals(thirdSelectionGroup.getFieldId(), "documentSelections.pickList", "selection type is not correct");
        softAssert.assertEquals(thirdSelectionGroup.getLabel().getTextSpans().get(0).getText(),
                L10n.content(propFile, "Pick_List"), "selection group label is not correct");

        //verify help info bubble
        Selections.Help helpBubble = selections.getHelp();
        String expHelpBubble = L10n.content(propFile, "Pick_List_Bubble_Text");

        if (!isPicklistEligible)
            expHelpBubble = L10n.content(propFile, "Pick_List_Bubble_Text_NOT_ELIGIBLE");

        softAssert.assertEquals(helpBubble.getMessageText().get(0).getTextSpans().get(0).getText(),
                expHelpBubble, "pick list info bubble text is not correct");
    }

    private void validatePdfInfo(PdfInfo pdfInfo, ValidateEnum module, String propFile, ModuleProviderRequest request, LabelServiceResponse expectedLabelServiceResp, String site) {
        breezeReport.logWithColor("Validating pdfInfo", "blue");
        //We may have Preview forms (1) / Preview forms (2) depend on how many documents we selected, thus only verify title text here.
        String pdfInfoTitle = pdfInfo.getTitle().getTextSpans().get(0).getText().split("(?<=\\s\\S{1,100})\\s")[0];
        if (module == ValidateEnum.COUPON_MODULE) {
        	if (!site.equalsIgnoreCase("DE"))
        		softAssert.assertEquals(pdfInfoTitle, L10n.content(propFile, "Preview_Coupons"), "pdfInfo title text is not correct");
        	else
        		softAssert.assertEquals(pdfInfoTitle, L10n.content(propFile, "Preview_Coupons_DE"), "pdfInfo title text is not correct");
        }
        else
        	if (!site.equalsIgnoreCase("DE"))
        		softAssert.assertEquals(pdfInfoTitle, L10n.content(propFile, "Preview_Documents"), "pdfInfo title text is not correct");
        	else	
        		softAssert.assertEquals(pdfInfoTitle, L10n.content(propFile, "Preview_Documents_DE"), "pdfInfo title text is not correct");


        /*
         * As per MESHORD-2372, help is not part of pdfInfo, so removing the validation.
         * String bubbleHelpText
         * =pdfInfo.getHelp().getMessageText().get(0).getTextSpans().get(0).getText();
         * softAssert.assertEquals(bubbleHelpText,
         * L10n.content(propFile,"PDF_Info_Title_Help_Text")
         * ,"pdfInfo title bubble help text is not correct");
         */

        if (allOrders(expectedLabelServiceResp, request.getOrderIds()).size() > 1) {
            String descriptionText = pdfInfo.getDescription().getTextSpans().get(0).getText();
            if (module == ValidateEnum.COUPON_MODULE)
                softAssert.assertEquals(descriptionText, L10n.content(propFile, "Coupon_PDF_Info_Description_Text"), "pdfInfo description text is not correct");
            else
                softAssert.assertEquals(descriptionText, L10n.content(propFile, "PDF_Info_Description_Text"), "pdfInfo description text is not correct");
        }

        if (pdfInfo.getData() != null) {
            String pdfData = pdfInfo.getData().getEncodedData();
            softAssert.assertNotNull(pdfData, "pdfInfo data is null");
        }
        breezeReport.logWithColor("----- validatePdfInfo Done -----", "green");
    }

    private void validateFeatureSurveyLink(TextualDisplay featureSurveyLink, String propFile, String site) {
        breezeReport.logWithColor("validate FeatureSurveyLink", "blue");

        String featureSurveyLinkText = featureSurveyLink.getTextSpans().get(0).getText();
        if (!site.equalsIgnoreCase("DE"))
        	softAssert.assertEquals(featureSurveyLinkText, L10n.content(propFile, "Feature_Survey_Link_Text"), "feature survey link text is not correct");
        else
        	softAssert.assertEquals(featureSurveyLinkText, L10n.content(propFile, "Feature_Survey_Link_Text_DE"), "feature survey link text is not correct");        
        breezeReport.logWithColor("----- validateFeatureSurveyLink Done -----", "green");
    }

    private void validatePrintAction(CallToAction printAction, String propFile, String site) {
    	if (!site.equalsIgnoreCase("DE"))
    		softAssert.assertEquals(printAction.getText(), L10n.content(propFile, "Print_Action_Text"), "print action text does not match");
    	else
    		softAssert.assertEquals(printAction.getText(), L10n.content(propFile, "Print_Action_Text_DE"), "print action text does not match");
    }

    private void validateCancelAction(CallToAction cancelAction, String propFile) {
        softAssert.assertEquals(cancelAction.getText(), L10n.content(propFile, "Cancel_Action_Text"), "cancel action text does not match");
    }

    private void validatePrintSelectionData(PrintSelectionData printSelectionData, ModuleProviderRequest request, String propFile, 
    		ValidateInput input) throws Exception {
        breezeReport.logWithColor("validate PrintSelectionData", "blue");

        List<String> orderIds = printSelectionData.getOrderIds();
        softAssert.assertEquals(orderIds, request.getOrderIds(), "OrderIds are not correct");
        List<String> labelIds = printSelectionData.getLabelIds();
        softAssert.assertEquals(labelIds, request.getLabelIds(), "LabelIds are not correct");
        
        if (input.getSite().equalsIgnoreCase("GB") && printSelectionData.getPreferenceSelections().getInvoiceNumber() != null) {
        	if (printSelectionData.getPreferenceSelections().getInvoiceNumber().getOriginalCounter() != null)
            	validateInvoiceNumberCounter(printSelectionData.getPreferenceSelections(), input);
        	else
        		breezeReport.logStep("Actual Tax Invoice Invoice Counter is NULL");
        }
        breezeReport.logWithColor("----- validatePrintSelectionData Done -----", "green");
    }

    private void validateInvoiceNumberCounter(PreferenceInfo preferenceSelections, ValidateInput input) throws Exception {
    	breezeReport.logWithColor("validate Invoice Number Counter", "blue");
    	String expInvCntr = printOrderUtil.getInvoiceCounterResponse(input);
    	String actInvCntr = preferenceSelections.getInvoiceNumber().getOriginalCounter();
    	breezeReport.logStep("Actual Tax Invoice Counter: " + actInvCntr);
        breezeReport.logStep("Expected Tax Invoice Counter: " + expInvCntr);
    	softAssert.assertEquals(actInvCntr, expInvCntr, "Invoice Counter does not match");
    	breezeReport.logWithColor("----- validateInvoiceNumberCounter Done -----", "green");
	}

	private void validateMessageBundle(List<Message> MessageBundle, String propFile, String marketplace, String mode) {
        breezeReport.logWithColor("validate MessageBundle", "blue");
        for (Message message : MessageBundle) {
            switch (message.getKey()) {
                case "noDocumentToShow":
                	if (marketplace.equalsIgnoreCase("GB"))
                		softAssert.assertEquals(message.getText(), L10n.content(propFile, "No_Documents_Show_Message_GB"),
                                "message info text is not correct");
                	else
                		softAssert.assertEquals(message.getText(), L10n.content(propFile, "No_Documents_Show_Message"),
                            "message info text is not correct");
                    softAssert.assertEquals(message.getType(), "WARNING", "message type is not correct");
                    break;
                case "previewUnavailable":
                    softAssert.assertEquals(message.getText(), L10n.content(propFile, "Preview_Unavailable_Message"),
                            "message info text is not correct");
                    softAssert.assertEquals(message.getType(), "ERROR", "message type is not correct");
                    break;
                case "serviceUnavailable":
                    softAssert.assertEquals(message.getText(), L10n.content(propFile, "Service_Unavailable_Message"),
                            "message info text is not correct");
                    softAssert.assertEquals(message.getType(), "ERROR", "message type is not correct");
                    break;
                case "close":
                    softAssert.assertEquals(message.getText(), L10n.content(propFile, "Close_Message"),
                            "message info text is not correct");
                    softAssert.assertEquals(message.getType(), "INFO", "message type is not correct");
                    break;
                case "CHANGES_SAVED":
                    softAssert.assertEquals(message.getText(), L10n.content(propFile, "ChangeS_Saved"),
                            "message info text is not correct");
                    break;
                case "couponServiceUnavailable":
                    softAssert.assertEquals(message.getTitle(), L10n.content(propFile, "Coupon_Service_Unavailable_Title"),
                            "message info title is not correct");
                    softAssert.assertEquals(message.getText(), L10n.content(propFile, "Coupon_Service_Unavailable_Text"),
                            "message info text is not correct");
                    softAssert.assertEquals(message.getType(), "ERROR", "message type is not correct");
                    break;
                case "noCouponSelectedToShow":
                	if (marketplace.equalsIgnoreCase("GB"))
                		softAssert.assertEquals(message.getText(), L10n.content(propFile, "No_Coupon_Selected_To_Show_GB"),
                                "message info text is not correct");
                	else
                		softAssert.assertEquals(message.getText(), L10n.content(propFile, "No_Coupon_Selected_To_Show"),
                            "message info text is not correct");
                    softAssert.assertEquals(message.getType(), "WARNING", "message type is not correct");
                    break;
                case "INVALID_PREFIX":
                    softAssert.assertEquals(message.getText(), L10n.content(propFile, "Invalid_Prefix"),
                            "message info text is not correct");
                    softAssert.assertEquals(message.getType(), "ERROR", "message type is not correct");
                    break;
                case "INVALID_COUNTER":
                    softAssert.assertEquals(message.getText(), L10n.content(propFile, "Invalid_Counter"),
                            "message info text is not correct");
                    softAssert.assertEquals(message.getType(), "ERROR", "message type is not correct");
                    break;
                case "Download":
                	if (mode != null) {
                		softAssert.assertEquals(message.getText(), L10n.content(propFile, "Download"),
                				"message info text is not correct");
                	    softAssert.assertEquals(message.getType(), "INFO", "message type is not correct");
                	}
                	break;
            }

        }
        breezeReport.logWithColor("----- validateMessageBundle Done -----", "green");
    }

    /*
     * Building ModuleProviderRequest
     */
    private ModuleProviderRequest buildRequest(ValidateInput input) {
//        OrdersInfo ordersInfo = input.getOrdersInfo();
        String[] documents = input.getDocuments().split(",");

        ModuleProviderRequest request = new ModuleProviderRequest();
//        ArrayList<String> ordersList = new ArrayList<>();
        DocumentSelections documentSelections = new DocumentSelections();

        //todo: temporally commnet out this session, currently we are using exiting orders to do the validation.
//        for (OrderInfo orderInfo : ordersInfo.getOrderInfo()) {
//            String orderId = orderInfo.getOrderData().getOrderId();
//
//            if (orderId == null) {//UnPaid Orders
//                for (ItemInfo eachItemInOrder : orderInfo.getItemsList()) {
//                    orderId = eachItemInOrder.getItemID() + "-" + eachItemInOrder.getTxnData().getTxnId();
//                    ordersList.add(orderId);
//                }
//            } else {
//                ordersList.add(orderId);
//            }
//        }
        request.setOrderIds(input.getOrders());
        request.setLabelIds(input.getLabels());
        for (String doc : documents) {
            if (doc.equals("packingSlip")) documentSelections.setPackingSlip(true);
            if (doc.equals("orderReceipt")) documentSelections.setOrderReceipt(true);
            if (doc.equals("pickList")) documentSelections.setPickList(true);
            if (doc.equals("coupon")) documentSelections.setCoupon(true);
            if (doc.equals("addressLabel")) documentSelections.setAddressLabel(true);
            if (doc.equals("genericCoupon")) documentSelections.setGenericCoupon(true);
        }
        request.setDocumentSelections(documentSelections);

        if (Optional.of(input.getCouponIds()).isPresent() && !input.getCouponIds().isEmpty() && input.getCouponIds().containsKey("couponModuleCouponId")) {
            List<String> a = Arrays.stream(input.getCouponIds().get("couponModuleCouponId").split(",")).collect(toList());
            request.setCouponIds(a);
        }

        if(Optional.ofNullable(input.getTemplate()).isPresent() && Optional.ofNullable(input.getCountPerSheet()).isPresent()){
            PreferenceInfo.StandaloneCoupon standaloneCoupon = new PreferenceInfo.StandaloneCoupon();
            standaloneCoupon.setCountPerSheet(Integer.valueOf(input.getCountPerSheet()));
            standaloneCoupon.setTemplate(input.getTemplate());
            standaloneCoupon.setId(Arrays.stream(input.getCouponIds().get("couponModuleCouponId").split(",")).collect(toList()).get(0));
            PreferenceInfo preferenceSelections = new PreferenceInfo();
            preferenceSelections.setStandaloneCoupon(standaloneCoupon);
            request.setPreferenceSelections(preferenceSelections);
        }


        return request;
    }

    private void validatePdfDocGenRawDataModule(PdfDocGenRawDataRequest req,
                                                ModuleProviderRequest request,
                                                GetAddressResponse expectedAddressBookResp,
                                                CosmosResponse expectedCosmosResp,
                                                Store expectedStoreServiceResp,
                                                GetUserResponse expectedUserReadSvcResp,
                                                String sellerName,
                                                String site,
                                                ValidateInput input,
                                                FormatResponse expectedPackingSlipSMEResp,
                                                FormatResponse expectedStandaloneCouponSMEResp,
                                                FormatResponse expectedCouponModuleSMEResp,
                                                String propFile,
                                                LabelServiceResponse dataFromLabelService) throws Exception {
        breezeReport.logWithColor("*-*-*- Validating Request -*-*-*", "blue");

        validateGlobalInfo(req);
        
        validatePrefInfo(req, request, input);

        validateSellerInfo(req, expectedAddressBookResp, expectedStoreServiceResp, expectedCosmosResp, expectedUserReadSvcResp, input, propFile);

        validateOrdersOfPdfDocGenRawData(req, expectedCosmosResp, input, dataFromLabelService, propFile);

        if (input.getValidate().equals("VALIDATE_COUPON")) {
            validateCouponInfo(req, expectedPackingSlipSMEResp, expectedStandaloneCouponSMEResp, expectedCouponModuleSMEResp, propFile);
        }

        breezeReport.logWithColor("*-*-*- ValidateRequest Done *-*-*-", "green");

    }

    private void validateGlobalInfo(PdfDocGenRawDataRequest req) {
    	breezeReport.logWithColor("Validating GlobalInfo", "blue");
    	if(req.getGlobalInfo().getFeatureFlagMap().getEnableMyEbayMode() != null) {
    		boolean expectedMyEbayMode = true;
        	boolean actualMyEbayMode = req.getGlobalInfo().getFeatureFlagMap().getEnableMyEbayMode().booleanValue();
        	softAssert.assertEquals(actualMyEbayMode, expectedMyEbayMode, "MyEbayMode is not matched");
    	}
    	
    	breezeReport.logWithColor("----- Validate GlobalInfo done -----", "green");
    }
    
    private void validatePrefInfo(PdfDocGenRawDataRequest req, ModuleProviderRequest request, ValidateInput input) {
        breezeReport.logWithColor("Validating PrefInfo", "blue");
        String actualPageSize = req.getPrefInfo().getPageSize();
        String expectedPageSize = actualPageSize;
        softAssert.assertEquals(actualPageSize, expectedPageSize, "PageSize Doesnt match");

        int actalFormsPerSheet = req.getPrefInfo().getFormsPerSheet();
        int expectedFormsPerSheet = actalFormsPerSheet;
        softAssert.assertEquals(actalFormsPerSheet, expectedFormsPerSheet, "FormsPerSheet Doesnt match");
        
        boolean actualHasShipFromNameAndAddressForPackingSlip = req.getPrefInfo()
                .getHasShipFromNameAndAddressForPackingSlip();
        boolean expectedHasShipFromNameAndAddressForPackingSlip = actualHasShipFromNameAndAddressForPackingSlip;
        softAssert.assertEquals(actualHasShipFromNameAndAddressForPackingSlip, expectedHasShipFromNameAndAddressForPackingSlip, "HasShipFromNameAndAddressForPackingSlip Doesnt match");

        if(input.getMode() == null) {
        boolean actualHasGift = req.getPrefInfo().getHasGift();
        boolean expectedHasGift = actualHasGift;
        softAssert.assertEquals(actualHasGift, expectedHasGift, "HasGift Doesnt match");

        boolean actualHasListingThumbnail = req.getPrefInfo().getHasListingThumbnail();
        boolean expectedHasListingThumbnail = actualHasListingThumbnail;
        softAssert.assertEquals(actualHasListingThumbnail, expectedHasListingThumbnail, "HasListingThumbnail Doesnt match");

        boolean actualHasReturnPolicy = req.getPrefInfo().getHasReturnPolicy();
        boolean expectedHasReturnPolicy = actualHasReturnPolicy;
        softAssert.assertEquals(actualHasReturnPolicy, expectedHasReturnPolicy, "HasReturnPolicy Doesnt match");


        boolean actualHasSellerRating = req.getPrefInfo().getHasSellerRating();
        boolean expectedHasSellerRating = actualHasSellerRating;
        softAssert.assertEquals(actualHasSellerRating, expectedHasSellerRating, "HasSellerRating Doesnt match");

        String actualThankYouNote = req.getPrefInfo().getThankYouNote();
        String expectedThankYouNote = actualThankYouNote;
        softAssert.assertEquals(actualThankYouNote, expectedThankYouNote, "ThankYouNote Doesnt match");

        String actualPersonalNote = req.getPrefInfo().getPersonalNote();
        String expectedPersonalNote = actualPersonalNote;
        softAssert.assertEquals(actualPersonalNote, expectedPersonalNote, "PersonalNote Doesnt match");


        boolean actualHasShipFromNameAndAddressForOrderReceipt = req.getPrefInfo()
                .getHasShipFromNameAndAddressForOrderReceipt();
        boolean expectedHasShipFromNameAndAddressForOrderReceipt = actualHasShipFromNameAndAddressForOrderReceipt;
        softAssert.assertEquals(actualHasShipFromNameAndAddressForOrderReceipt, expectedHasShipFromNameAndAddressForOrderReceipt, "HasShipFromNameAndAddressForOrderReceipt Doesnt match");

        boolean actualHasStoreLogo = req.getPrefInfo().getHasStoreLogo();
        boolean expectedHasStoreLogo = actualHasStoreLogo;
        softAssert.assertEquals(actualHasStoreLogo, expectedHasStoreLogo, "HasStoreLogo Doesnt match");

        boolean actualHasStoreUrl = req.getPrefInfo().getHasStoreUrl();
        boolean expectedHasStoreUrl = actualHasStoreUrl;
        softAssert.assertEquals(actualHasStoreUrl, expectedHasStoreUrl, "HasStoreUrl Doesnt match");

        boolean actualHasStoreQRCodeLink = req.getPrefInfo().getHasStoreQRCodeLink();
        boolean expectedHasStoreQRCodeLink = actualHasStoreQRCodeLink;
        softAssert.assertEquals(actualHasStoreQRCodeLink, expectedHasStoreQRCodeLink, "HasStoreQRCodeLink Doesnt match");

        boolean actualHasShippingInfo = req.getPrefInfo().getHasShippingInfo();
        boolean expectedHasShippingInfo = actualHasShippingInfo;
        softAssert.assertEquals(actualHasShippingInfo, expectedHasShippingInfo, "HasShippingInfo Doesnt match");

        boolean actualHasPaymentInfo = req.getPrefInfo().getHasPaymentInfo();
        boolean expectedHasPaymentInfo = actualHasPaymentInfo;
        softAssert.assertEquals(actualHasPaymentInfo, expectedHasPaymentInfo, "HasPaymentInfo Doesnt match");

        boolean actualHasSellerNote = req.getPrefInfo().getHasSellerNote();
        boolean expectedHasSellerNote = actualHasSellerNote;
        softAssert.assertEquals(actualHasSellerNote, expectedHasSellerNote, "HasSellerNote Doesnt match");

        boolean actualHasBuyerNoteForPackingSlip = req.getPrefInfo().getHasBuyerNoteForPackingSlip();
        boolean expectedHasBuyerNoteForPackingSlip = actualHasBuyerNoteForPackingSlip;
        softAssert.assertEquals(actualHasBuyerNoteForPackingSlip, expectedHasBuyerNoteForPackingSlip, "HasBuyerNoteForPackingSlip Doesnt match");

        boolean actualHasBuyerNoteForOrderReceipt = req.getPrefInfo().getHasBuyerNoteForOrderReceipt();
        boolean expectedHasBuyerNoteForOrderReceipt = actualHasBuyerNoteForOrderReceipt;
        softAssert.assertEquals(actualHasBuyerNoteForOrderReceipt, expectedHasBuyerNoteForOrderReceipt, "HasBuyerNoteForOrderReceipt Doesnt match");

        boolean actualHasCustomLabel = req.getPrefInfo().getHasCustomLabel();
        boolean expectedHasCustomLabel = actualHasCustomLabel;
        softAssert.assertEquals(actualHasCustomLabel, expectedHasCustomLabel, "HasCustomLabel Doesnt match");

        boolean actualHasCustomLabelForPackingSlip = req.getPrefInfo().getHasCustomLabelForPackingSlip();
        boolean expectedHasCustomLabelForPackingSlip = actualHasCustomLabelForPackingSlip;
        softAssert.assertEquals(actualHasCustomLabelForPackingSlip, expectedHasCustomLabelForPackingSlip, "HasCustomLabelForPackingSlip Doesnt match");

        boolean actualHasListingThumbnailForOrderReceipt = req.getPrefInfo().getHasListingThumbnailForOrderReceipt();
        boolean expectedHasListingThumbnailForOrderReceipt = actualHasListingThumbnailForOrderReceipt;
        softAssert.assertEquals(actualHasListingThumbnailForOrderReceipt, expectedHasListingThumbnailForOrderReceipt, "HasListingThumbnailForOrderReceipt Doesnt match");
        breezeReport.logWithColor("----- Validate PrefInfo done -----", "green");
        }
    }

    private void validateSellerInfo(PdfDocGenRawDataRequest req, GetAddressResponse expectedAddressBookResp, Store expectedStoreServiceResp, CosmosResponse expectedCosmosResp, GetUserResponse expectedUserReadSvcResp, ValidateInput input, String propFile) {
        breezeReport.logWithColor("Validating Seller Info", "blue");
        boolean expectedRespOfNonStoreSeller = true;

        if (req.getSellerInfo().getLoginId() != null) {
            String actualSellerLoginId = req.getSellerInfo().getLoginId();
            String expectedSellerLoginId = expectedCosmosResp.getMembers().get(0).getOrder().getSeller().getUserIdentifier().getUserName();
            softAssert.assertEquals(actualSellerLoginId, expectedSellerLoginId, "Seller loginId doesnt match");
        }

        if (req.getSellerInfo().getFeedback() != null) {
            int actualSellerFeedback = req.getSellerInfo().getFeedback().getFeedbackCount();
            int expectedSellerFeedback = expectedCosmosResp.getMembers().get(0).getOrder().getSeller().getFeedbackScore();
            softAssert.assertEquals(actualSellerFeedback, expectedSellerFeedback, "Feedback score doesnt match");
        }

        if (req.getSellerInfo().getStoreLogo() != null 
        		&& expectedStoreServiceResp != null 
        		&& expectedStoreServiceResp.getDescription() != null
        		&& !expectedStoreServiceResp.getDescription().equals("Exception")) {
            String actualSellerStoreLogoUrl = req.getSellerInfo().getStoreLogo();
            String expectedSellerStoreLogoUrl = expectedStoreServiceResp.getLogoUrl();
            softAssert.assertEquals(actualSellerStoreLogoUrl, expectedSellerStoreLogoUrl, "Seller logo url doesnt match");
        }

        if (req.getSellerInfo().getStoreUrl() != null) {
            String actualSellerStoreUrl = req.getSellerInfo().getStoreUrl();
            String expectedSellerStoreUrl = null;
            if (expectedStoreServiceResp.getStoreId() != null) {
            	if (input.getSite().equalsIgnoreCase("GB"))
            		expectedSellerStoreUrl = L10n.content(propFile, "storeURL_GB") + expectedStoreServiceResp.getStoreId();
            	else
            		expectedSellerStoreUrl = (TestParams.TestEnv.customparam.get("storeURL")) + expectedStoreServiceResp.getStoreId();
            softAssert.assertEquals(actualSellerStoreUrl, expectedSellerStoreUrl, "Seller Storeurl doesnt match");
            }
        }

        if (req.getSellerInfo().getStoreName() != null 
        		&& expectedStoreServiceResp.getDescription() != null
        		&& !expectedStoreServiceResp.getDescription().equals("Exception")) {
            String actualSellerStoreName = req.getSellerInfo().getStoreName();
            String expectedSellerStoreName = expectedStoreServiceResp.getName();
            softAssert.assertEquals(actualSellerStoreName, expectedSellerStoreName, "Seller logo url doesnt match");
        }

        //String actualSellerFeedbackPercentage = req.getSellerInfo().getFeedback().getPositiveFeedback().toString();
        String expectedSellerFeedbackPercentage = "0.0";
        if (expectedStoreServiceResp != null) {
            if (expectedStoreServiceResp.getFeedbackPercentage() != null) {
                DecimalFormat decimalFormat = new DecimalFormat("#.00");
                decimalFormat.setMinimumFractionDigits(1);
                expectedSellerFeedbackPercentage = decimalFormat.format(expectedStoreServiceResp.getFeedbackPercentage());
            }
        }

//		softAssert.assertEquals(actualSellerFeedbackPercentage, expectedSellerFeedbackPercentage, "Seller Feedback percentage is not same");

        boolean actualRespOfNonStoreSeller = req.getSellerInfo().isNonStoreSeller();
        if (null != expectedStoreServiceResp) {
            expectedRespOfNonStoreSeller = false;
        }
        if (expectedStoreServiceResp.getDescription() != null && !expectedStoreServiceResp.getDescription().equals("Exception"))
        	softAssert.assertEquals(actualRespOfNonStoreSeller, expectedRespOfNonStoreSeller, "IsNonStoreSeller Rating doesnt match");

        if (req.getSellerInfo().getAddress() != null)
            validateSellerAddresssOfPdfDoc(req, expectedAddressBookResp);
        if(input.getMode() == null)
        validateIsTopRatedSeller(req, expectedUserReadSvcResp);
        breezeReport.logWithColor("Validating Seller Info Done", "green");
    }

    private void validateSellerAddresssOfPdfDoc(PdfDocGenRawDataRequest req, GetAddressResponse expectedAddressBookResp) {
        breezeReport.logWithColor("Validating SellerAddresssOfPdfDoc", "blue");

        if (req.getSellerInfo().getAddress().getName() != null) {
            String actualSellerName = req.getSellerInfo().getAddress().getName();
            String expectedSellerName = expectedAddressBookResp.getAddresses().get(0).getName();
            softAssert.assertEquals(actualSellerName, expectedSellerName, "Seller Name doesnt match");
        }

        if (req.getSellerInfo().getAddress().getAddressLine1() != null) {
            String actualSellerAddressLine1 = req.getSellerInfo().getAddress().getAddressLine1();
            String expectedSellerAddressLine1 = expectedAddressBookResp.getAddresses().get(0).getLocation().getAddressLine1();
            softAssert.assertEquals(actualSellerAddressLine1, expectedSellerAddressLine1, "Seller Location address Line 1 doesnt match");
        }

        if (req.getSellerInfo().getAddress().getAddressLine2() != null) {
            String actualSellerAddressLine2 = req.getSellerInfo().getAddress().getAddressLine2();
            String expectedSellerAddressLine2 = expectedAddressBookResp.getAddresses().get(0).getLocation().getAddressLine2();
            softAssert.assertEquals(actualSellerAddressLine2, expectedSellerAddressLine2, "Seller Location address Line 2 doesnt match");
        }

        if (req.getSellerInfo().getAddress().getCity() != null) {
            String actualSellerCity = req.getSellerInfo().getAddress().getCity();
            String expectedSellerCity = expectedAddressBookResp.getAddresses().get(0).getLocation().getCity();
            softAssert.assertEquals(actualSellerCity, expectedSellerCity, "Seller Location city doesnt match");
        }

        if (req.getSellerInfo().getAddress().getState() != null) {
            String actualSellerState = req.getSellerInfo().getAddress().getState();
            String expectedSellerState = expectedAddressBookResp.getAddresses().get(0).getLocation().getStateOrProvince();
            softAssert.assertEquals(actualSellerState, expectedSellerState, "Seller Location state doesnt match");
        }

        if (req.getSellerInfo().getAddress().getPostalCode() != null) {
            String actualSellerPostalCode = req.getSellerInfo().getAddress().getPostalCode();
            String expectedSellerPostalCode = expectedAddressBookResp.getAddresses().get(0).getLocation().getPostalCode();
            softAssert.assertEquals(actualSellerPostalCode, expectedSellerPostalCode, "Seller Location postalCode doesnt match");
        }

        //CountryCodeEnum countryCodeEnum = CountryCodeEnum.findByAlpha3IsoCountryCode(req.getSellerInfo().getAddress().getCountry());
        //String sellerCountryId = CountryCodeEnum.findByCountry_Name(req.getSellerInfo().getAddress().getCountry());
        //CountryCodeEnum countryCodeEnum = CountryCodeEnum.findByCountryId(sellerCountryId);

        if (req.getSellerInfo().getAddress().getCountry() != null) {
            CountryCodeEnum countryCodeEnum = CountryCodeEnum.findByCountryName(req.getSellerInfo().getAddress().getCountry());

            String actualSellerCountry = null;
            if (!countryCodeEnum.name().isEmpty())
                actualSellerCountry = countryCodeEnum.name();
            String expectedIsoCountryCode = expectedAddressBookResp.getAddresses().get(0).getLocation().getCountry();
//			TODO: Please make use of countryCodeEnum to validate later the changes are done for MESHORD-3096
            softAssert.assertEquals(actualSellerCountry, expectedIsoCountryCode, "Seller Location country doesnt match");
        }

        if (req.getSellerInfo().getAddress().getPhoneNumber() != null) {
            String actualSellerPhoneNumber = req.getSellerInfo().getAddress().getPhoneNumber();
            String expectedSellerPhoneNumber = expectedAddressBookResp.getAddresses().get(0).getPhoneNumber();
            softAssert.assertEquals(actualSellerPhoneNumber, expectedSellerPhoneNumber, "SellerPhoneNumber doesnt match");
        }

    }

    private void validateIsTopRatedSeller(PdfDocGenRawDataRequest req, GetUserResponse expectedUserReadSvcResp) {
        breezeReport.logWithColor("Validating IsTopRatedSeller", "blue");
        boolean isTopRatedSeller = false;
        List<Extension> extensions = expectedUserReadSvcResp.getData().getUser().get(0).getExtensions();
        List<Extension> filteredList = Optional.ofNullable(extensions)
                .orElse(new ArrayList<>())
                .stream()
                .filter(extn -> ExtentionKeyEnum.getAll().stream().anyMatch(slrRatngEnm -> slrRatngEnm.getName().equals(extn.getKey())))
                .filter(extn -> extn.getValue().equalsIgnoreCase(TRUE))
                .collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(filteredList)) {
            for (Extension extn : filteredList) {
                isTopRatedSeller = SellerRating.isTopRatedSeller(extn, siteEnum);
                if (isTopRatedSeller) break;
            }
        }
        boolean actualValueOfTopRatedSeller = req.getSellerInfo().isTopRatedSeller();
        boolean expectedValueOfTopRatedSeller = isTopRatedSeller;
        softAssert.assertEquals(actualValueOfTopRatedSeller, expectedValueOfTopRatedSeller, "IsTopRatedSeller value doesnt match");
    }

    private void validateOrdersOfPdfDocGenRawData(PdfDocGenRawDataRequest req, CosmosResponse expectedCosmosResp, 
    		ValidateInput input, LabelServiceResponse dataFromLabelService, String propFile) throws Exception {
        breezeReport.logWithColor("Validating OrderPdfDocGenRawData", "blue");
        List<String> inputOrderIds = allOrders(dataFromLabelService, input.getOrders());
        List<String> labels = input.getLabels();
        Map<String, OrderAddresses> labelServiceAddressesPerOrderId = new HashMap<>();
        if (dataFromLabelService != null) {
            dataFromLabelService.getDetails().stream().map(Optional::ofNullable)
                    .forEach(packingSlipDetail -> {
                        OrderAddresses addresses = new OrderAddresses();
                        addresses.setToAddress(packingSlipDetail.map(LabelServiceDetails::getTo).orElse(null));
                        addresses.setFromAddress(packingSlipDetail.map(LabelServiceDetails::getFrom).orElse(null));
                        packingSlipDetail.map(LabelServiceDetails::getOrderIds).orElse(Collections.emptyList()).forEach(orderId -> {
                            labelServiceAddressesPerOrderId.put(orderId, addresses);
                        });
                    });
        }
        List<MembersC> members = expectedCosmosResp.getMembers();
        List<PdfDocOrders> actualOrders = req.getOrders();
        PdfDocOrders actualOrder;
        MembersC expectedOrder;
        for (String inputOrderId : inputOrderIds) {
            actualOrder = null;
            expectedOrder = null;
            for (PdfDocOrders pdfDocOrder : actualOrders) {
                if (inputOrderId.equals(pdfDocOrder.getOrderId())) {
                    actualOrder = pdfDocOrder;
                    break;
                }
            }
            for (MembersC member : members) {
                String orderId = member.getIdentifier().getPublicContractId();
                if (inputOrderId.equals(orderId) && member.getContractType().equals("ORDER")) {
                    expectedOrder = member;
                    if (CollectionUtils.isNotEmpty(labels)) {
                        if (labelServiceAddressesPerOrderId.get(orderId) != null) {
                            Address toAddress = labelServiceAddressesPerOrderId.get(orderId).getToAddress();
                            com.ebay.orders.list.cosmos.pojo.Address cosmosAddress = new com.ebay.orders.list.cosmos.pojo.Address();
                            cosmosAddress.setAddressLine1(toAddress.getAddressLine1());
                            cosmosAddress.setCity(toAddress.getCity());
                            cosmosAddress.setStateOrProvince(toAddress.getStateOrProvince());
                            cosmosAddress.setPostalCode(toAddress.getPostalCode());
                            cosmosAddress.setCountry(toAddress.getCountry());
                            for (DestinationAddress address : expectedOrder.getOrder().getAddress()) {
                                address.setAddress(cosmosAddress);
                            }
                        }
                    }
                    break;
                }
            }
            if ((null != actualOrder) && (null != expectedOrder)) {
                breezeReport.logStep("Actual order info text: " + actualOrder.getOrderId());
                breezeReport.logStep("Expected order info text: " + expectedOrder.getIdentifier().getPublicContractId());
                softAssert.assertEquals(actualOrder.getOrderId(), expectedOrder.getIdentifier().getPublicContractId(), "Order info text is not correct");

//				validateCostBreakDown(actualOrder.getPriceLines(), expectedOrder.getOrder());
                if (input.isPicklistEligible()) {
                    if (CollectionUtils.isEmpty(labels)) {
                        validatePickListItemPdfDocGen(actualOrder.getItems(), expectedOrder.getOrder());
                    }
                } else {
                    softAssert.assertFalse(req.getOrders().get(0).isPickListEligible());
                    breezeReport.logWithColor("Not eligible for pick list", "brown");
                }

                validateShipToAddress(input, actualOrder.getShipToAddress(), expectedOrder);
                if(input.getMode() == null)
                	validateShipToAddressEmailAddress(req,actualOrder.getShipToAddress(),expectedOrder, propFile);
                if (expectedOrder.getOrder().getPrograms().size() >= 1) {
                    validateGspReferenceId(actualOrder.getGspReferenceId(), expectedOrder.getOrder());
                }
                
                //validate ShippingMethod
                String actShipMethod = actualOrder.getShippingMethod();
                String expShipMethod = expectedOrder.getOrder().getLogistics().get(0).getSteps().get(0).getStepExtension()
                		.getShippingStep().getShippingOptions().get(0).getShipppingMethod().getShippingMethodCode().getDisplayName();
                assertLog(actShipMethod, expShipMethod, "ShippingMethod");
                
                if (actualOrder.getPriceLines() != null) {
            		validateTotalCost(expectedOrder, actualOrder, req, input, propFile);
            		softAssert.assertAll();
            	}
                
                validateTAXDetails_Disclaimer(actualOrder.getAttributes(), expectedOrder.getOrder().getAttributes(), 
                		input, expectedOrder.getOrder().getBuyer(), propFile);
            }
        }
    }

    
	private void validateTaxInfo(Order order, PdfDocGenRawDataRequest req, String tempDoc) {
		
		breezeReport.logWithColor("----- Validating Tax Info Preferences -----", "blue");
		String orderReceiptVat = null, packingSlipVat = null;
		List<ItemInfo> reqItems = req.getOrders().get(0).getItems();
		DecimalFormat df = new DecimalFormat("0.00");
		if(reqItems.size() > 1) {
			for( int i = 0; i < reqItems.size(); i++) {
                breezeReport.logStep("Item ID: " + reqItems.get(i).getItemId());
    			String expVatPercent = String.format("%.2f",order.getLineItemTypes().get(i).getTax().getSalesTaxPercentage());
                packingSlipVat = reqItems.get(i).getVatPercentForPackingSlip();
    			Float tempPsVat = Float.parseFloat(packingSlipVat);
    			packingSlipVat = df.format(tempPsVat);
                orderReceiptVat = reqItems.get(i).getVatPercentForOrderReceipt();
    			Float tempOrVat = Float.parseFloat(orderReceiptVat);
    			orderReceiptVat = df.format(tempOrVat);
    			if (packingSlipVat != null && tempDoc.equalsIgnoreCase("PACKING_SLIP"))
    				assertLog(packingSlipVat, expVatPercent, "VatPercentForPackingSlip");
    			else if (orderReceiptVat != null && tempDoc.equalsIgnoreCase("ORDER_RECEIPT"))
    				assertLog(orderReceiptVat, expVatPercent, "VatPercentForOrderReceipt");
			}
		} else { 
			df.setMaximumFractionDigits(2);
			if(reqItems.get(0).getVatPercentForPackingSlip() != null) {
			packingSlipVat = reqItems.get(0).getVatPercentForPackingSlip();
			Float tempPsVat = Float.parseFloat(packingSlipVat);
			packingSlipVat = df.format(tempPsVat);
		}
			orderReceiptVat = reqItems.get(0).getVatPercentForOrderReceipt();
			Float tempOrVat = Float.parseFloat(orderReceiptVat);
			orderReceiptVat = df.format(tempOrVat);
			String expVatPercent = String.format("%.2f",order.getLineItemTypes().get(0).getTax().getSalesTaxPercentage());
			if (packingSlipVat != null && tempDoc.equalsIgnoreCase("PACKING_SLIP"))
				assertLog(packingSlipVat, expVatPercent, "VatPercentForPackingSlip");
			else if (orderReceiptVat != null && tempDoc.equalsIgnoreCase("ORDER_RECEIPT"))
				assertLog(orderReceiptVat, expVatPercent, "VatPercentForOrderReceipt");
		}
		
		if (req.getOrders().get(0).getInvoiceNumber() != null && order.getExtendedIdentifiers() != null) {
				if (order.getExtendedIdentifiers().get(0).getType().equalsIgnoreCase("SELLER_TAX_INVOICE_ID")) {
					String actInvoiceNum = req.getOrders().get(0).getInvoiceNumber();
					String expInvoiceNum = order.getExtendedIdentifiers().get(0).getBaseIdentifier();
					assertLog(actInvoiceNum, expInvoiceNum, tempDoc + " TaxInvoiceNumber");
			}
		}
		
		if (req.getOrders().get(0).getSellerVatId() != null) {
			String actSelectedVatId = req.getOrders().get(0).getSellerVatId();
			for (String id : sellerVatId) {
				if (actSelectedVatId.equalsIgnoreCase(id)) {
					assertLog(actSelectedVatId, id, tempDoc + " Selected VAT ID");
					break;
				}
			}
		}
	}

	private void validateTAXDetails_Disclaimer(Map<String, String> attributesMap, List<Attributes> cAttributesList, 
			ValidateInput input, Buyer buyer, String propFile) throws Exception {
		
		breezeReport.logWithColor("----- Validating Tax Details & Disclaimer -----", "blue");

		String taxPartner = null, collectedTaxPaidStatus = null, taxType = null, taxSubType = null, 
				eBayTaxIdentity = null, taxState = null, expTaxNumber = null, expVatInfo = null;
		
		for(Attributes cList: cAttributesList) {
			switch(cList.getName()) {
			case "hasTaxPartner" :
				taxPartner = cList.getValue();
				break;
				
			case "CollectedTaxPaidStatus" :
				collectedTaxPaidStatus = cList.getValue();
				break;
				
			case "taxType" :
				taxType = cList.getValue();
				break;
				
			case "taxSubType" :
				taxSubType = cList.getValue();
				break;
				
			case "eBayTaxIdentity" :
				eBayTaxIdentity = cList.getValue();
				break;
				
			case "taxState" :
				taxState = cList.getValue();
				break;
			}
		}
		
		if (eBayTaxIdentity != null && taxSubType != null && !taxSubType.equalsIgnoreCase("DDG")) {
			GetUserRequest userRequest = buildUserRequest(input, eBayTaxIdentity, true);
			GetUserResponse expectedUserReadSvcResp = getUserReadSvcResponse(input, input.getSellerName(), userRequest, true);
			expTaxNumber = expectedUserReadSvcResp.getData().getUser().get(0).getBusinessIdentityProfile().getGovtIssuedIds().get(1).getGovtIssuedIdValue();
			
			StringBuilder result = new StringBuilder();
			for(int i = 0 ; i < expTaxNumber.length(); i++)
			{
			   result = result.append(expTaxNumber.charAt(i));
			   if(i == expTaxNumber.length()-1)
			      break;
			   else if ((i == 5) || (i == 9))
				   result = result.append(' ');
			}
			expTaxNumber = result.toString();
			expVatInfo = collectedTaxPaidStatus + ": " + taxSubType + " - " + expTaxNumber;
		}
		
		for (String name : attributesMap.keySet()) {
			String val = null, actTaxSubType = null, actTaxNumber = null, actVatInfo = null; 
			
			if (name.equals("hasTaxPartner")) {
				val = attributesMap.get(name);
				assertLog(val, taxPartner, "TaxPartner");
			} else if (name.equals("taxPaidStatus")) {
				val = attributesMap.get(name);
				assertLog(val, collectedTaxPaidStatus, "TaxPaidStatus");
			} else if (name.equals("taxType")) {
				val = attributesMap.get(name);
				assertLog(val, taxType, "TaxType");
			} else if (name.equals("eBayTaxIdentity")) {
				val = attributesMap.get(name);
				assertLog(val, eBayTaxIdentity, "eBayTaxIdentity");
			} else if (name.equals("taxState")) {
				val = attributesMap.get(name);
				assertLog(val, taxState, "TaxState");
			} else if (name.equals("taxNumber")) {
				actTaxNumber = attributesMap.get(name);
				assertLog(actTaxNumber, expTaxNumber, "TaxNumber");
			} else if (name.equals("VAT_INFO")) {
				actVatInfo = attributesMap.get(name);
				assertLog(actVatInfo, expVatInfo, "VAT_INFO");
			} else if (name.equals("taxSubType")) {
				actTaxSubType = attributesMap.get(name);
				assertLog(actTaxSubType, taxSubType, "TaxSubType");
			} else if (name.equals("DISCLAIMER") && taxSubType != null) {
				val = "**" + attributesMap.get(name);
				if (taxSubType.equalsIgnoreCase("DDG")) {
					if (taxState.equalsIgnoreCase("UK"))
						assertLog(val,  L10n.content(propFile, "UK_VAT_DDG_DISCLAIMER"), "Disclaimer");
					else if (taxState.equalsIgnoreCase("EU"))
						assertLog(val,  L10n.content(propFile, "EU_VAT_DDG_DISCLAIMER"), "Disclaimer");
				} else if (taxSubType.equalsIgnoreCase("OSS")){
					if (taxState.equalsIgnoreCase("UK"))
						assertLog(val,  L10n.content(propFile, "UK_VAT_DISCLAIMER"), "Disclaimer");
					else if (taxState.equalsIgnoreCase("EU"))
						assertLog(val,  L10n.content(propFile, "EU_VAT_DISCLAIMER"), "Disclaimer");
				}		
			} 
		}
	}

	private void assertLog(String actVal, String expVal, String keyName) {
		breezeReport.logStep("Actual " + keyName + " value: " + actVal);
		breezeReport.logStep("Expected " + keyName + " value: " + expVal);
		softAssert.assertEquals(actVal, expVal, keyName + " value does not match");	
	}

	private void validateTotalCost(MembersC expectedOrder, PdfDocOrders actualOrder, PdfDocGenRawDataRequest req, 
			ValidateInput input, String propFile) {
   		
		String expOrderTotal = "0.00";
       	breezeReport.logWithColor("Validating TotalCost", "blue");
   		setFlags(expectedOrder);
   		String expCurrency = expectedOrder.getOrder().getOrderTotal().getAmount().getCurrency();
   		if(expCurrency.equalsIgnoreCase("GBP") || expCurrency.equalsIgnoreCase("EUR"))
   			expCurrency = expCurrency + " ";
   		else {
   			expCurrency = getCurrencyBasedOnCountry(expCurrency);
   			if (expCurrency.equalsIgnoreCase("AUD"))
   				expCurrency = "AU " + expCurrency;
   		}
   		
   		expOrderTotal = getAmountWithCurrency(expCurrency, expectedOrder.getOrder().getOrderTotal().getAmount().getValue());
   		
   		// Get Expected Total Cost Breakdown
   		getExpectedOrderPriceLines(expCurrency, expectedOrder, expOrderTotal);
   		
   		// Get Actual Total Cost Breakdown
   		getActualOrderPriceLines(actualOrder);
   		
   		expSalesTax = getAmountWithCurrency(expCurrency, 0.00);
   		for (int i = 0; i < req.getDocuments().size(); i++) {
   			if (req.getDocuments().get(i) != null) {

   				String tempDoc = req.getDocuments().get(i).getValue();
   				if (tempDoc.equalsIgnoreCase(ValidateEnum.PACKING_SLIP.toString()) || tempDoc.equalsIgnoreCase(L10n.content(propFile,"Packing_Slip_GB"))) {
   					if(input.getSite().equalsIgnoreCase("GB"))
   						//validate TaxInfo
   						validateTaxInfo(expectedOrder.getOrder(), req, tempDoc);
   					validateTotal(expCurrency, actPackingSlip_ShipCost, actPackingSlip_Total, tempDoc, expOrderTotal, expItemSubTotal, expShippingCost, expectedOrder.getOrder(), input.getSite());
   				} else if (tempDoc.equalsIgnoreCase(ValidateEnum.ORDER_RECEIPT.toString())) {
   					if(input.getSite().equalsIgnoreCase("GB"))
   						//validate TaxInfo
   						validateTaxInfo(expectedOrder.getOrder(), req, tempDoc);
   					if (!isGSP)    						
   						validateTotal(expCurrency, actOrderReceipt_Shipcost, actOrderReceipt_Total, tempDoc, expOrderTotal, expItemSubTotal, expShippingCost, expectedOrder.getOrder(), input.getSite());
   					else 
   						validateOrderReceiptTotal(expectedOrder, expCurrency, tempDoc, expItemSubTotal, expShippingCost,
   								actOrderReceipt_Shipcost, actOrderReceipt_Total, expOrderTotal, expRefundAmt, input.getSite());	
   				}
   			}
   		}
   		sellerVatId.clear();
   		breezeReport.logWithColor("----- Validate TotalCost Done -----", "green");
   	}

	private void validateTotal(String expCurrency, String act_ShippingCost, String act_Total, String tempDoc, String expOrderTotal, String expItemSubTotal,
			String expShippingCost, Order order, String site) {
		
		breezeReport.logWithColor("----- Validating " + tempDoc + " TotalCost -----", "blue");
   		breezeReport.logStep("Actual SubTotal: " + actItemCost);
		breezeReport.logStep("Expected SubTotal: " + expItemSubTotal);
		softAssert.assertEquals(actItemCost, expItemSubTotal, "SubTotal does not match");

		breezeReport.logStep("Actual Shipping Cost: " + act_ShippingCost);
		//if (order.getLineItemTypes().get(0).getTax().getSalesTaxPercentage() != 0.00 && !site.equalsIgnoreCase("US")) {
		if (isSellerVatId && !isVat && !site.equalsIgnoreCase("US")) {
			Double vatPercent = order.getLineItemTypes().get(0).getTax().getSalesTaxPercentage();
			String temp_expShippingCost = expShippingCost;
			String eShip_Cost = temp_expShippingCost.split(" ")[1];
			String aShip_Cost = act_ShippingCost.split(" ")[1];
			String cal_ShipCost = calShippingCost(eShip_Cost, vatPercent, aShip_Cost);
			expShippingCost = temp_expShippingCost.split(" ")[0] + " " + cal_ShipCost;
			breezeReport.logStep("Expected Shipping Cost: " +  cal_ShipCost );
		} else
			breezeReport.logStep("Expected Shipping Cost: " + expShippingCost);
		softAssert.assertEquals(act_ShippingCost, expShippingCost, "Shipping Cost does not match");

		if(!isGSP && actSalesTaxEbayCollected != null && actSalesTaxEbayCollected != "0.00") {
			breezeReport.logStep("Actual Sales Tax (eBay Collected): " + actSalesTaxEbayCollected);
			breezeReport.logStep("Expected Sales Tax (eBay Collected): " + expItemTax);
			softAssert.assertEquals(actSalesTaxEbayCollected, expItemTax, "Sales Tax EbayCollected does not match");
        }
       
		if (actImportCharges != null && actImportCharges != "0.00") {
			breezeReport.logStep("Actual Import Charges: " + actImportCharges);
			breezeReport.logStep("Expected Import Charges: " + expImportCharges);
			softAssert.assertEquals(actImportCharges, expImportCharges, "Import Charges does not match");
		}
       
		if (isVat) {
			if(actVAT.equals("0.00"))
					actVAT = expCurrency + actVAT;
			breezeReport.logStep("Actual VAT: " + actVAT);
			double tempVat = expImportTax + expShippingImportTax;
			expVAT = getAmountWithCurrency(expCurrency,tempVat);
			breezeReport.logStep("Expected VAT: " + expVAT);
			softAssert.assertEquals(actVAT, expVAT, "VAT does not match");
		} else {
			if(actSalesTax != null && actSalesTax != "0.00") {
				if (expItemTax != "0.00") {
					breezeReport.logStep("Actual Sales Tax: " + actSalesTax);
					breezeReport.logStep("Expected Sales Tax: " + expItemTax);
	                softAssert.assertEquals(actSalesTax, expItemTax, "Sales Tax does not match");
	            } else if(expSalesTax != "0.00"){
	            	breezeReport.logStep("Actual Sales Tax: " + actSalesTax);
	                breezeReport.logStep("Expected Sales Tax: " + expSalesTax);
	                softAssert.assertEquals(actSalesTax, expSalesTax, "Sales Tax does not match");
	            }
			}
		}
		
		if (actDiscount != null) {
			breezeReport.logStep("Actual Discount: " + actDiscount);
			if (!hasPromotion && expShippingDiscount != null) {
				breezeReport.logStep("Expected Discount: " + expShippingDiscount);
				softAssert.assertEquals(actDiscount, expShippingDiscount, "Discount Cost does not match");
			} 
			if (hasPromotion) {
				breezeReport.logStep("Expected Discount: " + expPromotion);
				softAssert.assertEquals(actDiscount, expPromotion, "Promotion Discount Cost does not match");
			}
		}
		
		if (isCancelRefund) {
			if (tempDoc.equalsIgnoreCase(ValidateEnum.PACKING_SLIP.toString())) {
				breezeReport.logStep("Actual Order Cancelled Total: " + actPackingSlip_OrderCancelled);
				breezeReport.logStep("Expected Order Cancelled Total: " + expRefundAmt);
				softAssert.assertEquals(actPackingSlip_OrderCancelled, expRefundAmt, tempDoc + " Order Cancelled Total Cost does not match");
			} else if (tempDoc.equalsIgnoreCase(ValidateEnum.ORDER_RECEIPT.toString())) {
				breezeReport.logStep("Actual Order Cancelled Total: " + actOrderReceipt_OrderCancelled);
				breezeReport.logStep("Expected Order Cancelled Total: " + expRefundAmt);
				softAssert.assertEquals(actOrderReceipt_OrderCancelled, expRefundAmt, tempDoc + " Order Cancelled Total Cost does not match");
			}
			breezeReport.logStep("Actual " + tempDoc + " Total: " + act_Total);
			breezeReport.logStep("Expected  " + tempDoc + " Total: " + expTotAfterRefundCancel);
			softAssert.assertEquals(act_Total, expTotAfterRefundCancel, tempDoc + " Total Cost does not match");
		} else if (isPartialRefund){
			if (tempDoc.equalsIgnoreCase(ValidateEnum.ORDER_RECEIPT.toString())) {
				breezeReport.logStep("Actual Order Partial Refund Amount: " + actOrderReceipt_RefundAmt);
				breezeReport.logStep("Expected Order Partial Refund Amount: " + expRefundAmt);
				softAssert.assertEquals(actOrderReceipt_RefundAmt, expRefundAmt, tempDoc + " Order Partial Refund Amount does not match");
			} else if (tempDoc.equalsIgnoreCase(ValidateEnum.PACKING_SLIP.toString())) {
				breezeReport.logStep("Actual Order Partial Refund Amount: " + actPackingSlip_RefundAmt);
				breezeReport.logStep("Expected Order Partial Refund Amount: " + expRefundAmt);
				softAssert.assertEquals(actPackingSlip_RefundAmt, expRefundAmt, tempDoc + " Order Partial Refund Amount does not match");
			}
			breezeReport.logStep("Actual " + tempDoc + " Total: " + act_Total);
			breezeReport.logStep("Expected  " + tempDoc + " Total: " + expTotAfterRefundCancel);
			softAssert.assertEquals(act_Total, expTotAfterRefundCancel, tempDoc + " Total Cost does not match");
		} else {
			breezeReport.logStep("Actual " + tempDoc + " Total: " + act_Total);
			breezeReport.logStep("Expected  " + tempDoc + " Total: " + expOrderTotal);
			softAssert.assertEquals(act_Total, expOrderTotal, tempDoc + " Total Cost does not match");
		}
		softAssert.assertAll();
	}

	private String calShippingCost(String eShip_Cost, Double vatPercent, String aShip_Cost) {
		double exp_ShipCost = Double.valueOf(eShip_Cost);
		double act_ShipCost = Double.valueOf(aShip_Cost);
		double tempPercent = vatPercent / 100;
		double shipCost = exp_ShipCost - (tempPercent * act_ShipCost);
		DecimalFormat df = new DecimalFormat("0.00");
		df.setMaximumFractionDigits(2);
		return String.valueOf(df.format(shipCost));
	}

	private void getExpectedOrderPriceLines(String expCurrency, MembersC expectedOrder, String expOrderTotal) {
		
		expItemTax = "0.00";
		expImportCharges = "0.00";
		expImportTax = 0.00;
		expShippingImportTax = 0.00;
		expPromotion = "0.00";
   		List<PriceLines> cosmosPriceLines = expectedOrder.getOrder().getOrderTotal().getPriceLines();
   		for (PriceLines priceLine : cosmosPriceLines) {
   			
   			if(priceLine.getType().equalsIgnoreCase("ITEM_COST"))
   				expItemSubTotal = getAmountWithCurrency(expCurrency,priceLine.getAmount().getValue());
   			
   			else if(priceLine.getType().equalsIgnoreCase("SHIPPING_COST"))
   				expShippingCost = getAmountWithCurrency(expCurrency,priceLine.getAmount().getValue());
   			
   			else if(priceLine.getType().equalsIgnoreCase("IMPORT_CHARGES"))
   				expImportCharges = getAmountWithCurrency(expCurrency,priceLine.getAmount().getValue());
   			
   			else if(priceLine.getType().equalsIgnoreCase("ITEM_TAX"))
   				expItemTax = getAmountWithCurrency(expCurrency,priceLine.getAmount().getValue());
   			
   			else if(priceLine.getType().equalsIgnoreCase("SHIPPING_TAX"))
   				expShippingTax = getAmountWithCurrency(expCurrency,priceLine.getAmount().getValue());
   			
   			else if(priceLine.getType().equalsIgnoreCase("SHIPPING_DISCOUNT"))
   				expShippingDiscount = getAmountWithCurrency(expCurrency,priceLine.getAmount().getValue());
   			
   			else if(priceLine.getType().equalsIgnoreCase("PROMOTION"))
   				expPromotion = "-" + getAmountWithCurrency(expCurrency,priceLine.getAmount().getValue());
   			
   			else if(priceLine.getType().equalsIgnoreCase("IMPORT_TAX"))
   				expImportTax = priceLine.getAmount().getValue();
   			
   			else if(priceLine.getType().equalsIgnoreCase("SHIPPING_IMPORT_TAX"))
   				expShippingImportTax = priceLine.getAmount().getValue();
   			
   		}
           
   		if (isCancelRefund || isPartialRefund) {
   			if(expectedOrder.getOrder().getAdjustments().get(0).getTypeExtension().getPaymentAdjustment().getDistribution() != null) {
   				expRefundAmt = getAmountWithCurrency(expCurrency, expectedOrder.getOrder().getAdjustments().get(0).getTypeExtension()
   	   					.getPaymentAdjustment().getDistribution().get(0).getTotalAmount().getAmount().getValue());
   	   	   		expRefundAmt = "-" + expRefundAmt;
   	   	   		double totalAfterRefund = expectedOrder.getOrder().getOrderTotal().getAmount().getValue() - expectedOrder.getOrder()
   	   	   				.getAdjustments().get(0).getTypeExtension().getPaymentAdjustment().getDistribution().get(0).getTotalAmount().getAmount().getValue();
   	   	   		expTotAfterRefundCancel = getAmountWithCurrency(expCurrency, totalAfterRefund);
   	   		} else {
   	   			expRefundAmt = "-" + expOrderTotal;
   	   			expTotAfterRefundCancel = getAmountWithCurrency(expCurrency, 0.00);
   	   		}
   		}	
	}

	private void getActualOrderPriceLines(PdfDocOrders actualOrder) {
		
		List<Attribute> priceLines = actualOrder.getPriceLines();
		actSalesTax = "0.00";
		actSalesTaxEbayCollected = "0.00";
		actImportCharges = "0.00";
		actVAT = "0.00";
   		for (Attribute priceLine : priceLines){
   			switch (priceLine.getKey()) {
   			
   			case "PACKING_SLIP_TOTAL":
            	actPackingSlip_Total = priceLine.getValue();
            	break;
            
   			case "PACKING_SLIP_SHIPPING_COST":
               	actPackingSlip_ShipCost = priceLine.getValue();
               	break;
               	
   			case "ORDER_CANCELED_AMT_FOR_PACKING_SLIP":
               	actPackingSlip_OrderCancelled = "-" + priceLine.getValue();
               	break;
               	
   			case "REFUNDED_AMT_FOR_PACKING_SLIP":
               	actPackingSlip_RefundAmt = "-" + priceLine.getValue();
               	break;
               	
            case "IMPORT_CHARGES":
               	actImportCharges = priceLine.getValue();
               	break;
               	
            case "SALES_TAX_EBAY_COLLECTED":
               	actSalesTaxEbayCollected = priceLine.getValue();
               	break;
               	
            case "SALES_TAX":
               	actSalesTax = priceLine.getValue();
               	break;
               	
            case "ITEM_COST":
               	actItemCost = priceLine.getValue();
               	break;
               
            case "DISCOUNT":
               	actDiscount = priceLine.getValue();
               	break;
               	
            case "ORDER_RECEIPT_TOTAL":
               	actOrderReceipt_Total = priceLine.getValue();
               	break;
               	
            case "ORDER_RECEIPT_SHIPPING_COST":
               	actOrderReceipt_Shipcost = priceLine.getValue();
               	break;
               	
            case "ORDER_CANCELED_AMT_FOR_ORDER_RECEIPT":
               	actOrderReceipt_OrderCancelled = "-" + priceLine.getValue();
               	break;
               	
            case "REFUNDED_AMT_FOR_ORDER_RECEIPT":
               	actOrderReceipt_RefundAmt = "-" + priceLine.getValue();
               	break;
            
            case "VAT_EBAY_COLLECTED":
            	actVAT = priceLine.getValue();
            	break;
               }
   		}		
	}

	private void setFlags(MembersC expectedOrder) {
		
		isVat = false; hasPromotion = false;
		if (expectedOrder.getOrder() != null) {
			isGSP = false;isPSA = false; isExports = false;
   			if (expectedOrder.getOrder().getPrograms() != null) {
   				for (Program program: expectedOrder.getOrder().getPrograms()) {
   					if (program.getName().equals("GLOBAL_SHIPPING_PROGRAM"))
   						isGSP = true;
   					else if(program.getName().equals("PSA"))
   						isPSA = true;
   					else if(program.getName().equals("Exports"))
   						isExports = true;
   				}
   			}
   			if (expectedOrder.getOrder().getOrderStates() != null) {
   				isCancelRefund = false;
   				isPartialRefund = false;
   				if (expectedOrder.getOrder().getOrderStates().getCancelStatus().equals(ValidateEnum.CANCEL_CLOSED_WITH_REFUND.toString()))
   					isCancelRefund = true;
   				else if (expectedOrder.getOrder().getOrderStates().getRefundStatus().equals(ValidateEnum.PARTIAL_REFUNDED.toString()))
   					isPartialRefund = true;
   			}
   		} else {
   			if (expectedOrder.getProformaOrder().getPrograms() != null) {
   				for (Program program: expectedOrder.getProformaOrder().getPrograms()) {
   					if (program.getName().equals("GLOBAL_SHIPPING_PROGRAM"))
   						isGSP = true;
   				}
   			}
   		}
		
		for (Attributes attribute: expectedOrder.getOrder().getAttributes()) {
			if(attribute.getName().equals("taxType") & attribute.getValue().equals("VAT"))
				isVat = true;
		}
		
		if(expectedOrder.getOrder().getLineItemTypes() != null) {
			List<LineItemTypes> lineItemTypes = expectedOrder.getOrder().getLineItemTypes();
			if (lineItemTypes.size() > 1) {
				for (int i = 0; i < lineItemTypes.size(); i++) {
					if(lineItemTypes.get(i).getPromotions() != null && !lineItemTypes.get(i).getPromotions().isEmpty()) {
						if(lineItemTypes.get(i).getPromotions().get(0).getAmount() != null &&
								lineItemTypes.get(i).getPromotions().get(0).getCode() != null)
							hasPromotion = true;
					}
				}
			} else if (lineItemTypes.get(0).getPromotions() != null && !lineItemTypes.get(0).getPromotions().isEmpty()) {
				if(lineItemTypes.get(0).getPromotions().get(0).getAmount() != null && 
						lineItemTypes.get(0).getPromotions().get(0).getCode() != null)
					hasPromotion = true;
			}
		}
		
		Date expDate  = expectedOrder.getOrder().getCreationDate().getDate();
		Date dMinus90 = DateTime.now().minusDays(90).toDate();
		if (expDate.before(dMinus90) || expDate.equals(dMinus90))
		  isOrderGreater90Days = true;
	}

	
	private void validateOrderReceiptTotal(MembersC expectedOrder, String expCurrency, String tempDoc, String expItemSubTotal,
			String expShippingCost, String actOrderReceipt_Shipcost, String actOrderReceipt_Total, String expOrderTotal,
			String expRefundAmt, String site) {
			
		List<LineItemTypes> lineItemTypes = expectedOrder.getOrder().getLineItemTypes();
		double tempItemCost = 0.0;; double tempDomesticCost = 0.00;
		
   		for (int j =0 ; j < lineItemTypes.size(); j++) {
   			List<PriceLines> cPriceLines = lineItemTypes.get(j).getLineItemTotal().getPriceLines();
   			for (PriceLines cPriceLine : cPriceLines) {
   				if(cPriceLine.getType().equalsIgnoreCase("ITEM_COST")) {
   					tempItemCost += cPriceLine.getAmount().getValue();	   				
   				} else if(cPriceLine.getType().equalsIgnoreCase("DOMESTIC_LEG_COST")) {
   					tempDomesticCost += cPriceLine.getAmount().getValue();
   					break;
   				}
   			}
   		}
   		expItemSubTotal = getAmountWithCurrency(expCurrency,tempItemCost);
		expShippingCost = getAmountWithCurrency(expCurrency,tempDomesticCost);
		expOrderTotal = getAmountWithCurrency(expCurrency,tempItemCost + tempDomesticCost);
		
		validateTotal(expCurrency, actOrderReceipt_Shipcost, actOrderReceipt_Total, tempDoc, expOrderTotal, expItemSubTotal, expShippingCost, expectedOrder.getOrder(), site);
		
   		/*validateTotal(tempDoc, act_ItemCost, expItemSubTotal, actOrderReceipt_Shipcost, expShippingCost, actSalesTaxEbayCollected,
   				expItemTax, actSalesTax, expSalesTax, actImportCharges, expImportCharges, actDiscount, expShippingDiscount,
   				actOrderReceipt_Total, expOrderTotal, actOrderReceipt_OrderCancelled, actPackingSlip_OrderCancelled, isCancelRefund,
   				isPartialRefund, expRefundAmt, actPackingSlip_RefundAmt, actOrderReceipt_RefundAmt);
   			*/
   	}

   	private String getAmountWithCurrency(String expCurrency, double d) {
   		
       	DecimalFormat df = new DecimalFormat("####,###,##0.00");
       	df.setMinimumFractionDigits(2);
       	return (expCurrency + df.format(d));
   	}

   	private String getCurrencyBasedOnCountry(String currency) {

       	Locale locale = null;		  
   	    switch(currency)
   	    {
   	    case "USD":	    	
   	    	locale=new Locale("en", "US");
   	    	break;
   	    
   	    case "GBP":
   	    	locale=new Locale("en", "GB");
   	    	break;
   	   
   	    case "AUD":
   	    	locale=new Locale("en", "AU");
       		break;
   	    
   	    /* case "EUR":
   	    	locale=new Locale("de", "DE");
       		break;
       	*/
       		
       	case "CAD":
   	    	locale=new Locale("en", "CA");
       		break;
   	     
   	    default:
   	    	break;
   	    }
   	    
   	    Currency currencyCode = Currency.getInstance(locale);
   	    return currencyCode.getSymbol(locale);
   	}
    
    private void validateCouponInfo(PdfDocGenRawDataRequest req,
                                    FormatResponse expectedPackingSlipSMEResp,
                                    FormatResponse expectedStandaloneCouponSMEResp,
                                    FormatResponse expectedCouponModuleSMEResp,
                                    String propFile) {
        if (expectedPackingSlipSMEResp == null) {
            softAssert.assertEquals(req.getCouponInfo().getPackingSlipCoupon().getCouponDetail(), null, "packing slip response should not exist");
        } else {
            validatePdfDocGenRawDataModulePackingSlipCouponInfo(req, expectedPackingSlipSMEResp, propFile);
        }

        if (expectedStandaloneCouponSMEResp == null && expectedCouponModuleSMEResp == null) {
            softAssert.assertEquals(req.getCouponInfo().getStandaloneCoupon().getCouponDetail(), null, "standalone coupon response should not exist");
        } else {
            validatePdfDocGenRawDataModuleStandaloneCouponInfo(req, expectedStandaloneCouponSMEResp, propFile);
        }
    }


    private void validatePdfDocGenRawDataModulePackingSlipCouponInfo(PdfDocGenRawDataRequest req, FormatResponse expectedPackingSlipSMEResp, String propFile) {
        DecimalFormat decimalFormat = new DecimalFormat("#.00");
        decimalFormat.setMinimumFractionDigits(2);
        String expectedCouponModuleMaxSaving = decimalFormat.format(expectedPackingSlipSMEResp.getSmeResponse().getMaxCouponDiscountAmount().getValue());
        String expectedCouponModuleMaxSavingStr = "$" + expectedCouponModuleMaxSaving;

        CouponDetail packingSlipCouponDetail = req.getCouponInfo().getPackingSlipCoupon().getCouponDetail();
        softAssert.assertEquals(packingSlipCouponDetail.getCouponMessage(), expectedPackingSlipSMEResp.getSmeResponse().getMessage(), "pdf doc packing slip coupon info message does not match");
        softAssert.assertEquals(packingSlipCouponDetail.getCouponCode(), expectedPackingSlipSMEResp.getSmeResponse().getCouponCode(), "pdf doc packing slip coupon info coupon code does not match");
        softAssert.assertEquals(packingSlipCouponDetail.getValidDate(), expectedPackingSlipSMEResp.getFormatValidEndDate(), "pdf doc packing slip coupon info valid date does not match");
        softAssert.assertEquals(packingSlipCouponDetail.getCouponType(), expectedPackingSlipSMEResp.getSmeResponse().getType(), "pdf doc packing slip coupon info coupon type does not match");
//        TODO getCouponBudget coming from wrong value
//        softAssert.assertEquals(packingSlipCouponDetail.getCouponBudget(), expectedCouponModuleMaxSavingStr);
        softAssert.assertEquals(packingSlipCouponDetail.getMaxRedemptionPerUser(), expectedPackingSlipSMEResp.getSmeResponse().getMaxCouponRedemptionPerUser(), "pdf doc packing slip coupon info max coupon redemption per user does not match");
        softAssert.assertNotNull(packingSlipCouponDetail.getCouponURL(), "Coupon url is null");
        softAssert.assertNotNull(packingSlipCouponDetail.getCouponURLForQRCode(), "Coupon url for QR code is null");
        softAssert.assertEquals(packingSlipCouponDetail.getTermsURL(), L10n.content(propFile, "Coupon_Terms_Url"), "Terms url do not match");
    }

    private void validatePdfDocGenRawDataModuleStandaloneCouponInfo(PdfDocGenRawDataRequest req, FormatResponse expectedStandaloneCouponSMEResp, String propFile) {
        DecimalFormat decimalFormat = new DecimalFormat("#.00");
        decimalFormat.setMinimumFractionDigits(2);
        String expectedCouponModuleMaxSaving = decimalFormat.format(expectedStandaloneCouponSMEResp.getSmeResponse().getMaxCouponDiscountAmount().getValue());
        String expectedCouponModuleMaxSavingStr = "$" + expectedCouponModuleMaxSaving;

        CouponDetail standaloneCouponDetail = req.getCouponInfo().getStandaloneCoupon().getCouponDetail();
        softAssert.assertEquals(standaloneCouponDetail.getCouponMessage(), expectedStandaloneCouponSMEResp.getSmeResponse().getMessage(), "pdf doc standalone coupon info message does not match");
        softAssert.assertEquals(standaloneCouponDetail.getCouponCode(), expectedStandaloneCouponSMEResp.getSmeResponse().getCouponCode(), "pdf doc standalone coupon info coupon code does not match");
        softAssert.assertEquals(standaloneCouponDetail.getValidDate(), expectedStandaloneCouponSMEResp.getFormatValidEndDate(), "pdf doc standalone coupon info valid date does not match");
        softAssert.assertEquals(standaloneCouponDetail.getCouponType(), expectedStandaloneCouponSMEResp.getSmeResponse().getType(), "pdf doc standalone coupon info coupon type does not match");
//      TODO getCouponBudget coming from wrong value
//      softAssert.assertEquals(standaloneCouponDetail.getCouponBudget(), expectedCouponModuleMaxSavingStr);
        softAssert.assertEquals(standaloneCouponDetail.getMaxRedemptionPerUser(), expectedStandaloneCouponSMEResp.getSmeResponse().getMaxCouponRedemptionPerUser(), "pdf doc standalone coupon info max coupon redemption per user does not match");
        softAssert.assertNotNull(standaloneCouponDetail.getCouponURL(), "Coupon url is null");
        softAssert.assertNotNull(standaloneCouponDetail.getCouponURLForQRCode(), "Coupon url for QR code is null");
        softAssert.assertEquals(standaloneCouponDetail.getTermsURL(), L10n.content(propFile, "Coupon_Terms_Url"), "Terms url do not match");
    }

    private void validateCostBreakDown(List<Attribute> priceLines, Order order) {
        String refundStatus = order.getOrderStates().getRefundStatus();
        breezeReport.logWithColor("validate PriceLines", "blue");

        DecimalFormat df = new DecimalFormat("####,###,##0.00");
        df.setMinimumFractionDigits(2);
        String expectedCurrency = null, expectedCurrencyConverted = null, site = null;
        List<PriceLines> expPriceLines = new ArrayList<PriceLines>();

        for (Attribute price : priceLines) {
            breezeReport.logWithColor("price.getKey() " + price.getKey(), "brown");
            if (refundStatus.equals("PARTIAL_REFUNDED") || refundStatus.equals("REFUNDED")) {
                switch (price.getKey()) {
                    case "refundedAmtForPackingSlip":
                        String ExpectedRefundedAmtForPackingSlip = df.format(order
                                .getOrderTotalSummary().getRefundTotal().getValue());
                        softAssert.assertEquals(price.getValue(), ExpectedRefundedAmtForPackingSlip,
                                "price value Not matched");
                        break;
                    case "refundedAmtForOrderReceipt":
                        double ExpectedRefundedAmtForOrderReceipt = order
                                .getPayments().getDistribution().get(0).getTotalAmount().getAmount().getValue();
                        softAssert.assertEquals(price.getValue(), ExpectedRefundedAmtForOrderReceipt,
                                "price value Not matched");
                        break;
                }
            }
            switch (price.getKey()) {
                case "PACKING_SLIP_SHIPPING_COST":
                    expectedCurrency = order.getOrderTotalSummary().getOriginalShippingCost().getCurrency();
                    expectedCurrencyConverted = order.getOrderTotalSummary().getOriginalShippingCost().getConvertedFromCurrency();
                    site = expectedCurrencyConverted == null ? getCountryBasedOnCurrency(expectedCurrency) : getCountryBasedOnCurrency(expectedCurrencyConverted);
                    String ExpectedPackingSlipShippingCost = df.format(order
                            .getOrderTotalSummary().getOriginalShippingCost().getValue());

                    if (site.equals("US"))
                        ExpectedPackingSlipShippingCost = getCurrencySymbol(site) + ExpectedPackingSlipShippingCost;
                    else
                        ExpectedPackingSlipShippingCost = expectedCurrency + " " + getCurrencySymbol(site) + ExpectedPackingSlipShippingCost;

                    softAssert.assertEquals(price.getValue(), ExpectedPackingSlipShippingCost, "Packing slip shipping cost value Not matched");
                    break;
                case "SALES_TAX_EBAY_COLLECTED":
                    double salesTax = 0.00;
                    String EbayCollectedTax = null;

                    if (order.getPayments().getDistribution() != null) {
                        for (Distribution distribution : order.getPayments().getDistribution()) {
                            if (distribution.getPriceLines() != null)
                                expPriceLines.addAll(distribution.getPriceLines());
                        }
                    } else if (order.getOrderTotal().getPriceLines() != null) {
                        expPriceLines = order.getOrderTotal().getPriceLines();
                    }

                    for (int i = 0; i < expPriceLines.size(); i++) {
                        if (expPriceLines.get(i).getType().equalsIgnoreCase("SALES_TAX")
                                || expPriceLines.get(i).getType().equalsIgnoreCase("ITEM_TAX")
                                || expPriceLines.get(i).getType().equalsIgnoreCase("SHIPPING_TAX")
                                || expPriceLines.get(i).getType().equalsIgnoreCase("IMPORT_TAX")
                                || expPriceLines.get(i).getType().equalsIgnoreCase("SHIPPING_IMPORT_TAX")
                                || expPriceLines.get(i).getType().equalsIgnoreCase("HANDLING_TAX")) {
                            salesTax += expPriceLines.get(i).getAmount().getValue();
                            expectedCurrency = expPriceLines.get(i).getAmount().getCurrency();
                            expectedCurrencyConverted = expPriceLines.get(i).getAmount().getConvertedFromCurrency();
                            site = expectedCurrencyConverted == null ? getCountryBasedOnCurrency(expectedCurrency) : getCountryBasedOnCurrency(expectedCurrencyConverted);
                        }
                    }

                    if (site.equals("US"))
                        EbayCollectedTax = getCurrencySymbol(site) + df.format(salesTax);
                    else
                        EbayCollectedTax = expectedCurrency + " " + getCurrencySymbol(site) + df.format(salesTax);

                    softAssert.assertEquals(price.getValue(), EbayCollectedTax, "Sales tax ebay collected value Not matched");
                    break;
                case "IMPORT_CHARGES":
                    expectedCurrency = order.getOrderTotalSummary().getTotal().getPriceLines().get(2).getAmount().getCurrency();
                    expectedCurrencyConverted = order.getOrderTotalSummary().getTotal().getPriceLines().get(2).getAmount().getConvertedFromCurrency();
                    site = expectedCurrencyConverted == null ? getCountryBasedOnCurrency(expectedCurrency) : getCountryBasedOnCurrency(expectedCurrencyConverted);
                    String ExpectedImportCharges = df.format(order.getOrderTotalSummary()
                            .getTotal().getPriceLines().get(2).getAmount().getValue());

                    if (site.equals("US"))
                        ExpectedImportCharges = getCurrencySymbol(site) + ExpectedImportCharges;
                    else
                        ExpectedImportCharges = expectedCurrency + " " + getCurrencySymbol(site) + ExpectedImportCharges;

                    softAssert.assertEquals(price.getValue(), ExpectedImportCharges, "Import charges price value Not matched");
                    break;
                case "ITEM_COST":
                    expectedCurrency = order.getOrderTotal().getPriceLines().get(0).getAmount().getCurrency();
                    expectedCurrencyConverted = order.getOrderTotal().getPriceLines().get(0).getAmount().getConvertedFromCurrency();
                    site = expectedCurrencyConverted == null ? getCountryBasedOnCurrency(expectedCurrency) : getCountryBasedOnCurrency(expectedCurrencyConverted);
                    String ExpectedItemCost = df.format(order.getOrderTotal()
                            .getPriceLines().get(0).getAmount().getValue());

                    if (site.equals("US"))
                        ExpectedItemCost = getCurrencySymbol(site) + ExpectedItemCost;
                    else
                        ExpectedItemCost = expectedCurrency + " " + getCurrencySymbol(site) + ExpectedItemCost;

                    softAssert.assertEquals(price.getValue(), ExpectedItemCost, "Item cost price value Not matched");
                    break;
                case "ORDER_RECEIPT_SHIPPING_COST":
                    expectedCurrency = order.getPayments().getDistribution().get(0).getPriceLines().get(1).getAmount().getCurrency();
                    expectedCurrencyConverted = order.getPayments().getDistribution().get(0).getPriceLines().get(1).getAmount().getConvertedFromCurrency();
                    site = expectedCurrencyConverted == null ? getCountryBasedOnCurrency(expectedCurrency) : getCountryBasedOnCurrency(expectedCurrencyConverted);
                    String ExpectedOrderReceiptShippingCost = df.format(order
                            .getPayments().getDistribution().get(0).getPriceLines().get(1).getAmount().getValue());

                    if (site.equals("US"))
                        ExpectedOrderReceiptShippingCost = getCurrencySymbol(site) + ExpectedOrderReceiptShippingCost;
                    else
                        ExpectedOrderReceiptShippingCost = expectedCurrency + " " + getCurrencySymbol(site) + ExpectedOrderReceiptShippingCost;

                    softAssert.assertEquals(price.getValue(), ExpectedOrderReceiptShippingCost, "Order receipt shipping cost price value Not matched");
                    break;
                case "PACKING_SLIP_TOTAL":
                    break;
                case "ORDER_RECEIPT_TOTAL":
                    break;
                case "DISCOUNT":
                    expectedCurrency = order.getOrderTotal().getPriceLines().get(3).getAmount().getCurrency();
                    expectedCurrencyConverted = order.getOrderTotal().getPriceLines().get(3).getAmount().getConvertedFromCurrency();
                    site = expectedCurrencyConverted == null ? getCountryBasedOnCurrency(expectedCurrency) : getCountryBasedOnCurrency(expectedCurrencyConverted);
                    String ExpectedDiscount = df.format(order.getOrderTotal().getPriceLines()
                            .get(3).getAmount().getValue());

                    if (site.equals("US"))
                        ExpectedDiscount = getCurrencySymbol(site) + ExpectedDiscount;
                    else
                        ExpectedDiscount = expectedCurrency + " " + getCurrencySymbol(site) + ExpectedDiscount;

                    softAssert.assertEquals(price.getValue(), ExpectedDiscount, "Discount price value Not matched");
                    break;
            }
        }
        breezeReport.logWithColor("----- validatePriceLines Done -----", "green");
    }

    private void validatePickListItemPdfDocGen(List<ItemInfo> items, Order order) {
        breezeReport.logWithColor("Validating ItemDetails in PickList", "blue");
        List<LineItemTypes> lineItemTypes = order.getLineItemTypes();
        List<Logistics> logistics = order.getLogistics();
        int i = 0;
        for (ItemInfo item : items) {
            String actualOrderItemIdInfoText = item.getItemId();
            String expectedOrderItemIdInfoText = lineItemTypes.get(i).getSourceId().getItemId();
            softAssert.assertEquals(actualOrderItemIdInfoText, expectedOrderItemIdInfoText, "Order info Item Id is not correct");

            String actualOrderItemTitleInfoText = item.getTitle();
            String expectedOrderItemTitleInfoText = lineItemTypes.get(i).getTitle().getContent();
            softAssert.assertEquals(actualOrderItemTitleInfoText, expectedOrderItemTitleInfoText, "Order info Item Title is not correct");

            int actualOrderItemQtyInfoText = item.getQty().intValue();
            int expectedOrderItemQtyInfoText = lineItemTypes.get(i).getQuantityPurchased();
            softAssert.assertEquals(actualOrderItemQtyInfoText, expectedOrderItemQtyInfoText, "Order info Item Id is not correct");

            validateItemSkuDetails(item.getItemSkuDetails(), lineItemTypes.get(i).getItemSkuDetails());
            validateShippingInfo(item.getShipmentInfo(), logistics.get(0), order);
            i++;
        }

        breezeReport.logWithColor("----- Validate ItemDetails PickList Done -----", "green");
    }

    private void validateItemSkuDetails(List<Attribute> itemSkuDetails, List<ItemSkuDetails> expectedSkudetails) {
        breezeReport.logWithColor("validate ItemSkuDetails", "blue");
        for (Attribute skuDetails : itemSkuDetails) {
            for (ItemSkuDetails expSkuDetail : expectedSkudetails) {
                if (skuDetails.getKey().equals(expSkuDetail.getName())) {
                    softAssert.assertEquals(skuDetails.getValue(), expSkuDetail.getValue(),
                            "skuDetail " + skuDetails.getKey() + " Not matched");
                    break;
                }
            }
        }
        breezeReport.logWithColor("----- Validate ItemSkuDetails Done -----", "green");
    }

    private void validateShipToAddress(ValidateInput input, List<AddressDetail> actualAddressDetail, MembersC expectedOrder) {
    	breezeReport.logWithColor("----- Validate ShipToAddress  -----", "blue");
        String[] documents = input.getDocuments().split(",");
        AddressDetail actualAddress = null;
        AddressDetail actPackingSlipAddress = null;
        DestinationAddress expectedAddress = null;
        DestinationAddress expAddressLabelOnPackingSlip = null;
        DestinationAddress expPackingSlipShipToAdd = null;
        List<DestinationAddress> expectedAddressDetail = expectedOrder.getOrder().getAddress();
        setFlags(expectedOrder);
        
        for (AddressDetail add : actualAddressDetail) {
            if (add.getDocumentType().equals("PICK_LIST")) {
                actualAddress = add;
                //break;
            }
            if (add.getDocumentType().equals("PACKING_SLIP")) {
            	actPackingSlipAddress = add;
            	//break;
            }
        }

        for (DestinationAddress destinationAddress : expectedAddressDetail) {
            if (expectedOrder.getOrder().getPrograms().size() > 0) {
                if (destinationAddress.getType().equals(wareHouseAddress)) {
                    expectedAddress = destinationAddress;
                    if (isAddressLabelOnPackingSlip)
                    	expAddressLabelOnPackingSlip = destinationAddress;
                    //break;
                } else if (destinationAddress.getType().equals(storeAddress)) {
                    expectedAddress = destinationAddress;
                    //break;
                } else if (destinationAddress.getType().equals(buyerShippingAddress) && isGSP)
                	expPackingSlipShipToAdd = destinationAddress;
            } else if (destinationAddress.getType() != null) {
                if (destinationAddress.getType().equals(buyerShippingAddress)) {
                    expectedAddress = expAddressLabelOnPackingSlip = destinationAddress;
                    //break;
                } 
            }
        }
        
        if ((null != actualAddress) && (null != expectedAddress)) {
        	for (String doc : documents) {
        			if (doc.equals("packingSlip")) {
        				if (isAddressLabelOnPackingSlip) {
        					String tempDoc = doc + " AddressLabel-";
            				validateAddress(tempDoc, expAddressLabelOnPackingSlip, actualAddress);
        				} 
        				
        				/* TODO : Validate Buyer Address in packingSlip for GSP Orders in EU site */
        				
        				if (isGSP && input.getSite().equalsIgnoreCase("US"))
        					validateAddress(doc, expPackingSlipShipToAdd, actPackingSlipAddress);
        				else
        					validateAddress(doc, expectedAddress, actPackingSlipAddress);
        			} else if (doc.equals("orderReceipt")) 
        				validateAddress(doc, expectedAddress, actualAddress);
        			  else if (doc.equals("pickList")) 
        				validateAddress(doc, expectedAddress, actualAddress);
        			  else if (doc.equals("addressLabel")) 
        				validateAddress(doc, expectedAddress, actualAddress);
        	}
        }
        breezeReport.logWithColor("----- Validate ShipToAddress done -----", "green");
    }

    private void validateShipToAddressEmailAddress(PdfDocGenRawDataRequest req ,List<AddressDetail> actualAddressDetail,MembersC expectedOrder, String propFile) {
    	breezeReport.logWithColor("----- Validate ShipToAddressEmailAddress  -----", "Blue");
    	// Non Intermediate Order mail address
    	if(expectedOrder.getOrder().getPrograms().isEmpty()){
    		for (AddressDetail list : actualAddressDetail) {
    			if (isOrderGreater90Days)	{
    				breezeReport.logStep("Actual Non Intermediate Order Mail Address: "+req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress());
    				breezeReport.logStep("Expected Non Intermediate Order Mail Address: null");
    		        softAssert.assertNull(req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress());
    				break;
    			}
    			else {
					String expectedEmailAddress = expectedOrder.getOrder().getBuyer().getAliasEmailAddress();
    				if (list.getDocumentType().equals("PACKING_SLIP")) {
    					String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress();
    					softAssert.assertEquals(actualEmailAddress, expectedEmailAddress, "Non Intermediate shipping Order mail is not matched");
    				}
    				else if(list.getDocumentType().equals("ORDER_RECEIPT")) {
    					String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(1).getAliasEmailAddress();
    					softAssert.assertEquals(actualEmailAddress, expectedEmailAddress, "Non Intermediate shipping Order mail is not matched");
    				}
    				else if(list.getDocumentType().equals("PICK_LIST")) {
    					String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(2).getAliasEmailAddress();
    					breezeReport.logStep("Actual Non Intermediate Order Mail Address: " +actualEmailAddress);
    					breezeReport.logStep("Expected Non Intermediate Order Mail Address: " +expectedEmailAddress);
    					softAssert.assertEquals(actualEmailAddress, expectedEmailAddress, "Non Intermediate shipping Order mail is not matched");
    				}
    			}
    		}
    	}
    	// Intermediate Order mail address
    	else {
    		String ordertype = expectedOrder.getOrder().getPrograms().get(0).getName();
    		if(isGSP || isPSA || isExports){
    			for (AddressDetail list : actualAddressDetail) {
    				if (isOrderGreater90Days)	{			
    					breezeReport.logStep("Actual Intermediate Order Mail Address: "+req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress());
        				breezeReport.logStep("Expected Intermediate Order Mail Address: null");
        		        softAssert.assertNull(req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress());
        				break;
    				}
    				else {
    					if (list.getDocumentType().equals("PACKING_SLIP")) {
    						String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress();
    						softAssert.assertEquals(actualEmailAddress, L10n.content(propFile, "Ebay_Intermediate_Shipping_Email"), "Intermediate Order shipping mail is not matched");
    					}
    					else if(list.getDocumentType().equals("ORDER_RECEIPT")) {
    						String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(1).getAliasEmailAddress();
    						softAssert.assertEquals(actualEmailAddress, L10n.content(propFile, "Ebay_Intermediate_Shipping_Email"), "Intermediate Order shipping mail is not matched");
    					}
    					else if(list.getDocumentType().equals("PICK_LIST")) {
    						String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(2).getAliasEmailAddress();
    						breezeReport.logStep("Actual Ebay Intermediate Mail Address: " +actualEmailAddress);
    						breezeReport.logStep("Expected Ebay Intermediate Mail Address: " +L10n.content(propFile, "Ebay_Intermediate_Shipping_Email"));
    						softAssert.assertEquals(actualEmailAddress, L10n.content(propFile, "Ebay_Intermediate_Shipping_Email"), "Intermediate Order shipping mail is not matched");
    					}
    				}
    			}
    		} 
    		// Non Intermediate Order mail address
    		else {
    			if(ordertype != null) {
    				for (AddressDetail list : actualAddressDetail) {
    					if (isOrderGreater90Days)	{			
    						breezeReport.logStep("Actual Non Intermediate Order Mail Address: "+req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress());
    	    				breezeReport.logStep("Expected Non Intermediate Order Mail Address: null");
    	    		        softAssert.assertNull(req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress());
    	    				break;
    					}
    					else {
    						String expectedEmailAddress = expectedOrder.getOrder().getBuyer().getAliasEmailAddress();
    						if (list.getDocumentType().equals("PACKING_SLIP")) {
    							String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(0).getAliasEmailAddress();	
    							softAssert.assertEquals(actualEmailAddress, expectedEmailAddress, "Non Intermediate Order shipping mail is not matched");
    						}
    						else if(list.getDocumentType().equals("ORDER_RECEIPT")) {
    							String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(1).getAliasEmailAddress();
    							softAssert.assertEquals(actualEmailAddress, expectedEmailAddress, "Non Intermediate Order shipping mail is not matched");
    						}
    						else if(list.getDocumentType().equals("PICK_LIST")) {
    							String actualEmailAddress = req.getOrders().get(0).getShipToAddress().get(2).getAliasEmailAddress();
    							breezeReport.logStep("Actual Non Intermediate Order Mail Address: " +actualEmailAddress);
    							breezeReport.logStep("Expected Non Intermediate Order Mail Address: " +expectedEmailAddress);
    							softAssert.assertEquals(actualEmailAddress, expectedEmailAddress, "Non Intermediate Order shipping mail is not matched");
    						}
    					}
    				}
    			}
    		}
    	}
    	breezeReport.logWithColor("----- Validate ShipToAddressEmailAddress done -----", "Green");  
    }
    
    private void validateAddress(String doc, DestinationAddress expectedAddress, AddressDetail actualAddress) {
		
    	breezeReport.logWithColor("** Validating " + doc + " ShipToAddress **", "blue");
    	
    	/* validate addressLine1 */
    	String expectedAddressLine1 = isOrderGreater90Days ? "--" : expectedAddress.getAddress().getAddressLine1();
        softAssert.assertEquals(actualAddress.getAddressLine1(), expectedAddressLine1, "AddressLine1 doesnot match");

        /* validate City */
        String expectedCity = expectedAddress.getAddress().getCity();
        softAssert.assertEquals(actualAddress.getCity(), expectedCity, "City Name doesnot match");

        /* validate state */
        if (actualAddress.getState() != null && expectedAddress.getAddress().getStateOrProvince() != null) {
        	String expectedState = expectedAddress.getAddress().getStateOrProvince();
        	softAssert.assertEquals(actualAddress.getState(), expectedState, "State Name doesnot match");
        }
        
        /* validate postalCode */
        String expectedPostalCode = expectedAddress.getAddress().getPostalCode();
        softAssert.assertEquals(actualAddress.getPostalCode(), expectedPostalCode, "PostalCode doesnot match");

        /* validate Country */
        String expectedCountry = expectedAddress.getAddress().getCountry();
        //String sellerCountryId = CountryCodeEnum.findByCountryName(actualAddress.getCountry());
        String actualCountry = actualAddress.getCountry();
        //Adding check for 'CZ' as the display name is different in ExpSvc 
        if (actualCountry.equals("Czechia"))
        	actualCountry = "Czech Republic";
        CountryCodeEnum countryCodeEnum = CountryCodeEnum.findByCountryName(actualCountry);
        
        String expectedCountryName = CountryCodeEnum.findByAlpha3IsoCountryCode(expectedCountry) != null ?
                CountryCodeEnum.findByAlpha3IsoCountryCode(expectedCountry).getName() :
                CountryCodeEnum.valueOf(expectedCountry).getName();

        String actualCountryName = null;
        if (countryCodeEnum != null && !countryCodeEnum.getName().isEmpty())
            actualCountryName = countryCodeEnum.getName();

        softAssert.assertEquals(actualCountryName, expectedCountryName, "Country Name does not match");
		
	}

    private void validateGspReferenceId(String actualGspReferenceId, Order order) {
        breezeReport.logWithColor("Validating GspId", "blue");
        String expectedGspReferenceId = order.getLogistics().get(0).getSteps().get(0).getStepExtension().getShippingStep().getDestinationAddress().getLocationId();
        softAssert.assertEquals(actualGspReferenceId, expectedGspReferenceId, "Gsp Reference Id does not match");
        breezeReport.logWithColor("----- Validating GspId Done", "green");
    }

    private void validateShippingInfo(ShipmentInfo shipmentInfo, Logistics expectedCosmosLogisticsResp, Order order) {
        breezeReport.logWithColor("Validating Shipping Info", "blue");
        String trackingId = expectedCosmosLogisticsResp.getSteps().get(0).getStepExtension().getShippingStep().getPackage().get(0).getPackageExtn().getShippingPackageExtn().getTrackingId();

        if (trackingId != null) {
            String actualShippingCarrierInfoText = shipmentInfo.getShippingCarrier();
            String expectedShippingCarrierInfoText = expectedCosmosLogisticsResp.getSteps().get(0).getStepExtension().getShippingStep().getShippingOptions().get(0).getShipppingMethod().getCarrier().getDisplayName();

            if (isPSA(order)) expectedShippingCarrierInfoText = psa;
            softAssert.assertEquals(actualShippingCarrierInfoText, expectedShippingCarrierInfoText, "Shipping Carrier Info does not match");

            String actualShippingTrackingNumInfoText = shipmentInfo.getTrackingNum();
            String expectedShippingTrackingNumInfoText = trackingId;
            // tracking number is comming as null currently - have to check with dev
//			softAssert.assertEquals(actualShippingTrackingNumInfoText, expectedShippingTrackingNumInfoText, "Shipping Tracking Number does not match");
        }

        breezeReport.logWithColor("----- Validate Shipping Info Done", "green");
    }

    private void validateCompleteDocumentModule(ModuleProviderResponse actualResponse){
        breezeReport.logWithColor("Asserting complete document module", "blue");

        softAssert.assertEquals(actualResponse.getModules().getPrintModule().getPdfInfo().getTitle().getTextSpans().get(0).getText(), "Preview coupon");
        softAssert.assertNotNull(actualResponse.getModules().getPrintModule().getPdfInfo().getData());


        softAssert.assertNotNull(actualResponse.getModules().getPdfDocGenRawDataModule());
        softAssert.assertEquals(actualResponse.getModules().getPdfDocGenRawDataModule().get_type(), "PdfDocGenRawDataModule");
        softAssert.assertEquals(actualResponse.getModules().getPdfDocGenRawDataModule().getRequest().getDocuments().size(), 1);
    }

    private void validateGenericCouponModule(ModuleProviderResponse actualResponse ){
        breezeReport.logWithColor("Asserting print coupon", "blue");

        softAssert.assertNotNull(actualResponse.getModules().getPrintOrderModule());
        softAssert.assertNotNull(actualResponse.getModules().getPdfDocGenRawDataModule());

        breezeReport.logWithColor("Asserting subsection in print order module", "blue");
        Subsection.Synopsis synopsys = actualResponse.getModules().getPrintOrderModule().getSelectionGroup().get(0).getSubSection().get(0).getSynopsis();
        softAssert.assertEquals(synopsys.getTitle().getTextSpans().get(0).getText(), "Coupon");
        softAssert.assertNotNull(synopsys.getEditAction().getTextSpans().get(0).getText());
        if (synopsys.getSelectionSummary() != null)
        	softAssert.assertEquals(synopsys.getSelectionSummary().size(), 4);

        breezeReport.logWithColor("Asserting pdfInfo in print order module", "blue");
        PdfInfo pdfInfo = actualResponse.getModules().getPrintOrderModule().getPdfInfo();
        softAssert.assertEquals(pdfInfo.getTitle().getTextSpans().get(0).getText(), "Preview coupon");

        breezeReport.logWithColor("Asserting feature survey link in print order module", "blue");
        TextualDisplay textualDisplay = actualResponse.getModules().getPrintOrderModule().getFeatureSurveyLink();
        softAssert.assertEquals(textualDisplay.getTextSpans().get(0).getText(), "Tell us what you think");

        breezeReport.logWithColor("Asserting call to actions", "blue");
        softAssert.assertNotNull(actualResponse.getModules().getPrintOrderModule().getCancelAction());
        softAssert.assertNotNull(actualResponse.getModules().getPrintOrderModule().getPrintAction());

        breezeReport.logWithColor("Asserting print selection data in print order module", "blue");
        PrintSelectionData printSelectionData = actualResponse.getModules().getPrintOrderModule().getPrintSelectionData();
        softAssert.assertEquals(printSelectionData.getPreferenceSelections().getThankYouNote(),"THANK_YOU_HOPE_YOU_LOVE_IT");
    }

    private boolean isPSA(Order order) {

        if (order.getPrograms() != null) {
            for (Program program : order.getPrograms()) {
                if (program.getName().equals(psa)) return true;
            }
        }
        return false;
    }
}
