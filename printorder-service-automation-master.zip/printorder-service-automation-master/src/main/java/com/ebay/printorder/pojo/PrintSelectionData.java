package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class PrintSelectionData {
    private List<String> orderIds;
    private List<String> labelIds;
    private DocumentSelections documentSelections;
    private PreferenceInfo preferenceSelections;
}
