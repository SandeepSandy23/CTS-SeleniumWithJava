package com.ebay.printorder.pojo.sme;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.ebay.printorder.pojo.TextualDisplay;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class Field {

	private String _type;
	private boolean disabled;
	private boolean lockable;
	private boolean selected;
	private String paramKey;
	private String paramValue;
	private String paramValueType;
	private TextualDisplay label;
	private TextualDisplay secondaryLabel;
	private boolean defaultChoice;
}
