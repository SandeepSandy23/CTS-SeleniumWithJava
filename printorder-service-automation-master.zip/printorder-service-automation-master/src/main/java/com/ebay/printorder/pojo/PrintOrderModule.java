package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class PrintOrderModule {
    private String _type;
    private Orders orders;
    private TextualDisplay printSummaryTitle;
    private List<Selections> selectionGroup;
    private PdfInfo pdfInfo;
    private TextualDisplay featureSurveyLink;
    private CallToAction printAction;
    private CallToAction cancelAction;
    private PrintSelectionData printSelectionData;
    private List<Message> messageBundle;
    private TextualDisplay description;
}
