package com.ebay.printorder.domain.executors;

import com.ebay.common.infra.executor.BaseExecutor;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public class PrintOrderDomainSvcFactory {

    private static final PrintOrderDomainSvcFactory printOrderDomainSvcFactory = new PrintOrderDomainSvcFactory();

    public PrintOrderDomainSvcFactory() {

    }

    public static PrintOrderDomainSvcFactory getInstance() {
    	return printOrderDomainSvcFactory;
    }

    public BaseExecutor getExecutor() throws Exception {
    	return new PrintOrderDomainSvcExecutor();
    }
}
