package com.ebay.printorder.util;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.common.util.timestamp.DateFormatterEnum;
import com.ebay.common.util.timestamp.DateTimeUtil;
import com.ebay.printorder.deserializer.RestCallDeserializer;
import com.ebay.printorder.pojo.sme.FormatResponse;
import com.ebay.printorder.pojo.sme.SmeExpResponse;
import com.ebay.printorder.pojo.ModuleProviderResponse;
import com.ebay.printorder.pojo.sme.CouponValidDate;
import com.ebay.printorder.pojo.sme.SMEResponse;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.serviceautil.apidriver.RestClient;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class SMEUtil extends BaseSvcUtil{

    public JSONObject getCouponDetails(String sellerName, String site, String packingSlipCouponId) throws Exception{
        site = overrideSite(site);
        String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
        String smeSvcURL = TestParams.TestEnv.customparam.get("smeSvcURL") + packingSlipCouponId;
        String bearer_token = "Bearer " + getAppToken("dXJuOmViYXktbWFya2V0cGxhY2UtY29uc3VtZXJpZDoxZjNlNTAzOS05OTc0LTQ4MTctYWUyOS1hMzA1YTQ1YzQwNDg6IGI0NWMwZjVlLTRlMWUtNGI5Yi1iODJjLWE1NGQ4ODZkZjY5NA==", 
        		"sell@user");
        Reporter.log("SME Endpoint URL" + smeSvcURL);

        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName + "%2CorigAcctId%3D" + sellerId);
        URL url = new URL(smeSvcURL);
        client.get(url);
        if (client.getResponseCode() != 200) {
            client.get(url);
        }
        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());
        return responseObject;
    }

    private String reformatDate(String date) throws ParseException {
    	SimpleDateFormat inputFormatter = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    	SimpleDateFormat outputFormatter = new SimpleDateFormat("MMM d, yyyy", Locale.US);
    	
        String convertedDateStr = DateTimeUtil.getConvertedDate(date, "GMT", "PST", DateFormatterEnum.FORMAT_16, DateFormatterEnum.FORMAT_3);
        Date convertedDate = inputFormatter.parse(convertedDateStr);
        String formattedDate = outputFormatter.format(convertedDate);
        return formattedDate;
    }

    public FormatResponse reformatValidDate(SMEResponse smeResponse) throws ParseException {
    	String startDate = reformatDate(smeResponse.getStartDate().getValue());
        String endDate = reformatDate(smeResponse.getEndDate().getValue());
        
        String formatValidDate = "Offer valid: " + startDate + " - " + endDate;
        FormatResponse smeFormatResponse = new FormatResponse();
        smeFormatResponse.setSmeResponse(smeResponse);
        smeFormatResponse.setFormatValidDate(formatValidDate);
        smeFormatResponse.setFormatValidEndDate(endDate);
        return smeFormatResponse;
    }

    public SMEResponse getSmeResponse(String sellerName, String site, String packingSlipCouponId) throws Exception {
        RestCallDeserializer deserializer = new RestCallDeserializer();
        JSONObject resp = getCouponDetails(sellerName, site, packingSlipCouponId);
        SMEResponse smeResponse = deserializer.deserializeSMEResponse(resp.toString());
        return smeResponse;
    }

   public SmeExpResponse getSmeExpResponse(String sellerName, String site) throws Exception {
       RestCallDeserializer deserializer = new RestCallDeserializer();
       JSONObject resp = getAvailableCouponDetails(sellerName, site);
       SmeExpResponse smeExpResponse = deserializer.deserializeSmeExpResponse(resp.toString());
        return smeExpResponse;
    }
    
    @SuppressWarnings("deprecation")
	public JSONObject getAvailableCouponDetails(String sellerName, String site) throws Exception{
        site = overrideSite(site);
        String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
        String smeSvcURL = TestParams.TestEnv.customparam.get("smeExpSvcURL") + "?modules=AVAILABLE_COUPON";
       // if(delPref)
        //	smeSvcURL = TestParams.TestEnv.customparam.get("delPerfURL") + "?userid=" +sellerId;
        
//        String bearer_token = "Bearer " + getAppToken("urn:ebay-marketplace-consumerid:1f3e5039-9974-4817-ae29-a305a45c4048", 
//        		"b45c0f5e-4e1e-4b9b-b82c-a54d886df694", "core@user");
        String bearer_token = "Bearer " + getAppToken("experience@user");
        Reporter.log("SME Endpoint URL" + smeSvcURL);

        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName + "%2CorigAcctId%3D" + sellerId);
        URL url = new URL(smeSvcURL);
        client.get(url);
        if (client.getResponseCode() != 200) {
            client.get(url);
        }
        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());
        return responseObject;
    }

    public FormatResponse reformatSmeExpResponse(SmeExpResponse smeExpResponse) throws ParseException {
        FormatResponse smeFormatResponse = new FormatResponse();
        smeFormatResponse.setSmeExpResponse(smeExpResponse);
        return smeFormatResponse;
    }
}
