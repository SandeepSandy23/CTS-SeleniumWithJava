package com.ebay.printorder.pojo.sme;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class InventoryAttribute {
	private String id;
	private String categoryAspectValue;
	private GlobalAspectValue globalAspectValue;
	
	@Getter
	public static class GlobalAspectValue {
		private ItemPriceFrom itemPriceFrom;
		private ItemPriceTo itemPriceTo;
		private List<String> itemCondition;
		}

	@Getter
	public static class ItemPriceFrom {
		private int	value;
		private String currency;
		}

	@Getter
	public static class ItemPriceTo {
		private int value;
		private String currency;
		}
}
