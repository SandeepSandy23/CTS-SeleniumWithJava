package com.ebay.printorder.pojo;


import lombok.Getter;
import lombok.Setter;
import java.util.List;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class SelectionGroup {
	private List<String> selection;
    private TextualDisplay title;
    private Help help;
    private List<Subsection> subSection;
    private TextualDisplay description;
    private CallToAction navAction;

    @Getter
    public static  class Help{
        private String _type;
        private TextualDisplay messageDismiss;
        private Icon bubbleIcon;
        private List<TextualDisplay> messageText;
        private Action action;
    }
    
    @Getter
    public static  class Icon{
    	private String _type;
    	private String name;
    	private String accessibilityText;
    	private Action action;
    }
    

}
