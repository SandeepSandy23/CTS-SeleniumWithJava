
package com.ebay.printorder.pojo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class TextSpan {

    private String _type;

    private String text;
    
    private List<String> styles = null;
    
    private String accessibilityText;
    
    private boolean selected;

    private Action action;
    
    public String getAccessibilityText() {
		return accessibilityText;
	}

	public void setAccessibilityText(String accessibilityText) {
		this.accessibilityText = accessibilityText;
	}

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

	public String get_type() {
		return _type;
	}

	public void set_type(String _type) {
		this._type = _type;
	}

	public List<String> getStyles() {
		return styles;
	}

	public void setStyles(List<String> styles) {
		this.styles = styles;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}

}
