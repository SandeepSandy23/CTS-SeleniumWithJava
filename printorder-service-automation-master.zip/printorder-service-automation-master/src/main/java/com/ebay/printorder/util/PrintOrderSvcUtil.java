package com.ebay.printorder.util;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.printorder.pojo.BlackListedWordsResponse;
import com.ebay.printorder.pojo.DeletePreferenceResponse;
import com.ebay.printorder.pojo.ModuleProviderResponse;
import com.ebay.printorder.pojo.PrintDocumentResponse;
import com.ebay.printorder.pojo.SellerVatResponse;
import com.ebay.printorder.pojo.SendCouponResponse;
import com.ebay.printorder.pojo.UpdateTargBuyerDetailResponse;
import com.ebay.printorder.pojo.ValidateInput;
import com.ebay.sellerhub.orders.common.CommonSvcUtil;
import com.ebay.testinfrastructure.dbautil.dbdriver.TokenMismatch;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.serviceautil.apidriver.RestClient;
import com.sun.jersey.api.client.UniformInterfaceException;
import org.json.JSONObject;
import org.testng.Assert;

import java.net.URL;

import static com.ebay.printorder.pojo.ValidateEnum.*;

public class PrintOrderSvcUtil extends BaseSvcUtil {
    static String printOrderModule = "PRINT_ORDER_MODULE";
    static String packingSlipModule = "PACKING_SLIP_MODULE";
    static String orderModule = "ORDER_RECEIPT_MODULE";
    static String couponModule = "COUPON_MODULE";
	static String genericCouponModule = "GENERIC_COUPON_MODULE";
	static String completeDocumentModule = "COMPLETE_DOCUMENT_MODULE";
	static String generateDocument = "generate_document";
    static String sendCouponModule = "module_provider";
    static String sendCouponNotification = "send_notification";
	static String validateBlacklistedWords = "validate_blacklisted_words";
//	static String deviceTypeMWeb = "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1";

    @SuppressWarnings("deprecation")
    public ModuleProviderResponse getModuleProviderResponse(String sellerName, String request, String site,
                                                            ValidateInput input) throws Exception {
        String bearer_token = "Bearer " + getAppToken();
        String sellerOracleId = DBSelectQueryUtil.getOracleId(sellerName);
        String svcUrl = getSvcUrl(input);
        site = overrideSite(site);
        breezeReport.logBoldStep("Endpoint URL: " + svcUrl);
        String deviceType = getDeviceType(input);
        // App Service Call
        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName
                        + "%2CorigAcctId%3D" + sellerOracleId)
                .header("User-Agent", deviceType)
                .header("ECHO_PDF_DOC_GEN_RAW_DATA",true);

        URL url = new URL(svcUrl);
        client.post(url, request);

        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());

        return CommonUtil.fromJson(responseObject, ModuleProviderResponse.class);
    }
    
    @SuppressWarnings("deprecation")
    public ModuleProviderResponse getModuleProviderResponseForErrorCase(String sellerName, String request, String site,
                                                            ValidateInput input) throws Exception {
        String bearer_token = "Bearer " + getAppToken();
        String sellerOracleId = DBSelectQueryUtil.getOracleId(sellerName);
        String svcUrl = getSvcUrl(input) + printOrderModule;
        site = overrideSite(site);
        breezeReport.logBoldStep("Endpoint URL: " + svcUrl);
        String deviceType = getDeviceType(input);

        // App Service Call
        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName
                        + "%2CorigAcctId%3D" + sellerOracleId)
                .header("User-Agent", deviceType)
                .header("ECHO_PDF_DOC_GEN_RAW_DATA",true);

        URL url = new URL(svcUrl);
        client.post(url, request);

        Assert.assertEquals(client.getResponseCode(), 500);
        JSONObject responseObject = new JSONObject(client.getResponse());

        return CommonUtil.fromJson(responseObject, ModuleProviderResponse.class);
    }

    private String getAppToken() throws Exception {
        return getAppToken("experience@user");
    }

    private String getSvcUrl(ValidateInput input) {
		StringBuffer svcUrl = new StringBuffer(TestParams.TestEnv.customparam.get("endpoint") + "module_provider?modules=");

		if (input.getValidate() == PRINT_ORDER_MODULE) {
			if(input.getMode() != null) {
				svcUrl.append(printOrderModule + "&mode=" +input.getMode());
			}
			else {
				svcUrl.append(printOrderModule);
			}
		} else if (input.getValidate() == PACKING_SLIP_MODULE) {
			svcUrl.append(packingSlipModule);
		} else if (input.getValidate() == ORDER_RECEIPT_MODULE) {
			svcUrl.append(orderModule);
		} else if (input.getValidate() == COUPON_MODULE) {
		    svcUrl.append(couponModule);
        }
		else if(input.getValidate() == GENERIC_COUPON_MODULE){
			svcUrl.append(genericCouponModule);
		}
		else if(input.getValidate() == COMPLETE_DOCUMENT_MODULE){
			svcUrl = new StringBuffer(TestParams.TestEnv.customparam.get("endpoint") + "module_provider/preview/?modules=" + completeDocumentModule);
		}
		else if (input.getValidate() == SEND_COUPON_MODULE) {
        	StringBuffer sendCouponEndpoint = new StringBuffer (TestParams.TestEnv.customparam.get("sendCouponEndpoint"));
        	svcUrl = sendCouponEndpoint.append(sendCouponModule);
        }

		if (input.getValidate() == GENERATE_DOCUMENTS) {
			return new StringBuffer(TestParams.TestEnv.customparam.get("endpoint")).append(generateDocument).toString();
		}
		if (input.getValidate() == BLACK_LISTED_WORDS_VALIDATE) {
			return new StringBuffer(TestParams.TestEnv.customparam.get("endpoint")).append(validateBlacklistedWords).toString();
		}

		return svcUrl.toString();
	}
    
    private String getDeviceType(ValidateInput input) {
    	String deviceTypeMWeb = "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1";
    	if (input.getDeviceType().equals("DWEB"))
    		deviceTypeMWeb = "";
    	else if (input.getDeviceType().equals("NATIVE"))
    		deviceTypeMWeb = "ebayUserAgent%2FeBayIOS%3B6.20.0%3BiOS%3B14.4%3BApple%3BMacBookPro14_3%3Bno-carrier%3B390x844%3B3.0,ip=10.226.9.29,referer=null,xff=10.222.22.19";
    	
    	return deviceTypeMWeb;
    }

    public int getGenerateDocumentsResponse(String sellerName, String request, String site, ValidateInput input) throws Exception {
        site = overrideSite(site);
        String bearer_token = "Bearer " + getAppToken();
        String sellerOracleId = DBSelectQueryUtil.getOracleId(sellerName);
        String svcUrl = getSvcUrl(input);

        breezeReport.logBoldStep("Endpoint URL: " + svcUrl);

        // App Service Call
        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY-US")
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName
                        + "%2CorigAcctId%3D" + sellerOracleId)
                .header("Accept-Encoding", "gzip,deflate,br");

        URL url = new URL(svcUrl);
        try {
            client.post(url, request);
        } catch (UniformInterfaceException e) {
            if (client.getResponseCode() == 204) {//No Content
                return client.getResponseCode();
            }
        }

        return client.getResponseCode();
    }

    public BlackListedWordsResponse getBlackListedWordsValidateResponse(String sellerName, String request, String site,
																	 ValidateInput input) throws Exception {
            site = overrideSite(site);
			String sellerOracleId = DBSelectQueryUtil.getOracleId(sellerName);
			String svcUrl = getSvcUrl(input);
			site = overrideSite(site);
			breezeReport.logBoldStep("Endpoint URL: " + svcUrl);

			// App Service Call
			RestClient<String> client = new RestClient<String>(String.class)
					.header("Authorization", "Bearer " + getAppToken())
					.header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
					.header("Accept", "application/json")
					.header("Content-Type", "application/json")
					.header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName
							+ "%2CorigAcctId%3D" + sellerOracleId);

			URL url = new URL(svcUrl);
			client.post(url, request);

			Assert.assertEquals(client.getResponseCode(), 200);
			JSONObject responseObject = new JSONObject(client.getResponse());

			return CommonUtil.fromJson(responseObject, BlackListedWordsResponse.class);
	}

    public PrintDocumentResponse getPrintDocumentResponse(String sellerName, String request, String site,
                                                                     ValidateInput input) throws Exception {
        site = overrideSite(site);
        String sellerOracleId = DBSelectQueryUtil.getOracleId(sellerName);
        StringBuffer endpoint = new StringBuffer(TestParams.TestEnv.customparam.get("endpoint") + "module_provider/preview?modules=COMPLETE_DOCUMENT_MODULE");

        String svcUrl = endpoint.toString();
        site = overrideSite(site);
        breezeReport.logBoldStep("Endpoint URL: " + svcUrl);

        // App Service Call
        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", "Bearer " + getAppToken())
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName
                        + "%2CorigAcctId%3D" + sellerOracleId);

        URL url = new URL(svcUrl);
        client.post(url, request);

        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());

        return CommonUtil.fromJson(responseObject, PrintDocumentResponse.class);
    }
    
    @SuppressWarnings("deprecation")
	public SendCouponResponse getSendCouponResponse(String sellerName, String request, String site, ValidateInput input,
    		boolean sendNotification, boolean couponAction, boolean sendNotificationError, boolean sendNotificationWithoutCoupon) throws Exception {
    	String bearer_token = "Bearer " + getAppToken();
    	String sellerOracleId = DBSelectQueryUtil.getOracleId(sellerName);
    	String svcUrl = null;
    	String deviceType = getDeviceType(input);
    	StringBuffer tempUrl = new StringBuffer(TestParams.TestEnv.customparam.get("sendCouponEndpoint"));
    	if (sendNotification || sendNotificationError || sendNotificationWithoutCoupon) {
    		tempUrl = tempUrl.append(sendCouponNotification);
        	svcUrl = tempUrl.toString();
    	}
    	else if(couponAction) {
    		StringBuffer smeExpSvcURL = new StringBuffer(TestParams.TestEnv.customparam.get("sendCouponEndpoint"));
    		svcUrl = smeExpSvcURL.append(sendCouponModule).toString();
    	}
    	
    	site = overrideSite(site);
    	breezeReport.logBoldStep("Endpoint URL: " + svcUrl);
		
		// App Service Call
		RestClient<String> client = new RestClient<String>(String.class)
		.header("Authorization", bearer_token)
		.header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
		.header("Accept", "application/json")
		.header("Content-Type", "application/json")
		.header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName
		+ "%2CorigAcctId%3D" + sellerOracleId)
		.header("User-Agent", deviceType)
		.header("ECHO_PDF_DOC_GEN_RAW_DATA",true);
		
		URL url = new URL(svcUrl);
		client.post(url, request);
		
		Assert.assertEquals(client.getResponseCode(), 200);
		
		JSONObject responseObject = new JSONObject(client.getResponse());
		
		return CommonUtil.fromJson(responseObject, SendCouponResponse.class);
		}

	@SuppressWarnings("deprecation")
	public String getDeletePreferenceResponse(ValidateInput input, String sellerName, String site) 
			throws Exception {
	//public DeletePreferenceResponse getDeletePreferenceResponse(ValidateInput input, String sellerName, String site) 
	//		throws Exception {
		String bearer_token = "Bearer " + getAppToken();
    	String sellerOracleId = DBSelectQueryUtil.getOracleId(sellerName);
    	String svcUrl = null;
    	String deviceType = getDeviceType(input);
    	StringBuffer tempUrl = new StringBuffer(TestParams.TestEnv.customparam.get("delPerfURL"));
    	svcUrl = (tempUrl + "?userid=" + sellerOracleId).toString(); 
    	site = overrideSite(site);
    	breezeReport.logBoldStep("Endpoint URL: " + svcUrl);
		
		// App Service Call
		RestClient<String> client = new RestClient<String>(String.class)
		.header("Authorization", bearer_token)
		.header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
		//.header("Accept", "application/json")
		//.header("Content-Type", "application/json")
		.header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName
		+ "%2CorigAcctId%3D" + sellerOracleId)
		.header("User-Agent", deviceType);
		
		URL url = new URL(svcUrl);
		client.post(url);
		
		Assert.assertEquals(client.getResponseCode(), 200);
		
		//JSONObject responseObject = new JSONObject(client.getResponse());
		String response = client.getResponse();
		return response;
		//	return CommonUtil.fromJson(responseObject, DeletePreferenceResponse.class);
	}
	
	@SuppressWarnings("deprecation")
	public UpdateTargBuyerDetailResponse getUpdateTarBuyerDetailResp(ValidateInput input, String request, String site) throws Exception {
		
		String bearer_token = "Bearer " + CommonSvcUtil.getAppToken("sell@user");
    	String sellerOracleId = DBSelectQueryUtil.getOracleId(input.getSellerName());
    	StringBuffer svcUrl = new StringBuffer(TestParams.TestEnv.customparam.get("updateTarBuyerDetailURL"));
    	//site = overrideSite(site);
    	breezeReport.logBoldStep("Endpoint URL: " + svcUrl);
		
		// App Service Call
		RestClient<String> client = new RestClient<String>(String.class)
		.header("Authorization", bearer_token)
		//.header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
		.header("Accept", "application/json")
		.header("Content-Type", "application/json")
		.header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + input.getSellerName()
		+ "%2CorigAcctId%3D" + sellerOracleId);
		
		URL url = new URL(svcUrl.toString());
		client.post(url, request);
		
		Assert.assertEquals(client.getResponseCode(), 200);
		
		JSONObject responseObject = new JSONObject(client.getResponse());
		
		return CommonUtil.fromJson(responseObject, UpdateTargBuyerDetailResponse.class);
	}

	public String getInvoiceCounterResponse(ValidateInput input) throws Exception {
		
		String bearer_token = "Bearer " + getAppToken();
    	String sellerOracleId = DBSelectQueryUtil.getOracleId(input.getSellerName());
    	String svcUrl = new StringBuffer(TestParams.TestEnv.customparam.get("endpoint")) + "get_counter?userid=inv_cntr_" + sellerOracleId;
    	String site = overrideSite(input.getSite());
    	breezeReport.logBoldStep("Endpoint URL: " + svcUrl);
		
		// App Service Call
		RestClient<String> client = new RestClient<String>(String.class)
		.header("Authorization", bearer_token)
		.header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
		//.header("Accept", "application/json")
		//.header("Content-Type", "application/json")
		.header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + input.getSellerName()
		+ "%2CorigAcctId%3D" + sellerOracleId);
		
		URL url = new URL(svcUrl);
		client.get(url);
		
		Assert.assertEquals(client.getResponseCode(), 200);
		
		//JSONObject responseObject = new JSONObject(client.getResponse());
		String response = client.getResponse();
		return response;
	
	}

	@SuppressWarnings("deprecation")
	public SellerVatResponse getSellerVatResponse(ValidateInput input) throws Exception {
		
		String bearer_token = "Bearer " + getAppToken("core@application");
		//String bearer_token = "Bearer " + getAppToken("dXJuOmViYXktbWFya2V0cGxhY2UtY29uc3VtZXJpZDo4Mzc1YjY1Yi0zNjQxLTRiYWEtODk1Mi1kZTE2ZDZjMDhiYWM6IDA4MjZiOTBjLTRhNmMtNDdlOS05YmZiLWFlMjM5NjdmMDhiYg==", "core@user");
    	String sellerOracleId = DBSelectQueryUtil.getOracleId(input.getSellerName());
    	String svcUrl = new StringBuffer(TestParams.TestEnv.customparam.get("sellerVAT")) + sellerOracleId + "/vat_profile/vat_details";
    	String site = overrideSite(input.getSite());
    	breezeReport.logBoldStep("Endpoint URL: " + svcUrl);
		
    	// App Service Call
    	RestClient<String> client = new RestClient<String>(String.class)
    	.header("Authorization", bearer_token)
    	.header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site);
    			
    	URL url = new URL(svcUrl);
    	client.get(url);
    	Assert.assertEquals(client.getResponseCode(), 200);
    	JSONObject responseObject = new JSONObject(client.getResponse());
		
		return CommonUtil.fromJson(responseObject, SellerVatResponse.class);
	}
}
