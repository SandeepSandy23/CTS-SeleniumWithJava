package com.ebay.printorder.exsvc.validators;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.orders.details.xs.spdservice.pojo.SpdResponse;
import com.ebay.orders.list.cosmos.pojo.CosmosResponse;
import com.ebay.printorder.pojo.*;
import com.ebay.printorder.pojo.ModuleFragments.Messages;
import com.ebay.printorder.pojo.SendCouponResponse.SubSectionFragment;
import com.ebay.printorder.pojo.Subsection.Synopsis;
import com.ebay.printorder.pojo.UpdateTargBuyerDetailResponse.BuyerPromotionDetails;
import com.ebay.printorder.pojo.SendCouponResponse.Content;
import com.ebay.printorder.pojo.SendCouponResponse.ModuleMessage;
import com.ebay.printorder.pojo.domain.GetUserResponse;
import com.ebay.printorder.pojo.domain.UserPuidInfo;
import com.ebay.printorder.pojo.sme.FormatResponse;
import com.ebay.printorder.pojo.sme.SMEResponse;
import com.ebay.printorder.pojo.sme.SmeExpResponse;
import com.ebay.printorder.pojo.sme.CouponPickerModel;
import com.ebay.printorder.pojo.sme.Field;
import com.ebay.printorder.util.CommonUtil;
import com.ebay.printorder.util.SMEUtil;
import com.ebay.testinfrastructure.dbautil.dbdriver.TokenMismatch;
import com.ebay.testinfrastructure.l10nautil.L10n;
import com.ebay.testinfrastructure.params.TestParams;
import org.apache.commons.collections.CollectionUtils;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class SendCouponModuleValidator extends ModuleProviderValidator {
	
	public void validateSendCoupon(Modules sendCouponModules, CosmosResponse expectedCosmosResp,
			ModuleProviderRequest request, FormatResponse expectedAvailableCouponModuleSMEResp, String propFile,
			ValidateInput input,GetUserResponse expectedUserReadSvcResp, String pageTitle, SpdResponse spdResponse) throws Exception{
		
		FormatResponse getAvailableCouponsSmeExpResp = null, expectedSmeResponse = null;
		softAssert = new SoftAssert();
		boolean sendNotification = false, selectCoupon = false, editCoupon = false, isPreferenceSet = false, couponAction =false,
				blackList = false, sendNotificationError = false, sendNotificationWithoutCoupon = false;
		String orderId = null, newSelectedCouponId = null;
		List <String> buyerId = null;
		String couponId = input.getCouponIds().get("sendCouponModuleCouponId");
		String messageToBuyer = null;
		String subSectionId = "sendCoupon";
		List <String> subSectionIds = Arrays.asList(subSectionId.split(","));;
		String sellerName = input.getSellerName();
        String site = input.getSite();
        String buyerID = expectedUserReadSvcResp.getData().getUser().get(0).getUserId();
        List<String> buyer_ID = Arrays.asList(buyerID.split(","));
        List<String> sendCouponAction = input.getSendCouponAction();
        List<String> wordsList = input.getWordsList();
		
        if (sendCouponModules != null && (sendCouponModules.getSendCouponModule() != null) && 
        		(sendCouponModules.getSendCouponModule().getSendSelectionData() != null) &&
        		(sendCouponModules.getSendCouponModule().getSendSelectionData().getCouponId() != null)) {
        	isPreferenceSet = true;
        	couponId = sendCouponModules.getSendCouponModule().getSendSelectionData().getCouponId();
        }
    			
		if (sendCouponAction != null) {
			if (sendCouponAction.get(0).equals("SendNotification"))
				sendNotification = true;
			else if ((sendCouponAction.get(0).equals("SelectCoupon")) || (sendCouponAction.get(0).equals("EditCoupon")))
				couponAction = true;
			else if (sendCouponAction.get(0).equals("BlackListWords"))
				blackList = true;
			else if (sendCouponAction.get(0).equals("SendNotificationError"))
				sendNotificationError = true;
			else if (sendCouponAction.get(0).equals("SendNotificationWithoutCoupon"))
				sendNotificationWithoutCoupon = true;
		}
		
		
		if (!sendNotificationError) {
			
			// No-Coupon-Seller & Non-Store-Seller Validation
			if(input.getSellerType().equals("No_Coupon_seller") || input.getSellerType().equals("Non_Store_seller")) {
				CreateCouponModule createCouponModule = sendCouponModules.getCreateCouponModule();
				validateSendCouponForNocouponSeller(createCouponModule, propFile, input);
			}
			
			// SendCoupon-ModuleProvider validation for Eligible Seller
			else {	 
				validateBuyerInfo(sendCouponModules.getSendCouponModule().getBuyerInfo(), expectedCosmosResp, request, propFile, spdResponse);
				validateSendCouponModuleSelectionGroup(sendCouponModules.getSendCouponModule().getSelectionGroup(), 
						expectedAvailableCouponModuleSMEResp, expectedCosmosResp, propFile, isPreferenceSet);
				validateMessageToBuyer(sendCouponModules.getSendCouponModule().getMessageToBuyer(), propFile);
				validateSendCancelAction(sendCouponModules.getSendCouponModule(), propFile);
	        	validateSendSelectionData(sendCouponModules.getSendCouponModule(), input, expectedCosmosResp, propFile, 
	        			isPreferenceSet, buyerID);
	        	validateMessageBundle(sendCouponModules.getSendCouponModule().getMessageBundle(), propFile);
	        	validateSendCouponFeatureSurveyLink(sendCouponModules.getSendCouponModule().getFeatureSurveyLink(), propFile, site);
	        	}
		}
	
		// SelectionGroup-SubSection validation
		if(couponAction) {
	
			newSelectedCouponId = validateSendCouponUserAction(sendCouponModules, couponId, input, isPreferenceSet);
			
			 // Building request for Module Provider-SendCoupon-SubsectionFragment 
			SendCouponRequest screquest = buildRequest(input, newSelectedCouponId, messageToBuyer, buyer_ID, 
					couponAction, subSectionIds );
			SendCouponResponse actualSCResponse = printOrderUtil.getSendCouponResponse(sellerName, CommonUtil.toJSON(screquest), 
					site, input,sendNotification, couponAction, sendNotificationError, sendNotificationWithoutCoupon);
			
			validateSendCouponModuleSubSectionFragment(actualSCResponse, input, newSelectedCouponId, propFile);
			
			if(sendCouponAction.get(0).equals("SelectCoupon"))
				validateDeletePreferences(input, sellerName, site);
			}
		
		// User Action - Send Coupon
		else if(sendNotification){
			
			// Update Targeted Buyer Promotion Details - Send Coupon
			UpdateTargBuyerDetailRequest buyTarPromoDetReq = buildRequest(input, buyer_ID, expectedCosmosResp);
			UpdateTargBuyerDetailResponse buyTarPromoDetRes = printOrderUtil.getUpdateTarBuyerDetailResp(input, CommonUtil.toJSON(buyTarPromoDetReq), site);
			
			if (!isPreferenceSet) //selecting a coupon
				newSelectedCouponId = validateSendCouponUserAction(sendCouponModules, couponId, input, isPreferenceSet);
			else
				newSelectedCouponId = couponId;
			
			// Building request for SendCoupon - SendNotification
			SendCouponRequest snrequest = buildRequest(input, newSelectedCouponId, messageToBuyer, buyer_ID, 
					couponAction, subSectionIds );
			SendCouponResponse actualSNResponse = printOrderUtil.getSendCouponResponse(sellerName, CommonUtil.toJSON(snrequest), 
					site, input,sendNotification, couponAction, sendNotificationError, sendNotificationWithoutCoupon);
			
			validateSendCouponNotification(actualSNResponse, sendNotification, sendNotificationWithoutCoupon, sendNotificationError, buyer_ID, couponId, propFile);	
			}
		
		//Send notification without coupon
		else if(sendNotificationWithoutCoupon){
			 // Building request for SendCoupon - SendNotification
			SendCouponRequest snrequest = buildRequest(input, null, messageToBuyer, buyer_ID, 
					couponAction, subSectionIds );
			SendCouponResponse actualSNResponse = printOrderUtil.getSendCouponResponse(sellerName, CommonUtil.toJSON(snrequest), 
					site, input,sendNotification, couponAction, sendNotificationError, sendNotificationWithoutCoupon);
			
			validateSendCouponNotification(actualSNResponse, sendNotification, sendNotificationWithoutCoupon, sendNotificationError, buyer_ID, couponId, propFile);	
		}
		
		// Validate Blacklisted words in MessageToBuyer - Send Notification
		else if (blackList) {
			sendNotification = true;
			messageToBuyer = wordsList.get(1);
			newSelectedCouponId = couponId;
			
			// Building request for SendCoupon-SendNotification
			SendCouponRequest snrequest = buildRequest(input, newSelectedCouponId, messageToBuyer, buyer_ID, 
					couponAction, subSectionIds );
			SendCouponResponse actualSNResponse = printOrderUtil.getSendCouponResponse(sellerName, CommonUtil.toJSON(snrequest), 
					site, input, sendNotification, couponAction, sendNotificationError, sendNotificationWithoutCoupon);
				
			validateBlacklistedWordsSendCouponNotification(actualSNResponse, buyer_ID, newSelectedCouponId, propFile, wordsList);
			}
		
		else if(sendNotificationError) {
			
			SendCouponRequest snrequest = buildRequest(input, couponId, messageToBuyer, buyer_ID, 
					couponAction, subSectionIds );
			SendCouponResponse actualSNResponse = printOrderUtil.getSendCouponResponse(sellerName, CommonUtil.toJSON(snrequest), 
					site, input,sendNotification, couponAction, sendNotificationError, sendNotificationWithoutCoupon);
			
			validateSendCouponNotification(actualSNResponse, sendNotification, sendNotificationWithoutCoupon, sendNotificationError, buyer_ID, couponId, propFile);			
		}
		softAssert.assertAll();
	}
	
	
	/*
	 * FeatureSurveyLink Validation
	 */
	private void validateSendCouponFeatureSurveyLink(TextualDisplay featureSurveyLink, String propFile, String site) {

		breezeReport.logWithColor("Validating FeatureSurveyLink", "blue");
		
		String actualSurveyLinkText = featureSurveyLink.getTextSpans().get(0).getText();
		String expectedSurveyLinkText = L10n.content(propFile, "SendCoupon_SurveyLinkText");
		breezeReport.logStep("Actual Feature Survey Link Text : " + actualSurveyLinkText);
		breezeReport.logStep("Expected Feature Survey Link Text : " + expectedSurveyLinkText);
		softAssert.assertEquals(actualSurveyLinkText, expectedSurveyLinkText," Feature Survey Link Text is not correct");
		
		String actualSurveyAccessText = featureSurveyLink.getAccessibilityText();
		String expectedSurveyAccessText = L10n.content(propFile, "SendCoupon_Survey_AccessTxt");
		breezeReport.logStep("Actual Feature Survey Link Accessibility Text : " + actualSurveyAccessText);
		breezeReport.logStep("Expected Feature Survey Link Accessibility Text : " + expectedSurveyAccessText);
		softAssert.assertEquals(actualSurveyAccessText, expectedSurveyAccessText," Feature Survey Link Accessibility Text is not correct");
		
		String actualSurveyActionType = featureSurveyLink.getAction().getType().toString();
		String expectedSurveyActionType = L10n.content(propFile, "SendCoupon_SurveyActionType");
		breezeReport.logStep("Actual Feature Survey Link Action Type : " + actualSurveyActionType);
		breezeReport.logStep("Expected Feature Survey Link Action Type : " + expectedSurveyActionType);
		softAssert.assertEquals(actualSurveyActionType, expectedSurveyActionType," Feature Survey Link Action Type is not correct");
		
		String actualSurveyActionName = featureSurveyLink.getAction().getName();
		String expectedSurveyActionName = L10n.content(propFile, "SendCoupon_SurveyActionName");
		breezeReport.logStep("Actual Feature Survey Link Action Name : " + actualSurveyActionName);
		breezeReport.logStep("Expected Feature Survey Link Action Name : " + expectedSurveyActionName);
		softAssert.assertEquals(actualSurveyActionName, expectedSurveyActionName," Feature Survey Link Action Name is not correct");
		
		String actualSurveyActionURL = featureSurveyLink.getAction().getURL();
		String expectedSurveyActionURL = null;
		
		if(site.equalsIgnoreCase("US"))
			expectedSurveyActionURL = L10n.content(propFile, "SendCoupon_SurveyURL_US");
	
		else if(site.equalsIgnoreCase("GB")) 
			expectedSurveyActionURL = L10n.content(propFile, "SendCoupon_SurveyURL_GB");
			
		else if(site.equalsIgnoreCase("AU")) 
			expectedSurveyActionURL = L10n.content(propFile, "SendCoupon_SurveyURL_AU");
		
		breezeReport.logStep("Actual Feature Survey Link Action URL : " + actualSurveyActionURL);
		breezeReport.logStep("Expected Feature Survey Link Action URL : " + expectedSurveyActionURL);
		softAssert.assertEquals(actualSurveyActionURL, expectedSurveyActionURL," Feature Survey Link Action URL is not correct");

		
		breezeReport.logWithColor("***** FeatureSurveyLink Validation Complete *****", "green");	
	}


	/*
	 * Delete Preference Saved
	 */
	private void validateDeletePreferences(ValidateInput input, String sellerName, String site) throws Exception {
		//DeletePreferenceResponse actualDelPrefResponse = printOrderUtil.getDeletePreferenceResponse(input, sellerName, site);
		String actualDelPrefResponse = printOrderUtil.getDeletePreferenceResponse(input, sellerName, site);
		//if(actualDelPrefResponse.getSuccess().equals("true"))
		if(actualDelPrefResponse.equalsIgnoreCase("success"))
			breezeReport.logWithColor("Coupon Preferences Deleted Successfuly", "blue");
	}

	
	/*
	 * SendCoupon Notification - Validation For BlackListed Words
	 */
	private void validateBlacklistedWordsSendCouponNotification(SendCouponResponse actualSNResponse,List<String> buyer_ID,
			String newSelectedCouponId, String propFile, List<String> wordsList) throws Exception {
		
		breezeReport.logWithColor("Validating SendNotification BlackListedWords", "blue");
		List<com.ebay.printorder.pojo.SendCouponResponse.Messages> message = actualSNResponse.getMessages();
		
		if (wordsList.get(0).equals("GoodWords")) {
			String actualMessageFieldId = message.get(0).getFieldId();
			String expectedMessageFieldId = L10n.content(propFile, "SendNotification_MessageFieldId");
			breezeReport.logStep("Actual Message Field Id : " + actualMessageFieldId);
			breezeReport.logStep("Expected Message Field Id : " + expectedMessageFieldId);
			softAssert.assertEquals(actualMessageFieldId, expectedMessageFieldId,"SendNotification MessageFieldId is not correct");
			
			String actualMessageKey = message.get(0).getKey();
			String expectedMessageKey = L10n.content(propFile, "SendNotification_MessageKey");
			breezeReport.logStep("Actual Message Key : " + actualMessageKey);
			breezeReport.logStep("Expected Message Key : " + expectedMessageKey);
			softAssert.assertEquals(actualMessageKey, expectedMessageKey,"SendNotification MessageKey is not correct");
			
			String actualMessageText = message.get(0).getText();
			String expectedMessageText = L10n.content(propFile, "SendNotification_MessageText");
			breezeReport.logStep("Actual Message Text : " + actualMessageText);
			breezeReport.logStep("Expected Message Text : " + expectedMessageText);
			softAssert.assertEquals(actualMessageText, expectedMessageText,"SendNotification MessageText is not correct");
			
			String actualMessageType = message.get(0).getType();
			String expectedMessageType = L10n.content(propFile, "SendNotification_MessageType");
			breezeReport.logStep("Actual Message Type : " + actualMessageType);
			breezeReport.logStep("Expected Message Type : " + expectedMessageType);
			softAssert.assertEquals(actualMessageType, expectedMessageType,"SendNotification MessageType is not correct");
		} else {
			String actualMessageFieldId = message.get(0).getFieldId();
			String expectedMessageFieldId = L10n.content(propFile, "SendNotification_BLMessageFieldId");
			breezeReport.logStep("Actual Message Field Id: " + actualMessageFieldId);
			breezeReport.logStep("Expected Message Field Id: " + expectedMessageFieldId);
			softAssert.assertEquals(actualMessageFieldId, expectedMessageFieldId,"SendNotification MessageFieldId is not correct");
			
			String actualMessageKey = message.get(0).getKey();
			String expectedMessageKey = L10n.content(propFile, "SendNotification_BLMessageKey");
			breezeReport.logStep("Actual Message Key : " + actualMessageKey);
			breezeReport.logStep("Expected Message Key : " + expectedMessageKey);
			softAssert.assertEquals(actualMessageKey, expectedMessageKey,"SendNotification MessageKey is not correct");
			
			String actualMessageText = message.get(0).getText();
			String expectedMessageText = L10n.content(propFile, "SendNotification_BLMessageText");
			breezeReport.logStep("Actual Message Text : " + actualMessageText);
			breezeReport.logStep("Expected Message Text : " + expectedMessageText);
			softAssert.assertEquals(actualMessageText, expectedMessageText,"SendNotification MessageText is not correct");
			
			String actualMessageType = message.get(0).getType();
			String expectedMessageType = L10n.content(propFile, "SendNotification_BLMessageType");
			breezeReport.logStep("Actual Message Type : " + actualMessageType);
			breezeReport.logStep("Expected Message Type : " + expectedMessageType);
			softAssert.assertEquals(actualMessageType, expectedMessageType,"SendNotification MessageType is not correct");
		}
		
		breezeReport.logWithColor("***** SendNotification BlackListedWords Validation Complete *****", "green");	
	}

	
	/*
	 * ModuleProvider - SendCoupon Validation For No Coupon & Non-Store Seller 
	 */
	private void validateSendCouponForNocouponSeller(CreateCouponModule createCouponModule, String propFile, 
			ValidateInput input) throws Exception {
		breezeReport.logWithColor("Validating CreateCouponModule", "blue");
		
		String actualModuleType = createCouponModule.get_type();
		String expectedModuleType = L10n.content(propFile, "CreateCouponModule_Type");
		breezeReport.logStep("Actual Module Type : " + actualModuleType);
		breezeReport.logStep("Expected Module Type : " + expectedModuleType);
		softAssert.assertEquals(actualModuleType, expectedModuleType,"Module Type is not correct");
		
		if (input.getDeviceType().equals("NATIVE")) {
			breezeReport.logWithColor("***** Validating CreateCouponModule - Native ***** ", "blue");
			String actualContentText1 = createCouponModule.getContent().get(0).getTextSpans().get(0).getText();
			String expectedContentText1 = L10n.content(propFile, "CreateCouponModule_ContentText1");
			breezeReport.logStep("Actual Content Text : " + actualContentText1);
			breezeReport.logStep("Expected Content Text : " + expectedContentText1);
			softAssert.assertEquals(actualContentText1, expectedContentText1,"CreateCoupon ContentText is not correct");
			
			String actualContentText2 = createCouponModule.getContent().get(1).getTextSpans().get(0).getText();
			String expectedContentText2 = L10n.content(propFile, "CreateCouponModule_NativeContentText2") + " ";
			breezeReport.logStep("Actual Content Text : " + actualContentText2);
			breezeReport.logStep("Expected Content Text : " + expectedContentText2);
			softAssert.assertEquals(actualContentText2, expectedContentText2,"CreateCoupon ContentText is not correct");
			
			String actualContentText3 = createCouponModule.getContent().get(1).getTextSpans().get(1).getText();
			String expectedContentText3 = L10n.content(propFile, "CreateCouponModule_NativeContentText3");
			breezeReport.logStep("Actual Content Text : " + actualContentText3);
			breezeReport.logStep("Expected Content Text : " + expectedContentText3);
			softAssert.assertEquals(actualContentText3, expectedContentText3,"CreateCoupon ContentText is not correct");
			
			String actualContentActionURL = createCouponModule.getContent().get(1).getAction().getURL();
			String expectedContentActionURL = L10n.content(propFile, "CreateCouponModule_ContentActionURL");
			breezeReport.logStep("Actual Content Action URL : " + actualContentActionURL);
			breezeReport.logStep("Expected Content Action URL : " + expectedContentActionURL);
			softAssert.assertEquals(actualContentActionURL, expectedContentActionURL,"CreateCoupon ContentActionURL is not correct");
			
			String actualContentActionType = createCouponModule.getContent().get(1).getAction().getType().toString();
			String expectedContentActionType = L10n.content(propFile, "CreateCouponModule_ContentActionType");
			breezeReport.logStep("Actual Content Action Type : " + actualContentActionType);
			breezeReport.logStep("Expected Content Action Type : " + expectedContentActionType);
			softAssert.assertEquals(actualContentActionType, expectedContentActionType,"CreateCoupon ContentActionType is not correct");
			
			String actualContentText4 = createCouponModule.getContent().get(2).getTextSpans().get(0).getText();
			String expectedContentText4 = L10n.content(propFile, "CreateCouponModule_NativeContentText4");
			breezeReport.logStep("Actual Content Text : " + actualContentText4);
			breezeReport.logStep("Expected Content Text : " + expectedContentText4);
			softAssert.assertEquals(actualContentText4, expectedContentText4,"CreateCoupon ContentText is not correct");
		}
		
		else if (input.getSellerType().equals("No_Coupon_seller")){
			breezeReport.logWithColor("***** Validating CreateCouponModule - No_Coupon_seller ***** ", "blue");
			String actualContentText1 = createCouponModule.getContent().get(0).getTextSpans().get(0).getText();
			String expectedContentText1 = L10n.content(propFile, "CreateCouponModule_ContentText1");
			breezeReport.logStep("Actual Content Text : " + actualContentText1);
			breezeReport.logStep("Expected Content Text : " + expectedContentText1);
			softAssert.assertEquals(actualContentText1, expectedContentText1,"CreateCoupon ContentText is not correct");
			
			String actualContentText2 = createCouponModule.getContent().get(1).getTextSpans().get(0).getText();
			String expectedContentText2 = L10n.content(propFile, "CreateCouponModule_ContentText2");
			breezeReport.logStep("Actual Content Text : " + actualContentText2);
			breezeReport.logStep("Expected Content Text : " + expectedContentText2);
			softAssert.assertEquals(actualContentText2, expectedContentText2,"CreateCoupon ContentText is not correct");
			
			String actualContentText3 = createCouponModule.getContent().get(2).getTextSpans().get(0).getText();
			String expectedContentText3 = L10n.content(propFile, "CreateCouponModule_ContentText3");
			breezeReport.logStep("Actual Content Text : " + actualContentText3);
			breezeReport.logStep("Expected Content Text : " + expectedContentText3);
			softAssert.assertEquals(actualContentText3, expectedContentText3,"CreateCoupon ContentText is not correct");
			
			String actualContentText4 = createCouponModule.getContent().get(3).getTextSpans().get(0).getText();
			String expectedContentText4 = L10n.content(propFile, "CreateCouponModule_ContentText4");
			breezeReport.logStep("Actual Content Text : " + actualContentText4);
			breezeReport.logStep("Expected Content Text : " + expectedContentText4);
			softAssert.assertEquals(actualContentText4, expectedContentText4,"CreateCoupon ContentText is not correct");
			
			String actualContentActionURL = createCouponModule.getContent().get(3).getAction().getURL();
			String expectedContentActionURL = L10n.content(propFile, "CreateCouponModule_ContentActionURL");
			breezeReport.logStep("Actual Content Action URL : " + actualContentActionURL);
			breezeReport.logStep("Expected Content Action URL : " + expectedContentActionURL);
			softAssert.assertEquals(actualContentActionURL, expectedContentActionURL,"CreateCoupon ContentActionURL is not correct");
			
			String actualContentActionName = createCouponModule.getContent().get(3).getAction().getName();
			String expectedContentActionName = L10n.content(propFile, "CreateCouponModule_ContentActionName");
			breezeReport.logStep("Actual Content Action Name : " + actualContentActionName);
			breezeReport.logStep("Expected Content Action Name : " + expectedContentActionName);
			softAssert.assertEquals(actualContentActionName, expectedContentActionName,"CreateCoupon ContentActionName is not correct");
			
			String actualContentActionType = createCouponModule.getContent().get(3).getAction().getType().toString();
			String expectedContentActionType = L10n.content(propFile, "CreateCouponModule_ContentActionType");
			breezeReport.logStep("Actual Content Action Type : " + actualContentActionType);
			breezeReport.logStep("Expected Content Action Type : " + expectedContentActionType);
			softAssert.assertEquals(actualContentActionType, expectedContentActionType,"CreateCoupon ContentActionType is not correct");
			
			String actualCancelActionText = createCouponModule.getCancelAction().getText();
			String expectedCancelActionText = L10n.content(propFile, "CreateCouponModule_CancelActionText");
			breezeReport.logStep("Actual Cancel Action Text : " + actualCancelActionText);
			breezeReport.logStep("Expected Cancel Action Text : " + expectedCancelActionText);
			softAssert.assertEquals(actualCancelActionText, expectedCancelActionText,"CreateCoupon CancelActionText is not correct");
			
			String actualCancelActionType = createCouponModule.getCancelAction().getType();
			String expectedCancelActionType = L10n.content(propFile, "CreateCouponModule_CancelActionType");
			breezeReport.logStep("Actual Cancel Action Type : " + actualCancelActionType);
			breezeReport.logStep("Expected Cancel Action Type : " + expectedCancelActionType);
			softAssert.assertEquals(actualCancelActionType, expectedCancelActionType,"CreateCoupon CancelActionType is not correct");
			
			String actualCancelAction_AT = createCouponModule.getCancelAction().getAction().getType().toString();
			String expectedCancelAction_AT = L10n.content(propFile, "CreateCouponModule_CancelAction_CAType");
			breezeReport.logStep("Actual Cancel Action Action Type : " + actualCancelAction_AT);
			breezeReport.logStep("Expected Cancel Action Action Type : " + expectedCancelAction_AT);
			softAssert.assertEquals(actualCancelAction_AT, expectedCancelAction_AT,"CreateCoupon CancelAction ActionType is not correct");
		}
		
		else if (input.getSellerType().equals("Non_Store_seller")) {
			breezeReport.logWithColor("***** Validating CreateCouponModule - Non_Store_seller ***** ", "blue");
			String actualContentText1 = createCouponModule.getContent().get(0).getTextSpans().get(0).getText();
			String expectedContentText1 = L10n.content(propFile, "CreateCouponModule_NonSeller_ContentText1");
			breezeReport.logStep("Actual Content Text : " + actualContentText1);
			breezeReport.logStep("Expected Content Text : " + expectedContentText1);
			softAssert.assertEquals(actualContentText1, expectedContentText1,"CreateCoupon ContentText is not correct");
			
			String actualContentText2 = createCouponModule.getContent().get(1).getTextSpans().get(0).getText();
			String expectedContentText2 = L10n.content(propFile, "CreateCouponModule_NonSeller_ContentText2");
			breezeReport.logStep("Actual Content Text : " + actualContentText2);
			breezeReport.logStep("Expected Content Text : " + expectedContentText2);
			softAssert.assertEquals(actualContentText2, expectedContentText2,"CreateCoupon ContentText is not correct");
			
			String actualContentText3 = createCouponModule.getContent().get(2).getTextSpans().get(0).getText();
			String expectedContentText3 = L10n.content(propFile, "CreateCouponModule_NonSeller_ContentText3");
			breezeReport.logStep("Actual Content Text : " + actualContentText3);
			breezeReport.logStep("Expected Content Text : " + expectedContentText3);
			softAssert.assertEquals(actualContentText3, expectedContentText3,"CreateCoupon ContentText is not correct");
			
			String actualContentText4 = createCouponModule.getContent().get(3).getTextSpans().get(0).getText();
			String expectedContentText4 = L10n.content(propFile, "CreateCouponModule_NonSeller_ContentText4");
			breezeReport.logStep("Actual Content Text : " + actualContentText4);
			breezeReport.logStep("Expected Content Text : " + expectedContentText4);
			softAssert.assertEquals(actualContentText4, expectedContentText4,"CreateCoupon ContentText is not correct");
			
			String actualContentActionURL = createCouponModule.getContent().get(3).getAction().getURL();
			String expectedContentActionURL = L10n.content(propFile, "CreateCouponModule_NonSeller_ContentActionURL");
			breezeReport.logStep("Actual Content Action URL : " + actualContentActionURL);
			breezeReport.logStep("Expected Content Action URL : " + expectedContentActionURL);
			softAssert.assertEquals(actualContentActionURL, expectedContentActionURL,"CreateCoupon ContentActionURL is not correct");
			
			String actualContentActionName = createCouponModule.getContent().get(3).getAction().getName();
			String expectedContentActionName = L10n.content(propFile, "CreateCouponModule_NonSeller_ContentActionName");
			breezeReport.logStep("Actual Content Action Name : " + actualContentActionName);
			breezeReport.logStep("Expected Content Action Name : " + expectedContentActionName);
			softAssert.assertEquals(actualContentActionName, expectedContentActionName,"CreateCoupon ContentActionName is not correct");
			
			String actualContentActionType = createCouponModule.getContent().get(3).getAction().getType().toString();
			String expectedContentActionType = L10n.content(propFile, "CreateCouponModule_NonSeller_ContentActionType");
			breezeReport.logStep("Actual Content Action Type : " + actualContentActionType);
			breezeReport.logStep("Expected Content Action Type : " + expectedContentActionType);
			softAssert.assertEquals(actualContentActionType, expectedContentActionType,"CreateCoupon ContentActionType is not correct");
			
			String actualCancelActionText = createCouponModule.getCancelAction().getText();
			String expectedCancelActionText = L10n.content(propFile, "CreateCouponModule_CancelActionText");
			breezeReport.logStep("Actual Cancel Action Text : " + actualCancelActionText);
			breezeReport.logStep("Expected Cancel Action Text : " + expectedCancelActionText);
			softAssert.assertEquals(actualCancelActionText, expectedCancelActionText,"CreateCoupon CancelActionText is not correct");
			
			String actualCancelActionType = createCouponModule.getCancelAction().getType();
			String expectedCancelActionType = L10n.content(propFile, "CreateCouponModule_CancelActionType");
			breezeReport.logStep("Actual Cancel Action Type : " + actualCancelActionType);
			breezeReport.logStep("Expected Cancel Action Type : " + expectedCancelActionType);
			softAssert.assertEquals(actualCancelActionType, expectedCancelActionType,"CreateCoupon CancelActionType is not correct");
			
			String actualCancelAction_AT = createCouponModule.getCancelAction().getAction().getType().toString();
			String expectedCancelAction_AT = L10n.content(propFile, "CreateCouponModule_CancelAction_CAType");
			breezeReport.logStep("Actual Cancel Action Action Type : " + actualCancelAction_AT);
			breezeReport.logStep("Expected Cancel Action Action Type : " + expectedCancelAction_AT);
			softAssert.assertEquals(actualCancelAction_AT, expectedCancelAction_AT,"CreateCoupon CancelAction ActionType is not correct");
		}
		
		breezeReport.logWithColor("***** CreateCouponModule Validation Complete *****", "green");	
	}
	
	
	/*
	 * ModuleProvider - SendCoupon - BuyerInfo Validation
	 */
	private void validateBuyerInfo(BuyerInfo buyerInfo, CosmosResponse expectedCosmosResp, ModuleProviderRequest request,
			String propFile, SpdResponse spdResponse) throws Exception {
		breezeReport.logWithColor("Validating BuyerInfo", "blue");		
		
        //String expectedBuyerName = expectedCosmosResp.getMembers().get(0).getOrder().getBuyer().getUserIdentifier().getUserName();
        String expectedBuyerName = expectedCosmosResp.getMembers().get(0).getOrder() != null ?
        		expectedCosmosResp.getMembers().get(0).getOrder().getBuyer().getFullName() :
        			expectedCosmosResp.getMembers().get(0).getProformaOrder().getBuyer().getFullName();
        String actualBuyerName =  buyerInfo.getName().getTextSpans().get(0).getText();
        breezeReport.logStep("Actual BuyerName : " + expectedBuyerName);
		breezeReport.logStep("Expected BuyerName : " + actualBuyerName);
		softAssert.assertEquals(actualBuyerName, expectedBuyerName, "BuyerInfo - Name is not correct");
        
        //String expectedFullName = expectedCosmosResp.getMembers().get(0).getOrder().getBuyer().getFullName();
        String expectedFullName = expectedCosmosResp.getMembers().get(0).getOrder() != null ?
        		expectedCosmosResp.getMembers().get(0).getOrder().getBuyer().getUserIdentifier().getUserName() :
        		expectedCosmosResp.getMembers().get(0).getProformaOrder().getBuyer().getUserIdentifier().getUserName();
        String actualFullName = buyerInfo.getUsernameAndFeedback().getTextSpans().get(0).getText();
        breezeReport.logStep("Actual Buyer Full Name : " + actualFullName);
		breezeReport.logStep("Expected Buyer Full Name : " + expectedFullName);
		softAssert.assertEquals(actualFullName, expectedFullName, "BuyerInfo - FullName is not correct");
        
        String expectedFeedbackScore = String.valueOf(expectedCosmosResp.getMembers().get(0).getOrder() != null ?
        		expectedCosmosResp.getMembers().get(0).getOrder().getBuyer().getFeedbackScore() :
        		expectedCosmosResp.getMembers().get(0).getProformaOrder().getBuyer().getFeedbackScore());
        String actualFeedbackScore = buyerInfo.getUsernameAndFeedback().getTextSpans().get(2).getText();
        breezeReport.logStep("Actual Buyer Feedback Score : " + actualFeedbackScore);
		breezeReport.logStep("Expected Buyer Feedback Score : " + expectedFeedbackScore);
		softAssert.assertEquals(actualFeedbackScore, expectedFeedbackScore, "BuyerInfo - FeedbackScore is not correct");
        
        String actualUserType = buyerInfo.getUserType();
        String expectedUserType = L10n.content(propFile, "BuyerInfo_UserType");
        breezeReport.logStep("Actual Buyer User Type : " + actualUserType);
		breezeReport.logStep("Expected Buyer User Type : " + expectedUserType);
		softAssert.assertEquals(actualUserType, expectedUserType, "BuyerInfo - UserType is not correct");
        
		if (buyerInfo.getProfileImage() != null) {
			String actualProfileImageTitle = buyerInfo.getProfileImage().getTitle();
	        String expectedProfileImageTitle = L10n.content(propFile, "BuyerInfo_ProfileImageTitle") +" "+ expectedFullName;
	        breezeReport.logStep("Actual Buyer Profile Image Title : " + actualProfileImageTitle);
			breezeReport.logStep("Expected Buyer Profile Image Title : " + expectedProfileImageTitle);
			softAssert.assertEquals(actualProfileImageTitle, expectedProfileImageTitle, "BuyerInfo - Profile ImageTitle is not correct");
	        		
	        String actualImageId = buyerInfo.getProfileImage().getImageId();
	        String expectedImageId = L10n.content(propFile, "BuyerInfo_ImageId");
	        breezeReport.logStep("Actual Buyer Profile ImageId : " + actualImageId);
			breezeReport.logStep("Expected Buyer Profile ImageId : " + expectedImageId);
			softAssert.assertEquals(actualImageId, expectedImageId, "BuyerInfo - Profile ImageId is not correct");
	        
	        String actualImageIdType = buyerInfo.getProfileImage().getImageIdType();
	        String expectedImageIdType = L10n.content(propFile, "BuyerInfo_ImageIdType");
	        breezeReport.logStep("Actual Buyer Profile ImageId Type : " + actualImageIdType);
			breezeReport.logStep("Expected Buyer Profile ImageId Type : " + expectedImageIdType);
			softAssert.assertEquals(actualImageIdType, expectedImageIdType, "BuyerInfo - Profile ImageId Type is not correct");
			}
        
		if (spdResponse.getGroupResults().get(0).getResults().get(0).equals("1") && 
				buyerInfo.getRepeatedBuyerInfo() != null) {
			String actualRBText = buyerInfo.getRepeatedBuyerInfo().getIndicator().getTextSpans().get(0).getText();
			String expRBText = L10n.content(propFile, "REPEAT_BUYER_TEXT");

			breezeReport.logStep("Expected repeat buyer text:" + expRBText);
			breezeReport.logStep("Actual repeat buyer text:" + actualRBText);
			softAssert.assertEquals(actualRBText, expRBText, "Repeat Buyer text didn't match");

			String actualRBHoverText = buyerInfo.getRepeatedBuyerInfo().getIndicatorHoverText().getTextSpans().get(0).getText();
			String expRBHoverText = L10n.content(propFile, "REPEAT_BUYER_HOVER_TEXT");

			breezeReport.logStep("Expected repeat buyer hover text:" + expRBHoverText);
			breezeReport.logStep("Actual repeat buyer hover text:" + actualRBHoverText);
			softAssert.assertEquals(actualRBHoverText, expRBHoverText, "Repeat Buyer hover text didn't match");
		}
		
        breezeReport.logWithColor("***** BuyerInfo Validation Complete *****", "green");
        }
	
	
	/*
	 * ModuleProvider - SendCoupon - selectionGroup Validation
	 */
	private void validateSendCouponModuleSelectionGroup(List<SelectionGroup> selectionGroup, FormatResponse 
			expectedAvailableCouponModuleSMEResp,CosmosResponse expectedCosmosResp, String propFile,
			boolean isPreferenceSet)throws Exception {
		
		breezeReport.logWithColor("Validating SelectionGroup", "blue");
		
		String actualSelectionGroupTitle = selectionGroup.get(0).getTitle().getTextSpans().get(0).getText();
		String expectedSelectionGroupTitle = L10n.content(propFile, "SelectionGroup_Title");
		breezeReport.logStep("Actual Selection Group Title : " + actualSelectionGroupTitle);
		breezeReport.logStep("Expected Selection Group Title : " + expectedSelectionGroupTitle);
		softAssert.assertEquals(actualSelectionGroupTitle, expectedSelectionGroupTitle,"SelectionGroupTitle is not correct");
		
		String actualMessageDismissText = selectionGroup.get(0).getHelp().getMessageDismiss().getTextSpans().get(0).getText();
		String expectedMessageDismissText = L10n.content(propFile, "Done");
		breezeReport.logStep("Actual BubbleHelp Message Dismiss Text : " + actualMessageDismissText);
		breezeReport.logStep("Expected BubbleHelp Message Dismiss Text : " + expectedMessageDismissText);
		softAssert.assertEquals(actualMessageDismissText, expectedMessageDismissText, 
				"SelectionGroup BubbleHelp Message Dismiss Text is not correct");
		
		String actualMessageDismissActionType = selectionGroup.get(0).getHelp().getMessageDismiss().getAction().getType().toString();
		String expectedMessageDismissActionType = L10n.content(propFile, "ActionType_Text");
		breezeReport.logStep("Actual BubbleHelp Message Dismiss ActionType : " + actualMessageDismissActionType);
		breezeReport.logStep("Expected BubbleHelp Message Dismiss ActionType : " + expectedMessageDismissActionType);
		softAssert.assertEquals(actualMessageDismissActionType, expectedMessageDismissActionType,
				"SelectionGroup BubbleHelp Action Type is not correct");
		
		String actualBubbleIconName = selectionGroup.get(0).getHelp().getBubbleIcon().getName();
		String expectedBubbleIconName = L10n.content(propFile, "BubbleIcon_Name");
		breezeReport.logStep("Actual BubbleIcon Name : " + actualBubbleIconName);
		breezeReport.logStep("Expected BubbleIcon Name : " + expectedBubbleIconName);
		softAssert.assertEquals(actualBubbleIconName, expectedBubbleIconName,"SelectionGroup BubbleIcon Name is not correct");
		
		String actualBubbleIconAccessTxt = selectionGroup.get(0).getHelp().getBubbleIcon().getAccessibilityText();
		String expectedBubbleIconAccessTxt = L10n.content(propFile, "BubbleIcon_AccessibilityText");
		breezeReport.logStep("Actual BubbleIcon Accessibility Text : " + actualBubbleIconAccessTxt);
		breezeReport.logStep("Expected BubbleIcon Accessibility Text : " + expectedBubbleIconAccessTxt);
		softAssert.assertEquals(actualBubbleIconAccessTxt, expectedBubbleIconAccessTxt,
				"SelectionGroup BubbleIcon AccessibilityText is not correct");
		
		String actualBubbleIconActionType = selectionGroup.get(0).getHelp().getBubbleIcon().getAction().getType().toString();
		String expectedBubbleIconActionType = L10n.content(propFile, "ActionType_Text");
		breezeReport.logStep("Actual BubbleIcon Action Type : " + actualBubbleIconActionType);
		breezeReport.logStep("Expected BubbleIcon Action Type : " + expectedBubbleIconActionType);
		softAssert.assertEquals(actualBubbleIconActionType, expectedBubbleIconActionType,
				"SelectionGroup BubbleIcon Action Type is not correct");
		
		softAssert.assertEquals(selectionGroup.get(0).getHelp().getBubbleIcon().getAction().getTrackingList().
				get(0).getEventFamily(), L10n.content(propFile, "Action_EventFamily"), 
				"SelectionGroup BubbleIcon TrackingList EventFamily is not correct");
		
		softAssert.assertEquals(selectionGroup.get(0).getHelp().getBubbleIcon().getAction().getTrackingList().
				get(0).getEventAction(), L10n.content(propFile, "Action_EventAction"), 
				"SelectionGroup BubbleIcon TrackingList EventAction is not correct");
		
		softAssert.assertEquals(selectionGroup.get(0).getHelp().getBubbleIcon().getAction().getTrackingList().
				get(0).getActionKind(), L10n.content(propFile, "Action_ActionKind"), 
				"SelectionGroup BubbleIcon TrackingList ActionKind is not correct");
		
		String actualHelpMsgTxt = selectionGroup.get(0).getHelp().getMessageText().get(0).getTextSpans().get(0).getText();
		String expectedHelpMsgTxt = L10n.content(propFile, "Help_MessageText");
		breezeReport.logStep("Actual Help Message Text : " + actualHelpMsgTxt);
		breezeReport.logStep("Expected Help Message Text : " + expectedHelpMsgTxt);
		softAssert.assertEquals(actualHelpMsgTxt, expectedHelpMsgTxt, "SelectionGroup Help MessageText is not correct");
		
		
		if(isPreferenceSet) {
			breezeReport.logWithColor("Validating SelectionGroup SubSection for Saved Coupon Preference", "blue");
			
			String actualSubSectionFieldId = selectionGroup.get(0).getSubSection().get(0).getFieldId();
			String expectedSubSectionFieldId = L10n.content(propFile, "SendCoupon_SubSection_FieldId");
			breezeReport.logStep("Actual SubSection FieldId : " + actualSubSectionFieldId);
			breezeReport.logStep("Expected SubSection FieldId : " + expectedSubSectionFieldId);
			softAssert.assertEquals(actualSubSectionFieldId, expectedSubSectionFieldId, "SubSection FieldId is not correct");
			
			Synopsis synopsis = selectionGroup.get(0).getSubSection().get(0).getSynopsis();
			
			String actualSubSectionTitle = synopsis.getTitle().getTextSpans().get(0).getText();
			String expectedSubSectionTitle = L10n.content(propFile, "SendCoupon_SubSectionTitle");
			breezeReport.logStep("Actual SubSection Title : " + actualSubSectionTitle);
			breezeReport.logStep("Expected SubSection Title : " + expectedSubSectionTitle);
			softAssert.assertEquals(actualSubSectionTitle, expectedSubSectionTitle, "SubSection Title is not correct");
			
			if(synopsis.getSynopsis() != null && expectedAvailableCouponModuleSMEResp != null) {
				String actualSynopsisText = synopsis.getSynopsis().getTextSpans().get(0).getText();
				String expectedSynopsisText = expectedAvailableCouponModuleSMEResp.getSmeResponse().getCouponCode();
				breezeReport.logStep("Actual Synopsis Text : " + actualSynopsisText);
				breezeReport.logStep("Expected Synopsis Text : " + expectedSynopsisText);
				softAssert.assertEquals(actualSynopsisText, expectedSynopsisText, "SubSection Synopsis Text does not match");

				String actualSynopsisAccessText = synopsis.getSynopsis().getAccessibilityText();
				String expectedSynopsisAccessText = expectedAvailableCouponModuleSMEResp.getSmeResponse().getCouponCode();
				breezeReport.logStep("Actual Synopsis Accessibility Text : " + actualSynopsisAccessText);
				breezeReport.logStep("Expected Synopsis Accessibility Text : " + expectedSynopsisAccessText);
				softAssert.assertEquals(actualSynopsisAccessText, expectedSynopsisAccessText, 
						"SubSection Synopsis Accessibility Text does not match");

				String actualEditActionText = synopsis.getEditAction().getTextSpans().get(0).getText();
				String expectedEditActionText = expectedAvailableCouponModuleSMEResp.getSmeResponse().getMessage();
				breezeReport.logStep("Actual Edit Action Text : " + actualEditActionText);
				breezeReport.logStep("Expected Edit Action Text : " + expectedEditActionText);
				softAssert.assertEquals(actualEditActionText, expectedEditActionText, "SubSection Edit Action Text does not match");

				String actualEditActionType = synopsis.getEditAction().getAction().getType().toString();
				String expectedEditActionType = L10n.content(propFile, "ActionType_Text");
				breezeReport.logStep("Actual EditAction Action Type : " + actualEditActionType);
				breezeReport.logStep("Expected EditAction Action Type : " + expectedEditActionType);
				softAssert.assertEquals(actualEditActionType, expectedEditActionType, 
						"SubSection EditAction Action Type does not match");

				String actualEditActionName = synopsis.getEditAction().getAction().getName();
				String expectedEditActionName = L10n.content(propFile, "EditAction_Name");
				breezeReport.logStep("Actual EditAction Action Name : " + actualEditActionName);
				breezeReport.logStep("Expected EditAction Action Name : " + expectedEditActionName);
				softAssert.assertEquals(actualEditActionName, expectedEditActionName, 
						"SubSection EditAction Action Name does not match");

				String actualActionParamsOption = synopsis.getEditAction().getAction().getParams().get("options");
				String expectedActionParamsOption = L10n.content(propFile, "SubSectionFragment_ParamOption");
				breezeReport.logStep("Actual EditAction Action Params Option : " + actualActionParamsOption);
				breezeReport.logStep("Expected EditAction Action Params Option : " + expectedActionParamsOption);
				softAssert.assertEquals(actualActionParamsOption, expectedActionParamsOption, 
						"SubSection EditAction Action Params Option does not match");

				String actualSelectedPromotionId = synopsis.getEditAction().getAction().getParams().get("selectedPromotionId");
				String expectedSelectedPromotionId = expectedAvailableCouponModuleSMEResp.getSmeResponse().getPromotionId();
				breezeReport.logStep("Actual EditAction Params Selected Promotion ID : " + actualSelectedPromotionId);
				breezeReport.logStep("Expected EditAction Params Selected Promotion ID : " + expectedSelectedPromotionId);
				softAssert.assertEquals(actualSelectedPromotionId, expectedSelectedPromotionId, 
						"SubSection EditAction Action Params Selected Promotion ID does not match");

				String actualParamsModule = synopsis.getEditAction().getAction().getParams().get("modules");
				String expectedParamsModule = L10n.content(propFile, "SubSectionFragment_ParamModule");
				breezeReport.logStep("Actual EditAction Params Modules : " + actualParamsModule);
				breezeReport.logStep("Expected EditAction Params Modules : " + expectedParamsModule);
				softAssert.assertEquals(actualParamsModule, expectedParamsModule, 
						"SubSection EditAction Action Params Modules does not match");

				String actualOfferValidDate = synopsis.getSelectionSummary().get(0).getTextSpans().get(0).getText();
				String expectedOfferValidDate = expectedAvailableCouponModuleSMEResp.getFormatValidDate();
				breezeReport.logStep("Actual Selection Summary Offer Valid Date : " + actualOfferValidDate);
				breezeReport.logStep("Expected Selection Summary Offer Valid Date  : " + expectedOfferValidDate);
				softAssert.assertEquals(actualOfferValidDate, expectedOfferValidDate, 
						"SubSection Selection Summary Offer Valid Date does not match");

				String actualCouponSubType = synopsis.getSelectionSummary().get(1).getTextSpans().get(0).getText();
				String expectedCouponSubType = expectedAvailableCouponModuleSMEResp.getSmeResponse().getSubType().
						equals("PUBLIC_SINGLE_SELLER_COUPON") ? "Public coupon" : "Private coupon";
				breezeReport.logStep("Actual Selection Summary Coupon Subtype : " + actualCouponSubType);
				breezeReport.logStep("Expected Selection Summary Coupon Subtype  : " + expectedCouponSubType);
				softAssert.assertEquals(actualCouponSubType, expectedCouponSubType, 
						"SubSection Selection Summary Coupon Subtype does not match");

				String actualmaxCouponDiscountAmount = synopsis.getSelectionSummary().get(2).getTextSpans().get(0).getText();
				DecimalFormat decimalFormat = new DecimalFormat("#.00");
				decimalFormat.setMinimumFractionDigits(2);
				String expectedmaxCouponDiscountAmount = decimalFormat.format(expectedAvailableCouponModuleSMEResp.getSmeResponse().
						getMaxCouponDiscountAmount().getValue());
				String expectedmaxCouponDiscountAmountStr = "Maximum savings of $" + expectedmaxCouponDiscountAmount + " per coupon";
				breezeReport.logStep("Actual Selection Summary Coupon Max Discount Amount : " + actualmaxCouponDiscountAmount);
				breezeReport.logStep("Expected Selection Summary Coupon Max Discount Amount  : " + expectedmaxCouponDiscountAmountStr);
				softAssert.assertEquals(actualmaxCouponDiscountAmount, expectedmaxCouponDiscountAmountStr, 
						"SubSection Selection Summary Coupon Max Discount Amount does not match");

				String actualmaxCouponRedemptionPerUser = synopsis.getSelectionSummary().get(3).getTextSpans().get(0).getText();
				int expectedmaxCouponRedemptionPerUser = expectedAvailableCouponModuleSMEResp.getSmeResponse().
						getMaxCouponRedemptionPerUser();
				String expectedmaxCouponRedemptionUsed = null;
				if (expectedmaxCouponRedemptionPerUser == 100000) 
					expectedmaxCouponRedemptionUsed = L10n.content(propFile, "SendCoupon_Module_Max_Coupon_Used");
				else
					expectedmaxCouponRedemptionUsed = "Limited to " + expectedmaxCouponRedemptionPerUser + " uses per coupon per buyer";
				breezeReport.logStep("Actual Selection Summary Max Coupon Redemptions per User : " + actualmaxCouponRedemptionPerUser);
				breezeReport.logStep("Expected Selection Summary Max Coupon Redemptions per User  : " + expectedmaxCouponRedemptionUsed);
				softAssert.assertEquals(actualmaxCouponRedemptionPerUser, expectedmaxCouponRedemptionUsed, 
						"SubSection Selection Summary Max Coupon Redemptions per User does not match");
			}
			breezeReport.logWithColor(" ***** SelectionGroup SubSection for Saved Coupon Preference Validation Complete *****", "green");
		}
		else { 
			breezeReport.logWithColor("Validating SelectionGroup SubSection", "blue");

			String actualSubSectionFieldId = selectionGroup.get(0).getSubSection().get(0).getFieldId();
			String expectedSubSectionFieldId = L10n.content(propFile, "SendCoupon_SubSection_FieldId");
			breezeReport.logStep("Actual SubSection FieldId : " + actualSubSectionFieldId);
			breezeReport.logStep("Expected SubSection FieldId : " + expectedSubSectionFieldId);
			softAssert.assertEquals(actualSubSectionFieldId, expectedSubSectionFieldId, "SubSection FieldId is not correct");
			
			Synopsis synopsis = selectionGroup.get(0).getSubSection().get(0).getSynopsis();
			
			String actualSubSectionTitle = synopsis.getTitle().getTextSpans().get(0).getText();
			String expectedSubSectionTitle = L10n.content(propFile, "SendCoupon_SubSectionTitle");
			breezeReport.logStep("Actual SubSection Title : " + actualSubSectionTitle);
			breezeReport.logStep("Expected SubSection Title : " + expectedSubSectionTitle);
			softAssert.assertEquals(actualSubSectionTitle, expectedSubSectionTitle, "SubSection Title is not correct");
			
			String actualEditActionText = synopsis.getEditAction().getTextSpans().get(0).getText();
			String expectedEditActionText = L10n.content(propFile, "SendCoupon_SubSectionEditAction");
			breezeReport.logStep("Actual Edit Action Text : " + actualEditActionText);
			breezeReport.logStep("Expected Edit Action Text : " + expectedEditActionText);
			softAssert.assertEquals(actualEditActionText, expectedEditActionText, "SubSection Edit Action Text does not match");
		
			String actualEditActionType = synopsis.getEditAction().getAction().getType().toString();
			String expectedEditActionType = L10n.content(propFile, "ActionType_Text");
			breezeReport.logStep("Actual EditAction Action Type : " + actualEditActionType);
			breezeReport.logStep("Expected EditAction Action Type : " + expectedEditActionType);
			softAssert.assertEquals(actualEditActionType, expectedEditActionType, 
					"SubSection EditAction Action Type does not match");
			
			String actualEditActionName = synopsis.getEditAction().getAction().getName();
			String expectedEditActionName = L10n.content(propFile, "EditAction_Name");
			breezeReport.logStep("Actual EditAction Action Name : " + actualEditActionName);
			breezeReport.logStep("Expected EditAction Action Name : " + expectedEditActionName);
			softAssert.assertEquals(actualEditActionName, expectedEditActionName, 
					"SubSection EditAction Action Name does not match");
			
			String actualActionParamsOption = synopsis.getEditAction().getAction().getParams().get("options");
			String expectedActionParamsOption = L10n.content(propFile, "SubSectionFragment_ParamOption");
			breezeReport.logStep("Actual EditAction Action Params Option : " + actualActionParamsOption);
			breezeReport.logStep("Expected EditAction Action Params Option : " + expectedActionParamsOption);
			softAssert.assertEquals(actualActionParamsOption, expectedActionParamsOption, 
					"SubSection EditAction Action Params Option does not match");
			
			String actualParamsModule = synopsis.getEditAction().getAction().getParams().get("modules");
			String expectedParamsModule = L10n.content(propFile, "SubSectionFragment_ParamModule");
			breezeReport.logStep("Actual EditAction Params Modules : " + actualParamsModule);
			breezeReport.logStep("Expected EditAction Params Modules : " + expectedParamsModule);
			softAssert.assertEquals(actualParamsModule, expectedParamsModule, 
					"SubSection EditAction Action Params Modules does not match");
			
			breezeReport.logWithColor(" ***** SelectionGroup SubSection Validation Complete *****", "blue");
		}
		breezeReport.logWithColor("***** SelectionGroup Validation Complete *****", "green");
	}
	
	
	/*
	 * ModuleProvider - SendCoupon - selectionGroup Validation
	 */
	private void validateMessageToBuyer(MessageToBuyer messageToBuyer, String propFile) throws Exception {
		breezeReport.logWithColor("Validating MessageToBuyer", "blue");
		
		String actualMsgToBuyerType = messageToBuyer.get_type();
		String expectedMsgToBuyerType = L10n.content(propFile, "MessageToBuyer_Type");
		breezeReport.logStep("Actual MessageToBuyer Type : " + actualMsgToBuyerType);
		breezeReport.logStep("Expected MessageToBuyer Type  : " + expectedMsgToBuyerType);
		softAssert.assertEquals(actualMsgToBuyerType, expectedMsgToBuyerType, "MessageToBuyer - Type is not correct");
        
		int actualMsgToBuyerMaxLength = messageToBuyer.getMaxLength();
		String expectedMsgToBuyerMaxLength = L10n.content(propFile, "MessageToBuyer_maxLength");
		breezeReport.logStep("Actual MessageToBuyer Max Length : " + actualMsgToBuyerMaxLength);
		breezeReport.logStep("Expected MessageToBuyer Max Length  : " + expectedMsgToBuyerMaxLength);
		softAssert.assertEquals(Integer.toString(actualMsgToBuyerMaxLength), expectedMsgToBuyerMaxLength, 
				"MessageToBuyer - Max Length is not correct");
        
		String actualMsgToBuyerFieldId= messageToBuyer.getFieldId();
		String expectedMsgToBuyerFieldId = L10n.content(propFile, "MessageToBuyer_FieldId");
		breezeReport.logStep("Actual MessageToBuyer Field Id : " + actualMsgToBuyerFieldId);
		breezeReport.logStep("Expected MessageToBuyer Field Id  : " + expectedMsgToBuyerFieldId);
		softAssert.assertEquals(actualMsgToBuyerFieldId, expectedMsgToBuyerFieldId, "MessageToBuyer - Field Id is not correct");
        
		String actualLabelText = messageToBuyer.getLabel().getTextSpans().get(0).getText();
		String expectedLabelText = L10n.content(propFile, "MessageToBuyer_Label");
		breezeReport.logStep("Actual MessageToBuyer Label Text : " + actualLabelText);
		breezeReport.logStep("Expected MessageToBuyer Label Text: " + expectedLabelText);
		softAssert.assertEquals(actualLabelText, expectedLabelText, 
				"MessageToBuyer - LabelText is not correct");
        
		String actualAccessoryLabelText = messageToBuyer.getAccessoryLabel().getTextSpans().get(0).getText();
		String expectedAccessoryLabelText = L10n.content(propFile, "MessageToBuyer_AccessoryLabel");
		breezeReport.logStep("Actual MessageToBuyer AccessoryLabel Text : " + actualAccessoryLabelText);
		breezeReport.logStep("Expected MessageToBuyer AccessoryLabel Text: " + expectedAccessoryLabelText);
		softAssert.assertEquals(actualAccessoryLabelText, expectedAccessoryLabelText, 
				"MessageToBuyer - AccessoryLabelText is not correct");
        
		String actualPlaceHolderText = messageToBuyer.getPlaceHolder().getTextSpans().get(0).getText();
		String expectedPlaceHolderText = L10n.content(propFile, "MessageToBuyer_PlaceHolder");
		breezeReport.logStep("Actual MessageToBuyer PlaceHolder Text: " + actualPlaceHolderText);
		breezeReport.logStep("Expected MessageToBuyer PlaceHolder Text : " + expectedPlaceHolderText);
		softAssert.assertEquals(actualPlaceHolderText, expectedPlaceHolderText, "MessageToBuyer - PlaceHolderText is not correct");
        
        String expectedMaxLength = L10n.content(propFile, "MessageToBuyer_maxLength");
        int actualMaxLength = messageToBuyer.getValidations().get(0).getMaxLength();
        breezeReport.logStep("Actual MessageToBuyer Validation Max length: " + actualMaxLength);
		breezeReport.logStep("Expected MessageToBuyer Validation Max length: " + expectedMaxLength);
		softAssert.assertEquals(Integer.toString(actualMaxLength), expectedMaxLength, 
        		"MessageToBuyer - Validation Maxlength is not correct");
        
		boolean actualRequiredFlag = messageToBuyer.getValidations().get(0).isRequired();
		breezeReport.logStep("Actual MessageToBuyer Validation Required Flag : " + actualRequiredFlag);
		softAssert.assertTrue(actualRequiredFlag, "MessageToBuyer - Validation Required Flag is not TRUE");
        
		breezeReport.logWithColor("***** MessageToBuyer Validation Complete *****", "green");
	}
	

	/*
	 * ModuleProvider - SendCoupon - Send & Cancel Action Validation
	 */
	private void validateSendCancelAction(SendCouponModules sendCouponModules, String propFile) throws Exception{
		breezeReport.logWithColor("Validating Send & Cancel Action ", "blue");
		
		if (sendCouponModules.getSendAction().getText().equals("Send")) {
			
			String actualActionType = sendCouponModules.getSendAction().get_type();
			String expectedActionType = L10n.content(propFile, "SendCoupon_ActionType");
			breezeReport.logStep("Actual Send Action Type : " + actualActionType);
			breezeReport.logStep("Expected Send Action Type  : " + expectedActionType);
			softAssert.assertEquals(actualActionType, expectedActionType, "SendAction Type does not match");
			
			String actualSendActionText = sendCouponModules.getSendAction().getText();
			String expectedSendActionText = L10n.content(propFile, "SendAction_Text");
			breezeReport.logStep("Actual Send Action Text : " + actualSendActionText);
			breezeReport.logStep("Expected Send Action Text  : " + expectedSendActionText);
			softAssert.assertEquals(actualSendActionText, expectedSendActionText, "SendAction Text does not match");
			
			String actualSendActionAccessTxt = sendCouponModules.getSendAction().getAccessibilityText();
			String expectedSendActionAccessTxt = L10n.content(propFile, "SendAction_Text");
			breezeReport.logStep("Actual SendAction Accessibility Text : " + actualSendActionAccessTxt);
			breezeReport.logStep("Expected SendAction Accessibility Text  : " + expectedSendActionAccessTxt);
			softAssert.assertEquals(actualSendActionAccessTxt, expectedSendActionAccessTxt, 
					"SendAction Accessibility Text does not match");
			
			String actualSendActionType = sendCouponModules.getSendAction().getType();
			String expectedSendActionType = L10n.content(propFile, "SendAction_Type");
			breezeReport.logStep("Actual Send Action Type : " + actualSendActionType);
			breezeReport.logStep("Expected Send Action Type  : " + expectedSendActionType);
			softAssert.assertEquals(actualSendActionType, expectedSendActionType, "SendAction Type does not match");
			
			String actualSendAction_Type = sendCouponModules.getSendAction().getAction().getType().toString();
			String expectedSendAction_Type = L10n.content(propFile, "ActionType_Text");
			breezeReport.logStep("Actual SendAction Action Type : " + actualSendAction_Type);
			breezeReport.logStep("Expected SendAction Action Type  : " + expectedSendAction_Type);
			softAssert.assertEquals(actualSendAction_Type, expectedSendAction_Type, "SendAction Action Type does not match");
			
			softAssert.assertEquals(sendCouponModules.getSendAction().getAction().getTrackingList().get(0).getEventFamily(),
					L10n.content(propFile, "Action_EventFamily"), "SelectionGroup BubbleIcon TrackingList EventFamily is not correct");
			
			softAssert.assertEquals(sendCouponModules.getSendAction().getAction().getTrackingList().get(0).getEventAction(),
					L10n.content(propFile, "Action_EventAction"), "SelectionGroup BubbleIcon TrackingList EventAction is not correct");
			
			softAssert.assertEquals(sendCouponModules.getSendAction().getAction().getTrackingList().get(0).getActionKind(),
					L10n.content(propFile, "Action_ActionKind"), "SelectionGroup BubbleIcon TrackingList ActionKind is not correct");
			}
		
		if (sendCouponModules.getCancelAction().getText().equals("Cancel")) {
			
			String actualActionType = sendCouponModules.getCancelAction().get_type();
			String expectedActionType = L10n.content(propFile, "SendCoupon_ActionType");
			breezeReport.logStep("Actual Cancel Action Type : " + actualActionType);
			breezeReport.logStep("Expected Cancel Action Type  : " + expectedActionType);
			softAssert.assertEquals(actualActionType, expectedActionType, "CancelAction Type does not match");
			
			String actualCancelActionText = sendCouponModules.getCancelAction().getText();
			String expectedCancelActionText = L10n.content(propFile, "CancelAction_Text");
			breezeReport.logStep("Actual Cancel Action Text : " + actualCancelActionText);
			breezeReport.logStep("Expected Cancel Action Text  : " + expectedCancelActionText);
			softAssert.assertEquals(actualCancelActionText, expectedCancelActionText, "CancelAction Text does not match");
			
			String actualCancelActionAccessTxt = sendCouponModules.getCancelAction().getAccessibilityText();
			String expectedCancelActionAccessTxt = L10n.content(propFile, "CancelAction_Text");
			breezeReport.logStep("Actual CancelAction Accessibility Text : " + actualCancelActionAccessTxt);
			breezeReport.logStep("Expected CancelAction Accessibility Text  : " + expectedCancelActionAccessTxt);
			softAssert.assertEquals(actualCancelActionAccessTxt, expectedCancelActionAccessTxt, 
					"CancelAction Accessibility Text does not match");
			
			String actualCancelActionType = sendCouponModules.getCancelAction().getType();
			String expectedCancelActionType = L10n.content(propFile, "CancelAction_Type");
			breezeReport.logStep("Actual Cancel Action Type : " + actualCancelActionType);
			breezeReport.logStep("Expected Cancel Action Type  : " + expectedCancelActionType);
			softAssert.assertEquals(actualCancelActionType, expectedCancelActionType, "CancelAction Type does not match");
			
			String actualCancelAction_Type = sendCouponModules.getCancelAction().getAction().getType().toString();
			String expectedCancelAction_Type = L10n.content(propFile, "ActionType_Text");
			breezeReport.logStep("Actual CancelAction Action Type : " + actualCancelAction_Type);
			breezeReport.logStep("Expected CancelAction Action Type  : " + expectedCancelAction_Type);
			softAssert.assertEquals(actualCancelAction_Type, expectedCancelAction_Type, "CancelAction Action Type does not match");
			
			softAssert.assertEquals(sendCouponModules.getCancelAction().getAction().getTrackingList().get(0).getEventFamily(),
					L10n.content(propFile, "Action_EventFamily"), "SelectionGroup BubbleIcon TrackingList EventFamily is not correct");
			softAssert.assertEquals(sendCouponModules.getCancelAction().getAction().getTrackingList().get(0).getEventAction(),
					L10n.content(propFile, "Action_EventAction"), "SelectionGroup BubbleIcon TrackingList EventAction is not correct");
			softAssert.assertEquals(sendCouponModules.getCancelAction().getAction().getTrackingList().get(0).getActionKind(),
					L10n.content(propFile, "Action_ActionKind"), "SelectionGroup BubbleIcon TrackingList ActionKind is not correct");
			
		}
		breezeReport.logWithColor("***** Send & CancelAction Validation Complete *****", "green");
	}
	
	
	/*
	 * ModuleProvider - SendCoupon - SendSelectionData Validation
	 */
	private void validateSendSelectionData(SendCouponModules sendCouponModules, ValidateInput input, 
			CosmosResponse expectedCosmosResp, String propFile, boolean isPreferenceSet, String buyerID) throws Exception {
        breezeReport.logWithColor("validate SendSelectionData", "blue");

        List<String> orderId = sendCouponModules.getSendSelectionData().getOrderIds();
        String actualOrderId =  orderId.stream().map(String::valueOf).collect(Collectors.joining());
        String expectedOrderId = expectedCosmosResp.getMembers().get(0).getIdentifier().getLookupKey();
        breezeReport.logStep("Actual Order Id : " + actualOrderId);
		breezeReport.logStep("Expected Order Id : " + expectedOrderId);
        softAssert.assertEquals(actualOrderId, expectedOrderId, "Order Id does not match");
        
        if(isPreferenceSet) {
        	String actualCouponId = sendCouponModules.getSendSelectionData().getCouponId();
        	breezeReport.logStep("Actual Coupon Id : " + actualCouponId);
        	softAssert.assertNotNull(actualCouponId, "SendCoupon CouponId  is null");
        }
        
        List<String> buyerId = sendCouponModules.getSendSelectionData().getBuyerIds();
        String actualBuyerId =  buyerId.stream().map(String::valueOf).collect(Collectors.joining());
        String expectedBuyerId = buyerID;
        breezeReport.logStep("Actual Buyer Id : " + actualBuyerId);
		breezeReport.logStep("Expected Buyer Id : " + expectedBuyerId);
        softAssert.assertEquals(actualBuyerId.toString(), expectedBuyerId, "Buyer Id does not match");
        
        breezeReport.logWithColor("***** SendSelectionData Validation Complete *****", "green");
    }
	

	/*
	 * ModuleProvider - SendCoupon - MessageBundle Validation
	 */
	private void validateMessageBundle(List<Message> MessageBundle, String propFile) throws Exception {
        breezeReport.logWithColor("validate MessageBundle", "blue");
        for (Message message : MessageBundle) {
            switch (message.getKey()) {
            
            case "serviceUnavailable":
            	String actualMessage = message.getText();
            	String expectedMessage = L10n.content(propFile, "Service_Unavailable_Message");
            	breezeReport.logStep("Actual Service Unavailable Message : " + actualMessage);
        		breezeReport.logStep("Expected Service Unavailable Message : " + expectedMessage);
            	softAssert.assertEquals(actualMessage, expectedMessage, "Message Text is not correct");
                
            	String actualMsgType = message.getType();
            	String expectedMsgType = "ERROR";
            	breezeReport.logStep("Actual Service Unavailable Message Type : " + actualMsgType);
        		breezeReport.logStep("Expected Service Unavailable Message Type : " + expectedMsgType);
            	softAssert.assertEquals(actualMsgType, expectedMsgType, "Message Type is not correct");
                break;
            
            case "close":
            	String actualCloseMessage = message.getText();
            	String expectedCloseMessage = L10n.content(propFile, "Close_Message");
            	breezeReport.logStep("Actual Close Message : " + actualCloseMessage);
        		breezeReport.logStep("Expected Close Message : " + expectedCloseMessage);
            	softAssert.assertEquals(actualCloseMessage, expectedCloseMessage, "Message Text is not correct");
                
            	String actualCloseMsgType = message.getType();
            	String expectedCloseMsgType = "INFO";
            	breezeReport.logStep("Actual Close Message Type : " + actualCloseMsgType);
        		breezeReport.logStep("Expected Close Message Type : " + expectedCloseMsgType);
            	softAssert.assertEquals(actualCloseMsgType, expectedCloseMsgType, "Message Type is not correct");
                break;    
             
            case "CHANGES_SAVED":
            	String actualChangesSavedMessage = message.getText();
            	String expectedChangesSavedessage = L10n.content(propFile, "ChangeS_Saved");
            	breezeReport.logStep("Actual Changes Saved Message : " + actualChangesSavedMessage);
        		breezeReport.logStep("Expected Changes Saved Message : " + expectedChangesSavedessage);
            	softAssert.assertEquals(actualChangesSavedMessage, expectedChangesSavedessage,
                        "Message Text is not correct");
                break;
                
            case "couponServiceUnavailable":
            	String actualCouponServiceUnavailableTitle = message.getTitle();
            	String expectedCouponServiceUnavailableTitle = L10n.content(propFile, "Coupon_Service_Unavailable_Title");
            	breezeReport.logStep("Actual Coupon Service Unavailable Title : " + actualCouponServiceUnavailableTitle);
        		breezeReport.logStep("Expected Coupon Service Unavailable Title : " + expectedCouponServiceUnavailableTitle);
            	softAssert.assertEquals(actualCouponServiceUnavailableTitle, expectedCouponServiceUnavailableTitle, 
            			"Message Title is not correct");
                
            	String actualCouponServiceUnavailableMsg = message.getText();
            	String expectedCouponServiceUnavailableMsg = L10n.content(propFile, "Coupon_Service_Unavailable_Text");
            	breezeReport.logStep("Actual Coupon Service Unavailable Message : " + actualCouponServiceUnavailableMsg);
        		breezeReport.logStep("Expected Coupon Service Unavailable Message : " + expectedCouponServiceUnavailableMsg);
            	softAssert.assertEquals(actualCouponServiceUnavailableMsg, expectedCouponServiceUnavailableMsg, 
            			"Message Text is not correct");
                
            	String actualCouponServiceUnavailableType = message.getType();
            	String expectedCouponServiceUnavailableType = "ERROR";
            	breezeReport.logStep("Actual Coupon Service Unavailable Message Type : " + actualCouponServiceUnavailableType);
        		breezeReport.logStep("Expected Coupon Service Unavailable Message Type : " + expectedCouponServiceUnavailableType);
            	softAssert.assertEquals(actualCouponServiceUnavailableType, expectedCouponServiceUnavailableType, 
            			"Message Type is not correct");
                break;  
                
            case "sendCouponServiceCallFailed":
            	String actualSendCouponServiceCallFailedMsg = message.getText();
            	String expectedSendCouponServiceCallFailedMsg = L10n.content(propFile, "SendCouponServiceCallFailed");
            	breezeReport.logStep("Actual SendCoupon Service Call Failed Message : " + actualSendCouponServiceCallFailedMsg);
        		breezeReport.logStep("Expected SendCoupon Service Call Failed Message : " + expectedSendCouponServiceCallFailedMsg);
            	softAssert.assertEquals(actualSendCouponServiceCallFailedMsg, expectedSendCouponServiceCallFailedMsg, 
            			"Message Text is not correct");
                
            	String actualSendCouponServiceCallFailedType = message.getType();
            	String expectedSendCouponServiceCallFailedType = "ERROR";
            	breezeReport.logStep("Actual SendCoupon Service Call Failed Message Type : " + actualSendCouponServiceCallFailedType);
        		breezeReport.logStep("Expected SendCoupon Service Call Failed Message Type : " + expectedSendCouponServiceCallFailedType);
            	softAssert.assertEquals(actualSendCouponServiceCallFailedType, expectedSendCouponServiceCallFailedType, 
            			"Message Type is not correct");
                break;   
            
            case "noCouponSelectedToSendNotification":
            	String actualNoCouponSelectedMsg = message.getText();
            	String expectedNoCouponSelectedMsg = L10n.content(propFile, "NoCouponSelectedToSendNotification");
            	breezeReport.logStep("Actual No Coupon Selected To Send Notification Message : " + actualNoCouponSelectedMsg);
        		breezeReport.logStep("Expected No Coupon Selected To Send Notification Message : " + expectedNoCouponSelectedMsg);
            	softAssert.assertEquals(actualNoCouponSelectedMsg, expectedNoCouponSelectedMsg, 
            			"Message Text is not correct");
                
            	String actualNoCouponSelectedType = message.getType();
            	String expectedNoCouponSelectedType = "ERROR";
            	breezeReport.logStep("Actual No Coupon Selected To Send Notification Message Type : " + actualNoCouponSelectedType);
        		breezeReport.logStep("Expected No Coupon Selected To Send Notification Message Type : " + expectedNoCouponSelectedType);
            	softAssert.assertEquals(actualNoCouponSelectedType, expectedNoCouponSelectedType, 
            			"Message Type is not correct");
            	break;
                
            case "couponNotificationSent":
            	String actualCouponNotificationSentMsg = message.getText();
            	String expectedCouponNotificationSentMsg = L10n.content(propFile, "CouponNotificationSent");
            	breezeReport.logStep("Actual CouponNotificationSent Message : " + actualCouponNotificationSentMsg);
        		breezeReport.logStep("Expected CouponNotificationSent Message : " + expectedCouponNotificationSentMsg);
            	softAssert.assertEquals(actualCouponNotificationSentMsg, expectedCouponNotificationSentMsg, 
            			"Message Text is not correct");
                
            	String actualCouponNotificationSentType = message.getType();
            	String expectedCouponNotificationSentType = "SUCCESS";
            	breezeReport.logStep("Actual CouponNotificationSent Message Type : " + actualCouponNotificationSentType);
        		breezeReport.logStep("Expected CouponNotificationSent Message Type : " + expectedCouponNotificationSentType);
            	softAssert.assertEquals(actualCouponNotificationSentType, expectedCouponNotificationSentType, 
            			"Message Type is not correct");
            	break;
            
            case "hasBlacklistedWords":
            	String actualBlacklistedWordsMsg = message.getText();
            	String expectedBlacklistedWordsMsg = L10n.content(propFile, "HasBlacklistedWords");
            	breezeReport.logStep("Actual hasBlacklistedWords Message : " + actualBlacklistedWordsMsg);
        		breezeReport.logStep("Expected hasBlacklistedWords Message : " + expectedBlacklistedWordsMsg);
            	softAssert.assertEquals(actualBlacklistedWordsMsg, expectedBlacklistedWordsMsg, 
            			"Message Text is not correct");
                
            	String actualBlacklistedWordsType = message.getType();
            	String expectedBlacklistedWordsType = "ERROR";
            	breezeReport.logStep("Actual hasBlacklistedWords Message Type : " + actualBlacklistedWordsType);
        		breezeReport.logStep("Expected hasBlacklistedWords Message Type : " + expectedBlacklistedWordsType);
            	softAssert.assertEquals(actualBlacklistedWordsType, expectedBlacklistedWordsType, 
            			"Message Type is not correct");
            	break;
                
            case "invalidRequest":
            	String actualInvalidRequestMsg = message.getText();
            	String expectedInvalidRequestMsg = L10n.content(propFile, "InvalidRequest");
            	breezeReport.logStep("Actual InvalidRequest Message : " + actualInvalidRequestMsg);
        		breezeReport.logStep("Expected InvalidRequest Message : " + expectedInvalidRequestMsg);
            	softAssert.assertEquals(actualInvalidRequestMsg, expectedInvalidRequestMsg, 
            			"Message Text is not correct");
                
            	String actualInvalidRequestType = message.getType();
            	String expectedInvalidRequestType = "ERROR";
            	breezeReport.logStep("Actual InvalidRequest Message Type : " + actualInvalidRequestType);
        		breezeReport.logStep("Expected InvalidRequest Message Type : " + expectedInvalidRequestType);
            	softAssert.assertEquals(actualInvalidRequestType, expectedInvalidRequestType, 
            			"Message Type is not correct");
            	break;
            }

        }
        breezeReport.logWithColor("***** MessageBundle Validation Complete *****", "green");
    }
	
	
	
	
	/*
	 * Module Provider - SendCoupon SubSection Fragment Validation
	 */
	private void validateSendCouponModuleSubSectionFragment(SendCouponResponse actualResponse, ValidateInput input, 
			String newSelectedCouponId, String propFile) throws Exception {
		breezeReport.logWithColor("Validating CouponModule SubSection Fragment", "blue");
		
		FormatResponse expectedSmeResponse = getSMEResponse(input, newSelectedCouponId);
		
		List<SubSectionFragment> subSectionFragment = actualResponse.getModuleFragments().getCouponModuleFragment()
				.getSubSectionFragment();
		
		String actualModuleFragmentType = actualResponse.getModuleFragments().getCouponModuleFragment().get_type();
		String expectedModuleFragmentType = L10n.content(propFile, "CouponModuleFragment_Type");
		breezeReport.logStep("Actual Coupon Module Fragment Type : " + actualModuleFragmentType);
		breezeReport.logStep("Expected Coupon Module Fragment Type : " + expectedModuleFragmentType);
		softAssert.assertEquals(actualModuleFragmentType, expectedModuleFragmentType,"CouponModuleFragment Type is not correct");
		
		String actualSubSectionFragmentFieldId = subSectionFragment.get(0).getFieldId();
		String expectedSubSectionFragmentFieldId = L10n.content(propFile, "SubSectionFragment_FieldId");
		breezeReport.logStep("Actual SubSection Fragment FieldId : " + actualSubSectionFragmentFieldId);
		breezeReport.logStep("Expected SubSection Fragment FieldId : " + expectedSubSectionFragmentFieldId);
		softAssert.assertEquals(actualSubSectionFragmentFieldId, expectedSubSectionFragmentFieldId,
				"SubSectionFragment FieldId is not correct");
		
		String actualTitle = subSectionFragment.get(0).getSynopsis().getTitle().getTextSpans().get(0).getText();
		String expectedTitle = L10n.content(propFile, "SubSectionFragment_Title");
		breezeReport.logStep("Actual SubSection Fragment Title : " + actualTitle);
		breezeReport.logStep("Expected SubSection Fragment Title : " + expectedTitle);
		softAssert.assertEquals(actualTitle, expectedTitle,"SubSection Fragment Title is not correct");
		
		if(expectedSmeResponse != null) {
			String actualSelectedCouponName = subSectionFragment.get(0).getSynopsis().getSynopsis().getTextSpans().get(0).getText();
			String expectedSelectedCouponName = expectedSmeResponse.getSmeResponse().getCouponCode();
			breezeReport.logStep("Actual SubSection Fragment CouponName : " + actualSelectedCouponName);
			breezeReport.logStep("Expected SubSection Fragment CouponName : " + expectedSelectedCouponName);
			softAssert.assertEquals(actualSelectedCouponName, expectedSelectedCouponName,"SubSection Fragment CouponName does not match");

			String actualEditActionText = subSectionFragment.get(0).getSynopsis().getEditAction().getTextSpans().get(0).getText();
			String expectedEditActionText = expectedSmeResponse.getSmeResponse().getMessage();
			breezeReport.logStep("Actual SubSection Fragment EditAction Text : " + actualEditActionText);
			breezeReport.logStep("Expected SubSection Fragment EditAction Text : " + expectedEditActionText);
			softAssert.assertEquals(actualEditActionText, expectedEditActionText,"SubSection Fragment EditAction Text does not match");

			String actualEditActionName = subSectionFragment.get(0).getSynopsis().getEditAction().getAction().getName();
			String expectedEditActionName = L10n.content(propFile, "EditAction_Name");
			breezeReport.logStep("Actual SubSection Fragment EditAction Params Options : " + actualEditActionName);
			breezeReport.logStep("Expected SubSection Fragment EditAction Params Options : " + expectedEditActionName);
			softAssert.assertEquals(actualEditActionName, expectedEditActionName,"SubSection Fragment EditAction Name does not match");

			String actualParamOption = subSectionFragment.get(0).getSynopsis().getEditAction().getAction().getParams().get("options");
			String expectedParamOption = L10n.content(propFile, "SubSectionFragment_ParamOption");
			breezeReport.logStep("Actual SubSection Fragment EditAction Params Options : " + actualParamOption);
			breezeReport.logStep("Expected SubSection Fragment EditAction Params Options : " + expectedParamOption);
			softAssert.assertEquals(actualParamOption, expectedParamOption,"SubSection Fragment EditAction Params Options does not match");

			String actualSelectedCouponId = subSectionFragment.get(0).getSynopsis().getEditAction().getAction().
					getParams().get("selectedPromotionId");
			String expectedSelectedCouponId = expectedSmeResponse.getSmeResponse().getPromotionId();
			breezeReport.logStep("Actual SubSection Fragment EditAction Params SelectedCouponId : " + actualSelectedCouponId);
			breezeReport.logStep("Expected SubSection Fragment EditAction Params SelectedCouponId : " + expectedSelectedCouponId);
			softAssert.assertEquals(actualSelectedCouponId, expectedSelectedCouponId,
					"SubSection Fragment EditAction Params SelectedCouponId does not match");

			String actualOfferValidDate = subSectionFragment.get(0).getSynopsis().getSelectionSummary().get(0).getTextSpans().
					get(0).getText();
			String expectedOfferValidDate = expectedSmeResponse.getFormatValidDate();
			breezeReport.logStep("Actual SubSection Fragment Selection Summary Offer Valid Date : " + actualOfferValidDate);
			breezeReport.logStep("Expected SubSection Fragment Selection Summary Offer Valid Date : " + expectedOfferValidDate);
			softAssert.assertEquals(actualOfferValidDate, expectedOfferValidDate, "Offer Valid Date does not match");

			String actualCouponSubType = subSectionFragment.get(0).getSynopsis().getSelectionSummary().get(1).getTextSpans().
					get(0).getText();
			String expectedCouponSubType = expectedSmeResponse.getSmeResponse().getSubType().equals("PUBLIC_SINGLE_SELLER_COUPON") ?
					"Public coupon" : "Private coupon";
			breezeReport.logStep("Actual SubSection Fragment Selection Summary Coupon SubType : " + actualCouponSubType);
			breezeReport.logStep("Expected SubSection Fragment Selection Summary Coupon SubType : " + expectedCouponSubType);
			softAssert.assertEquals(actualCouponSubType, expectedCouponSubType, "Coupon Subtype does not match");

			String actualmaxCouponDiscountAmount = subSectionFragment.get(0).getSynopsis().getSelectionSummary().get(2).getTextSpans().
					get(0).getText();
			DecimalFormat decimalFormat = new DecimalFormat("#.00");
			decimalFormat.setMinimumFractionDigits(2);
			decimalFormat.setGroupingUsed(true);
			decimalFormat.setGroupingSize(3);
			String expectedmaxCouponDiscountAmount = decimalFormat.format(expectedSmeResponse.getSmeResponse().
					getMaxCouponDiscountAmount().getValue());
			String expectedmaxCouponDiscountAmountStr = "Maximum savings of $" + expectedmaxCouponDiscountAmount + " per coupon";
			breezeReport.logStep("Actual SubSection Fragment Selection Summary Coupon Max Discount Amount : " + actualmaxCouponDiscountAmount);
			breezeReport.logStep("Expected SubSection Fragment Selection Summary Coupon Max Discount Amount : " + expectedmaxCouponDiscountAmountStr);
			softAssert.assertEquals(actualmaxCouponDiscountAmount, expectedmaxCouponDiscountAmountStr, 
					"Coupon Max Discount Amount does not match");

			String actualmaxCouponRedemptionPerUser = subSectionFragment.get(0).getSynopsis().getSelectionSummary().get(3).
					getTextSpans().get(0).getText();
			int expectedmaxCouponRedemptionPerUser = expectedSmeResponse.getSmeResponse().getMaxCouponRedemptionPerUser();
			String expectedmaxCouponRedemptionUsed = null;
			if (expectedmaxCouponRedemptionPerUser == 100000) 
				expectedmaxCouponRedemptionUsed = L10n.content(propFile, "SendCoupon_Module_Max_Coupon_Used");
			else
				expectedmaxCouponRedemptionUsed = "Limited to " + expectedmaxCouponRedemptionPerUser + " uses per coupon per buyer";

			breezeReport.logStep("Actual Selection Summary Max Coupon Redemptions per User : " + actualmaxCouponRedemptionPerUser);
			breezeReport.logStep("Expected  Selection Summary Max Coupon Redemptions per User : " + expectedmaxCouponRedemptionUsed);
			softAssert.assertEquals(actualmaxCouponRedemptionPerUser, expectedmaxCouponRedemptionUsed, 
					" Max Coupon Redemptions per User does not match");
		}
		breezeReport.logWithColor("***** CouponModuleSubSectionFragment Validation Complete *****", "green");

	}
	
	
	
	
	/*
	 * Send Coupon - Selection Group - SubSection User Action Validation
	 */
	private String validateSendCouponUserAction(Modules sendCouponModules, String couponId, 
			ValidateInput input, boolean isPreferenceSet) throws Exception {
		
		String userAction = input.getSendCouponAction().get(0);
		breezeReport.logStep("Validating SendCouponModule UserAction : " + userAction);
		breezeReport.logWithColor("SME call for AVAILABLE COUPONS - Module Provider", "blue");
		
		FormatResponse getAvailableCouponsSmeExpResp = getSmeExpResponse(input);
		String newSelectedCouponId = null, expectedModule = null, newSelectedCouponName = null, 
				expectedCouponLabel = null, expectedSelectionSummary = null;
		
		if(getAvailableCouponsSmeExpResp.getSmeExpResponse().getModules().getAVAILABLE_COUPON().
				get_type().equals("AvailableCouponModule"))
			expectedModule = "AVAILABLE_COUPON";
		
		CouponPickerModel couponPickerModel = getAvailableCouponsSmeExpResp.getSmeExpResponse().getModules().
				getAVAILABLE_COUPON().getCouponPickerModel();
		List<Field> entries = couponPickerModel.getCampaignDetails().getEntries();
		String expectedTitle = couponPickerModel.getTitle().getTextSpans().get(0).getText();
		
		/*
		 * Select New Coupon Action
		 */
		if (!isPreferenceSet) {
			breezeReport.logWithColor("Selecting First Coupon from AvailableCouponModule", "blue");
			newSelectedCouponId = entries.get(0).getParamValue();
			newSelectedCouponName = entries.get(0).getSecondaryLabel().getTextSpans().get(0).getText();
			breezeReport.logStep("New Coupon Selected: " + newSelectedCouponId);
		}
		
		/*
		 * Edit Coupon Action & select new Coupon
		 */
		else if (isPreferenceSet) {
			breezeReport.logStep("Coupon set as preference : " + couponId);
			breezeReport.logWithColor("Selecting another Coupon from AvailableCouponModule", "blue");
			if(entries != null) {
				if (entries.size() > 1) {
					for (int i = 0; i < entries.size() ; i++) {
						if (!entries.get(i).getParamValue().equals(couponId)) {
							newSelectedCouponId = entries.get(i).getParamValue();
							newSelectedCouponName = entries.get(i).getSecondaryLabel().getTextSpans().get(0).getText();
							break;
							}
						}
					breezeReport.logStep("New Coupon Selected: " + newSelectedCouponId);
					}
				else {
					breezeReport.logWithColor("Only one coupon exist", "blue");
					newSelectedCouponId = entries.get(0).getParamValue();
					}
				}
			}
		breezeReport.logWithColor("***** SendCouponModuleUserAction Validation Complete *****", "green");
		return newSelectedCouponId;
		}
	

	
	/*
	 * Send Notification Response Validation for Service Failure Error Case
	 */
	private void validateSendCouponNotification(SendCouponResponse actualSNResponse ,boolean sendNotification, boolean sendNotificationWithoutCoupon, boolean sendNotificationError, 
			List<String> buyer_ID, String newSelectedCouponId,String propFile) throws Exception {
		
		breezeReport.logWithColor("Validating SendCoupon Notification", "blue");
		
		/*
		 * Send Notification Response Validation for No-Coupon Request
		 */
		if(sendNotificationWithoutCoupon) {
			List<com.ebay.printorder.pojo.SendCouponResponse.Messages> message = actualSNResponse.getMessages();
			breezeReport.logWithColor("***** Validating SendCoupon Notification - No Coupon Response *****", "blue");
			
			String actualMessageFieldId = message.get(0).getFieldId();
			String expectedMessageFieldId = L10n.content(propFile, "SendNotification_NCMessageFieldId");
			breezeReport.logStep("Actual Message Field Id: " + actualMessageFieldId);
			breezeReport.logStep("Expected Message Field Id: " + expectedMessageFieldId);
			softAssert.assertEquals(actualMessageFieldId, expectedMessageFieldId,"SendNotification MessageFieldId is not correct");
			
			String actualMessageKey = message.get(0).getKey();
			String expectedMessageKey = L10n.content(propFile, "SendNotification_NCMessageKey");
			breezeReport.logStep("Actual Message Key : " + actualMessageKey);
			breezeReport.logStep("Expected Message Key : " + expectedMessageKey);
			softAssert.assertEquals(actualMessageKey, expectedMessageKey,"SendNotification MessageKey is not correct");
			
			String actualMessageText = message.get(0).getText();
			String expectedMessageText = L10n.content(propFile, "SendNotification_NCMessageText");
			breezeReport.logStep("Actual Message Text : " + actualMessageText);
			breezeReport.logStep("Expected Message Text : " + expectedMessageText);
			softAssert.assertEquals(actualMessageText, expectedMessageText,"SendNotification MessageText is not correct");
			
			String actualMessageType = message.get(0).getType();
			String expectedMessageType = L10n.content(propFile, "SendNotification_NCMessageType");
			breezeReport.logStep("Actual Message Type : " + actualMessageType);
			breezeReport.logStep("Expected Message Type : " + expectedMessageType);
			softAssert.assertEquals(actualMessageType, expectedMessageType,"SendNotification MessageType is not correct");
			
			}
		
		/*
		 * Send Notification Response Validation for Service Failure Error Case
		 */
		else if(sendNotificationError) {
			
			List<com.ebay.printorder.pojo.SendCouponResponse.Messages> message = actualSNResponse.getMessages();
			breezeReport.logWithColor("***** Validating SendCoupon Notification - Error Response *****", "blue");
			
			String actualMessageFieldId = message.get(0).getFieldId();
			String expectedMessageFieldId = L10n.content(propFile, "SendNotification_ErrorMessageFieldId");
			breezeReport.logStep("Actual Message Field Id: " + actualMessageFieldId);
			breezeReport.logStep("Expected Message Field Id: " + expectedMessageFieldId);
			softAssert.assertEquals(actualMessageFieldId, expectedMessageFieldId,"SendNotification MessageFieldId is not correct");
			
			String actualMessageKey = message.get(0).getKey();
			String expectedMessageKey = L10n.content(propFile, "SendNotification_ErrorMessageKey");
			breezeReport.logStep("Actual Message Key : " + actualMessageKey);
			breezeReport.logStep("Expected Message Key : " + expectedMessageKey);
			softAssert.assertEquals(actualMessageKey, expectedMessageKey,"SendNotification MessageKey is not correct");
			
			String actualMessageText = message.get(0).getText();
			String expectedMessageText = L10n.content(propFile, "SendNotification_ErrorMessageText");
			breezeReport.logStep("Actual Message Text : " + actualMessageText);
			breezeReport.logStep("Expected Message Text : " + expectedMessageText);
			softAssert.assertEquals(actualMessageText, expectedMessageText,"SendNotification MessageText is not correct");
			
			String actualMessageType = message.get(0).getType();
			String expectedMessageType = L10n.content(propFile, "SendNotification_ErrorMessageType");
			breezeReport.logStep("Actual Message Type : " + actualMessageType);
			breezeReport.logStep("Expected Message Type : " + expectedMessageType);
			softAssert.assertEquals(actualMessageType, expectedMessageType,"SendNotification MessageType is not correct");
		}
		
		/*
		 * Send Notification Success Response Validation
		 */
		else {
			
			List<com.ebay.printorder.pojo.SendCouponResponse.Messages> message = actualSNResponse.getMessages();
			breezeReport.logWithColor("***** Validating SendCoupon Notification - Success Response *****", "blue");
			
			String actualMessageFieldId = message.get(0).getFieldId();
			String expectedMessageFieldId = L10n.content(propFile, "SendNotification_MessageFieldId");
			breezeReport.logStep("Actual Message Field Id: " + actualMessageFieldId);
			breezeReport.logStep("Expected Message Field Id: " + expectedMessageFieldId);
			softAssert.assertEquals(actualMessageFieldId, expectedMessageFieldId,"SendNotification MessageFieldId is not correct");
			
			String actualMessageKey = message.get(0).getKey();
			String expectedMessageKey = L10n.content(propFile, "SendNotification_MessageKey");
			breezeReport.logStep("Actual Message Key : " + actualMessageKey);
			breezeReport.logStep("Expected Message Key : " + expectedMessageKey);
			softAssert.assertEquals(actualMessageKey, expectedMessageKey,"SendNotification MessageKey is not correct");
			
			String actualMessageText = message.get(0).getText();
			String expectedMessageText = L10n.content(propFile, "SendNotification_MessageText");
			breezeReport.logStep("Actual Message Text : " + actualMessageText);
			breezeReport.logStep("Expected Message Text : " + expectedMessageText);
			softAssert.assertEquals(actualMessageText, expectedMessageText,"SendNotification MessageText is not correct");
			
			String actualMessageType = message.get(0).getType();
			String expectedMessageType = L10n.content(propFile, "SendNotification_MessageType");
			breezeReport.logStep("Actual Message Type : " + actualMessageType);
			breezeReport.logStep("Expected Message Type : " + expectedMessageType);
			softAssert.assertEquals(actualMessageType, expectedMessageType,"SendNotification MessageType is not correct");			
		}
		breezeReport.logWithColor("***** SendCouponNotification Validation Complete *****", "green");	
	}
	
	
	
	
	/*
     * Building SendCouponRequest for SendNotification & SubsectionModuleFragments
     */
    private SendCouponRequest buildRequest(ValidateInput input, String couponId, String messageToBuyer, List<String> buyerId, 
    		boolean couponAction, List<String> subSectionIds  ) {

    	SendCouponRequest srequest = new SendCouponRequest();

        srequest.setOrderIds(input.getOrders());
        if (couponId != null)
        	srequest.setCouponId(couponId);
        else
        	srequest.setCouponId("");
        
        if (messageToBuyer != null)
        	srequest.setMessageToBuyer(messageToBuyer);
        else
        	srequest.setMessageToBuyer("");
        
        srequest.setBuyerIds(buyerId);
        
        if(couponAction)
        	srequest.setSubSectionIds(subSectionIds);

		return srequest;
    }
    
    
    /*
     * Building Request for Update Targeted Buyer Promotion Details
     */
	private UpdateTargBuyerDetailRequest buildRequest (ValidateInput input, List<String> buyerId,
			CosmosResponse expectedCosmosResp) throws Exception {
    	
    	UpdateTargBuyerDetailRequest bRequest = new UpdateTargBuyerDetailRequest();
    	String sellerOracleId = DBSelectQueryUtil.getOracleId(input.getSellerName());
    	String buyerType = "CURRENT";
    	String buyerID = expectedCosmosResp.getMembers().get(0).getOrder().getBuyer().getUserIdentifier().getUserId();
    	
    	BuyerPromotionDetail buyerPromotionDetail = new BuyerPromotionDetail();
    	buyerPromotionDetail.setSellerId(Long.parseLong(sellerOracleId));
    	buyerPromotionDetail.setBuyerId(Long.parseLong(buyerID));
    	buyerPromotionDetail.setBuyerType(buyerType);
    	buyerPromotionDetail.setEligible(true);
    	
    	ArrayList<BuyerPromotionDetail> buyerPromotionDetails = new ArrayList<BuyerPromotionDetail>();
    	buyerPromotionDetails.add(buyerPromotionDetail);
		bRequest.setBuyerPromotionDetails(buyerPromotionDetails);
    	
    	return bRequest;
    }
    
    
    /*
     * Building SmeExpResponse for AvailableCouponsModule 
     */
    private FormatResponse getSmeExpResponse(ValidateInput input) {
        FormatResponse fresp = null;
        try {
            SMEUtil smeUtil = new SMEUtil();
            SmeExpResponse resp = smeUtil.getSmeExpResponse(input.getSellerName(), input.getSite());
            fresp = smeUtil.reformatSmeExpResponse(resp);
        } catch (Exception e) {
        	breezeReport.logWithColor("Exception while making SME call" + e, "brown");
        }
        return fresp;
    }
    
    
    
    
    /*
     * Building SmeResponse for getCoupon
     */
    private FormatResponse getSMEResponse(ValidateInput input, String newCouponId) {
        FormatResponse fresp = null;
        try {
            SMEUtil smeUtil = new SMEUtil();
            SMEResponse resp = smeUtil.getSmeResponse(input.getSellerName(), input.getSite(), newCouponId);
            fresp = smeUtil.reformatValidDate(resp);
        } catch (Exception e) {
        	breezeReport.logWithColor("Exception while making SME call" + e, "brown");
        }
        return fresp;
    }
}