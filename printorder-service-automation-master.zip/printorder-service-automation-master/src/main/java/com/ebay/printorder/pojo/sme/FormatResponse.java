package com.ebay.printorder.pojo.sme;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FormatResponse {
    private SMEResponse smeResponse;
    private String formatValidDate;
    private String formatValidEndDate;
    private SmeExpResponse smeExpResponse;
}
    