package com.ebay.printorder.deserializer;

import com.ebay.orders.list.cosmos.pojo.CosmosResponse;
import com.ebay.printorder.pojo.domain.GetAddressResponse;
import com.ebay.printorder.pojo.domain.GetUserResponse;
import com.ebay.printorder.pojo.domain.UserPuidInfo;
import com.ebay.printorder.pojo.domain.Store;
import com.ebay.printorder.pojo.sme.SmeExpResponse;
import com.ebay.printorder.pojo.sme.SMEResponse;
import org.codehaus.jackson.map.ObjectMapper;

public class RestCallDeserializer {
  public ObjectMapper mapper = new ObjectMapper();
  public CosmosResponse deserializeCosmosResponse(String cosmosResponse) throws Exception {
    return mapper.readValue(cosmosResponse, CosmosResponse.class);
  }
  public GetAddressResponse deserializeGetAddressResponse(String addressBookSvcResponse) throws Exception {
	    return mapper.readValue(addressBookSvcResponse, GetAddressResponse.class);
	  }
  public UserPuidInfo deserializeUserPuidInfo(String storePuIdResponse) throws Exception {
	    return mapper.readValue(storePuIdResponse, UserPuidInfo.class);
	  }
  public Store deserializeStore(String storeDetailsResponse) throws Exception {
	    return mapper.readValue(storeDetailsResponse, Store.class);
	  }
  public GetUserResponse deserializeGetUserResponse(String storeRatingDetailsResponse) throws Exception {
	    return mapper.readValue(storeRatingDetailsResponse, GetUserResponse.class);
	  }

  public SMEResponse deserializeSMEResponse(String smeResponse) throws Exception {
      return mapper.readValue(smeResponse, SMEResponse.class);
  }
  
  public SmeExpResponse deserializeSmeExpResponse(String smeExpResponse) throws Exception {
      return mapper.readValue(smeExpResponse, SmeExpResponse.class);
  }
}
