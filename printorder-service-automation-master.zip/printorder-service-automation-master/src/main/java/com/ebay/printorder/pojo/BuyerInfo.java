package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Setter @Getter
public class BuyerInfo {

	private TextualDisplay name;
	private TextualDisplay usernameAndFeedback;
	private String userType;
	private Image profileImage;
    private RepeatedBuyerInfo repeatedBuyerInfo;


	 @Getter
	public static class Image{
		 private String title;
		 private String imageId;
		 private String imageIdType;
		 private String URL;
	 }
	
}