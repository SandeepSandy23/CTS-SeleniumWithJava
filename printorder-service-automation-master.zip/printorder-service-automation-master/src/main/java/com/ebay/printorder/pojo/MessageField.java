package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)

public class MessageField {

	private String value;
	private boolean required;
	private String format;
	private boolean readOnly;
	private Integer maxLength;
	
}