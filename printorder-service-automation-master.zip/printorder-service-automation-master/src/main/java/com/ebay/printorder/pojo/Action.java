package com.ebay.printorder.pojo;

import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class Action {
	private String URL;
	private ActionType type;
	private String name;
	private Map<String, String> params;
	private String accessibilityText;
	private List<Tracking> trackingList;
	private boolean signInRequired;
}
