package com.ebay.printorder.pojo.sme;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class Modules {
	@JsonProperty("AVAILABLE_COUPON")
	private AVAILABLE_COUPON AVAILABLE_COUPON;
}
