package com.ebay.printorder.pojo;


import lombok.Getter;
import lombok.Setter;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.ebay.printorder.pojo.SelectionGroup.Icon;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class
Selections {

    private List<SingleSelection> selection;
    private TextualDisplay title;
    private Help help;
    private List<Subsection> subSection;
    private TextualDisplay description;
    private CallToAction navAction;


    @Getter
    public static class SingleSelection{
        private String _type;
        private String fieldId;
        private boolean disabled;
        private boolean lockable;
        private boolean selected;
        private TextualDisplay label;
        private TextualDisplay secondaryLabel;
        private String uxComponentHint;
        private boolean defaultChoice;
        private List<Entries> entries;
        private Help help;
    }

    @Getter
    public static  class Help{
        private String _type;
        private TextualDisplay messageDismiss;
        private Icon bubbleIcon;
        private List<TextualDisplay> messageText;
    }
    
    @Getter
    public static class Entries{
    	private String _type;
    	private String characterCounterText;
    	private String maxLength;
    	private TextualDisplay accessoryLabel;
    	private String accessibilityText;
    	private Object paramKey;
    	private Object paramValue;
    	private List<Entries> entries;
    	private TextualDisplay label;
    }

}
