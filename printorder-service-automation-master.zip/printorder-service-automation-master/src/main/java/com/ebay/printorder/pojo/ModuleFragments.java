package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class ModuleFragments {
    private ModuleMessage moduleMessage;


    @Getter
    public class ModuleMessage{
        private List<Messages> messages;
    }

    @Getter
    public class Messages{
        private List<Message> content;
        private String messageType;
    }
}
