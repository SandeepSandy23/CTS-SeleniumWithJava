package com.ebay.printorder.domain.test;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.ITestContext;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.xml.XmlSuite;

import com.ebay.common.infra.executor.ActionsXMLRequests;
import com.ebay.common.util.TestFilterUtil;
import com.ebay.printorder.domain.flow.PrintOrderDomainSvcFlow;
import com.ebay.quality.testdataautil.common.EasyFilter;
import com.ebay.quality.testdataautil.common.SpreadSheetUtil;
import com.ebay.quality.testdataautil.type.TestObject;
import com.ebay.testinfrastructure.serviceautil.testdriver.ServiceBaseTest;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public class PrintOrderDomainSvcTestPlan extends ServiceBaseTest {
    private Map<String, String> allParameters;

    @BeforeSuite(groups = "PrintOrder_Domain_svc")
    public void loadContext(ITestContext context) {
    	XmlSuite xmlSuite = context.getSuite().getXmlSuite();
    	allParameters = xmlSuite.getAllParameters();
	
		for (Map.Entry<String, String> e : allParameters.entrySet()) {
		    context.setAttribute(e.getKey(), e.getValue());
		}
    }
    
    @DataProvider(name = "PrintOrder_Domain_Data_Provider", parallel = false)
    public static Iterator<Object[]> getData(Method m,
        ITestContext testContex) throws Exception {
	    EasyFilter filter = EasyFilter.equalsIgnoreCase(TestObject.TEST_METHOD, m.getName());
	    filter = TestFilterUtil.addFilter(filter, testContex);
	    LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
	    entityClazzMap.put("TestObject", TestObject.class);
	    entityClazzMap.put("ActionsXMLRequests", ActionsXMLRequests.class);
	    
	    return SpreadSheetUtil.getEntitiesFromSpreadsheet(PrintOrderDomainSvcTestPlan.class, entityClazzMap,
	        "PrintOrderDomainSvcData.xls","Test Data", -1, null, filter);
    }
    
    @Test(groups = "testPrintOrderDomainSvc", dataProvider = "PrintOrder_Domain_Data_Provider")
    public void runPrintOrderDomainSvcTest(String testFilterType,
        TestObject object, ActionsXMLRequests xmlrequests) throws Exception {
    		runTest(testFilterType, object, xmlrequests);
    }
    
    private void runTest(String testFilterType, TestObject object,
	    ActionsXMLRequests xmlrequests) throws Exception {
    		PrintOrderDomainSvcFlow flow = new PrintOrderDomainSvcFlow();
    		flow.executeProcess(xmlrequests);
    }
}
