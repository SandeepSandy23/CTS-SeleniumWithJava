package com.ebay.printorder.pojo.domain;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.ebay.orders.details.xs.userread.pojo.BusinessIdentityProfile;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {
	
	@JsonProperty("userId")
	private String userId;	
	@JsonProperty("legacyUserId")
	private String legacyUserId;	
	@JsonProperty("userAccountName")
	private String userAccountName;	
	@JsonProperty("registrationSiteId")
	private String registrationSiteId;
	@JsonProperty("countryOfResidence")
	private String countryOfResidence;
	@JsonProperty("userAccountStatus")
	private String userAccountStatus;
	@JsonProperty("extensions")
	private List<Extension> extensions;
	@JsonProperty("businessIdentityProfile")
	private BusinessIdentityProfile businessIdentityProfile;
}
