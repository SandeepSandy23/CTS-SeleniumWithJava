package com.ebay.printorder.domain.validators;

import org.testng.asserts.SoftAssert;

import com.ebay.printorder.deserializer.RestCallDeserializer;
import com.ebay.printorder.pojo.ValidateInput;
import com.ebay.printorder.util.PrintOrderSvcUtil;
import com.ebay.testinfrastructure.reporter_generator.ReportLogger;

public abstract class BaseValidator {
	protected RestCallDeserializer restCallDeserializer = new RestCallDeserializer();
	protected PrintOrderSvcUtil printOrderUtil = new PrintOrderSvcUtil();
	protected ReportLogger breezeReport = new ReportLogger();
	protected SoftAssert softAssert = new SoftAssert();
	
	public void validate(ValidateInput input) throws Exception{
		//Error use case
		if(input.isErrorFlow()){
			validateErrorFlow(input);
			return;
		}
		validateFlow(input);
	}
	public abstract void validateFlow(ValidateInput input) throws Exception;
	public  void validateErrorFlow(ValidateInput input) throws Exception{
		//Do Nothing
	}

}
