package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Orders {
	private TextualDisplay orderInfo;
	
	private TextualDisplay viewOrdersAction;
	
	private OrdersSummary ordersSummary;

	public TextualDisplay getOrderInfo() {
		return orderInfo;
	}

	public void setOrderInfo(TextualDisplay orderInfo) {
		this.orderInfo = orderInfo;
	}

	public TextualDisplay getViewOrdersAction() {
		return viewOrdersAction;
	}

	public void setViewOrdersAction(TextualDisplay viewOrdersAction) {
		this.viewOrdersAction = viewOrdersAction;
	}

	public OrdersSummary getOrdersSummary() {
		return ordersSummary;
	}

	public void setOrdersSummary(OrdersSummary ordersSummary) {
		this.ordersSummary = ordersSummary;
	}
}
