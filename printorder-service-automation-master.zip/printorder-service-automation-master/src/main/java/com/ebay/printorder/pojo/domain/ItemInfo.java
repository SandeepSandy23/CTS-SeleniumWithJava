package com.ebay.printorder.pojo.domain;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;


@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemInfo {
	private String image;
	  private String title;
	  private Integer qty;
	  private String price;
	  private String customLabel;
	  private String itemId;
	  private String sellerNote;
	  private ReturnPolicyDetail returnPolicyDetail;
	  private List<Attribute> itemSkuDetails;
	  private ShipmentInfo shipmentInfo;
	  private String vatPercentForPackingSlip;
	  private String vatPercentForOrderReceipt;
}
