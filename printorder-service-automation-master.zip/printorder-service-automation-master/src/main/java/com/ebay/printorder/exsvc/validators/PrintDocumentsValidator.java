package com.ebay.printorder.exsvc.validators;

import java.util.ArrayList;
import java.util.List;

import com.ebay.printorder.pojo.*;
import com.ebay.printorder.pojo.PreferenceInfo.StandaloneCoupon;
import com.ebay.printorder.util.CommonUtil;
import com.ebay.printorder.util.PrintOrderSvcUtil;
import com.ebay.testinfrastructure.l10nautil.L10n;
import com.google.common.collect.ImmutableList;

import java.util.Collection;
import java.util.Objects;
import java.util.stream.Stream;

public class PrintDocumentsValidator extends BaseValidator {

    private int documentsNumber = 0;
    private int orders = 0;
    private int documentCounter = 0;

    @Override
    public void validateFlow(ValidateInput input) throws Exception {
        breezeReport.logWithColor("Validating PDF generation", "blue");
        String sellerName = input.getSellerName();
        String site = input.getSite();

        String propFile = input.getPropFile();
        orders = numberOfOrders(input);
        documentsNumber = 0;


        PrintDocumentRequest request = buildRequest(input, propFile);
        PrintOrderSvcUtil printOrderSvcUtil = new PrintOrderSvcUtil();

        PrintDocumentResponse response = printOrderSvcUtil.getPrintDocumentResponse(sellerName, CommonUtil.toJSON(request), site, input);
        PrintModule printModule = response.getModules().getPrintModule();

        validatePrintDocuments(printModule, input.getPropFile());
        breezeReport.logWithColor("----- Validating PDF generation -----", "green");
    }

    private int numberOfOrders(ValidateInput input) {
        ImmutableList<String> labelsWithTwoOrders = ImmutableList.of("60d1135f1d19e44a681d300d");
        return Stream.of(input.getLabels(), input.getOrders())
          .filter(Objects::nonNull)
          .flatMap(Collection::stream)
          .map(object -> labelsWithTwoOrders.contains(object) ? 2 : 1)
          .mapToInt(Integer::valueOf)
          .sum();
    }


    private void validatePrintDocuments(PrintModule printModule, String propFile) {

        //validate title
        String title = printModule.getPdfInfo().getTitle().getTextSpans().get(0).getText();
        String expectedTitle = L10n.content(propFile, "Preview_Documents") + " (" + (orders*documentsNumber+documentCounter) + ")";
        softAssert.assertEquals(title, expectedTitle, "pdfInfo title text is not correct");


		/* As per MESHORD-2372, help is not part of pdfInfo, so removing the validation.
		 * //validate help message String helpMessage =
		 * printModule.getPdfInfo().getHelp().getMessageText().get(0).getTextSpans().get
		 * (0).getText(); softAssert.assertEquals(helpMessage, L10n.content(propFile,
		 * "PDF_Info_Title_Help_Text"), "pdfInfo help message text is not correct");
		 *
		 *
		 * //validate description if (orders > 1) { String descriptionText =
		 * printModule.getPdfInfo().getDescription().getTextSpans().get(0).getText();
		 * softAssert.assertEquals(descriptionText, L10n.content(propFile,
		 * "PDF_Info_Description"), "pdfInfo description text is not correct"); }
		 */

        //validate data
        String documentType = printModule.getPdfInfo().getData().getDocumentType();
        softAssert.assertEquals(documentType, "PDF", "document type is not correct");

        String pdfEncodeData = printModule.getPdfInfo().getData().getEncodedData();
        softAssert.assertNotNull(pdfEncodeData, "document content is empty/null");
        softAssert.assertAll();
    }

    private PrintDocumentRequest buildRequest(ValidateInput input, String propFile) {
        PrintDocumentRequest req = new PrintDocumentRequest();

        req.setOrderIds(input.getOrders());
        req.setLabelIds(input.getLabels());
        String[] documents = input.getDocuments().split(",");
        DocumentSelections documentSelections = new DocumentSelections();

        for (String doc : documents) {
            switch (doc) {
                case "packingSlip":
                    documentSelections.setPackingSlip(true);
                    documentsNumber++;
                    break;
                case "orderReceipt":
                    documentSelections.setOrderReceipt(true);
                    documentsNumber++;
                    break;
                case "pickList":
                    documentSelections.setPickList(true);
                    documentCounter++;
                    break;
                case "addressLabel":
                    documentSelections.setAddressLabel(true);
                    documentCounter++;
                    break;
                case "coupon":
                    documentSelections.setCoupon(true);
                    documentsNumber++;
                    break;
            }
        }
        req.setDocumentSelections(documentSelections);

        //Set print orders preference info
        PreferenceInfo preferenceInfo = new PreferenceInfo();
        
        preferenceInfo.setPageSize("3");
        preferenceInfo.setFormsPerSheet(1);
        preferenceInfo.setGift(false);
        preferenceInfo.setShipFromNameAndAddressForPackingSlip(true);
        preferenceInfo.setShipFromNameAndAddressForOrderReceipt(true);
        preferenceInfo.setListingThumbnail(true);
        preferenceInfo.setListingThumbnailForOrderReceipt(true);
        preferenceInfo.setWarrantyInfo(true);
        preferenceInfo.setReturnPolicy(true);
        preferenceInfo.setSellerRating(true);
        preferenceInfo.setThankYouNote("Thanks for your purchase! Hope you enjoy it!");
        preferenceInfo.setPersonalNote("Thanks");
        preferenceInfo.setStoreLogo(true);
        preferenceInfo.setStoreUrl(true);
        preferenceInfo.setStoreQRCodeLink(true);
        preferenceInfo.setShippingInfo(true);
        preferenceInfo.setPaymentInfo(true);
        preferenceInfo.setSellerNote(true);
        preferenceInfo.setBuyerNoteForPackingSlip(true);
        preferenceInfo.setBuyerNoteForOrderReceipt(true);
        preferenceInfo.setCustomLabel(true);
        preferenceInfo.setCustomLabelForPackingSlip(true);
        
        String standaloneCouponId = null;
        PreferenceInfo.StandaloneCoupon standaloneCoupon = null;
        if (input.getCouponIds().get("standaloneCouponId") != null)
        	standaloneCouponId = input.getCouponIds().get("standaloneCouponId");
        else if (input.getCouponIds().get("couponModuleCouponId") != null)
        	standaloneCouponId = input.getCouponIds().get("couponModuleCouponId");
        standaloneCoupon = new PreferenceInfo.StandaloneCoupon(standaloneCouponId,"COUPON_WITH_NOTE",
            		L10n.content(propFile, "SelectionEntries_Msg_ToBuyer"), 1);
        
        PreferenceInfo.PackingSlipCoupon packingSlipCoupon = new PreferenceInfo.PackingSlipCoupon("COUPON_WITH_NOTE", 1);
        
        preferenceInfo.setStandaloneCoupon(standaloneCoupon);
        preferenceInfo.setPackingSlipCoupon(packingSlipCoupon);
        
        req.setPreferenceSelections(preferenceInfo);
        return req;
    }
}
