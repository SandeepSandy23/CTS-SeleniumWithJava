package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class SendCouponModules {
    private String _type;
    private BuyerInfo buyerInfo;
    //private List<Selections> selectionGroup;
    private List<SelectionGroup> selectionGroup;
    private MessageToBuyer messageToBuyer;
    private CallToAction sendAction;
    private CallToAction cancelAction;
    private SendSelectionData sendSelectionData;
    private List<Message> messageBundle;
    private TextualDisplay featureSurveyLink;
}