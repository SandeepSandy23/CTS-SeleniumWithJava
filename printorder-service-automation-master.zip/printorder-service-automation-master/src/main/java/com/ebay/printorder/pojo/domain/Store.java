package com.ebay.printorder.pojo.domain;

import java.util.List;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Store {
	String storeId;
	String ownerId; // Store owner's PUID
	String ownerUsername; // Store owner's eBay user name
	Boolean isCustomStore;
	Boolean lexingtonStoreOptOut;
	String name;
	String description;
	String logoUrl;
	Object feedbackPercentage;
	String videoUrl;
	String billboardUrl;
	Boolean directSubscribeToNewStore;
	List<Long> featuredListings;
	Integer siteId;
	Boolean isFeaturedListingsHidden;
	Boolean hasDraftData;
	Boolean isPauseSelling;
}
