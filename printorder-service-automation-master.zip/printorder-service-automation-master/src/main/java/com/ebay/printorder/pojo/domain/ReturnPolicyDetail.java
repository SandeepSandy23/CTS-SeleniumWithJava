package com.ebay.printorder.pojo.domain;


import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReturnPolicyDetail {
	private boolean returnsAccepted;
	private String returnPeriod;
	private String refundMethod;
	private String returnShippingCostPayer;

}
