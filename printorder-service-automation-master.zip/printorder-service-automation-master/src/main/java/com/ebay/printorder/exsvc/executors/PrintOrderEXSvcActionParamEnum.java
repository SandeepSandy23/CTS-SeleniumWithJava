package com.ebay.printorder.exsvc.executors;

import com.ebay.common.infra.executor.IBaseParamType;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public enum PrintOrderEXSvcActionParamEnum implements IBaseParamType {
	SELLER_NAME, SELLER_TYPE, SITE, VALIDATE, ERROR_FLOW, DOCUMENTS,ORDERS,DEVICE_TYPE,WORDS_LIST,PICKLIST_ELIGIBLE,
	VALIDATE_COUPON, COUPONIDS, SENDCOUPON_ACTION, LABELS, TEMPLATE, COUNT_PER_SHEET, MODE
}
