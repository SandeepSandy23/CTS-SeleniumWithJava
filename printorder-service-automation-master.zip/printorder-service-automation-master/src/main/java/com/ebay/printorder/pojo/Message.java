package com.ebay.printorder.pojo;


import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class Message {
    private String key;
    private String text;
    private String type;
    private TextualDisplay message;
    private String title;
    private String actionName;
}
