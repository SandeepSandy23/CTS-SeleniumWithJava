package com.ebay.printorder.pojo.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ebay.globalenv.SiteEnum;
import org.apache.commons.collections.CollectionUtils;
public class SellerRating {
	private static Map<String, List<SiteEnum>> map; 
    private static List<SiteEnum> ukSites = new ArrayList<>(Arrays.asList(SiteEnum.EBAY_UK, SiteEnum.EBAY_AT));
    private static List<SiteEnum> usSites = new ArrayList<>(Arrays.asList(SiteEnum.EBAY_MAIN, SiteEnum.EBAY_CA, SiteEnum.EBAY_AUTOS, SiteEnum.EBAY_QUEBEC));
    private static List<SiteEnum> deSites = new ArrayList<>(Arrays.asList(SiteEnum.EBAY_DE, SiteEnum.EBAY_AT, SiteEnum.EBAY_CH));
    private static List<SiteEnum> globalSites = new ArrayList<>(Arrays.asList(SiteEnum.EBAY_CA, SiteEnum.EBAY_QUEBEC, SiteEnum.EBAY_IN, SiteEnum.EBAY_FR, SiteEnum.EBAY_IT, SiteEnum.EBAY_ES, SiteEnum.EBAY_AU));
  
    static
    { 
        map = new HashMap<>(); 
        map.put(ExtentionKeyEnum.SPS_TOP_RATED_SELLER_US.getName(), usSites); 
        map.put(ExtentionKeyEnum.SPS_TOP_RATED_SELLER_UK.getName(), ukSites);
        map.put(ExtentionKeyEnum.SPS_TOP_RATED_SELLER_DE.getName(), deSites);
        map.put(ExtentionKeyEnum.SPS_TOP_RATED_SELLER_GLOBAL.getName(), globalSites); 
    } 

    public static boolean isTopRatedSeller(Extension sellerExtension, SiteEnum siteEnum) {
    	boolean isTopRated = false;
    	List<SiteEnum> siteLst = map.get(sellerExtension.getKey());
    	if(CollectionUtils.isNotEmpty(siteLst) && siteLst.contains(siteEnum)) {
    		isTopRated = true;
    	}
    	return isTopRated;
    }

}
