package com.ebay.printorder.exsvc.validators;

import java.util.Currency;
import java.util.Locale;

import org.testng.asserts.SoftAssert;

import com.ebay.printorder.deserializer.RestCallDeserializer;
import com.ebay.printorder.pojo.ValidateInput;
import com.ebay.printorder.util.PrintOrderSvcUtil;
import com.ebay.testinfrastructure.reporter_generator.ReportLogger;

public abstract class BaseValidator {
	protected RestCallDeserializer restCallDeserializer = new RestCallDeserializer();
	protected PrintOrderSvcUtil printOrderUtil = new PrintOrderSvcUtil();
	protected ReportLogger breezeReport = new ReportLogger();
	protected SoftAssert softAssert = new SoftAssert();
	
	public void validate(ValidateInput input) throws Exception{
		//Error use case
		if(input.isErrorFlow()){
			validateErrorFlow(input);
			return;
		}
		validateFlow(input);
	}
	public abstract void validateFlow(ValidateInput input) throws Exception;
	public  void validateErrorFlow(ValidateInput input) throws Exception{
		//Do Nothing
	}

	
	public static String getCountryBasedOnCurrency(String currency) {
		switch(currency) {
			case "USD":	
				return "US";
			case "GBP":
				return "GB";
		    case "AUD":
		    	return "AU";
		    case "EUR":
		    	return "DE";
		    case "EU":
		    	return "DE";
		    case "CAD":
		    	return "CA";
		    default:
		    	return "US";
		}
	}
	
	public static String getSymbolBasedOnCurrency(String currency) {
		switch(currency) {
			case "USD":	
				return "US";
			case "GBP":
				return "GB";
		    case "AUD":
		    	return "AU";
		    case "EUR":
		    	return "EU";
		    case "CAD":
		    	return "C";
		    default:
		    	return "US";
		}
	}
	
	public static String getCurrencySymbol(String checkoutSite) {
		Locale locale = new Locale("EN",checkoutSite);
        Currency currency = Currency.getInstance(locale);
        String currencySymbol = currency.getSymbol(locale);
        
        if (currency.toString().trim().equals(currencySymbol.trim()) && checkoutSite.equals("DE"))
        	currencySymbol = "€";
        
		return currencySymbol;
	}
}
