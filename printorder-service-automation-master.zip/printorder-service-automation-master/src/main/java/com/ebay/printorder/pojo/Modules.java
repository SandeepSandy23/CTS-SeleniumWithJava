package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import com.ebay.printorder.pojo.Meta;
import com.ebay.printorder.pojo.domain.PdfDocGenRawDataModule;



@JsonIgnoreProperties(ignoreUnknown = true)
@Setter @Getter
public class Modules {
	private PrintOrderModule printOrderModule;
	private PrintModule printModule;
	private PdfDocGenRawDataModule pdfDocGenRawDataModule;
	private SendCouponModules sendCouponModule;
	private CreateCouponModule createCouponModule;
	private Meta meta;


	public PrintOrderModule getPrintOrderModule() {
		return printOrderModule;
	}

	public void setPrintOrderModule(PrintOrderModule printOrderModule) {
		this.printOrderModule = printOrderModule;
	}
	
	public SendCouponModules getSendCouponModule() {
		return sendCouponModule;
	}

	public void setSendCouponModule(SendCouponModules sendCouponModule) {
		this.sendCouponModule = sendCouponModule;
	}
	
	public CreateCouponModule getCreateCouponModule() {
		return createCouponModule;
	}

	public void setCreateCouponModule(CreateCouponModule createCouponModule) {
		this.createCouponModule = createCouponModule;
	}
	
	
	
}
