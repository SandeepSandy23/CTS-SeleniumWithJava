package com.ebay.printorder.pojo.domain;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class GlobalInfo {

	private boolean isFRVATEnabled;
	private String ebayIaxAddress;
	private FeatureFlagMap featureFlagMap;

}
