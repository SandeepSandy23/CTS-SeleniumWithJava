package com.ebay.printorder.exsvc.flow;

import com.ebay.common.infra.executor.BaseAppFlow;
import com.ebay.common.infra.executor.BaseExecutor;
import com.ebay.meshorders.datagen.executors.OrderFactory;
import com.ebay.meshorders.datagen.item.executors.ListItemFactory;
import com.ebay.printorder.exsvc.executors.PrintOrderEXSvcFactory;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public class PrintOrderEXSvcFlow extends BaseAppFlow {

	@Override
	protected void executeFlow() throws Exception {
		// list item
		ListItemFactory itemFactory = ListItemFactory.getInstance();
		BaseExecutor itemExecutor = itemFactory.getExecutor();
		this.executeExecutor(itemExecutor);

		// order
		OrderFactory orderFactory = OrderFactory.getInstance();
		BaseExecutor orderExecutor = orderFactory.getExecutor();
		this.executeExecutor(orderExecutor);

		//Print order EX service
		PrintOrderEXSvcFactory printOrderEXSvcFactory = PrintOrderEXSvcFactory.getInstance();
		BaseExecutor PrintOrderEXSvcExecutor = printOrderEXSvcFactory.getExecutor();
		this.executeExecutor(PrintOrderEXSvcExecutor);
	}
}
