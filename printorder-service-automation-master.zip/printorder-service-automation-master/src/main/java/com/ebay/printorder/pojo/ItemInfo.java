package com.ebay.printorder.pojo;


import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class ItemInfo {

    private String image;
    private String title;
    private int qty;
    private String price;
    private String customLabel;
    private String itemId;
    private String sellerNote;
    private ReturnPolicyDetail returnPolicyDetail;

    @Getter @Setter
    private class ReturnPolicyDetail {
        private boolean returnsAccepted;
        private String returnPeriod;
        private String refundMethod;
        private String returnShippingCostPayer;
    }

}
