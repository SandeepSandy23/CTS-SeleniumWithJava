package com.ebay.printorder.util;

import java.net.URL;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.printorder.deserializer.RestCallDeserializer;
import com.ebay.printorder.pojo.domain.GetAddressResponse;
import com.ebay.printorder.pojo.domain.GetUserResponse;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.serviceautil.apidriver.RestClient;

public class UserReadSvcUtil extends BaseSvcUtil{
	public JSONObject getStoreRatingDetails( String sellerName, String site,String userRequest, boolean taxIdentity) throws Exception {
        site = overrideSite(site);
        String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
        //Get list of orders info here, not just a single order.
        String userReadSvcURL = null;
        if(!taxIdentity) 
        	userReadSvcURL = (TestParams.TestEnv.customparam.get("userReadPlatformSvcURL")) + "v4/query";
        else 
        	userReadSvcURL = (TestParams.TestEnv.customparam.get("userReadPlatformSvcURL")) + "v5/query";
        
        String bearer_token = "Bearer " + getAppToken("dXJuOmViYXktbWFya2V0cGxhY2UtY29uc3VtZXJpZDo4Mzc1YjY1Yi0zNjQxLTRiYWEtODk1Mi1kZTE2ZDZjMDhiYWM6IDA4MjZiOTBjLTRhNmMtNDdlOS05YmZiLWFlMjM5NjdmMDhiYg==", "core@user");
        Reporter.log("UserReadSvc Endpoint URL" + userReadSvcURL);

        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName + "%2CorigAcctId%3D" + sellerId)
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site);
        URL url = new URL(userReadSvcURL);
        client.post(url,userRequest);
        if (client.getResponseCode() != 200) {
            client.post(url,userRequest);
        }
        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());
        return responseObject;
    }
	
    public GetUserResponse getUserReadSvcResponse(String sellerName, String site,String userRequest, boolean taxIdentity) throws Exception {
    	RestCallDeserializer deserializer = new RestCallDeserializer();       
        JSONObject resp = getStoreRatingDetails(sellerName, site,userRequest, taxIdentity);
        GetUserResponse userReadSvcResponse = deserializer.deserializeGetUserResponse(resp.toString());
        return userReadSvcResponse;
    }
}
