package com.ebay.printorder.pojo;

import com.ebay.printorder.pojo.Action;
import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class CallToAction {
	private String _type;
    private String text;
    private String type;
    private Action action;
    private String accessibilityText;
    private boolean disabled;
}
