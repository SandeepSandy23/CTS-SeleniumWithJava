package com.ebay.printorder.domain.executors;

import java.util.Arrays;

import com.ebay.common.infra.executor.IBaseActionType;
import com.ebay.common.infra.executor.IBaseParamType;
import com.ebay.common.infra.executor.IScopeEnum;
import com.ebay.common.infra.obj.orders.OrdersScopeEnum;
import com.ebay.printorder.domain.validators.BaseValidator;
import com.ebay.printorder.domain.validators.PrintDocumentValidator;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public enum PrintOrderDomainSvcActionEnum implements IBaseActionType {

	PRINT_DOCUMENT(new IScopeEnum[] { OrdersScopeEnum.ORDERSINFO },
			new PrintOrderDomainSvcActionParamEnum[] {
				PrintOrderDomainSvcActionParamEnum.SELLER_NAME,
				PrintOrderDomainSvcActionParamEnum.VALIDATE,
				PrintOrderDomainSvcActionParamEnum.ERROR_FLOW,
				PrintOrderDomainSvcActionParamEnum.INFO
				}, new PrintDocumentValidator());

	private PrintOrderDomainSvcActionParamEnum[] supportedParamTypes;
	private IScopeEnum[] supportedScopes;
	private BaseValidator validator;

	PrintOrderDomainSvcActionEnum(IScopeEnum[] scopes,
			PrintOrderDomainSvcActionParamEnum[] paramtypeenum,BaseValidator validator) {
		if (scopes != null) {
			this.supportedScopes = Arrays.copyOf(scopes, scopes.length);
		}

		if (paramtypeenum != null) {
			this.supportedParamTypes = Arrays.copyOf(paramtypeenum,
					paramtypeenum.length);
		}
		if(validator == null){
			throw new IllegalArgumentException("Validator is null for action:"+name());
		}
		this.validator = validator;
	}

	public IScopeEnum[] getScope() {
		return supportedScopes;
	}

	public IBaseParamType[] getParams() {
		return supportedParamTypes;
	}
	
	public BaseValidator getValidator() {
		return validator;
	}
}
