package com.ebay.printorder.pojo.domain;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class StandaloneCoupon {
    private CouponDetail couponDetail;
    private String personalNote;
    private boolean defaultPreview;
}
