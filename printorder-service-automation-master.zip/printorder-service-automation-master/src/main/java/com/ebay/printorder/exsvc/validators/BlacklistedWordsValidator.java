package com.ebay.printorder.exsvc.validators;

import com.ebay.printorder.pojo.*;
import com.ebay.printorder.util.CommonUtil;
import com.ebay.printorder.util.PrintOrderSvcUtil;
import com.ebay.testinfrastructure.l10nautil.L10n;

import java.util.List;

public class BlacklistedWordsValidator extends BaseValidator{
    @Override
    public void validateFlow(ValidateInput input) throws Exception {

        breezeReport.logWithColor("Validating blackListed words", "blue");
        String sellerName = input.getSellerName();
        String site = input.getSite();
        String propFile = input.getPropFile();
        List<String> wordsList = input.getWordsList();

        BlackListedWordsRequest request = buildRequest(wordsList.get(1));

        PrintOrderSvcUtil printOrderSvcUtil = new PrintOrderSvcUtil();

        BlackListedWordsResponse response = printOrderSvcUtil.getBlackListedWordsValidateResponse(sellerName,
                CommonUtil.toJSON(request),site, input);
        ModuleFragments moduleFragmentsGood = response.getModuleFragments();


        if(wordsList.get(0).equals("goodwords"))
            validateGoodWords(moduleFragmentsGood);
        else
            validateBadWords(moduleFragmentsGood,propFile);

        softAssert.assertAll();

        breezeReport.logWithColor("----- Validating blackListed words Done -----", "green");
    }

    private BlackListedWordsRequest buildRequest(String words){
        BlackListedWordsRequest request = new BlackListedWordsRequest();
        request.setInputText(words);
        return request;
    }

    public void validateGoodWords(ModuleFragments moduleFragments){
        breezeReport.logWithColor("----- Validating all good words -----", "green");
        String messageType = moduleFragments.getModuleMessage().getMessages().get(0).getMessageType();
        softAssert.assertEquals(messageType, "SUCCESS", "validate good words type is not correct");
    }

    public void validateBadWords(ModuleFragments moduleFragments, String propFile) {
        breezeReport.logWithColor("----- Validating bad words -----", "green");
        String messageType = moduleFragments.getModuleMessage().getMessages().get(0).getMessageType();
        softAssert.assertEquals(messageType, "ERROR", "validate bad words type is not correct");

        String infoText = moduleFragments.getModuleMessage().getMessages().get(0).getContent().get(0).
                getMessage().getTextSpans().get(0).getText();
        softAssert.assertEquals(infoText, L10n.content(propFile, "Black_Listed_Words_Info"), "validate bad words info is not correct");
    }

}
