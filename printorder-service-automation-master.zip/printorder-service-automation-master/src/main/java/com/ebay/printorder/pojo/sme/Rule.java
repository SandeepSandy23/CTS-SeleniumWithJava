package com.ebay.printorder.pojo.sme;

import lombok.Getter;
import lombok.Setter;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class Rule {
    private String ruleType;
    private Integer ruleOrder;
    private SpendAmount spendAmount;
    private BuyQuantity buyQuantity;
    private SMEDiscount discount;


}
