package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
public class OrderAddresses {
  private Address toAddress;
  private Address fromAddress;
}
