package com.ebay.printorder.pojo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Member {
	private String _type;
	
	private TextualDisplay orderTitle;
	
	private TextualDisplay orderSubTitle;
	
	private TextualDisplay soldDate;
	
	private TextualDisplay buyer;

	private TextualDisplay itemCount;
	
	private List<Image> images;
	
	private TextualDisplay totalQuantity;
    
    private String moreImagesCaption;

	public String get_type() {
		return _type;
	}

	public void set_type(String _type) {
		this._type = _type;
	}

	public TextualDisplay getOrderTitle() {
		return orderTitle;
	}

	public void setOrderTitle(TextualDisplay orderTitle) {
		this.orderTitle = orderTitle;
	}
	
	public TextualDisplay getOrderSubTitle() {
		return orderSubTitle;
	}

	public void setOrderSubTitle(TextualDisplay orderTitle) {
		this.orderSubTitle = orderTitle;
	}

	public TextualDisplay getSoldDate() {
		return soldDate;
	}

	public void setSoldDate(TextualDisplay soldDate) {
		this.soldDate = soldDate;
	}

	public TextualDisplay getBuyer() {
		return buyer;
	}

	public void setBuyer(TextualDisplay buyer) {
		this.buyer = buyer;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public TextualDisplay getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(TextualDisplay totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public TextualDisplay getItemCount() {
		return itemCount;
	}

	public void setItemCount(TextualDisplay itemCount) {
		this.itemCount = itemCount;
	}

	public String getMoreImagesCaption() {
		return moreImagesCaption;
	}

	public void setMoreImagesCaption(String moreImagesCaption) {
		this.moreImagesCaption = moreImagesCaption;
	}
}
