package com.ebay.printorder.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class PrintOrderInfo {

    private String orderId;
    private String buyerNotesToSeller;
    private List<ShipAddressInfo> shipToAddress;
    private String scheduledShipDate;
    private String shippedOnDate;
    private String shippingMethod;
    private String gspReferenceId;
    private String orderDate;
    private List<ItemInfo> items;
    private String subTotal;
    private String tax;
    private String totalTax;
    private String shippingAndHandlingCharges;
    private String orderTotal;
    private String totalSellingFee;
    private String purchaseOrderId;
    private String paymentMethod;
    private String paymentDate;
    private String paymentState;
    private List<Prices> priceLines;

    @AllArgsConstructor
    public static class ShipAddressInfo {
        private String name;
        private String firstName;
        private String lastName;
        private String addressLine1;
        private String addressLine2;
        private String city;
        private String state;
        private String postalCode;
        private String country;
        private String documentType;
    }

    @AllArgsConstructor
    public static class Prices{
        private String key;
        private String value;
    }
}
