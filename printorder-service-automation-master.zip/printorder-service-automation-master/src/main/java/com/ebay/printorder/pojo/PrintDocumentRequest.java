package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class PrintDocumentRequest {
    private List<String> orderIds;
    private DocumentSelections documentSelections;
    private PreferenceInfo preferenceSelections;
    private List<String> labelIds;
}
