package com.ebay.printorder.pojo.domain;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public enum PrintDocumentTypeEnum {

	PACKING_SLIP("PACKING_SLIP"),
	ORDER_RECEIPT("ORDER_RECEIPT"),
	PICK_LIST("PICK_LIST");

	private String value;
	
	PrintDocumentTypeEnum(String value) {
		this.value = value;
	}
	
	public static PrintDocumentTypeEnum fromValue(String text) {
	    for (PrintDocumentTypeEnum b : PrintDocumentTypeEnum.values()) {
	      if (String.valueOf(b.value).equals(text)) {
	        return b;
	      }
	    }
	    return null;
	  }
}
