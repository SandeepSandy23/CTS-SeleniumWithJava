package com.ebay.printorder.exsvc.executors;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.testng.Reporter;

import com.ebay.common.infra.executor.BaseExecutor;
import com.ebay.common.infra.obj.Action;
import com.ebay.common.infra.obj.BaseKeyNode;
import com.ebay.common.infra.obj.Param;
import com.ebay.common.infra.obj.orders.OrdersInfo;
import com.ebay.common.infra.obj.orders.OrdersScopeEnum;
import com.ebay.printorder.pojo.*;
import com.ebay.qi.autobot.util.Console;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.reporter_generator.ReportLogger;

public class PrintOrderEXSvcExecutor extends BaseExecutor {
    ReportLogger breezeReport = new ReportLogger();
    String site = null;
    String propFile = null;
    
	public PrintOrderEXSvcExecutor() throws Exception {
    	super();
    }

	@Override
	public Class<? extends Enum<?>> getActionsTypeEnumClass() {
		return PrintOrderEXSvcActionEnum.class;
	}

	@Override
	protected void execute() throws Exception {
		site = TestParams.CommonTestEnv.site.get();
		propFile = TestParams.get("propFile");
		executeActions();
	}

	private void executeActions() throws Exception {
        List<BaseKeyNode> nodes = getNodesWithActions(OrdersScopeEnum.ORDERSINFO);
        Console.log(" #####[Print Order Experience Svc Executor] Total # of Nodes  = " + nodes.size());
        String sellerName = null;
        String sellerType = "";
        String validate = null;
        String errFlow = null;
        String documents = null;
        String orderIds = null;
        String labelIds = null;
        String deviceType = null;
        String wordsList = null;
        String sendCouponAction = null;
        boolean isPicklistEligible = true;
        boolean validateCoupon = false;
        String template = null;
        String countsPerSheet = null;
        String mode = null;
        Map<String, String> couponIds = new HashMap<String, String>(); // this is not required if pref call works

        for (int i = 0; i < nodes.size(); i++) {
            OrdersInfo ordersInfo = (OrdersInfo) nodes.get(i);
            Action eachAction = ordersInfo.getActionsList().get(i);
            PrintOrderEXSvcActionEnum action = (PrintOrderEXSvcActionEnum) eachAction
                    .getActionEnum();
            ArrayList<Param> paramList = eachAction.getParamList();
            Console.log(action.name().toLowerCase() +" action params count = " + paramList.size());
            for (Param p : paramList) {
            	PrintOrderEXSvcActionParamEnum pEnum = (PrintOrderEXSvcActionParamEnum) p.getParamEnum();
                switch (pEnum) {
                    case SELLER_NAME:
                        Reporter.log("Seller Name value = " + p.getValue());
                        sellerName = p.getValue();
                        break;
                    case SELLER_TYPE:
                    	Reporter.log("Seller type value = " + p.getValue());
                        sellerType = p.getValue();
                        break;
                    case SITE:
                		Reporter.log("Site value = " + p.getValue());
                		site = p.getValue();
                        break;
                    case VALIDATE:
                        Reporter.log("Validate value = " + p.getValue());
                        validate = p.getValue();
                        break;
                    case ERROR_FLOW:
                        Reporter.log("ErrorFlow value = " + p.getValue());
                        errFlow = p.getValue();
                        break;
                    case DOCUMENTS:
                        Reporter.log("Documents selection value = " + p.getValue());
                        documents = p.getValue();
                        break;
                    case ORDERS:
                        Reporter.log("Orders value = " + p.getValue());
                        orderIds = p.getValue();
                        break;
                    case LABELS:
                        Reporter.log("Labels value = " + p.getValue());
                        labelIds = p.getValue();
                        break;
                    case DEVICE_TYPE:
                        Reporter.log("device type = " + p.getValue());
                        deviceType = p.getValue();
                        break;
                    case WORDS_LIST:
                        Reporter.log("Words list = " + p.getValue());
                        wordsList = p.getValue();
                        break;
                    case PICKLIST_ELIGIBLE:
                        Reporter.log("isPicklistEligible = " + p.getValue());
                        isPicklistEligible = Boolean.parseBoolean(p.getValue());
                        break;
                    case VALIDATE_COUPON:
                        Reporter.log("Validate coupon = " + p.getValue());
                        validateCoupon = Boolean.parseBoolean(p.getValue());
                        break;
                    case SENDCOUPON_ACTION:
                        Reporter.log("Validate SendCoupon Action = " + p.getValue());
                        sendCouponAction = p.getValue();
                        break;
                    case COUPONIDS:
                        Reporter.log("CouponIds = " + p.getValue());
                        String couponIdsString = p.getValue();
                        
                        if (couponIdsString != null) {
	                        String[] couponIdsArray = couponIdsString.split(",");
	                        
	                        for (int j = 0; j < couponIdsArray.length; j++) {
	                        	couponIds.put(couponIdsArray[j].split(":")[0], couponIdsArray[j].split(":")[1]);
	                        }
                        }
                        break;
                    case TEMPLATE:
                        Reporter.log("Template = " + p.getValue());
                        template = p.getValue();
                        break;

                    case COUNT_PER_SHEET:
                        Reporter.log("Count per sheet = " + p.getValue());
                        countsPerSheet = p.getValue();
                        break;
                    case MODE:
                        Reporter.log("Mode = " + p.getValue());
                        mode = p.getValue(); 
                        break;

                    default:
                        Reporter.log("Incorrect Parameter action input" + pEnum);
                        Assert.fail();
                        break;
                }
            }
            
            if(sellerName == null && ordersInfo.getOrderInfo() != null && !ordersInfo.getOrderInfo().isEmpty()) {
            	sellerName = ordersInfo.getOrderInfo().get(0).getSellerID();
            }
            
            ValidateInput input = new ValidateInput();
            input.setSellerName(sellerName);
            input.setSellerType(sellerType);
            input.setSite(site);
            input.setPropFile(propFile);
            input.setOrdersInfo(ordersInfo);
            input.setErrorFlow(errFlow);
            input.setValidate(ValidateEnum.getEnum(validate));
            input.setDocuments(documents);
            input.setDeviceType(deviceType);
            input.setPicklistEligible(isPicklistEligible);
            input.setValidateCoupon(validateCoupon);
            input.setCouponIds(couponIds);
            input.setTemplate(template);
            input.setCountPerSheet(countsPerSheet);
            input.setMode(mode);
            
            if(orderIds!=null) {
                input.setOrders(Arrays.asList(orderIds.split(",").clone()));
            }

            if(wordsList!=null) {
                input.setWordsList(Arrays.asList(wordsList.split(":").clone()));
            }
            
            if((sendCouponAction!=null) && (validate.equals("SEND_COUPON_MODULE"))) {
                input.setSendCouponAction(Arrays.asList(sendCouponAction.split(",").clone()));
            }
            
            if(labelIds!=null) {
                input.setLabels(Arrays.asList(labelIds.split(",").clone()));
            }
            //ValidateInput
            validateInput(input);
            // Action processing starts here
            breezeReport.logWithColor("***** "+action.name()+" action Start *****", "blue");
            Console.log(action.name());
            //validate
            action.getValidator().validate(input);
            breezeReport.logWithColor("***** "+action.name()+" action End *****", "blue");
        }
	}
	
	private void validateInput(ValidateInput input) {
		//SellerName Validation
        if (input.getSellerName() == null) {
        	Reporter.log("Please provide seller name");
            Assert.fail();
        }
        
        //Site Validation
        if (input.getSite() == null) {
        	Reporter.log("Please provide site");
            Assert.fail();
        } 
	}
}
