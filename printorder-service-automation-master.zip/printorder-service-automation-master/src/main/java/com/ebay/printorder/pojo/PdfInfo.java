package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class PdfInfo {

    private TextualDisplay title;
    private Selections.Help help;
    private TextualDisplay description;
    private PdfData data;

    @Getter
    public class PdfData{
        private String name;
        private String encodedData;
        private String documentType;
    }
}
