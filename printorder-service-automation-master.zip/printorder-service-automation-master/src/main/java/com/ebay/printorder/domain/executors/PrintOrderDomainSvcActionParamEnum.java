package com.ebay.printorder.domain.executors;

import com.ebay.common.infra.executor.IBaseParamType;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public enum PrintOrderDomainSvcActionParamEnum implements IBaseParamType {
	SELLER_NAME, SITE, VALIDATE,ERROR_FLOW,INFO, ORDERS, LABELS
}
