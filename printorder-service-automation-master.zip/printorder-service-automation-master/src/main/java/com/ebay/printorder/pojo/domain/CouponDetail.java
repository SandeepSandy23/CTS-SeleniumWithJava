package com.ebay.printorder.pojo.domain;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class CouponDetail {
    private String couponMessage;
    private String couponCode;
    private String ValidDate;
    private String categories;
    private String couponType;
    private String couponBudget;
    private String maxDiscount;
    private Integer maxRedemptionPerUser;
    private String couponURL;
    private String couponURLForQRCode;
    private String termsURL;
}
