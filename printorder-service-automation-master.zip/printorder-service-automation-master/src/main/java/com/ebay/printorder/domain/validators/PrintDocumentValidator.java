package com.ebay.printorder.domain.validators;

import com.ebay.orders.list.cosmos.pojo.Buyer;
import com.ebay.orders.list.cosmos.pojo.CosmosResponse;
import com.ebay.orders.list.cosmos.pojo.LineItemTypes;
import com.ebay.orders.list.cosmos.pojo.Order;
import com.ebay.printorder.deserializer.RestCallDeserializer;
import com.ebay.printorder.pojo.*;
import com.ebay.printorder.util.CommonUtil;
import com.ebay.printorder.util.CosmosUtil;
import org.apache.commons.collections.CollectionUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.List;

public class PrintDocumentValidator extends BaseValidator {

    @Override
    public void validateFlow(ValidateInput input) throws Exception {
        softAssert = new SoftAssert();

        String sellerName = input.getSellerName();
        String site = input.getSite();
        boolean isSingleOrder = false;
        CosmosUtil cosmosUtil = new CosmosUtil();
        RestCallDeserializer deserializer = new RestCallDeserializer();
        List<String> orders = input.getOrders();
        CosmosResponse cosmosResponse = new CosmosResponse();
        // check if orders are present
        if (CollectionUtils.isNotEmpty(orders)) {
            JSONObject jsonObject = cosmosUtil.getOrderDetails(orders, sellerName, site);
            cosmosResponse = deserializer.deserializeCosmosResponse(jsonObject.toString());
            if (orders.size() == 1) isSingleOrder = true;
        }

        breezeReport.logWithColor("SellerName: " + sellerName, "blue");
        breezeReport.logWithColor("Site: " + site, "blue");

        //happy case: set the  request for printOrder domain svc
        GenerateDocumentRequest request = buildRequest(cosmosResponse);
        String reqStr = CommonUtil.toJSON(request);

        breezeReport.logWithColor("Generate Documents call", "brown");
        int statusCode = printOrderUtil.getGenerateDocumentsResponse(sellerName, reqStr, site, input);
        breezeReport.logBoldStep("print order domain svc generate documents for " + (isSingleOrder ? "single order: " : "multi orders: ") + (statusCode == 200 ? "success" : "fail"));

        //bad case : if the request is null/malformed, we will get 204 no content error.
        breezeReport.logWithColor("null/malformed request test for print order domain service", "red");
        statusCode = printOrderUtil.getGenerateDocumentsResponse(sellerName, null, site, input);
        Assert.assertEquals(statusCode, 400, "PrintOrder domain service response is not correct because of null request");
        breezeReport.logBoldStep("print order domain svc generate documents for " + (isSingleOrder ? "single order: " : "multi orders: ") + (statusCode == 400 ? "fail" : "success") + " because of null request. ");

        String malFormedRequest = reqStr.replace("prefInfo", "preInfo");
        statusCode = printOrderUtil.getGenerateDocumentsResponse(sellerName, malFormedRequest, site, input);
        Assert.assertEquals(statusCode, 204, "PrintOrder domain service response is not correct because of malformed request");
        breezeReport.logBoldStep("print order domain svc generate documents for " + (isSingleOrder ? "single order: " : "multi orders: ") + (statusCode == 204 ? "fail" : "success") + " because of malformed request. ");


    }


    private GenerateDocumentRequest buildRequest(CosmosResponse ordersInfo) {
        GenerateDocumentRequest req = new GenerateDocumentRequest();


        //There are 2 document type: packing slip or order receipt
        List<String> documentTypes = new ArrayList<>();
        documentTypes.add("PACKING_SLIP");
        documentTypes.add("ORDER_RECEIPT");

        //Set print orders preference info
        PreferenceInfo preferenceInfo = new PreferenceInfo();
        
        preferenceInfo.setPageSize("3");
        preferenceInfo.setFormsPerSheet(1);
        preferenceInfo.setGift(false);
        preferenceInfo.setShipFromNameAndAddressForPackingSlip(true);
        preferenceInfo.setShipFromNameAndAddressForOrderReceipt(true);
        preferenceInfo.setListingThumbnail(true);
        preferenceInfo.setListingThumbnailForOrderReceipt(true);
        preferenceInfo.setWarrantyInfo(true);
        preferenceInfo.setReturnPolicy(true);
        preferenceInfo.setSellerRating(true);
        preferenceInfo.setThankYouNote("Thanks for your purchase! Hope you enjoy it!");
        preferenceInfo.setPersonalNote("Thanks");
        preferenceInfo.setStoreLogo(true);
        preferenceInfo.setStoreUrl(true);
        preferenceInfo.setStoreQRCodeLink(true);
        preferenceInfo.setShippingInfo(true);
        preferenceInfo.setPaymentInfo(true);
        preferenceInfo.setSellerNote(true);
        preferenceInfo.setBuyerNoteForPackingSlip(true);
        preferenceInfo.setBuyerNoteForOrderReceipt(true);
        preferenceInfo.setCustomLabel(true);
        preferenceInfo.setCustomLabelForPackingSlip(true);

        List<PrintOrderInfo> printOrderInfoList = new ArrayList<>();
        Order singleOrder = ordersInfo.getMembers().get(0).getOrder();

        //Set seller store info
        SellerStoreInfo sellerStoreInfo = new SellerStoreInfo();

        int sellerFeedbackScore = singleOrder.getSeller().getFeedbackScore();
        SellerStoreInfo.FeedbackInfo feedbackInfo = new SellerStoreInfo.FeedbackInfo(18956, sellerFeedbackScore);
        SellerStoreInfo.SellerAddressInfo address = new SellerStoreInfo.SellerAddressInfo(singleOrder.getSeller().getUserIdentifier().getUserName(),
                "Test", "Seller", "1146 Harrison St", "", "", "","","","666666");

        sellerStoreInfo.setStoreUrl("stores.ebay.com/eCop-Police-Supply");
        sellerStoreInfo.setStoreName("Sample_store_test");
        sellerStoreInfo.setStoreLogo("https://www.iconfinder.com/data/icons/real-estate-1-12/50/13-512.png");
        sellerStoreInfo.setFeedback(feedbackInfo);
        sellerStoreInfo.setAddress(address);


        for (int i = 0; i < ordersInfo.getMembers().size(); i++) {


            Order order = ordersInfo.getMembers().get(i).getOrder();

            //Set orders info
            PrintOrderInfo printOrderInfo = new PrintOrderInfo();
            Buyer buyerInfo = order.getBuyer();

            List<PrintOrderInfo.ShipAddressInfo> shipToAddressList = new ArrayList<>();
            shipToAddressList.add(new PrintOrderInfo.ShipAddressInfo(buyerInfo.getFullName(),buyerInfo.getFirstName(),buyerInfo.getLastName(),"1146 Harrison","","","","","","Packing_Slip"));

            printOrderInfo.setOrderId(order.getOrderId());

            printOrderInfo.setShipToAddress(shipToAddressList);
            printOrderInfo.setOrderDate(order.getCreationDate().getValue());
            printOrderInfo.setOrderTotal(String.valueOf(order.getOrderTotalSummary().getTotal().getAmount().getValue()));


            //Set itemsInfo
            List<ItemInfo> items = new ArrayList<>();
            for (LineItemTypes item : order.getLineItemTypes()) {
                ItemInfo itemInfo = new ItemInfo();
                itemInfo.setItemId(item.getSourceId().getItemId());
                itemInfo.setTitle(item.getTitle().getContent());
                items.add(itemInfo);
            }
            //Set itemsInfo
            printOrderInfo.setItems(items);
            printOrderInfoList.add(printOrderInfo);
        }

        req.setDocuments(documentTypes);
        req.setPrefInfo(preferenceInfo);
        req.setSellerInfo(sellerStoreInfo);
        req.setOrders(printOrderInfoList);

        return req;
    }
}
