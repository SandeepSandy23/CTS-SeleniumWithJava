package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class OrdersSummary {
    private TextualDisplay summaryTitle;

    private TextualDisplay doneAction;

    private List<Member> members;

    public TextualDisplay getSummaryTitle() {
        return summaryTitle;
    }

    public void setSummaryTitle(TextualDisplay summaryTitle) {
        this.summaryTitle = summaryTitle;
    }

    public TextualDisplay getDoneAction() {
        return doneAction;
    }

    public void setDoneAction(TextualDisplay doneAction) {
        this.doneAction = doneAction;
    }

    public List<Member> getMembers() {
        return members;
    }

    public void setMembers(List<Member> ordersSummary) {
        this.members = ordersSummary;
    }
}
