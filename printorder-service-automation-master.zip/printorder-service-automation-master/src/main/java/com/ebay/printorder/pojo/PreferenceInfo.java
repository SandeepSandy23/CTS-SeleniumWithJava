package com.ebay.printorder.pojo;

import java.util.List;

import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class PreferenceInfo {

    private String pageSize;
    private int formsPerSheet;
    private boolean gift;
    private boolean shipFromNameAndAddressForPackingSlip;
    private boolean shipFromNameAndAddressForOrderReceipt;
    private boolean listingThumbnail;
    private boolean listingThumbnailForOrderReceipt;
    private boolean warrantyInfo;
    private boolean returnPolicy;
    private boolean sellerRating;
    private String thankYouNote;
    private String personalNote;
    private boolean storeLogo;
    private boolean storeUrl;
    private boolean storeQRCodeLink;
    private boolean shippingInfo;
    private boolean paymentInfo;
    private boolean sellerNote;
    private boolean buyerNoteForPackingSlip;
    private boolean buyerNoteForOrderReceipt;
    private boolean customLabel;
    private boolean customLabelForPackingSlip;
    private PackingSlipCoupon packingSlipCoupon;
    private StandaloneCoupon standaloneCoupon;
    private InvoiceNumber invoiceNumber;
    
    @AllArgsConstructor
    public static class PackingSlipCoupon{
    	private String template;
    	private int countPerSheet;
    }
    
    @AllArgsConstructor
    @NoArgsConstructor
    @Getter
    @Setter
    public static class StandaloneCoupon{
    	private String id;
    	private String template;
    	private String personalNote;
    	private int countPerSheet;
    }
    
    @AllArgsConstructor
    @NoArgsConstructor
    @Getter
    @Setter
    public static class InvoiceNumber{
    	private String originalPrefix;
    	private String originalCounter;
    	private String prefix;
    	private String counter;
    }
    
}
