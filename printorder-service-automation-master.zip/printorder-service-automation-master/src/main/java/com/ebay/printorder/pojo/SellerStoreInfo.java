package com.ebay.printorder.pojo;


import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class SellerStoreInfo {

    private String storeLogo;
    private String storeName;
    private String storeUrl;
    private FeedbackInfo feedback;
    private SellerAddressInfo address;
    private boolean topRatedSeller;
    private boolean nonStoreSeller;

    @AllArgsConstructor
    public static class FeedbackInfo {
        private int feedbackCount;
        private double positiveFeedback;
    }


    @AllArgsConstructor
    public static class SellerAddressInfo {
        private String name;
        private String firstName;
        private String lastName;
        private String addressLine1;
        private String addressLine2;
        private String city;
        private String state;
        private String postalCode;
        private String country;
        private String phoneNumber;
    }
}
