package com.ebay.printorder.util;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.printorder.pojo.LabelServiceResponse;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.serviceautil.apidriver.RestClient;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;

import java.net.URL;
import java.util.List;

import static com.ebay.common.utils.TokenUtil.getAppToken;

public class LabelServiceUtil {
  public LabelServiceResponse getDataFromLabelService(List<String> labelIds, String sellerName) throws Exception {
    String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
    String labelServiceURL = (TestParams.TestEnv.customparam.get("labelServiceURL"))
      + "?shipmentIds=" + String.join(",", labelIds);
    String bearer_token = "Bearer " + getAppToken("sell@user");
    Reporter.log("LabelService Endpoint URL" + labelServiceURL);

    RestClient<String> client = new RestClient<>(String.class)
      .header("Authorization", bearer_token)
      .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName + "%2CorigAcctId%3D" + sellerId);
    URL url = new URL(labelServiceURL);
    client.get(url);

    Assert.assertEquals(client.getResponseCode(), 200);
    JSONObject responseObject = new JSONObject(client.getResponse());
    return CommonUtil.fromJson(responseObject, LabelServiceResponse.class);
  }
}
