package com.ebay.printorder.pojo.domain;



import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class SellerInfo {
	
	private String loginId;
	private String storeLogo;
	private Feedback feedback;
	private AddressDetail address;
	private String storeName;
	private String storeUrl;	
	private boolean isNonStoreSeller;
	private boolean isTopRatedSeller;

}
