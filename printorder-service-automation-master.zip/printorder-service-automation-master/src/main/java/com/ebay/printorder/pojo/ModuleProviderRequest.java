package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import java.util.List;

/**
 * @author mrudrappa (Mamatha Rudrappa)
 */

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ModuleProviderRequest {
    private List<String> orderIds;
    private List<String> couponIds;
    private List<String> labelIds;
    private DocumentSelections documentSelections;
    private PreferenceInfo preferenceSelections;
    public List<String> getOrderIds() {
        return orderIds;
    }

    public void setOrderIds(List<String> orderIds) {
        this.orderIds = orderIds;
    }

    public DocumentSelections getDocumentSelections() {
        return documentSelections;
    }

    public void setDocumentSelections(DocumentSelections documentSelections) {
        this.documentSelections = documentSelections;
    }

    public List<String> getLabelIds() {
        return labelIds;
    }

    public void setLabelIds(List<String> labelIds) {
        this.labelIds = labelIds;
    }

    public List<String> getCouponIds() {
        return couponIds;
    }

    public void setCouponIds(List<String> couponIds) {
        this.couponIds = couponIds;
    }

    public PreferenceInfo getPreferenceSelections() {
        return preferenceSelections;
    }

    public void setPreferenceSelections(PreferenceInfo preferenceSelections) {
        this.preferenceSelections = preferenceSelections;
    }
}
