package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class Subsection {

    private Synopsis synopsis;
    private String fieldId;
    private SelectionDetails selectionDetails;
    private EditAction editAction;
    private List<TextualDisplay> selectionSummary;

    @Getter
    public static class Synopsis{
        private TextualDisplay title;
        private TextualDisplay synopsis;
        private TextualDisplay editAction;
        private List<TextualDisplay> selectionSummary;
        private String accessibilityText;
    }

    @Getter
    public static class SelectionDetails{
        private TextualDisplay title;
        private TextualDisplay description;
        private TextualDisplay doneAction;
        private List<Selections> selectionGroup;
    }
    
    @Getter
    public static class EditAction{
        private String _type;
        private TextualDisplay editAction;
        private Action action;
    }
}
