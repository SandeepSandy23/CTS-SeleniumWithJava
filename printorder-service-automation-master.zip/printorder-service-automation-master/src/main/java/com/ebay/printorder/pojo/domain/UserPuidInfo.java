package com.ebay.printorder.pojo.domain;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserPuidInfo {
	
	private String username;
	private String sellerId;
	private String userLookUpHostId;
	private String blockedBuyerIds;
	private String puid;
	private String public_user_id;
}
