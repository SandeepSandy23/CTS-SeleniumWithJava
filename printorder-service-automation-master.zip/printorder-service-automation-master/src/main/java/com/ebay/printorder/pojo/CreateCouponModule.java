package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.ebay.printorder.pojo.SendCouponResponse.RequestParameters;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class CreateCouponModule {
	 private String _type;
	 private List<TextualDisplay> content;
	// private CreateCouponImage createCouponImage;
	// private CouponIntroduction couponIntroduction;
	 
	 private CancelAction cancelAction;
	 
	 @Getter
	 public static class CancelAction {
		 private String _type;
		 private String text;
		 private String type;
		 private Action action;
		 private RequestParameters requestParameters;
		 }
}