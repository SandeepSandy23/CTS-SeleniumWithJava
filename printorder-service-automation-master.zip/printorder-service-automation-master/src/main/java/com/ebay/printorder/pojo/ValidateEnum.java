package com.ebay.printorder.pojo;

import com.ebay.testinfrastructure.reporter_generator.ReportLogger;

public enum ValidateEnum {
	PRINT_ORDER_MODULE,
	PACKING_SLIP_MODULE,
	ORDER_RECEIPT_MODULE,
	COUPON_MODULE,
	GENERATE_DOCUMENTS,
	BLACK_LISTED_WORDS_VALIDATE,
	SEND_COUPON_MODULE,
	ERROR_CASE,
	GENERIC_COUPON_MODULE,
	COMPLETE_DOCUMENT_MODULE,
	PACKING_SLIP,
	ORDER_RECEIPT,
	CANCEL_CLOSED_WITH_REFUND,
	PARTIAL_REFUNDED;

	private static ReportLogger breezeReport = new ReportLogger();
	
	public static ValidateEnum getEnum(String name) {
		if(name == null || name.trim().isEmpty()) {
			return null;
		}
		try{
			return ValidateEnum.valueOf(name);
		} catch(Exception e) {
			breezeReport.logWarningStep("Exception while creating ValidateEnum for name:" + name);
		}
		return null;
	}

}
