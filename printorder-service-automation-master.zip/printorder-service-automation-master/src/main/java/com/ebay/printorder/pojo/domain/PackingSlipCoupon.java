package com.ebay.printorder.pojo.domain;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PackingSlipCoupon {
    private CouponDetail couponDetail;
}
