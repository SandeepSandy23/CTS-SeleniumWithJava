package com.ebay.printorder.pojo.domain;


import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Attribute {
	private String key;
	private String value;
}
