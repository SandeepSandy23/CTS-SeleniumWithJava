package com.ebay.printorder.pojo.domain;


import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PreferenceInfo {
	  private String pageSize;
	  private Integer formsPerSheet;
	  private Boolean hasGift;
	  private Boolean hasShipFromNameAndAddressForPackingSlip;
	  private Boolean hasListingThumbnail;
	  private Boolean hasReturnPolicy;
	  private Boolean hasSellerRating;
	  private String thankYouNote;
	  private String personalNote;
	  private Boolean hasShipFromNameAndAddressForOrderReceipt;
	  private Boolean hasStoreLogo;
	  private Boolean hasStoreUrl;
	  private Boolean hasStoreQRCodeLink;
	  private Boolean hasShippingInfo;
	  private Boolean hasPaymentInfo;
	  private Boolean hasSellerNote;  
	  private Boolean hasBuyerNoteForPackingSlip;
	  private Boolean hasBuyerNoteForOrderReceipt;	
	  private Boolean hasCustomLabel;
	  private Boolean hasCustomLabelForPackingSlip;
	  private Boolean hasListingThumbnailForOrderReceipt;
}
