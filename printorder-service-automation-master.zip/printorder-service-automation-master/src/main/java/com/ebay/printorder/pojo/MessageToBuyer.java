package com.ebay.printorder.pojo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class MessageToBuyer {

	private TextualDisplay label;
	private TextualDisplay accessoryLabel;
	private TextualDisplay placeHolder;
	private MessageField messageField;
	private String _type;
	private boolean disabled;
	private boolean lockable;
	private boolean selected;
	private boolean defaultChoice;
	private boolean readOnly;
	private String paramValue;
	private String paramValueType;
	private List<Validations> validations;
	private String fieldId;
	private int maxLength;
	
	@Getter
	public class Validations{
		private int maxLength;
		private boolean required;
	}
	
	public TextualDisplay getLabel() {
		return label;
	}

	public void setLabel(TextualDisplay label) {
		this.label = label;
	}
	
	public TextualDisplay getAccessoryLabel() {
		return accessoryLabel;
	}

	public void setAccessoryLabel(TextualDisplay accessoryLabel) {
		this.accessoryLabel = accessoryLabel;
	}
	
	public TextualDisplay getPlaceHolder() {
		return placeHolder;
	}

	public void setPlaceHolder(TextualDisplay placeHolder) {
		this.placeHolder = placeHolder;
	}
	
	public MessageField getMessageField() {
		return messageField;
	}

	public void setMessageField(MessageField messageField) {
		this.messageField = messageField;
	}
}

