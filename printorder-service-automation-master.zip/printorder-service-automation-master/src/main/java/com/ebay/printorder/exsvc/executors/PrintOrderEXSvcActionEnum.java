package com.ebay.printorder.exsvc.executors;

import com.ebay.common.infra.executor.IBaseActionType;
import com.ebay.common.infra.executor.IBaseParamType;
import com.ebay.common.infra.executor.IScopeEnum;
import com.ebay.common.infra.obj.orders.OrdersScopeEnum;
import com.ebay.printorder.exsvc.validators.BaseValidator;
import com.ebay.printorder.exsvc.validators.BlacklistedWordsValidator;
import com.ebay.printorder.exsvc.validators.ModuleProviderValidator;
import com.ebay.printorder.exsvc.validators.PrintDocumentsValidator;

import java.util.Arrays;

/**
 *
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public enum PrintOrderEXSvcActionEnum implements IBaseActionType {

	MODULE_PROVIDER(new IScopeEnum[] { OrdersScopeEnum.ORDERSINFO },
			new PrintOrderEXSvcActionParamEnum[] {
					PrintOrderEXSvcActionParamEnum.SELLER_NAME,
					PrintOrderEXSvcActionParamEnum.VALIDATE,
					PrintOrderEXSvcActionParamEnum.ERROR_FLOW,
					PrintOrderEXSvcActionParamEnum.DOCUMENTS,
					PrintOrderEXSvcActionParamEnum.ORDERS,
				  PrintOrderEXSvcActionParamEnum.LABELS,
				}, new ModuleProviderValidator()),

	BLACK_LISTED_WORDS_VALIDATOR(new IScopeEnum[] { OrdersScopeEnum.ORDERSINFO },
			new PrintOrderEXSvcActionParamEnum[] {
		PrintOrderEXSvcActionParamEnum.SELLER_NAME,
				PrintOrderEXSvcActionParamEnum.VALIDATE,
				PrintOrderEXSvcActionParamEnum.ERROR_FLOW,
				PrintOrderEXSvcActionParamEnum.DOCUMENTS,
				PrintOrderEXSvcActionParamEnum.ORDERS,
	}, new BlacklistedWordsValidator()),
	PRINT_DOCUMENTS_MODULE(new IScopeEnum[] { OrdersScopeEnum.ORDERSINFO },
			new PrintOrderEXSvcActionParamEnum[] {
					PrintOrderEXSvcActionParamEnum.SELLER_NAME,
					PrintOrderEXSvcActionParamEnum.VALIDATE,
					PrintOrderEXSvcActionParamEnum.ERROR_FLOW,
					PrintOrderEXSvcActionParamEnum.DOCUMENTS,
					PrintOrderEXSvcActionParamEnum.ORDERS,
					PrintOrderEXSvcActionParamEnum.LABELS,
			}, new PrintDocumentsValidator());

	private PrintOrderEXSvcActionParamEnum[] supportedParamTypes;
	private IScopeEnum[] supportedScopes;
	private BaseValidator validator;

	PrintOrderEXSvcActionEnum(IScopeEnum[] scopes,
			PrintOrderEXSvcActionParamEnum[] paramtypeenum, BaseValidator validator) {
		if (scopes != null) {
			this.supportedScopes = Arrays.copyOf(scopes, scopes.length);
		}

		if (paramtypeenum != null) {
			this.supportedParamTypes = Arrays.copyOf(paramtypeenum,
					paramtypeenum.length);
		}
		if(validator == null){
			throw new IllegalArgumentException("Validator is null for action:" + name());
		}
		this.validator = validator;
	}

	public IScopeEnum[] getScope() {
		return supportedScopes;
	}

	public IBaseParamType[] getParams() {
		return supportedParamTypes;
	}

	public BaseValidator getValidator() {
		return validator;
	}
}
