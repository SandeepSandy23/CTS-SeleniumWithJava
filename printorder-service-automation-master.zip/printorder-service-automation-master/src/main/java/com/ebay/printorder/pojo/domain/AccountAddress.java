package com.ebay.printorder.pojo.domain;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import lombok.Getter;
import lombok.Setter;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class AccountAddress {

	@JsonProperty("addressId")
	private String addressId;
	@JsonProperty("location")
	private SellerAddressDetail location;
	@JsonProperty("phoneNumber")
	private String phoneNumber;
	@JsonProperty("name")
	private String name;
}

