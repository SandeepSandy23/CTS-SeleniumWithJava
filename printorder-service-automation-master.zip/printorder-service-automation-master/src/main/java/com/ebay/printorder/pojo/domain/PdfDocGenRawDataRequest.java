package com.ebay.printorder.pojo.domain;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;



@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PdfDocGenRawDataRequest {
	@JsonProperty("globalInfo")
	private GlobalInfo globalInfo;
	@JsonProperty("prefInfo")
	private PreferenceInfo prefInfo;
	@JsonProperty("sellerInfo")
	private SellerInfo sellerInfo;
	@JsonProperty("orders")
	private List<PdfDocOrders> orders;
	private List<PrintDocumentTypeEnum> documents;
	private String browserName;
	@JsonProperty("couponInfo")
	private CouponInfo couponInfo;
}
