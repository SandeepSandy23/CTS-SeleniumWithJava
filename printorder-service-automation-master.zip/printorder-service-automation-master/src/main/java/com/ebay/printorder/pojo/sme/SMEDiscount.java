package com.ebay.printorder.pojo.sme;

import lombok.Getter;
import lombok.Setter;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class SMEDiscount {
    private String discountType;
    private DiscountValue discountValue;
    private Integer itemQuantity;
    private List<Attribute> discountAttribute;
    private Integer discountOrder;
    private Inventory inventory;
}
