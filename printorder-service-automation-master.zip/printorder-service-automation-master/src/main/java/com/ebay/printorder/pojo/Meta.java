package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Meta {
	private String pageTitle;
	
	private RequestParameters requestParameters;

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public RequestParameters getRequestParameters() {
		return requestParameters;
	}

	public void setRequestParameters(RequestParameters requestParameters) {
		this.requestParameters = requestParameters;
	}

}
