package com.ebay.printorder.pojo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import lombok.Getter;
import lombok.Setter;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class SendCouponRequest {
	
	private List<String> orderIds;
	private String couponId;
	private String messageToBuyer;
	private List<String> buyerIds;
	private List<String> subSectionIds;
	
}
