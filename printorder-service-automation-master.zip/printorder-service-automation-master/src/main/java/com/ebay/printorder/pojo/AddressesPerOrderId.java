package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.Map;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressesPerOrderId {
  private Map<String, OrderAddresses> addressesPerOrderId;
}
