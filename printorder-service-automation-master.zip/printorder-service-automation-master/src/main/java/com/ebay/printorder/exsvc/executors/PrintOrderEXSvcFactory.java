package com.ebay.printorder.exsvc.executors;

import com.ebay.common.infra.executor.BaseExecutor;

/**
 * 
 * @author mrudrappa (Mamatha Rudrappa)
 *
 */

public class PrintOrderEXSvcFactory {

    private static final PrintOrderEXSvcFactory printOrderEXSvcFactory = new PrintOrderEXSvcFactory();

    public PrintOrderEXSvcFactory() {

    }

    public static PrintOrderEXSvcFactory getInstance() {
    	return printOrderEXSvcFactory;
    }

    public BaseExecutor getExecutor() throws Exception {
    	return new PrintOrderEXSvcExecutor();
    }
}
