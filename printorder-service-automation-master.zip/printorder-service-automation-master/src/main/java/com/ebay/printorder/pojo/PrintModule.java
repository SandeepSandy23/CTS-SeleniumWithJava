package com.ebay.printorder.pojo;


import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter @Setter
public class PrintModule {
    private String _type;
    private PdfInfo pdfInfo;
}
