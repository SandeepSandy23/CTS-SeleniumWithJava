package com.ebay.printorder.pojo.domain;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.printorder.pojo.ValidateInput;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetUserRequest {
	
	private String query = "query userQuery{user(id:\"%s\"){userId extensions(namespace:[\"SELLING\", \"TRUST\"]){key value type}}}";
	
	private String taxQuery = "query userQuery{user(id:\"%s\"){businessIdentityProfile{govtIssuedIds{govtIssuedIdType govtIssuedIdValue}}}}";

}

