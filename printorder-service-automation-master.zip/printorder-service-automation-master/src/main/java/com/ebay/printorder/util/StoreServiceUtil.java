package com.ebay.printorder.util;

import java.net.URL;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.printorder.deserializer.RestCallDeserializer;
import com.ebay.printorder.pojo.domain.GetAddressResponse;
import com.ebay.printorder.pojo.domain.UserPuidInfo;
import com.ebay.printorder.pojo.domain.Store;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.serviceautil.apidriver.RestClient;
import com.sun.jersey.api.client.UniformInterfaceException;

public class StoreServiceUtil extends BaseSvcUtil {
	public JSONObject getSellerStorePuIdDetails( String sellerName, String site) throws Exception {
        site = overrideSite(site);
        String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
        //Get list of orders info here, not just a single order.
        String sellerStorePUIDURL = (TestParams.TestEnv.customparam.get("sellerPUIDURL"))
                + sellerName;
        String bearer_token = "Bearer " + getAppToken("core@application");
        Reporter.log("Seller store PUID Endpoint URL" + sellerStorePUIDURL);

        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token);
        URL url = new URL(sellerStorePUIDURL);
        try {
        	client.get(url);
        } catch (Exception e) {
        	Reporter.log("Exception" + e);
        }
        
        if (client.getResponseCode() != 200) {
            client.get(url);
        }
        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());
        return responseObject;
    }
	
    public UserPuidInfo getStorePuIdResponse(String sellerName, String site) throws Exception {
    	RestCallDeserializer deserializer = new RestCallDeserializer();       
        JSONObject resp = getSellerStorePuIdDetails(sellerName, site);
        UserPuidInfo storePuIdResponse = deserializer.deserializeUserPuidInfo(resp.toString());
        return storePuIdResponse;
    }
    
    public JSONObject getSellerStoreDetails( String sellerName, String site,String public_user_id) throws Exception {
        site = overrideSite(site);
        String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
        //Get list of orders info here, not just a single order.
        String sellerStoreDetailsURL = (TestParams.TestEnv.customparam.get("storeSvcURL"))
                + "?owner_id="+public_user_id;
        String bearer_token = "Bearer " + getAppToken("buy@user");
        Reporter.log("Seller store Details Endpoint URL" + sellerStoreDetailsURL);

        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-MARKETPLACE-ID","EBAY-US");
        URL url = new URL(sellerStoreDetailsURL);
        try {
        	client.get(url);
        } catch (Exception e) {
        	Reporter.log("Exception: " + e);
        }
        
        if (client.getResponseCode() != 200) {
            client.get(url);
        }
        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());
        return responseObject;
    }
    public Store getStoreDetailsResponse(String sellerName, String site,String public_user_id) throws Exception {
    	RestCallDeserializer deserializer = new RestCallDeserializer();       
        JSONObject resp = getSellerStoreDetails(sellerName, site,public_user_id);
        Store sellerStoreDetailsResponse = deserializer.deserializeStore(resp.toString());
        return sellerStoreDetailsResponse;
    }
}
