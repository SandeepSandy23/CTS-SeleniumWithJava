package com.ebay.printorder.pojo;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class Tracking {
    private String eventFamily;
    private String eventAction;
    private String actionKind;
    private boolean flushImmediately;
    private EventProperty eventProperty;

    @Getter
    @Setter
    private class EventProperty{
        private String moduledtl;
        private String sid;
    }
}
