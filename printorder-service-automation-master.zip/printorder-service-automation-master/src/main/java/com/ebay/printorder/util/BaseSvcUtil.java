package com.ebay.printorder.util;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import com.ebay.qi.autobot.util.Console;
import com.ebay.testinfrastructure.reporter_generator.ReportLogger;
import com.ebay.testinfrastructure.serviceautil.asserts.RestfulChainAssert;
import com.ebay.testinfrastructure.serviceautil.rest.JsonWrapper;
import com.ebay.testinfrastructure.serviceautil.rest.MediaType;
import com.ebay.testinfrastructure.serviceautil.rest.Response;
import com.ebay.testinfrastructure.serviceautil.rest.RestfulClient;

public class BaseSvcUtil {
	private static final int RETRY_COUNT = 3;
	protected static ReportLogger breezeReport = new ReportLogger();
	
	public String getAppToken(String scope) throws Exception {
		String token = null;
		String requestBody = "grant_type=client_credentials&scope=https://api.ebay.com/oauth/scope/" + scope;
		String endPoint = "https://oauth.qa.ebay.com/identity/v1/oauth2/token";
		Map<String, String> headers = new HashMap<String, String>();
	    
		headers.put("Authorization", "Basic "
	                + "dXJuOmViYXktbWFya2V0cGxhY2UtY29uc3VtZXJpZDozMTNlNDhkMS1lYjJmLTQzY2EtYmNhNS03MTYwNGU4MGI2NzI6IDAzN2M2ZjZhLTI2YzctNGZlZC04MjA3LWY1NGI2OGE3NTA5OQ==");
	    
		Response tokenResp = null;
		for (int count = 0; count < RETRY_COUNT; count++) {
			tokenResp = makeSvcCall(endPoint, "POST", requestBody, headers,
	    			MediaType.APPLICATION_FORM_URLENCODED, false);
	    	
			if (tokenResp != null) {
				token = tokenResp.asJSONObject().get("access_token").toString();
				break;
			}
			breezeReport.logRedStep("Token call. Counter = " + count);
		}
	    return token;
	}
	
	public String getAppToken(String client_Id_Secret, String scope) throws Exception {
		String token = null;
		String requestBody = "grant_type=client_credentials&scope=https://api.ebay.com/oauth/scope/" + scope;
		String endPoint = "https://oauth.qa.ebay.com/identity/v1/oauth2/token";
		Map<String, String> headers = new HashMap<String, String>();
	    
		headers.put("Authorization", "Basic " + client_Id_Secret);
	    
		Response tokenResp = null;
		for (int count = 0; count < RETRY_COUNT; count++) {
			tokenResp = makeSvcCall(endPoint, "POST", requestBody, headers,
	    			MediaType.APPLICATION_FORM_URLENCODED, false);
	    	
			if (tokenResp != null) {
				token = tokenResp.asJSONObject().get("access_token").toString();
				break;
			}
			breezeReport.logRedStep("Token call. Counter = " + count);
		}
	    return token;       
  	}
	
	public  Response makeSvcCall(String svcUrl, String type, String payload,
		      Map<String, String> headers, MediaType mediaType, boolean validateRespCode) throws Exception {

			return makeSvcCall(svcUrl, type, payload, headers, mediaType, validateRespCode,
		        RespCodeEnum.RESP_200);
		}
		  
	  
	public  Response makeSvcCall(String svcUrl, String type, String payload, Map<String, String> headers, 
				MediaType mediaType, boolean validateRespCode, RespCodeEnum httpRespCode) throws Exception {
		  
			Response response = null;

			Console.log("payload = " + payload + ", URL = " + svcUrl);
			breezeReport.logBoldStep("URL = " + svcUrl);

			if (httpRespCode == null) {
				httpRespCode = RespCodeEnum.RESP_200;
			}

			switch (type) {
			case "GET":
				response = new RestfulClient.Builder().enableConsoleLogging(true).build().request()
	          		.headers(headers).contentType(mediaType).build().get(svcUrl);
				Console.log("Response = " + response.asJson());
				break;
		    	
			case "POST":
				response = new RestfulClient.Builder().enableConsoleLogging(true).build().request()
		          .headers(headers).payload(payload).contentType(mediaType).build().post(svcUrl);
				break;
			}

			if (validateRespCode) {
				if (response != null) {
					RestfulChainAssert assertion = new RestfulChainAssert();

					assertion.onResponse(response).code()
		            	.equals(httpRespCode.getCode(), "Code is not equal to 200").end();

					breezeReport.logBoldStep("Response code is " + httpRespCode.getCode()
		    			  + " as expected. PASSED.");
				} else {
					Assert.fail("REST call didn't go through. Response is Null/Empty.");
				}
			}
		  return response;
		}
	
	public String overrideSite(String site){
		if (site.equals("UK")) {
			site = "GB";
		}else if (site.equals("CAFR")) {
			site = "FRCA";
		}
		return site;
		
	}

}
