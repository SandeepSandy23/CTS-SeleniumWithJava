package com.ebay.printorder.pojo;

import com.ebay.common.infra.obj.orders.OrdersInfo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ValidateInput {

	List<String> orders;
	List<String> labels;
	String sellerName;
	String sellerType = "";
	String site;
	OrdersInfo ordersInfo;
	ValidateEnum validate;
	String propFile;
	String errorFlow = "false";
	String documents;
	String deviceType;
	List<String> sendCouponAction;
	List<String> wordsList;
	boolean isPicklistEligible = true;
	boolean validateCoupon = false; //if pref service call works this is not required
	Map<String, String> couponIds = new HashMap<String, String>(); //if pref service call works this is not required
	String template = "";
	String countPerSheet = "";
	String mode;
	
	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public List<String> getOrders() {
		return orders;
	}

	public void setOrders(List<String> orders) {
		this.orders = orders;
	}

	public List<String> getLabels() {
		return labels;
	}

	public void setLabels(List<String> labels) {
		this.labels = labels;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getSellerType() {
		return sellerType;
	}

	public void setSellerType(String sellerType) {
		this.sellerType = sellerType;
	}
	
	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public OrdersInfo getOrdersInfo() {
		return ordersInfo;
	}

	public void setOrdersInfo(OrdersInfo ordersInfo) {
		this.ordersInfo = ordersInfo;
	}

	public ValidateEnum getValidate() {
		return validate;
	}

	public void setValidate(ValidateEnum validate) {
		this.validate = validate;
	}

	public String getPropFile() {
		return propFile;
	}

	public void setPropFile(String propFile) {
		this.propFile = propFile;
	}

	public boolean isErrorFlow() {
		return errorFlow != null && errorFlow.equalsIgnoreCase("true");
	}

	public void setErrorFlow(String errorFlow) {
		this.errorFlow = errorFlow;
	}

	public String getDocuments() {
		return documents;
	}

	public void setDocuments(String documents) {
		this.documents = documents;
	}

	public void setDeviceType(String deviceType){this.deviceType = deviceType;}

	public String getDeviceType(){return deviceType;}

	public List<String> getWordsList() {
		return wordsList;
	}

	public void setWordsList(List<String> wordsList) {
		this.wordsList = wordsList;
	}
	
	public boolean isPicklistEligible() {
		return isPicklistEligible;
	}

	public void setPicklistEligible(boolean isPicklistEligible) {
		this.isPicklistEligible = isPicklistEligible;
	}
	
	public boolean isValidateCoupon() {
		return validateCoupon;
	}

	public void setValidateCoupon(boolean validateCoupon) {
		this.validateCoupon = validateCoupon;
	}
	
	public Map<String, String> getCouponIds() {
		return couponIds;
	}

	public void setCouponIds(Map<String, String> couponIds) {
		this.couponIds = couponIds;
	}
	
	public List<String> getSendCouponAction() {
		return sendCouponAction;
	}

	public void setSendCouponAction(List<String> sendCouponAction) {
		this.sendCouponAction = sendCouponAction;
	}
	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}

	public String getCountPerSheet() {
		return countPerSheet;
	}

	public void setCountPerSheet(String countPerSheet) {
		this.countPerSheet = countPerSheet;
	}
}
