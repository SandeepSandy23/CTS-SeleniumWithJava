package com.ebay.printorder.pojo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)

public class SendPreferenceSelections {

	private SendCoupon sendCoupon;
}