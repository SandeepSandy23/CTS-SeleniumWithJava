package com.ebay.printorder.util;

import com.ebay.common.util.db.DBSelectQueryUtil;
import com.ebay.orders.list.cosmos.pojo.CosmosResponse;
import com.ebay.orders.list.cosmos.pojo.ProformaOrder;
import com.ebay.printorder.deserializer.RestCallDeserializer;
import com.ebay.testinfrastructure.params.TestParams;
import com.ebay.testinfrastructure.serviceautil.apidriver.RestClient;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class CosmosUtil extends BaseSvcUtil {

    public JSONObject getOrderDetails(List<String> orders, String sellerName, String site) throws Exception {
        site = overrideSite(site);
        String sellerId = DBSelectQueryUtil.getOracleId(sellerName);
        //Get list of orders info here, not just a single order.
        String cosmosPlatformSvcURL = (TestParams.TestEnv.customparam.get("cosmosPlatformSvcURL"))
                + "?fields=address,logistics,payments,buyeraddress,summary,lineactions,lineitem,orderdetails&userType=seller&findfieldgroups=full&keys=" + String.join(",", orders);
        String bearer_token = "Bearer " + getAppToken("core@user");
        Reporter.log("Cosmos Endpoint URL" + cosmosPlatformSvcURL);

        RestClient<String> client = new RestClient<String>(String.class)
                .header("Authorization", bearer_token)
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY-" + site)
                .header("X-EBAY-OMS-VERSION", "3.7.56")
                .header("X-EBAY-C-ENDUSERCTX", "origUserId=origUserName%3D" + sellerName + "%2CorigAcctId%3D" + sellerId);
        URL url = new URL(cosmosPlatformSvcURL);
        client.get(url);
        if (client.getResponseCode() != 200) {
            client.get(url);
        }
        Assert.assertEquals(client.getResponseCode(), 200);
        JSONObject responseObject = new JSONObject(client.getResponse());
        return responseObject;
    }

    public boolean isMultiItemOrder(String orderId, String sellerName, String site) throws Exception {

        RestCallDeserializer deserializer = new RestCallDeserializer();
        List<String> order = new ArrayList<>();
        order.add(orderId);
        JSONObject resp = getOrderDetails(order, sellerName, site);
        CosmosResponse cosmosResponse = deserializer.deserializeCosmosResponse(resp.toString());

        ProformaOrder proformaOrder = cosmosResponse.getMembers().get(0).getProformaOrder();

        if (proformaOrder != null) {
            return proformaOrder.getLineItemTypes().size() > 1;
        } else
            return cosmosResponse.getMembers().get(0).getOrder().getLineItemTypes().size() > 1;
    }
    public CosmosResponse getCosmosResponse(List<String> orders, String sellerName, String site) throws Exception {
    	RestCallDeserializer deserializer = new RestCallDeserializer();       
        JSONObject resp = getOrderDetails(orders, sellerName, site);
        CosmosResponse cosmosResponse = deserializer.deserializeCosmosResponse(resp.toString());
        return cosmosResponse;
    } 
}
