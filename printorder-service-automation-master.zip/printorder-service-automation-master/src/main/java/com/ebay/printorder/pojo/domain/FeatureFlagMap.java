package com.ebay.printorder.pojo.domain;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeatureFlagMap {

	private Boolean EnableMyEbayMode;
	private Boolean EnableIndependentInvoiceNumberPref;
	private Boolean EnableSellerVatIdPref;


}
