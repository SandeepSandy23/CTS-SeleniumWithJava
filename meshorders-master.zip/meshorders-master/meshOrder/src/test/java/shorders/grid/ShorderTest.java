package shorders.grid;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import org.junit.jupiter.api.Test;


public class ShorderTest {

    @Test
    public void testParallel() {
        Results results = (new Runner.Builder()).forClass(getClass())
                              .tags("~@ignore")
                              .parallel(5);
    }
}