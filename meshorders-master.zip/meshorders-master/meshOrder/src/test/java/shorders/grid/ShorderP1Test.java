package shorders.grid;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import org.junit.jupiter.api.Test;


public class ShorderP1Test {

    @Test
    public void testParallel() {
        Results results = (new Runner.Builder()).forClass(getClass())
                              .tags("~@ignore")
                              .tags("@P1")
                              .parallel(5);
    }
}