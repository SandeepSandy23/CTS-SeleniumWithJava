function fn() {
  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 50000);
  karate.configure('logPrettyResponse', true);
  karate.configure('report', { showLog: true});
  karate.configure('ssl', { trustAll: true });

  var env = karate.env; // get system property 'karate.env'
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'dev';
  }
  var config = {
    appId: 'my.app.id',
    appSecret: 'my.secret',
    soldsvc_stg: 'https://soldsvc.vip.qa.ebay.com',
    omsvodexp_stg: 'https://omsvodexp2.vip.qa.ebay.com',
    shordersvc_url: karate.properties['shordersvc_url'] || 'https://shorder.vip.qa.ebay.com',
    shordersvc_native_url: karate.properties['shordersvc_native_url'] || 'https://api4.qa.ebay.com',
    expAuthTokenResp: karate.callSingle('classpath:expsvcToken.feature').response,
    shorder_vod_mock : true
  }
  if (env == 'dev') {
    // customize
    // e.g. config.foo = 'bar';
  } else if (env == 'e2e') {
    // customize
  }
  return config;
}

function getRequestId (location){ // @auther Tejas Vora

    var reqid = location.substring(location.indexOf('-') + 1);
    return reqid;
}
