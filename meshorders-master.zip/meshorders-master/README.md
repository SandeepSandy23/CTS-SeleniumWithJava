# meshorders
MeshOrders-integration-tests

VOD Karate Automation folder structure conventions
==================================================
> Folder structure options and naming conventions for VOD automation - https://github.corp.ebay.com/sdey1/meshorders/tree/master/meshOrder/src/test/java/VOD 

### Layout description

    .
    ├── mesh                   # most updated VOD automation
    │   ├── assertions         # common assertions for individual modules of experience service response, if needed, please create new folders for specific responses such as sh, nativ, myeBay
    │   │   └──json            # json to assert schema for Native VOD, Native line actions, Mesh VOD, Mesh VOD line actions             
    │   ├── myeBay             # Verify myeBay VOD response. Any different testcases for myeBay VOD should be included here
    │   ├── nativ              # Verify native VOD response. Any different testcases for native VOD should be included here
    │    ├── sh                 # Verify SH VOD response. Any different testcases for SH VOD should be included here
    │    ├── VodMeshTest.java   # Java file to execute Karate tests inside this folder
    │    ├── getMESHVODResponse.feature         # Returns exp service response for MESH VOD   
    │    └── verifyMESHVODResponse.feature      # Main file which executes karate test automation for all MESH VOD endpoints.  Any different testcases for native, myeBay and SH VOD should be │included here
    ├── myeBayOld                    # 