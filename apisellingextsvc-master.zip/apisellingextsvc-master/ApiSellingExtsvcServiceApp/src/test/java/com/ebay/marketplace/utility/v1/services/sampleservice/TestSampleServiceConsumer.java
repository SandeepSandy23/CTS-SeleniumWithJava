package com.ebay.marketplace.utility.v1.services.sampleservice;

import com.ebay.app.services.apisellingextsvc.tradingapiservice.gen.SharedTradingAPIServiceConsumer;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.ebay.soaframework.sif.service.EnvironmentMapper;

public class TestSampleServiceConsumer extends SharedTradingAPIServiceConsumer {

	public TestSampleServiceConsumer(String clientName) throws ServiceException {
		super(clientName);
	}

	public TestSampleServiceConsumer(String clientName, Class caller,
			boolean useDefaultClientConfig) throws ServiceException {
		super(clientName, caller, useDefaultClientConfig);
	}

	public TestSampleServiceConsumer(String clientName,
			EnvironmentMapper environmentMapper,
			boolean useDefaultClientConfig, Class caller)
			throws ServiceException {
		super(clientName, environmentMapper, useDefaultClientConfig, caller);
	}

	public TestSampleServiceConsumer(String clientName, String environment,
			Class caller, boolean useDefaultClientConfig)
			throws ServiceException {
		super(clientName, environment, caller, useDefaultClientConfig);
	}

	public TestSampleServiceConsumer(String clientName, String environment)
			throws ServiceException {
		super(clientName, environment);
	}
	
	

}
