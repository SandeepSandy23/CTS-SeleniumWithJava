package com.ebay.app.apisellingextsvc.filters;

import com.ebay.app.apisellingextsvc.common.CustomHttpRequestWrapper;
import com.ebay.app.apisellingextsvc.common.IAFHelper;
import com.ebay.app.apisellingextsvc.common.LoginHelper;
import com.ebay.raptor.metadata.api.IMetadataCoreRegistry;
import com.ebay.soaframework.common.types.SOAHeaders;
import com.google.common.collect.ImmutableSet;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.client.UserLookupClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.app.apisellingextsvc.service.client.model.GingerResponseType;
import com.ebay.app.apisellingextsvc.service.client.model.UserIdLookupResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;
import java.util.Set;
import javax.inject.Inject;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@Order(11)
public class SOAStagingAuthFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(SOAStagingAuthFilter.class);
    private static final Set<String> STAGING_ENV = ImmutableSet.of("Dev", "Feature", "Staging", "QA");

    private static final String EBAY_AUTH_TOKEN_START = "<eBayAuthToken>";
    private static final String EBAY_AUTH_TOKEN_END = "</eBayAuthToken>";
    private static final String USERNAME_START = "<username>";
    private static final String USERNAME_END = "</username>";

    @Inject
    private Environment environment;

    @Inject
    private IMetadataCoreRegistry metadataCoreRegistry;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        CustomHttpRequestWrapper requestWrapper = new CustomHttpRequestWrapper((HttpServletRequest) request);
        String body = extractRequestBody(requestWrapper);
        CalLogger.info("SOAStagingAuthFilter request body", body);
        if (isIAFTokenInHeader(requestWrapper)
                || !shouldAuthByUsername()) {
            // preprod, prod and sandbox will skip this filter
            chain.doFilter(req, response);
            return;
        }
        // only dev, feature and staging pools are qualified to authorize without auth token
        if (StringUtils.isBlank(body)) {
            CalLogger.info("SOAStagingAuthFilter", "blank request body, unable to fetch username");
            chain.doFilter(req, response);
            return;
        }
        final long stagingAuthFilterStartTime = getCurrentTime();
        final long parsingInputStartTime = getCurrentTime();
        String username = fetchCredential(body, USERNAME_START, USERNAME_END);
        String bodyAuthToken = fetchCredential(body, EBAY_AUTH_TOKEN_START, EBAY_AUTH_TOKEN_END);
        CalLogger.debug("parsing input", "parsing input time = "
                + getTimeDiff(parsingInputStartTime) + " ms.");
        if (bodyAuthToken != null) {
            // if request body has token then skip filter
            chain.doFilter(req, response);
            return;
        }
        logger.info("Generate IAF token by username and password");
        String consumerId = metadataCoreRegistry.getAppMetadata().getAppId();
        CalLogger.debug("consumerId", consumerId);

        final long loginTokenStartTime = getCurrentTime();
        String loginToken = LoginHelper.getLoginToken(consumerId);
        CalLogger.debug("loginToken", loginToken);
        CalLogger.debug("loginToken", "loginToken fetch time = "
                + getTimeDiff(loginTokenStartTime) + " ms.");
        String userId = fetchUserId(username);
        CalLogger.debug("userId", userId);

        final long iafTokenStartTime = getCurrentTime();
        String iafToken = IAFHelper.getInstance().getUserIAFToken(userId, loginToken, consumerId);
        CalLogger.debug("iafToken", iafToken);
        CalLogger.debug("iafToken", "iafToken fetch time = "
                + getTimeDiff(iafTokenStartTime) + " ms.");
        if (iafToken != null) {
            requestWrapper.addHeader(SOAHeaders.SECURE_EBAY_API_IAFTOKEN, iafToken);
        }
        CalLogger.debug("SOAStagingAuthFilter", "total process time = "
                + getTimeDiff(stagingAuthFilterStartTime)
                + " ms");
        chain.doFilter(requestWrapper, response);
    }

    private String fetchCredential(String target, String startToken, String endToken) {
        int start = target.indexOf(startToken);
        int end = target.indexOf(endToken);
        if (start + startToken.length() < end) {
            return target.substring(start + startToken.length(), end);
        }
        return null;
    }

    private String fetchUserId(String username) {
        GingerClientRequest<String> request = new GingerClientRequest<>();
        request.setRequest(username);
        GingerClientResponse<UserIdLookupResponse> gingerResponse = new UserLookupClient().getGingerResponse(request);
        if (GingerResponseType.FAILURE == gingerResponse.getResponseType()
                || gingerResponse.getResponse() == null
                || gingerResponse.getResponse().internalId == null) {
            CalLogger.error("Error when fetch user id from username", "username=" + username);
            return null;
        }
        return gingerResponse.getResponse().internalId.toString();
    }

    private String extractRequestBody(HttpServletRequest request) {
        // https://stackoverflow.com/a/18632784
        Scanner s = null;
        try {
            s = new Scanner(request.getInputStream(), "UTF-8").useDelimiter("\\A");
        } catch (IOException e) {
            logger.error("Error when Extract request body ", e);
            CalLogger.error("Error when Extract request body ", ExceptionUtils.getStackTrace(e));
        }
        if (s == null) {
            return "";
        }
        return s.hasNext() ? s.next() : "";
    }

    private boolean shouldAuthByUsername() {
        CalLogger.debug("Environment", Arrays.toString(this.environment.getActiveProfiles()));
        return Arrays.stream(this.environment.getActiveProfiles()).anyMatch(STAGING_ENV::contains);
    }

    private boolean isIAFTokenInHeader(CustomHttpRequestWrapper httpBodyRequestWrapper) {
        return httpBodyRequestWrapper.getHeader(SOAHeaders.SECURE_EBAY_API_IAFTOKEN) != null
                || httpBodyRequestWrapper.getHeader(SOAHeaders.SECURE_EBAY_API_IAFTOKEN.toLowerCase(Locale.US)) != null;
    }

    private long getCurrentTime() {
        return System.currentTimeMillis();
    }

    private long getTimeDiff(final long startTime) {
        return System.currentTimeMillis() - startTime;
    }

}
