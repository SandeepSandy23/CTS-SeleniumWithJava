package com.ebay.app.apisellingextsvc;

import com.ebay.com.google.common.collect.ImmutableList;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.ebay.soaframework.spf.pipeline.SPFServlet;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@SpringBootApplication
public class ApiSellingExtsvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiSellingExtsvcApplication.class, args);
	}

	@Bean
	public ServletRegistrationBean<SPFServlet> soaProviderServlet() {
		ServletRegistrationBean<SPFServlet> registrationBean = new ServletRegistrationBean<>();
		registrationBean.addUrlMappings(ImmutableList.of("/ws/api.dll/*", "/wsapi/*", "/ws/websvc/eBayAPI/*",
														 "/ws/spf/*").stream()
													 .toArray(String[]::new));
		registrationBean.setServlet(new SPFServlet());
		registrationBean.addInitParameter("SOA_ADMIN_NAME", "TradingAPIService");

		return registrationBean;
	}

	@Bean(name = "apisellingExecutor")
	public Executor getAsyncExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(400);
		executor.setMaxPoolSize(600);
		executor.setQueueCapacity(1000);
		executor.setThreadNamePrefix("apisellingExecutor-");
		executor.initialize();
		return executor;
	}
	
}
