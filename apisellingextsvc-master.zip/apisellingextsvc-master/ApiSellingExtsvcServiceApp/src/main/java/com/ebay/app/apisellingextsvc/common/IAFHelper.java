package com.ebay.app.apisellingextsvc.common;

import com.ebay.marketplace.iaf.v1.services.*;
import com.ebay.marketplace.services.ErrorData;
import com.ebay.marketplace.services.iafservice.iafservice.gen.SharedIAFServiceConsumer;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.ebay.soaframework.common.types.SOAHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class IAFHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(IAFHelper.class);

    private static final String EBAYAPP = "EBAYAPP";

    private static IAFHelper iafHelper;

    private IAFHelper() {
    }

    public static IAFHelper getInstance() {
        if (iafHelper == null) {
            iafHelper = new IAFHelper();
        }
        return iafHelper;
    }

    public String getUserIAFToken(String userId, String loginToken, String consumerId) {

        String iafToken = null;
        try {
            RequestSecurityTokenRequest rstRequest = new RequestSecurityTokenRequest();
            SharedIAFServiceConsumer sharedIAFServiceConsumer = getIAFConsumer(loginToken);
            Subject sub = prepareSubject(consumerId);
            sub.getIdentifier().setImmutableId(userId);
            rstRequest.setSubject(sub);
            RequestSecurityTokenResponse rstresponse = sharedIAFServiceConsumer.requestSecurityToken(rstRequest);
            if (rstresponse.getErrorMessage() != null) {
                List<ErrorData> eds = rstresponse.getErrorMessage().getError();
                for (ErrorData ed : eds) {
                    throw new Exception(ed.getMessage());
                }
            } else {
                SecurityToken stoken = rstresponse.getSecurityToken();
                if (stoken != null) {
                    iafToken = stoken.getToken();
                }
            }

        } catch (Exception ex) {
            LOGGER.error("Error fetching IAF token for " + userId + " " + ex.getMessage());
        }
        return iafToken;
    }


    private SharedIAFServiceConsumer getIAFConsumer(String loginToken) throws ServiceException {
        SharedIAFServiceConsumer iafConsumer = new SharedIAFServiceConsumer("IAFServiceClient", "staging");
        iafConsumer.getService().setSessionTransportHeader(SOAHeaders.AUTH_IAFTOKEN, loginToken);
        return iafConsumer;
    }

    static Subject prepareSubject(String name) {
        Identifier ident = new Identifier();
        ident.setFormat("USERNAME");
        ident.setValue(name);
        Subject sub = new Subject();
        sub.setIdentifier(ident);
        sub.setIdentityDomain(EBAYAPP);
        return sub;
    }


}