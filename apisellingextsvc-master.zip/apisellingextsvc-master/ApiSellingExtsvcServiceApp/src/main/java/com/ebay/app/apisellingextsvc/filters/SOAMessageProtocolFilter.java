package com.ebay.app.apisellingextsvc.filters;

import com.ebay.app.apisellingextsvc.common.CustomHttpRequestWrapper;
import com.ebay.soaframework.common.types.SOAConstants;
import com.ebay.soaframework.common.types.SOAHeaders;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Component
@Order(9)
public class SOAMessageProtocolFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(SOAMessageProtocolFilter.class);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        // HttpServletResponse res = (HttpServletResponse) response;

        String messageProtocol = req.getHeader(SOAHeaders.MESSAGE_PROTOCOL);
        if (StringUtils.isNotBlank(messageProtocol)) {
            chain.doFilter(req, response);
            return;
        }
        String soapAction = req.getHeader(HTTPConstants.HEADER_SOAP_ACTION);
        if (soapAction != null && StringUtils.isNotBlank(req.getParameter("callname"))) {
            CustomHttpRequestWrapper requestWrapper = new CustomHttpRequestWrapper(req);
            requestWrapper.addHeader(SOAHeaders.MESSAGE_PROTOCOL, SOAConstants.MSG_PROTOCOL_SOAP_11);
            logger.info("Added header " + SOAHeaders.MESSAGE_PROTOCOL + " value " + SOAConstants.MSG_PROTOCOL_SOAP_11);
            chain.doFilter(requestWrapper, response);
        } else {
            chain.doFilter(req, response);
        }

    }
}
