package com.ebay.app.apisellingextsvc.common;

import com.ebay.iaf.service.client.standard.IAFServiceStdClient;
import com.ebay.iaf.service.client.standard.IAFServiceStdClient.Endpoint;
import com.ebay.marketplace.iaf.v1.services.iafservice.client.*;
import com.ebay.security.exceptions.EsamsException;
import com.ebay.security.holders.NonKeyHolder;
import com.ebay.security.nameservice.NameService;
import com.ebay.security.nameservice.NameServiceFactory;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class LoginHelper {

    private static final Logger logger = LoggerFactory.getLogger(LoginHelper.class);
    private static final String SECRET_PATH = "/orderextsvc/staging_secret";
    private static final String ENV = "staging";

    public static String getLoginToken(String consumerId) {
        try {
            IAFServiceStdClient client = new IAFServiceStdClient(Endpoint.GENERAL, consumerId, ENV);
            //Prepare loginRequest
            LoginRequest request = new LoginRequest();
            Subject sub = prepareSubject("EBAYAPP", consumerId);
            request.setSubject(sub);
            Secret secret = prepareSecret(getSecretFromFidelius());

            request.getSecret().add(secret);
            LoginResponse response = client.login(request);

            // If an error happens during the call, it will sent back in the response and securityToken will be null
            if (response.getErrorMessage() != null) {
                logger.error("IAFService Login Token fetch failed for SellerRegistrationService");
                throw new ServiceException(response.getErrorMessage().getError());
            }
            SecurityToken secToken = response.getSecurityToken();
            if (secToken != null) {
                return secToken.getToken();
            }
        } catch (Exception e) {
            logger.error("Error when generate staging log in token", e);
            CalLogger.error("Error when generate staging log in token", ExceptionUtils.getStackTrace(e));
        }
        return null;
    }

    /**
     * For Ebay security standard, do not hardcode pool secret or in any unsecured system. Recommend to put secret in Fidelius
     * <p>
     * <p>
     * 1. Request access to orderextsvc pool
     * <a href="https://wiki.vip.corp.ebay.com/display/PLATSEC/Security+Assets+Management+Self+Service+Portal">Request fidelius access</a>
     * <p>
     * 2. Get secret from GET http://clientregistry.qa.ebay.com/oauthclnt/core/v1/detail/${consumerid} (ignore if you don't need this)
     * <p>
     * 3. add encodedSecret = Base64.encode(String(secret).getByte) into Fidelius (dev, staging, qa - qa means feature pool).
     * <a href="https://sam.muse.vip.ebay.com/root/orderextsvc/dev">orderextsvc fidelius link</a>
     * <p>
     * 4. Fidelius will ask you to input name and value. put encodedSecret to value, and any name
     * <p>
     * 5. after adding the name/value, click "copy path", this is the path for you to get value.
     * <p>
     * 6 to Get value, use the following code import com.ebay.security.nameservice.NameServiceFactory; NonKeyHolder nonKeyHolder =
     * NameServiceFactory.getInstance().getNonKey(${path}, -1) String value = new String(Base64.decode(nonKeyHolder.getNonKey()));
     *
     * @return secret
     */
    private static String getSecretFromFidelius() {
        try {
            NonKeyHolder nonKeyHolder = NameServiceFactory.getInstance()
                    .getNonKey(SECRET_PATH, NameService.VERSION_LAST_ENABLED);
            return new String(Base64.getDecoder().decode(nonKeyHolder.getNonKey().getBytes(StandardCharsets.UTF_8)), Charset.defaultCharset());
        } catch (EsamsException e) {
            logger.error("Error when Get secret from Fidelius ", e);
            CalLogger.error("Error when Get secret from Fidelius ", ExceptionUtils.getStackTrace(e));

        }
        return null;
    }

    private static Secret prepareSecret(String password) {
        Secret secret = new Secret();
        secret.setEncoding("DEFAULT");
        secret.setType("PASSWORD");
        secret.setValue(password);
        return secret;
    }

    private static Subject prepareSubject(String domain, String id) {
        Identifier ident = new Identifier();
        ident.setFormat("USERNAME");
        ident.setValue(id);
        Subject sub = new Subject();
        sub.setIdentifier(ident);
        sub.setIdentityDomain(domain);
        return sub;
    }
}
