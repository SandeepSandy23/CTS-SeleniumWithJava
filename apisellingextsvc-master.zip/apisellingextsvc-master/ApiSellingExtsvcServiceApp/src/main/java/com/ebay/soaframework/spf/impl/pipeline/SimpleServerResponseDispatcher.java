package com.ebay.soaframework.spf.impl.pipeline;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.ebay.soaframework.common.impl.internal.monitoring.SystemMetricDefs;
import com.ebay.soaframework.common.impl.monitoring.storage.SOAServerMetrics;
import com.ebay.soaframework.common.impl.pipeline.SimpleTransportDispatcher;
import com.ebay.soaframework.common.pipeline.Message;
import com.ebay.soaframework.common.pipeline.MessageContext;
import com.ebay.soaframework.spf.impl.internal.pipeline.ServerMessageContextImpl;

import java.util.concurrent.Future;

/**
 * Override jar file in order to show request data during outboundMessageImpl
 */
public class SimpleServerResponseDispatcher extends SimpleTransportDispatcher {

	public SimpleServerResponseDispatcher(boolean shouldCleanupData) {
		// make it false in order to pass request data. We need output select in request data in order to partial serialize.
		super(false);
		CalLogger.info("SimpleServerResponseDispatcher", "Run SimpleServerResponseDispatcher");
	}

	@Override
	protected void invokeTransport(MessageContext ctx, Object transportData) throws ServiceException {
		ServerMessageContextImpl serverCtx = (ServerMessageContextImpl) ctx;
		Message rspMessage = serverCtx.getResponseMessage();
		rspMessage.setTransportData(transportData);

		long startTime = System.nanoTime();
		try {
			// TODO - server side may need to pass transport options also?
			serverCtx.getTransport().invoke(rspMessage, null);
		} finally {
			long duration = System.nanoTime() - startTime;
			serverCtx.updateSvcAndOpMetric(SystemMetricDefs.OP_TIME_RESP_DISPATCH, startTime, duration);

			serverCtx.updateSOAMetrics(SOAServerMetrics.OP_TIME_RESP_DISPATCH, duration);
		}
	}

	@Override
	protected void doPreTransportMapping(MessageContext ctx) throws ServiceException {
		// noop
	}

	@Override
	protected Future<?> invokeAsyncTransport(MessageContext ctx, Object transportData) throws ServiceException {
		throw new UnsupportedOperationException("SimpleServerResponseDispatcher does not support invokeAsyncTransport");
	}

	@Override
	protected void retrieveTransport(MessageContext ctx, Future<?> futureResp) throws ServiceException {
		throw new UnsupportedOperationException("SimpleServerResponseDispatcher does not support retrieveTransport");
	}
}
