package com.ebay.lib.lasng.mapper;

import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.ItemVariation;
import com.ebay.cos.type.v3.core.listing.PriceSettings;
import com.ebay.cos.type.v3.core.listing.QuantityAndAvailabilityByLogisticsPlans;
import com.ebay.cos.type.v3.core.listing.classification.RankedSellerAspect;
import com.ebay.cos.type.v3.core.listing.classification.RankedSellerAspectValue;
import com.ebay.cos.type.v3.core.listing.tradingSummary.ItemVariationTradingSummary;
import com.ebay.lib.lasng.model.*;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

/**
 * Clone from com.ebay.lib.listingAdapter-0.6.jar to address few missing mappings (aspects & variationSKU). 
 * Also it creates variations eventhough the listing does not belong to variation type.
 *
 */
public class ItemVariationsBuilder {
    public ItemVariationsBuilder() {
    }

    public static List<ItemVariation> build(ListingActivity listingActivity) {
        if (Optional.ofNullable(listingActivity.getCore().getHasMultipleVariations()).isPresent() && listingActivity.getCore().getHasMultipleVariations()) {
            List<VariationInfo> variations = listingActivity.getCore().getVariations();
            if (!Optional.ofNullable(variations).isPresent()) {
                return null;
            } else {
                List<ItemVariation> itemVariations = new ArrayList(variations.size());
                Iterator var10 = variations.iterator();

                while(var10.hasNext()) {
                    VariationInfo variationInfo = (VariationInfo)var10.next();
                    ItemVariation itemVariation = new ItemVariation();
                    itemVariation.setVariationId(variationInfo.getVariationId());
                    itemVariation.setPriceSettings((PriceSettings)Optional.ofNullable(variationInfo.getPrice()).map((price) -> {
                        return toPriceSettings(listingActivity, price);
                    }).orElse(null));
                    QuantityAndAvailabilityByLogisticsPlans logisticsPlans = LogisticsPlansBuilder.build(variationInfo);
                    itemVariation.setQuantityAndAvailabilityByLogisticsPlans(Collections.singletonList(logisticsPlans));
                    itemVariation.setQuantityAvailabilityByLogisticPlans(Collections.singletonList(logisticsPlans));
                    // Workaround to fix missing mappings - Start
                    itemVariation.setAspects(getVariationSpecifics(variationInfo));
                    itemVariation.setVariationSKU(variationInfo.getSku());
                    // Workaround to fix missing mappings - End
                    itemVariations.add(itemVariation);
                }

                return Collections.unmodifiableList(itemVariations);
            }
        } else {
        	//TODO: Needs to be discussed with LAS team & addressed. The below logic creates ItemVariation even though the listing does not have variations.
            ItemVariation itemVariation = new ItemVariation();
            itemVariation.setPriceSettings((PriceSettings)Optional.ofNullable(listingActivity.getCore().getPrice()).map(ItemVariationsBuilder::toPriceSettings).orElse(null));
            ItemVariationTradingSummary itemVariationTradingSummary = new ItemVariationTradingSummary();
            if (Optional.ofNullable(listingActivity.getCore()).isPresent()) {
                PricingInfo pricingInfo = listingActivity.getCore().getPrice();
                if (Optional.ofNullable(pricingInfo).isPresent()) {
                    itemVariationTradingSummary.setCurrentBidPrice(AmountBuilder.build(pricingInfo.getCurrency(), pricingInfo.getCurrentPrice()));
                }
            }

            if (Optional.ofNullable(listingActivity.getAdditionalAttributes()).isPresent() && Optional.ofNullable(listingActivity.getAdditionalAttributes().getBuyingInfo()).isPresent()) {
                BuyingInfo buyingInfo = listingActivity.getAdditionalAttributes().getBuyingInfo();
                itemVariationTradingSummary.setWatchCount(buyingInfo.getWatchCount());
                itemVariationTradingSummary.setBidCount(buyingInfo.getBidCount());
                int pendingOffers = Optional.ofNullable(buyingInfo.getOffers()).isPresent() ? buyingInfo.getOffers().getPendingOfferCount() : 0;
                itemVariationTradingSummary.setPendingOfferCount(pendingOffers);
            }

            itemVariation.setItemVariationTradingSummary(itemVariationTradingSummary);
            return Collections.singletonList(itemVariation);
        }
    }

    private static PriceSettings toPriceSettings(ListingActivity listingActivity, Double variationPrice) {
        PriceSettings priceSettings = new PriceSettings();
        priceSettings.setLowestFixedPrice(AmountBuilder.build(listingActivity.getCore().getPrice().getCurrency(), variationPrice));
        return priceSettings;
    }

    private static PriceSettings toPriceSettings(PricingInfo pricingInfo) {
        PriceSettings priceSettings = new PriceSettings();
        priceSettings.setAuctionReservePrice(AmountBuilder.build(pricingInfo.getCurrency(), pricingInfo.getReservePrice()));
        priceSettings.setStartingBidPrice(AmountBuilder.build(pricingInfo.getCurrency(), pricingInfo.getStartPrice()));
        priceSettings.setLowestFixedPrice(AmountBuilder.build(pricingInfo.getCurrency(), pricingInfo.getBuyItNowPrice()));
        return priceSettings;
    }

    private static List<RankedSellerAspect> getVariationSpecifics(VariationInfo variationInfo) {
        List<RankedSellerAspect> variationAspectsList = null;
        if (CollectionUtils.isNotEmpty(variationInfo.getVariationSpecifics())) {
            variationAspectsList = new ArrayList<>();
            for (KeyValue keyValue : variationInfo.getVariationSpecifics()) {
                RankedSellerAspect variationAspect = new RankedSellerAspect();
                Text variationAspectKey = new Text();
                variationAspectKey.setContent(keyValue.getKey());
                List<RankedSellerAspectValue> variationAspectValuesList = new ArrayList<>();
                for (String value : keyValue.getValue()) {
                    RankedSellerAspectValue rankedSellerAspectValue = new RankedSellerAspectValue();
                    Text variationAspectValue = new Text();
                    variationAspectValue.setContent(value);
                    rankedSellerAspectValue.setValue(variationAspectValue);
                    variationAspectValuesList.add(rankedSellerAspectValue);
                }
                variationAspect.setAspectValues(variationAspectValuesList);
                variationAspect.setName(variationAspectKey);
                variationAspectsList.add(variationAspect);
            }
        }
        return variationAspectsList;
    }
}
