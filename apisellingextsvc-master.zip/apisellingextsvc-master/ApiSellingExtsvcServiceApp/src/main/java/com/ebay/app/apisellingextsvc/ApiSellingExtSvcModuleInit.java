package com.ebay.app.apisellingextsvc;

import com.ebay.globalenv.policy.PolicyConfig;
import com.ebay.kernel.initialization.BaseInitializationManager;
import com.ebay.kernel.initialization.ModuleInterface;
import com.ebay.raptor.kernel.init.BaseDIAwareModule;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

@Configuration
@DependsOn("com.ebay.raptor.dal.autoconfigure.DalAutoConfigure")
public class ApiSellingExtSvcModuleInit extends BaseDIAwareModule {

    private static final ApiSellingExtSvcModuleInit module = new ApiSellingExtSvcModuleInit();

    public ApiSellingExtSvcModuleInit() {
        super(new InitializationManager());
    }

    public static ModuleInterface getInstance() {
        return module;
    }

    private static class InitializationManager extends BaseInitializationManager {

        private static final ModuleInterface[] DEPENDENT_MODULES = {};

        InitializationManager() {
            super(DEPENDENT_MODULES);
            getInitializationHelper().add(PolicyConfig.getInitializable());
        }
    }
}
