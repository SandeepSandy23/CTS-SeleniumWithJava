package com.ebay.app.apisellingextsvc;


import com.ebay.app.apisellingextsvc.filters.SOAMessageProtocolFilter;
import com.ebay.app.apisellingextsvc.filters.SOAOperationFilter;
import com.ebay.app.apisellingextsvc.filters.SOAStagingAuthFilter;
import com.ebay.app.apisellingextsvc.impl.RaptorApplicationContext;
import com.ebay.com.google.common.collect.ImmutableList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class ApiSellingExtsvcFilterConfiguration {


    private ApplicationContextProvider appCtxProvider;

    @Autowired
    public void setAppCtxProvider(ApplicationContextProvider appCtxProvider) {
        this.appCtxProvider = appCtxProvider;
    }

    @Bean
    public FilterRegistrationBean<SOAOperationFilter> httpFilter() {
        RaptorApplicationContext.setContext(appCtxProvider.getApplicationContext());
        FilterRegistrationBean<SOAOperationFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.addUrlPatterns(ImmutableList.of("/ws/api.dll/*", "/wsapi/*", "/ws/websvc/eBayAPI/*",
                                                         "/ws/spf/*").stream()
                                                     .toArray(String[]::new));
        registrationBean.setFilter(new SOAOperationFilter());

        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean<SOAMessageProtocolFilter> messageFilter() {
        RaptorApplicationContext.setContext(appCtxProvider.getApplicationContext());
        FilterRegistrationBean<SOAMessageProtocolFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.addUrlPatterns(ImmutableList.of("/ws/api.dll/*", "/wsapi/*", "/ws/websvc/eBayAPI/*",
                                                         "/ws/spf/*").stream()
                                                     .toArray(String[]::new));
        registrationBean.setFilter(new SOAMessageProtocolFilter());

        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean<SOAStagingAuthFilter> stagingAuthFilter() {
        RaptorApplicationContext.setContext(appCtxProvider.getApplicationContext());
        FilterRegistrationBean<SOAStagingAuthFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.addUrlPatterns(ImmutableList.of("/ws/api.dll/*", "/wsapi/*", "/ws/websvc/eBayAPI/*",
                        "/ws/spf/*").stream()
                .toArray(String[]::new));
        registrationBean.setFilter(new SOAStagingAuthFilter());

        return registrationBean;
    }

}
