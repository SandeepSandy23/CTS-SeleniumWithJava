package com.ebay.app.apisellingextsvc.filters;

import com.ebay.app.apisellingextsvc.common.CustomHttpRequestWrapper;
import com.ebay.app.apisellingextsvc.impl.common.SOAOperationEnum;
import com.ebay.soaframework.common.types.SOAHeaders;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Component
@Order(10)
public class SOAOperationFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(SOAOperationFilter.class);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        HttpServletRequest req = (HttpServletRequest) request;

        String operationName = req.getParameter(SOAHeaders.SERVICE_OPERATION_NAME);
        if (StringUtils.isNotBlank(operationName)) {
            chain.doFilter(req, response);
            return;
        }

        String callName = req.getParameter("callname");
        String siteId = req.getParameter("siteid");
        callName = callName == null ? req.getHeader("X-EBAY-API-CALL-NAME") : callName;
        if (callName == null) {
            chain.doFilter(req, response);
            return;
        }
        CustomHttpRequestWrapper requestWrapper = new CustomHttpRequestWrapper(req);
        try {
            SOAOperationEnum operationEnum = SOAOperationEnum.valueOf(callName);
            requestWrapper.addHeader(SOAHeaders.SERVICE_OPERATION_NAME, operationEnum.getSoaOperationName());
            if (req.getHeader("X-EBAY-API-SITEID") == null && siteId != null) {
                requestWrapper.addHeader("X-EBAY-API-SITEID", siteId);
            }

        } catch (IllegalArgumentException e) {
            logger.warn("Unable to map callName to SOA Operation Name ", e);
        } catch (Exception t) {
            logger.error("UnExpected Error when mapping callName to SOA Operation Name ", t);
        }
        chain.doFilter(requestWrapper, response);
    }
}
