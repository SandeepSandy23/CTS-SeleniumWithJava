package com.ebay.app.apisellingextsvc.impl;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import com.ebay.app.apisellingextsvc.application.common.request.GetSellerTransactionsRequest;
import com.ebay.app.apisellingextsvc.application.common.response.GetMyeBaySellingResponse;
import com.ebay.app.apisellingextsvc.application.common.response.GetSellerListResponse;
import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.exception.ApplicationException;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfig;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.EnvironmentContext;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.handlers.GetMyeBaySellingHandler;
import com.ebay.app.apisellingextsvc.handlers.GetSellerTransactionsHandler;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.app.apisellingextsvc.utils.IConfigHandler;
import com.ebay.app.apisellingextsvc.utils.SoapUtil;
import com.ebay.app.services.apisellingextsvc.TradingAPIService;
import com.ebay.platform.raptor.cosadaptor.exceptions.TokenCreationException;
import com.ebay.platform.raptor.cosadaptor.token.ISecureTokenManager;
import com.ebay.raptor.content.api.IContentBuilderFactory;
import com.ebay.raptorio.globalconfig.impl.GlobalConfigPropertySource;
import ebay.apis.eblbasecomponents.GetMyeBaySellingRequestType;
import ebay.apis.eblbasecomponents.GetSellerListRequestType;
import ebay.apis.eblbasecomponents.GetSellerTransactionsRequestType;
import io.opentelemetry.api.trace.Tracer;
import io.opentracing.util.GlobalTracer;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.StandardServletEnvironment;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Context;
import java.util.concurrent.Executor;

@Component
public class TradingAPIServiceImpl implements TradingAPIService {
	@Inject
	private Environment environment;

	@Context
	ContainerRequestContext containerRequestContext;

	@Inject
	private IContentBuilderFactory contentBuilderFactory;

	@Override
	public GetSellerListResponse getSellerList(GetSellerListRequestType getSellerListRequest) {
			return null;
	}

	private ApiSellingExtSvcConfigValues config;

	private TracerContext tracerContext;
	@Inject
	Tracer openTeleTracer;

	io.opentracing.Tracer openTracingTracer = GlobalTracer.get();

	@Inject
	ISecureTokenManager tokenManager;

	@Inject
	@Named("apisellingExecutor")
	Executor executor;

	@Override
	public GetSellerTransactionsResponse getSellerTransactions(
			GetSellerTransactionsRequestType getSellerTransactionsRequest) {
		config =createConfigValue();
		tracerContext = new TracerContext(openTeleTracer, openTeleTracer.spanBuilder("getSellerTransactionsSpan").startSpan(), openTracingTracer, GlobalTracer.get().buildSpan("getSellerTransactionsSpan").start());
		try (
		      GetSellerTransactionsRequest request = new GetSellerTransactionsRequest(getSellerTransactionsRequest,
																				   SoapUtil.getAllHeaders(),
																				   SoapUtil.getUser(),
																				   contentBuilderFactory,
																				   config,
																				   createEnvironmentCtx(), tracerContext )) {

			return GetSellerTransactionsHandler.getResponse(request,executor);
		} catch (ApplicationException t) {
			throw t;
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			tracerContext.getOpenTeleParentSpan().end();
			tracerContext.getOpenTracingParentSpan().finish();
		}
	}

	@Override
	public GetMyeBaySellingResponse getMyeBaySelling(GetMyeBaySellingRequestType getMyeBaySellingRequest) {
		config =createConfigValue();
		tracerContext = new TracerContext(openTeleTracer,
										  openTeleTracer.spanBuilder("getMyebaySellingSpan").startSpan(), openTracingTracer, GlobalTracer.get().buildSpan("getMyebaySellingSpan").start());
		try (GetMyeBaySellingRequest request = new GetMyeBaySellingRequest(getMyeBaySellingRequest,
																		   SoapUtil.getAllHeaders(),
																		   SoapUtil.getUser(), contentBuilderFactory,
																		   config, createEnvironmentCtx(),
																		   tracerContext, executor, tokenManager)) {
			return GetMyeBaySellingHandler.getResponse(request, executor);
		} catch (ApplicationException t) {
			throw t;
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			tracerContext.getOpenTeleParentSpan().end();
			tracerContext.getOpenTracingParentSpan().finish();
		}
	}

	private GlobalConfigPropertySource getGlobalConfig() {
		return (GlobalConfigPropertySource) ((StandardServletEnvironment) environment)
				.getPropertySources().get(ApiSellingExtSvcConstants.GLOBAL_CONFIG_PROPERTY);
	}

	public ApiSellingExtSvcConfigValues createConfigValue() {
		String siteIdStr = HeaderUtil.getSiteId(SoapUtil.getAllHeaders());
		int siteId = 0;
		if (NumberUtils.isDigits(siteIdStr)) {
			siteId = NumberUtils.createInteger(siteIdStr);
		}
		IConfigHandler configHandler = ApiSellingExtSvcConfig.getConfig(getGlobalConfig(), siteId);
		return new ApiSellingExtSvcConfigValues(configHandler);
	}

	private EnvironmentContext createEnvironmentCtx() {
		String[] activeProfiles = environment.getActiveProfiles();
		if (activeProfiles.length > 0) {
			return EnvironmentContext.create(activeProfiles[0]);
		}
		return EnvironmentContext.create(EnvironmentContext.PROD);
	}
}
