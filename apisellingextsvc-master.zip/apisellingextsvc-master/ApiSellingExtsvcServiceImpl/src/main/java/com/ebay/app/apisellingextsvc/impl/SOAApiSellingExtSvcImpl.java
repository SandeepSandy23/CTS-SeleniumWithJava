package com.ebay.app.apisellingextsvc.impl;

import com.ebay.app.services.apisellingextsvc.TradingAPIService;
import ebay.apis.eblbasecomponents.*;
import org.springframework.stereotype.Component;

@Component
public class SOAApiSellingExtSvcImpl implements TradingAPIService {

    private final TradingAPIService service;

    public SOAApiSellingExtSvcImpl() {
        service = RaptorApplicationContext.getContext().getBean(TradingAPIServiceImpl.class);
    }

    @Override
    public GetSellerTransactionsResponseType getSellerTransactions(GetSellerTransactionsRequestType request) {
        return service.getSellerTransactions(request);
    }

    @Override
    public GetMyeBaySellingResponseType getMyeBaySelling(GetMyeBaySellingRequestType getMyeBaySellingRequest) {
        return service.getMyeBaySelling(getMyeBaySellingRequest);
    }

    @Override
    public GetSellerListResponseType getSellerList(GetSellerListRequestType getSellerListRequest) {
        return null;
    }
}
