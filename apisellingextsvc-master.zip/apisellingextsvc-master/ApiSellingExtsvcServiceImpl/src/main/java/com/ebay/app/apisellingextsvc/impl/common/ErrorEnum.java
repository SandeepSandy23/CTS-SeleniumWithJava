package com.ebay.app.apisellingextsvc.impl.common;

public enum ErrorEnum {

    TOKEN_EXPIRED("932", "iaftoken:IAF Token Validation Failed : Token Expired"),
    TOKEN_INVALID("931", "iaftoken:IAF Token Validation Failed : Unable to verify the signature of the token.");

    private final String errorCode;

    private final String errorMessage;

    ErrorEnum(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

}
