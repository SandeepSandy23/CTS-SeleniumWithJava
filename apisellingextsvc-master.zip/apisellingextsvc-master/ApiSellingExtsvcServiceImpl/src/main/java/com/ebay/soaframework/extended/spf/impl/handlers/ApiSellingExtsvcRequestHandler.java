package com.ebay.soaframework.extended.spf.impl.handlers;

import com.ebay.binding.objectnode.ObjectNode;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.ebay.soaframework.common.impl.handlers.BaseHandler;
import com.ebay.soaframework.common.pipeline.Message;
import com.ebay.soaframework.common.pipeline.MessageContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.stream.XMLStreamException;
import java.util.Collection;


/**
 * API support token in request body also. in that case, Read Token from requestbody and set it to header
 */
public class ApiSellingExtsvcRequestHandler extends BaseHandler {

	private static final Logger logger = LoggerFactory.getLogger(ApiSellingExtsvcRequestHandler.class);

	@Override
	public void invoke(MessageContext ctx) throws ServiceException {
		Message requestMsg = ctx.getRequestMessage();
		if (requestMsg == null) {
			return;
		}
		Collection<ObjectNode> messageHeaders = ctx.getRequestMessage().getMessageHeaders();
		if (messageHeaders != null) {
			try {
				messageHeaders.forEach(objectNode -> {
					try {
						populateIAFToken(ctx, objectNode);
					} catch (Exception e) {
						logger.error("Unable to extract messageHeaders Child Nodes ", e);
					}
				});

			} catch (Exception t) {
				logger.error("Exception when trying to parse messageHeaders ", t);
			}
		}

		ObjectNode messageBody = ctx.getRequestMessage().getMessageBody();
		if (messageBody != null) {
			try {
				messageBody.getChildNodes().forEach(
						childNode -> {
							try {
								childNode.getChildNodes().forEach(
										innerNode -> {
											if (innerNode.getNodeName().getLocalPart().equals("RequesterCredentials")) {
												try {
													populateIAFToken(ctx, innerNode);
												} catch (Exception e) {
													logger.error("Unable to extract eBayAuthToken ", e);
												}
											}
										}

								);
							} catch (Exception e) {
								logger.error("Unable to extract eBayAuthToken ", e);
							}
						});

			} catch (XMLStreamException e) {
				logger.error("XMLStreamException when trying to parse messageBody ", e);
			} catch (Exception t) {
				logger.error("UnException when trying to parse messageBody ", t);
			}
		}
	}

	private void populateIAFToken(MessageContext ctx, ObjectNode objectNode) throws XMLStreamException {
		objectNode.getChildNodes().forEach(child -> {
			if (child.getNodeName().getLocalPart().equals("eBayAuthToken")) {
				String token = String.valueOf(child.getNodeValue());
				try {
					ctx.getRequestMessage().setTransportHeader("X-EBAY-API-IAF-TOKEN", token);
				} catch (Exception e) {
					logger.error("Unable to extract eBayAuthToken ", e);
				}
			}
		});
	}
}