package com.ebay.soaframework.extended.spf.impl.handlers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfig;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.impl.RaptorApplicationContext;
import com.ebay.app.apisellingextsvc.impl.common.ReflectionHelper;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.app.apisellingextsvc.utils.IConfigHandler;
import com.ebay.app.apisellingextsvc.utils.SoapUtil;
import com.ebay.raptorio.globalconfig.impl.GlobalConfigPropertySource;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.ebay.soaframework.common.impl.handlers.BaseHandler;
import com.ebay.soaframework.common.pipeline.MessageContext;
import com.google.common.collect.ImmutableSet;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.StandardServletEnvironment;

import java.lang.reflect.Field;
import java.util.Set;

/**
 * Response pipeline handler to clear the service version string from the current service operation's context. This in turn will prevent the service
 * from emitting the version string in its response payload.
 *
 * <p>
 * To use this handler, add it to the service provider's response pipeline via ServiceConfig.xml, e.g.: *
 *
 * <pre>
 * &lt;response-handlers&gt;
 *     &lt;chain name="servicehandlers"&gt;
 *         &lt;handler name="ServiceVersionRemovalHandler" run-on-error="true"&gt;
 *             &lt;class-name&gt;
 *                 com.ebay.checkout.services.common.responsehandlers.ServiceVersionRemovalHandler
 *             &lt;/class-name&gt;
 *         &lt;/handler&gt;
 *     &lt;/chain&gt;
 * &lt;/response-handlers&gt;
 * </pre>
 * <p>
 * *
 *
 * @author kelim
 */
public class ServiceVersionRemovalHandler extends BaseHandler {
    private static final String SERVICE_VERSION_FIELD_NAME = "m_serviceVersion";

    private static final Set<String> OPERATIONS_TO_SKIP = ImmutableSet.of("getVersion");

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceVersionRemovalHandler.class);

    private ApiSellingExtSvcConfigValues config;

    /**
     * Invokes this pipeline handler.
     * <p>
     * This will clear the service version string (if any) from the provided MessageContext, unless the current service operation is among the
     * predefined list of operations which should be skipped.
     *
     * @param messageContext SOA context
     * @throws ServiceException If an error occurs during the handler processing
     */
    @Override
    public void invoke(MessageContext messageContext) throws ServiceException {
        ApplicationContext applicationContext = RaptorApplicationContext.getContext();
        config = createConfigValue(applicationContext, messageContext);
        try {
            if (shouldRemoveServiceVersion(messageContext) && config != null) {
                String serviceVersion = messageContext.getServiceVersion();
                if (serviceVersion != null) {
                    Field serviceVersionField = ReflectionHelper.getFieldFromClassHierarchy(messageContext.getClass(),
                            SERVICE_VERSION_FIELD_NAME);
                    serviceVersionField.set(messageContext, config.getServiceVersion());
                }
            }
        } catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException e) {
            LOGGER.error("Unable to get private Field " + SERVICE_VERSION_FIELD_NAME + " ", e);
        }
    }

    /**
     * Indicates whether the service version string should be removed for the current service operation.
     *
     * @param ctx SOA context
     * @return True if the service version string should be removed
     */
    private boolean shouldRemoveServiceVersion(MessageContext ctx) {
        return !OPERATIONS_TO_SKIP.contains(ctx.getOperationName());
    }

    private GlobalConfigPropertySource getGlobalConfig(ApplicationContext applicationContext) {
        return (GlobalConfigPropertySource) ((StandardServletEnvironment) applicationContext.getEnvironment())
                .getPropertySources().get(ApiSellingExtSvcConstants.GLOBAL_CONFIG_PROPERTY);
    }

    public ApiSellingExtSvcConfigValues createConfigValue(ApplicationContext applicationContext, MessageContext messageContext) {
        String siteIdStr = HeaderUtil.getSiteId(SoapUtil.getAllHeaders(messageContext));
        int siteId = 0;
        if (NumberUtils.isDigits(siteIdStr)) {
            siteId = NumberUtils.createInteger(siteIdStr);
        }

        IConfigHandler configHandler = ApiSellingExtSvcConfig.getConfig(getGlobalConfig(applicationContext), siteId);
        return new ApiSellingExtSvcConfigValues(configHandler);
    }
}
