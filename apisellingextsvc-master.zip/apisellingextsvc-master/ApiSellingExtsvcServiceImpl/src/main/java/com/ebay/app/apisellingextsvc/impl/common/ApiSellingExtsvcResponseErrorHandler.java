package com.ebay.app.apisellingextsvc.impl.common;

import com.ebay.soaframework.common.exceptions.ServiceException;
import com.ebay.soaframework.common.pipeline.MessageContext;
import com.ebay.soaframework.extended.spf.impl.handlers.ServiceResponseAuthErrorHandler;
import ebay.apis.eblbasecomponents.ErrorClassificationCodeType;
import ebay.apis.eblbasecomponents.ErrorType;
import ebay.apis.eblbasecomponents.SeverityCodeType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;


@Configuration
public class ApiSellingExtsvcResponseErrorHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceResponseAuthErrorHandler.class);

    public ErrorType populateErrorType(String errorParameter, MessageContext ctx) {

        String shortMessage = null;
        String longMessage = null;
        String errorCode = null;

        int siteId = 0;
        try {
            String siteIdHeaderValue = ctx.getRequestMessage().getTransportHeader("X-EBAY-API-SITEID");
            siteId = Integer.parseInt(siteIdHeaderValue);
        } catch (ServiceException e) {
            LOGGER.error("ServiceException which fetching siteId", e);
        }
        // todo error handling, and remove temporary ErrorEnum
        if (ErrorEnum.TOKEN_EXPIRED.getErrorMessage().equalsIgnoreCase(errorParameter)) {
            //TODO: populate content from content file
            shortMessage = "dummy short  message - IAF Token Expired ";
            longMessage = "dummy long message - IAF Token Expired";
            errorCode = ErrorEnum.TOKEN_EXPIRED.getErrorCode();

        } else if (ErrorEnum.TOKEN_INVALID.getErrorMessage().equalsIgnoreCase(errorParameter)
                || errorParameter.contains("IAF Token Validation Failed")
                || errorParameter.contains("Missing required credential for authn method")) {
            //TODO: populate content from content file
            shortMessage = "dummy short  message - IAF Token Validation Failed: ";
            longMessage = "dummy long message - IAF Token Validation Failed";
            errorCode = ErrorEnum.TOKEN_EXPIRED.getErrorCode();
        }

        ErrorType errorType = null;
        if (shortMessage != null) {
            errorType = populateErrorModel(shortMessage, longMessage, errorCode);
        }
        return errorType;
    }

    private ErrorType populateErrorModel(String shortMessage, String longMessage, String errorCode) {
        ErrorType errorType = new ErrorType();
        errorType.setSeverityCode(SeverityCodeType.ERROR);
        errorType.setShortMessage(shortMessage);
        errorType.setLongMessage(longMessage);
        errorType.setErrorCode(errorCode);
        errorType.setErrorClassification(ErrorClassificationCodeType.REQUEST_ERROR);
        return errorType;
    }


}
