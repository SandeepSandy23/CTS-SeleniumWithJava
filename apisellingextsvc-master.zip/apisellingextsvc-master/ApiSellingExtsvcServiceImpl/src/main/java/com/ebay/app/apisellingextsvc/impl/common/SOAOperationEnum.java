package com.ebay.app.apisellingextsvc.impl.common;

public enum SOAOperationEnum {


    GetSellerTransactions("getSellerTransactions"),
    GetMyeBaySelling("getMyeBaySelling");

    private final String soaOperationName;

    SOAOperationEnum(String soaOperationName) {
        this.soaOperationName = soaOperationName;
    }

    public String getSoaOperationName() {
        return soaOperationName;
    }

}
