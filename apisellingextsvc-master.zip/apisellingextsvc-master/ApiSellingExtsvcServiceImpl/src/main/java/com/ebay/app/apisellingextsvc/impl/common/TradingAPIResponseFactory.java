package com.ebay.app.apisellingextsvc.impl.common;

import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.AbstractResponseType;
import ebay.apis.eblbasecomponents.GetMyeBaySellingResponseType;
import ebay.apis.eblbasecomponents.GetSellerTransactionsResponseType;

public class TradingAPIResponseFactory {

    private static final ImmutableMap<String, AbstractResponseType> OP_MAP
            = new ImmutableMap.Builder<String, AbstractResponseType>()
            .put(SOAOperationEnum.GetSellerTransactions.getSoaOperationName(), new GetSellerTransactionsResponseType())
            .put(SOAOperationEnum.GetMyeBaySelling.getSoaOperationName(), new GetMyeBaySellingResponseType())

            .build();

    public AbstractResponseType getResponseTye(String operationName) {
        return OP_MAP.getOrDefault(operationName, null);
    }

}
