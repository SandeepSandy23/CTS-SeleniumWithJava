package com.ebay.app.apisellingextsvc.impl;

import org.springframework.context.ApplicationContext;

public class RaptorApplicationContext {

    private static ApplicationContext context;


    public static void setContext(ApplicationContext context) {
        RaptorApplicationContext.context = context;
    }

    public static ApplicationContext getContext() {
        return context;
    }

}