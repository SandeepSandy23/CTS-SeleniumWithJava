package com.ebay.soaframework.extended.spf.impl.handlers;

import com.ebay.app.apisellingextsvc.impl.RaptorApplicationContext;
import com.ebay.app.apisellingextsvc.impl.common.ApiSellingExtsvcResponseErrorHandler;
import com.ebay.app.apisellingextsvc.impl.common.ReflectionHelper;
import com.ebay.app.apisellingextsvc.impl.common.TradingAPIResponseFactory;
import com.ebay.soaframework.common.exceptions.SecurityException;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.ebay.soaframework.common.impl.handlers.BaseHandler;
import com.ebay.soaframework.common.pipeline.Message;
import com.ebay.soaframework.common.pipeline.MessageContext;
import ebay.apis.eblbasecomponents.AbstractResponseType;
import ebay.apis.eblbasecomponents.AckCodeType;
import ebay.apis.eblbasecomponents.ErrorType;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.lang.reflect.Field;
import java.util.*;

/**
 * Response pipeline handler to handle Authentication Failure Errors. Existing Trading APIs handles Authentication Failure as HTTP 200 with custom
 * Error Message inside Errors
 *
 * <p>
 * To use this handler, add it to the service provider's response pipeline via ServiceConfig.xml, e.g.: *
 *
 * <pre>
 * &lt;response-handlers&gt;
 *     &lt;chain name="servicehandlers"&gt;
 *         &lt;handler name="ServiceVersionRemovalHandler" run-on-error="true"&gt;
 *             &lt;class-name&gt;
 *                 com.ebay.checkout.services.common.responsehandlers.ServiceResponseAuthErrorHandler
 *             &lt;/class-name&gt;
 *         &lt;/handler&gt;
 *     &lt;/chain&gt;
 * &lt;/response-handlers&gt;
 * </pre>
 * <p>
 * *
 *
 */
@Configuration
public class ServiceResponseAuthErrorHandler extends BaseHandler {

    private static final String UTC = "UTC";

    @Bean
    public ApiSellingExtsvcResponseErrorHandler getErrorHandler() {
        return new ApiSellingExtsvcResponseErrorHandler();
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceResponseAuthErrorHandler.class);

    /**
     * Invokes this pipeline handler.
     * <p>
     * This will clear the service version string (if any) from the provided MessageContext, unless the current service operation is among the
     * predefined list of operations which should be skipped.
     *
     * @param ctx SOA context
     * @throws ServiceException If an error occurs during the handler processing
     */
    @Override
    public void invoke(MessageContext ctx) throws ServiceException {

        try {
            handleError(ctx);
        } catch (Exception e) {
            LOGGER.error("GenericException", e);
        }

    }

    private void handleError(MessageContext ctx) {
        String operationName = ctx.getOperationName();
        List<Throwable> errors = ctx.getErrorList();
        TradingAPIResponseFactory responseFactory = new TradingAPIResponseFactory();
        AbstractResponseType response = responseFactory.getResponseTye(operationName);
        if (CollectionUtils.isEmpty(errors)) {
            return;
        }
        errors.forEach(error -> {
            if (StringUtils.isNotBlank(error.getMessage())
                    && ((SecurityException) error).getErrorMessage() != null
                    && !CollectionUtils.isEmpty(((SecurityException) error).getErrorMessage().getError())) {

                ((SecurityException) error).getErrorMessage().getError().forEach(errorData -> {
                            if (!CollectionUtils.isEmpty(errorData.getParameter())) {
                                errorData.getParameter().forEach(parameter -> {

                                    ApiSellingExtsvcResponseErrorHandler errorhandler = RaptorApplicationContext.getContext().getBean(ApiSellingExtsvcResponseErrorHandler.class);
                                    ErrorType errorType = errorhandler.populateErrorType(parameter.getValue(), ctx);
                                    if (errorType != null) {
                                        response.setAck(AckCodeType.FAILURE);
                                        setTimeStamp(response);
                                        response.getErrors().add(errorType);
                                        response.setVersion("999");
                                        response.setBuild("E999_CORE_APISELLINGIO__R1");
                                    }
                                });
                            }
                        }
                );
            }
        });
        try {
            Field m_errors = ReflectionHelper.getFieldFromClassHierarchy(ctx.getClass(), "m_errors");
            m_errors.set(ctx, new ArrayList<Throwable>());
            Message msg = ctx.getResponseMessage();
            //int paramCount = msg.getParamCount();
            msg.setParam(0, response);
        } catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException e) {
            LOGGER.error("Reflection Exception when fetching m_errors ", e);
        } catch (ServiceException se) {
            LOGGER.error("ServiceException", se);
        }
    }

    private void setTimeStamp(AbstractResponseType response) {
        GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone(UTC));
        calendar.setTime(new Date());
        XMLGregorianCalendar currentDate;
        try {
            currentDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
            response.setTimestamp(currentDate);
        } catch (DatatypeConfigurationException e) {
            LOGGER.error("DatatypeConfigurationException", e);
        }
    }

}
