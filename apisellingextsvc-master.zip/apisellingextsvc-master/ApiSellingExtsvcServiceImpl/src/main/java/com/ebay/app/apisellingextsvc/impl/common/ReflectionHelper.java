package com.ebay.app.apisellingextsvc.impl.common;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReflectionHelper {


    /**
     * Logger.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ReflectionHelper.class);


    /**
     * Thread-local cache for {@link #getFieldFromClassHierarchy(Class, String)}.
     */
    private static final ThreadLocal<Map<Pair<Class<?>, String>, Field>> CACHED_FIELDS_FOR_CLASS =
            ThreadLocal.withInitial(HashMap::new);


    /**
     * An exception that denotes the same meaning as {@link InvocationTargetException}, except that this is an unchecked exception.
     */
    public static class InvocationTargetRuntimeException extends RuntimeException {

        private static final long serialVersionUID = 3667850323631974811L;

        /**
         * Constructs a new {@link InvocationTargetRuntimeException}.
         *
         * @param cause Underlying exception thrown by the invocation target
         */
        public InvocationTargetRuntimeException(Throwable cause) {
            super(cause);
        }
    }


    /**
     * Private constructor.
     */
    private ReflectionHelper() {
        // Not intended to be instantiated.
    }


    /**
     * Gets the field from the specified class which matches the specified field name.
     * <p>
     * If the class does not itself contain a matching field, this will look in each successive superclass until either a match is found or no further
     * superclasses are available.
     * <p>
     * Once a matching field has been found for a particular class, this field will be cached (within the current thread) for subsequent use.
     *
     * @param clazz     Class to examine
     * @param fieldName Field name to match against
     * @return The matched field if found
     * @throws NoSuchFieldException If no matching field was found
     */
    public static Field getFieldFromClassHierarchy(Class<?> clazz, String fieldName) throws NoSuchFieldException {

        // Check whether a matching field had already previously been found
        // and cached.  If so, just return the cached field.

        Pair<Class<?>, String> cacheKey = Pair.of(clazz, fieldName);
        Field field = CACHED_FIELDS_FOR_CLASS.get().get(cacheKey);
        if (field != null) {
            return field;
        }

        // There was no match in the cache.
        // Proceed to introspect the class and its superclasses.

        NoSuchFieldException originalException = null;

        Class<?> currentClazz = clazz;
        while (currentClazz != null) {
            try {
                field = currentClazz.getDeclaredField(fieldName);
                field.setAccessible(true);
                break;

            } catch (NoSuchFieldException e) {

                // No match was found in the current class.
                // Proceed to try its superclass, if there is one.

                if (originalException == null) {
                    originalException = e;
                }

                currentClazz = currentClazz.getSuperclass();
                if (currentClazz == null) {
                    throw originalException;
                }
            }
        }

        // If a matching field was found, cache it for subsequent re-use.

        CACHED_FIELDS_FOR_CLASS.get().put(cacheKey, field);

        return field;
    }


    /**
     * Gets a field that can be modified from the given object's class.
     *
     * <p>This will work even with static final fields, which normally cannot
     * be modified even via reflection.  See {@link #getModifiableField(Class, String)} for additional notes.
     *
     * @param object    Object whose class will be examined
     * @param fieldName Field name to match against
     * @return The matched field if found
     * @throws ReflectiveOperationException If no matching field was found or some other reflection failure occurs
     */
    public static Field getModifiableField(Object object, String fieldName) throws ReflectiveOperationException {
        return getModifiableField(object.getClass(), fieldName);
    }


    /**
     * Gets a field that can be modified from the given class.
     *
     * <p>This will work even with static final fields, which normally cannot
     * be modified even via reflection.  However, this method will work around the restriction by changing the field's modifiers at runtime to
     * non-final, thus enabling modification.
     *
     * <p>One major caveat is that some static final fields will be inlined
     * by the compiler.  In such cases, even modifying the field value may not have the desired effect!
     *
     * @param clazz     Class to examine
     * @param fieldName Field name to match against
     * @return The matched field if found
     * @throws ReflectiveOperationException If no matching field was found or some other reflection failure occurs
     */
    public static Field getModifiableField(Class<?> clazz, String fieldName) throws ReflectiveOperationException {

        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);

        int modifiers = field.getModifiers();
        if (Modifier.isStatic(modifiers) && Modifier.isFinal(modifiers)) {
            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
        }

        return field;
    }


    /**
     * Returns a class-level method with the given name and parameter types. This will return <code>null</code> if there is no match.
     *
     * @param clazz          Class to examine
     * @param methodName     Method name to match against
     * @param parameterTypes Method parameter types to match against
     * @return The matched method if found, else <code>null</code>
     */
    public static Method getMethod(Class<?> clazz, String methodName, Class<?>... parameterTypes) {

        try {
            Method method = clazz.getDeclaredMethod(methodName, parameterTypes);
            method.setAccessible(true);
            return method;

        } catch (NoSuchMethodException | SecurityException e) {
            return null;
        }
    }


    /**
     * Invokes a class-level method with the given name and parameter types. This will return <code>null</code> if there is no matching method.
     *
     * <p>If the underlying method throws an exception, then this method
     * will throw an {@link InvocationTargetRuntimeException} wrapping the method's exception.
     *
     * @param clazz          Class to examine
     * @param methodName     Method name to match against
     * @param parameterTypes Method parameter types to match against
     * @param returnType     Method return value type
     * @param parameters     Method parameter values to use
     * @param <T>            Method return value type
     * @return The matched method if found, else <code>null</code>
     * @throws InvocationTargetRuntimeException If the underlying method throws an exception.
     */
    public static <T> T invokeMethod(Class<?> clazz, String methodName, Class<?>[] parameterTypes,
                                     Class<T> returnType, Object... parameters) {

        try {
            Method method = getMethod(clazz, methodName, parameterTypes);
            return (method == null) ? null : returnType.cast(method.invoke(null, parameters));

        } catch (InvocationTargetException e) {
            throw new InvocationTargetRuntimeException(e.getCause());    // NOPMD - Deliberately unwrap this exception

        } catch (IllegalArgumentException | IllegalAccessException e) {
            LOGGER.error("Illegal Argument or Access Exception ");
            return null;
        }
    }


    /**
     * Invokes a class-level method with the given name and no parameters. This will return <code>null</code> if there is no matching method.
     *
     * <p>If the underlying method throws an exception, then this method
     * will throw an {@link InvocationTargetRuntimeException} wrapping the method's exception.
     *
     * @param clazz      Class to examine
     * @param methodName Method name to match against
     * @param returnType Method return value type
     * @param <T>        Method return value type
     * @return The matched method if found, else <code>null</code>
     * @throws InvocationTargetRuntimeException If the underlying method throws an exception.
     */
    public static <T> T invokeMethod(Class<?> clazz, String methodName,
                                     Class<T> returnType) {

        return invokeMethod(clazz, methodName, new Class<?>[0], returnType);
    }


}
