package com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign;


import com.ebay.integ.dal.BaseDo3;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.persistence.DALVersion;

import java.util.Date;

@DALVersion("3.0")
public class SellerDiscountCampaignCodeGenDoImpl extends BaseDo3 implements SellerDiscountCampaign {
    public static final long serialVersionUID = 1L;
    public static final int SELLERCAMPAIGNID = 0;
    public static final int SELLERID = 1;
    public static final int SITEID = 2;
    public static final int CAMPAIGNNAME = 3;
    public static final int CAMPAIGNTYPE = 4;
    public static final int CAMPAIGNSUBTYPE = 5;
    public static final int CAMPAIGNDESC = 6;
    public static final int CAMPAIGNSTATUS = 7;
    public static final int BUDGETAMOUNT = 8;
    public static final int REDEEMEDAMOUNT = 9;
    public static final int CURRENCYCODE = 10;
    public static final int MARKETINGPRIORITY = 11;
    public static final int CAMPAIGNFLAGS01 = 12;
    public static final int STARTDATE = 13;
    public static final int ENDDATE = 14;
    public static final int RESTRICTIONTYPE = 15;
    public static final int RULETEMPLATEID = 16;
    public static final int DELETEDDATE = 17;
    public static final int CREATIONDATE = 18;
    public static final int LASTMODIFIEDDATE = 19;
    public static final int REDIRECTCATEGORYID = 20;
    public static final int SBELASTPROCESSEDDATE = 21;
    public static final int CAMPAIGNIMGURL = 22;
    public static final int CAMPAIGNIMGMD5 = 23;
    public static final int NUM_FIELDS = 24;
    public static final int NUM_SUBOBJECT_FIELDS = 0;
    public String m_campaignImgMd5;
    public String m_campaignImgUrl;
    public Date m_sBELastProcessedDate;
    public long m_redirectCategoryId;
    public Date m_lastModifiedDate;
    public Date m_creationDate;
    public Date m_deletedDate;
    public long m_ruleTemplateId;
    public int m_restrictionType;
    public Date m_endDate;
    public Date m_startDate;
    public long m_campaignFlags01;
    public int m_marketingPriority;
    public String m_currencyCode;
    public double m_redeemedAmount;
    public double m_budgetAmount;
    public int m_campaignStatus;
    public String m_campaignDesc;
    public int m_campaignSubType;
    public int m_campaignType;
    public String m_campaignName;
    public int m_siteId;
    public long m_sellerId;
    public long m_sellerCampaignId;

    public SellerDiscountCampaignCodeGenDoImpl() {
        super(SellerDiscountCampaignDAO.getInstance(), GenericMap.getInitializedMap(SellerDiscountCampaign.class));
    }

    public SellerDiscountCampaignCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public String getCampaignImgMd5() {
        this.loadValue(23);
        return this.m_campaignImgMd5;
    }

    public void setCampaignImgMd5(String p_campaignImgMd5) {
        this.m_campaignImgMd5 = p_campaignImgMd5;
        this.setDirty(23);
    }

    public String getCampaignImgUrl() {
        this.loadValue(22);
        return this.m_campaignImgUrl;
    }

    public void setCampaignImgUrl(String p_campaignImgUrl) {
        this.m_campaignImgUrl = p_campaignImgUrl;
        this.setDirty(22);
    }

    public Date getSBELastProcessedDate() {
        this.loadValue(21);
        return this.m_sBELastProcessedDate;
    }

    public void setSBELastProcessedDate(Date p_sBELastProcessedDate) {
        this.m_sBELastProcessedDate = p_sBELastProcessedDate;
        this.setDirty(21);
    }

    public long getRedirectCategoryId() {
        this.loadValue(20);
        return this.m_redirectCategoryId;
    }

    public void setRedirectCategoryId(long p_redirectCategoryId) {
        this.m_redirectCategoryId = p_redirectCategoryId;
        this.setDirty(20);
    }

    public Date getLastModifiedDate() {
        this.loadValue(19);
        return this.m_lastModifiedDate;
    }

    public void setLastModifiedDate(Date p_lastModifiedDate) {
        this.m_lastModifiedDate = p_lastModifiedDate;
        this.setDirty(19);
    }

    public Date getCreationDate() {
        this.loadValue(18);
        return this.m_creationDate;
    }

    public void setCreationDate(Date p_creationDate) {
        this.m_creationDate = p_creationDate;
        this.setDirty(18);
    }

    public Date getDeletedDate() {
        this.loadValue(17);
        return this.m_deletedDate;
    }

    public void setDeletedDate(Date p_deletedDate) {
        this.m_deletedDate = p_deletedDate;
        this.setDirty(17);
    }

    public long getRuleTemplateId() {
        this.loadValue(16);
        return this.m_ruleTemplateId;
    }

    public void setRuleTemplateId(long p_ruleTemplateId) {
        this.m_ruleTemplateId = p_ruleTemplateId;
        this.setDirty(16);
    }

    public int getRestrictionType() {
        this.loadValue(15);
        return this.m_restrictionType;
    }

    public void setRestrictionType(int p_restrictionType) {
        this.m_restrictionType = p_restrictionType;
        this.setDirty(15);
    }

    public Date getEndDate() {
        this.loadValue(14);
        return this.m_endDate;
    }

    public void setEndDate(Date p_endDate) {
        this.m_endDate = p_endDate;
        this.setDirty(14);
    }

    public Date getStartDate() {
        this.loadValue(13);
        return this.m_startDate;
    }

    public void setStartDate(Date p_startDate) {
        this.m_startDate = p_startDate;
        this.setDirty(13);
    }

    public long getCampaignFlags01() {
        this.loadValue(12);
        return this.m_campaignFlags01;
    }

    public void setCampaignFlags01(long p_campaignFlags01) {
        this.m_campaignFlags01 = p_campaignFlags01;
        this.setDirty(12);
    }

    public int getMarketingPriority() {
        this.loadValue(11);
        return this.m_marketingPriority;
    }

    public void setMarketingPriority(int p_marketingPriority) {
        this.m_marketingPriority = p_marketingPriority;
        this.setDirty(11);
    }

    public String getCurrencyCode() {
        this.loadValue(10);
        return this.m_currencyCode;
    }

    public void setCurrencyCode(String p_currencyCode) {
        this.m_currencyCode = p_currencyCode;
        this.setDirty(10);
    }

    public double getRedeemedAmount() {
        this.loadValue(9);
        return this.m_redeemedAmount;
    }

    public void setRedeemedAmount(double p_redeemedAmount) {
        this.m_redeemedAmount = p_redeemedAmount;
        this.setDirty(9);
    }

    public double getBudgetAmount() {
        this.loadValue(8);
        return this.m_budgetAmount;
    }

    public void setBudgetAmount(double p_budgetAmount) {
        this.m_budgetAmount = p_budgetAmount;
        this.setDirty(8);
    }

    public int getCampaignStatus() {
        this.loadValue(7);
        return this.m_campaignStatus;
    }

    public void setCampaignStatus(int p_campaignStatus) {
        this.m_campaignStatus = p_campaignStatus;
        this.setDirty(7);
    }

    public String getCampaignDesc() {
        this.loadValue(6);
        return this.m_campaignDesc;
    }

    public void setCampaignDesc(String p_campaignDesc) {
        this.m_campaignDesc = p_campaignDesc;
        this.setDirty(6);
    }

    public int getCampaignSubType() {
        this.loadValue(5);
        return this.m_campaignSubType;
    }

    public void setCampaignSubType(int p_campaignSubType) {
        this.m_campaignSubType = p_campaignSubType;
        this.setDirty(5);
    }

    public int getCampaignType() {
        this.loadValue(4);
        return this.m_campaignType;
    }

    public void setCampaignType(int p_campaignType) {
        this.m_campaignType = p_campaignType;
        this.setDirty(4);
    }

    public String getCampaignName() {
        this.loadValue(3);
        return this.m_campaignName;
    }

    public void setCampaignName(String p_campaignName) {
        this.m_campaignName = p_campaignName;
        this.setDirty(3);
    }

    public int getSiteId() {
        this.loadValue(2);
        return this.m_siteId;
    }

    public void setSiteId(int p_siteId) {
        this.m_siteId = p_siteId;
        this.setDirty(2);
    }

    public long getSellerId() {
        this.loadValue(1);
        return this.m_sellerId;
    }

    public void setSellerId(long p_sellerId) {
        this.m_sellerId = p_sellerId;
        this.setDirty(1);
    }

    public long getSellerCampaignId() {
        this.loadValue(0);
        return this.m_sellerCampaignId;
    }

    public void setSellerCampaignId(long p_sellerCampaignId) {
        this.m_sellerCampaignId = p_sellerCampaignId;
        this.setDirty(0);
    }

    public Date getFromDate() {
        return (Date)this.getHashValue("fromDate");
    }

    public void setFromDate(Date fromDate) {
        this.setHashValue("fromDate", fromDate);
    }

    public Date getToDate() {
        return (Date)this.getHashValue("toDate");
    }

    public void setToDate(Date toDate) {
        this.setHashValue("toDate", toDate);
    }

    public int getNumFields() {
        return 24;
    }

    public int getNumSubObjects() {
        return 0;
    }
}
