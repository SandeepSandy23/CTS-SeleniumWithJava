package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.enums.HoldReleaseReasonEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.PaymentHoldReasonCodeType;

public class PaymentHoldReasonMapper {

    // todo proforma order mapping
    // checkout trans payment method
    private static final ImmutableMap<String, PaymentHoldReasonCodeType> mapName
            = new ImmutableMap.Builder<String, PaymentHoldReasonCodeType>()
            .put(HoldReleaseReasonEnum.NEW_SELLER.name(), PaymentHoldReasonCodeType.NEW_SELLER)
            .put(HoldReleaseReasonEnum.NEW_SELLER_MP.name(), PaymentHoldReasonCodeType.NEW_SELLER)
            .put(HoldReleaseReasonEnum.BELOW_STANDARD_SELLER.name(), PaymentHoldReasonCodeType.BELOW_STANDARD_SELLER)
            .put(HoldReleaseReasonEnum.EBP_CASE_OPEN.name(), PaymentHoldReasonCodeType.EBP_CASE_OPEN)
            .put(HoldReleaseReasonEnum.REINSTATEMENT_AFTER_SUSPENSION.name(), PaymentHoldReasonCodeType.REINSTATEMENT_AFTER_SUSPENSION)
            .put(HoldReleaseReasonEnum.CASUAL_SELLER.name(), PaymentHoldReasonCodeType.CASUAL_SELLER)
            .put(HoldReleaseReasonEnum.NEW_PAYPAL_ACCOUNT_ADDED.name(), PaymentHoldReasonCodeType.NEW_PAYPAL_ACCOUNT_ADDED)
            .put(HoldReleaseReasonEnum.NOT_AVAILABLE.name(), PaymentHoldReasonCodeType.NOT_AVAILABLE)
            .put(HoldReleaseReasonEnum.SELLER_IS_ON_BLACK_LIST.name(), PaymentHoldReasonCodeType.SELLER_IS_ON_BLACK_LIST)
            .build();

    private PaymentHoldReasonMapper() {
    }

    public static PaymentHoldReasonCodeType map(String key) {
        return mapName.getOrDefault(key, PaymentHoldReasonCodeType.CUSTOM_CODE);
    }

}
