package com.ebay.app.apisellingextsvc.tasks.audit;

import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.api.GetSellerTransactionsComparator;
import com.ebay.app.apisellingextsvc.audit.es.ESResponse;
import com.ebay.app.apisellingextsvc.audit.es.Report;
import com.ebay.app.apisellingextsvc.audit.es.Request;
import com.ebay.app.apisellingextsvc.audit.es.Response;
import com.ebay.app.apisellingextsvc.audit.reporter.BaseAuditReporter;
import com.ebay.app.apisellingextsvc.audit.reporter.GetSellerTransactionsReporter;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.enums.APITypeEnum;
import com.ebay.app.apisellingextsvc.enums.ESAuditIndexEnum;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.utils.XmlUtil;
import com.fasterxml.jackson.databind.JsonNode;
import ebay.apis.eblbasecomponents.GetSellerTransactionsRequestType;
import ebay.apis.eblbasecomponents.GetSellerTransactionsResponseType;
import ebay.apis.eblbasecomponents.TransactionArrayType;
import org.apache.commons.lang3.StringUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class GetSellerTransactionsAuditTask extends BaseApiSellingExtAuditTask{

        private static final String REQUEST_PATH = "tradingApi/getSellerTransactions";
        private final GetSellerTransactionsRequestType request;


        public GetSellerTransactionsAuditTask(
                GetSellerTransactionsResponse oldTradingApi,
                GetSellerTransactionsResponse newTradingApi,
                GetSellerTransactionsRequestType request,
                IServiceInvoker<Report, ESResponse> esServiceInvoker,
                HttpHeaders headers,
                ApiSellingExtSvcConfigValues configValue) {
            super(oldTradingApi, newTradingApi, esServiceInvoker, headers, configValue);
            this.request = request;
        }

        protected void populateRequest(Report report) {
                Map<String, String> map = new ConcurrentHashMap<>();
                if (headers.getRequestHeaders() != null) {
                        for (Map.Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
                                String key = entry.getKey();
                                if (key != null) {
                                        map.put(key, entry.getValue().toString());
                                }
                        }
                }

                if (StringUtils.isNotBlank(getPayload())) {
                        report.setRequest(new Request(Calendar.getInstance().getTime(), getESDocName(), getPayload(),
                                                      map, null));
                }
        }

        @Override
        protected ExtensiveComparator getResponseComparator() {
        return new GetSellerTransactionsComparator(true, false, configValue.getSellerTransactionsAuditExcludeFields);
        }

        @Override
        protected BaseAuditReporter getAuditReporter() {
        return new GetSellerTransactionsReporter();
        }

        @Override
        protected String getUrl() {
        return REQUEST_PATH;
        }

        @Override
        protected String getPayload() {
        return XmlUtil.writeRequestAsString(request, APITypeEnum.GetSellerTransactions);
        }

        protected String getESDocName() {
        return ESAuditIndexEnum.GET_SELLER_TRANSACTIONS_MODIFIED_DATE.getIndexName();
        }

        public void populateResponse(JsonNode org, JsonNode tar,Object orgStr, Object tarStr, Report report) {
                report.setResponse(new Response(org, tar, null, null));
        }
    }


