package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.User;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserInfo;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserReadResponse;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.EiasTokenUtil;
import com.ebay.app.apisellingextsvc.utils.TypeCastUtil;
import com.ebay.app.apisellingextsvc.utils.URLHelperUtil;
import com.ebay.app.apisellingextsvc.utils.UserUtil;
import com.ebay.app.apisellingextsvc.utils.VatStatusUtil;
import com.ebay.content.runtime.UrlFixerConstants;
import com.ebay.cos.type.v3.base.CountryCodeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.MerchandizingPrefCodeType;
import ebay.apis.eblbasecomponents.SellerType;
import ebay.apis.eblbasecomponents.UserType;
import shaded.com.nimbusds.oauth2.sdk.util.MapUtils;

import javax.xml.datatype.XMLGregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class SellerBuilder extends BaseFacetBuilder<UserType>{
    private final UserReadResponse userReadResponse;
    private final int trxVersion;
    private final ApiSellingExtSvcConfigValues configValues;
    private final String FEEDBACK_SCORE = "FEEDBACKSCORE";
    private final String USERID_LAST_CHANGE = "USERID_LAST_CHANGE";
    private final String ALLOW_PAYMENT_EDIT = "ALLOW_PAYMENT_EDIT";
    private final String CHECKOUT_ENABLED = "CHECKOUT_ENABLED";
    private final String SELLER_NOT_IN_GOOD_STANDING = "SELLER_NOT_IN_GOOD_STANDING";
    private final String SAFE_PAYMENT_EXEMPT = "SAFE_PAYMENT_METHOD_EXEMPT";
    private final String STORE_OWNER = "IS_OWNS_STORE";
    private final String INDIVIDUAL_ACCOUNT_TYPE = "INDIVIDUAL";
    private final String BUSINESS_ACCOUNT_TYPE = "BUSINESS";
    private final String CIP_BANK_ACCOUNT_STORED = "CIP_BANK_ACCOUNT_STORED";
    private final String QUALIFIES_FOR_B2B_VAT = "QUALIFIES_FOR_B2B_VAT";
    private final String MERCHANDISING_PREF_OPTED_OUT = "MERCHANDIZING_PREF";
    private final String SPS_TOP_RATED_SELLER_US = "SPS_TOP_RATED_SELLER_US";
    private final String SPS_TOP_RATED_SELLER_UK = "SPS_TOP_RATED_SELLER_UK";
    private final String SPS_TOP_RATED_SELLER_DE = "SPS_TOP_RATED_SELLER_DE";
    private final String TAX_STATUS = "TAX_STATUS";
    private final String IS_FEEDBACK_PRIVATE = "IS_FEEDBACK_PRIVATE";
    private final String storeIdentifier;
    private final List<DetailLevelCodeType> detailLevels;
    private final SiteContext siteContext;
    private final SellerProfileDataContext dataContext;
    private final Map<String, Double> feedbackPercentageMap;

    public SellerBuilder(Task<?> task,
                         int trxVersion,
                         SiteContext siteContext,
                         ApiSellingExtSvcConfigValues configValues,
                         UserReadResponse userReadResponse,
                         SellerProfileDataContext dataContext,
                         String storeIdentifier,
                         List<DetailLevelCodeType> detailLevels,
                         Map<String, Double> feedbackPercentageMap) {

        super(task);
        this.trxVersion = trxVersion;
        this.siteContext = siteContext;
        this.configValues = configValues;
        this.userReadResponse = userReadResponse;
        this.storeIdentifier = storeIdentifier;
        this.detailLevels = detailLevels;
        this.dataContext = dataContext;
        this.feedbackPercentageMap = feedbackPercentageMap;
    }

    @Override
    protected UserType doBuild() {
        if (!CommonUtil.shouldExposeForReturnAllOrEmpty(detailLevels)) {
            return null;
        }
        UserType seller = new UserType();
        UserInfo userInfo =  Optional.ofNullable(userReadResponse).map(UserReadResponse::getData)
                                .map(User::getUser)
                                .flatMap(userInfos -> (userInfos.stream().findFirst()))
                                .orElse(null);

        if (Objects.nonNull(userInfo)) {
            String sellerId = Optional.ofNullable(userInfo).map(UserInfo::getInternalId).orElse(null);
            seller.setAboutMePage(Boolean.FALSE);
            seller.setEBayGoodStanding(Boolean.TRUE);
            seller.setEIASToken(Optional.ofNullable(userInfo).map(UserInfo::getInternalId).map(EiasTokenUtil::encode).orElse(null));
            seller.setEmail(getEmail(userInfo));
            //Feedback private
            seller.setFeedbackPrivate(Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, IS_FEEDBACK_PRIVATE)).map(Boolean::valueOf)
                    .orElse(Boolean.FALSE));
            //Feedback rating star
            String feedBackScore = UserUtil.getValueFromExtensions(userInfo, FEEDBACK_SCORE);
            seller.setFeedbackScore((feedBackScore != null) ? Integer.parseInt(feedBackScore) : null);
            seller.setIDVerified(Boolean.FALSE);
            //Positive Feedback percentage
            if (MapUtils.isNotEmpty(feedbackPercentageMap) && feedbackPercentageMap.get(sellerId) != null) {
                seller.setPositiveFeedbackPercent(TypeCastUtil.setDoubleWithSingleDecimal(feedbackPercentageMap.get(sellerId)).floatValue());
            }
            //If true, identifies a new user who has been a registered eBay user for 30 days or less.
            // This is always false after the user has been registered for more than 30 days.
            seller.setNewUser(UserUtil.isNewUser(Optional.ofNullable(userInfo).map(UserInfo::getCreationDate).orElse(null), null));

            //Todo: Positive feedback percent
            seller.setRegistrationDate(getUserCreationDate(userInfo));

            SellerType sellerType = new SellerType();
            sellerType.setAllowPaymentEdit(Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, ALLOW_PAYMENT_EDIT)).map(Boolean::valueOf)
                    .orElse(Boolean.FALSE));
            sellerType.setCheckoutEnabled(Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, CHECKOUT_ENABLED)).map(Boolean::valueOf)
                    .orElse(Boolean.TRUE));
            sellerType.setCIPBankAccountStored(Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, CIP_BANK_ACCOUNT_STORED)).map(Boolean::valueOf)
                    .orElse(Boolean.FALSE));
            //Refer  "SELLER_NOT_IN_GOOD_STANDING"  key in Userreadsvc response. If it false, then user has good standing.
            Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, SELLER_NOT_IN_GOOD_STANDING)).map(Boolean::valueOf)
                    .ifPresent(isNotInGoodStanding -> sellerType.setGoodStanding(Boolean.FALSE.equals(isNotInGoodStanding)));
            Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, MERCHANDISING_PREF_OPTED_OUT)).map(Boolean::valueOf)
                    .ifPresent(isMerchandisingPrefOptedOut -> sellerType.setMerchandizingPref(Boolean.TRUE.equals(isMerchandisingPrefOptedOut) ?
                            MerchandizingPrefCodeType.OPT_OUT : MerchandizingPrefCodeType.OPT_IN));
            sellerType.setQualifiesForB2BVAT(Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, QUALIFIES_FOR_B2B_VAT)).map(Boolean::valueOf)
                    .orElse(Boolean.FALSE));
            boolean storeOwner = Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, STORE_OWNER)).map(Boolean::valueOf).orElse(Boolean.FALSE);
            sellerType.setStoreOwner(storeIdentifier != null && storeOwner);
            if (storeOwner && storeIdentifier != null) {
                Integer siteId = Optional.ofNullable(userInfo).map(UserInfo::getRegistrationSiteId).map(Integer::parseInt).orElse(-1);
                sellerType.setStoreURL(buildStoreURL(storeIdentifier, siteId));
            }
            sellerType.setSafePaymentExempt(Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, SAFE_PAYMENT_EXEMPT)).map(Boolean::valueOf)
                    .orElse(Boolean.FALSE));
            if (getTopRatedSeller(userInfo) != null) {
                sellerType.setTopRatedSeller(getTopRatedSeller(userInfo));
            }

            seller.setSellerInfo(sellerType);
            seller.setSite(UserUtil.getUserSite(userInfo));
            seller.setStatus(UserUtil.getUserStatus(userInfo));
            seller.setUserID(Optional.ofNullable(userInfo).map(UserInfo::getUsername).orElse(null));
            seller.setUserIDChanged(UserUtil.isUserIdChanged(userInfo, USERID_LAST_CHANGE));
            seller.setUserIDLastChanged(getUserIdLastChangedDate(userInfo));

            CountryCodeEnum country = Optional.ofNullable(userInfo).map(UserInfo::getCountryOfResidence).map(CountryCodeEnum::valueOf).orElse(null);
            Integer legacyCountryId = Optional.ofNullable(country).map(CountryCodeEnum::getLegacyCountryId).orElse(null);
            Integer registrationSiteId = Optional.ofNullable(userInfo).map(UserInfo::getRegistrationSiteId).map(Integer::parseInt).orElse(null);
            Integer taxStatus = Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, TAX_STATUS)).map(Integer::valueOf).orElse(null);
            seller.setVATStatus(VatStatusUtil.getVatStatusForSeller(dataContext.getTaxRateBof(),
                    configValues, legacyCountryId, registrationSiteId, taxStatus));
        }
        return seller;
    }

    private XMLGregorianCalendar getUserIdLastChangedDate(UserInfo userInfo) {
        String dateValue = UserUtil.getValueFromExtensions(userInfo, USERID_LAST_CHANGE);
        if (null == dateValue) return null;
        return UserUtil.getUserIdLastChangedDate(dateValue);
    }

    private XMLGregorianCalendar getUserCreationDate(UserInfo userInfo) {
        return Optional.ofNullable(userInfo)
                .map(UserInfo::getCreationDate)
                .map(DateUtil::convertToXMLGregorianCalendar)
                .orElse(null);
    }

    protected String buildStoreURL(String storeIdentifier, int siteId) {
        StringBuilder baseURL = new StringBuilder();
        if (storeIdentifier != null && siteId != -1) {
            String domainString = URLHelperUtil.getDomainString(siteId);
            baseURL.append(UrlFixerConstants.HTTPS)
                    .append(ApiSellingExtSvcConstants.WWW)
                    .append(ApiSellingExtSvcConstants.DOT)
                    .append(domainString)
                    .append(ApiSellingExtSvcConstants.SINGLE_SLASH)
                    .append(ApiSellingExtSvcConstants.STORE)
                    .append(ApiSellingExtSvcConstants.SINGLE_SLASH)
                    .append(storeIdentifier);
        }
        return baseURL.toString();
    }

    private String getEmail(UserInfo userInfo) {
        if (userInfo != null && userInfo.getUserAccountType().equalsIgnoreCase(INDIVIDUAL_ACCOUNT_TYPE)) {
            return (userInfo.getIndividualIdentityProfile() != null) ? userInfo.getIndividualIdentityProfile().getEmail() : null;
        } else if (userInfo != null && userInfo.getUserAccountType().equalsIgnoreCase(BUSINESS_ACCOUNT_TYPE)) {
            return (userInfo.getBusinessIdentityProfile() != null) ?  userInfo.getBusinessIdentityProfile().getEmail() : null;
        }
        return null;
    }

    private Boolean getTopRatedSeller(UserInfo userInfo) {
        String registrationSiteId = Optional.ofNullable(userInfo).map(UserInfo::getRegistrationSiteId).orElse(null);
        if (registrationSiteId != null && registrationSiteId.equals("0")) {
            return Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, SPS_TOP_RATED_SELLER_US))
                    .map(Boolean::valueOf).orElse(null);
        } else if (registrationSiteId != null && registrationSiteId.equals("3")) {
            return Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, SPS_TOP_RATED_SELLER_UK))
                    .map(Boolean::valueOf).orElse(null);
        } else if (registrationSiteId != null && registrationSiteId.equals("77")) {
            return Optional.ofNullable(UserUtil.getValueFromExtensions(userInfo, SPS_TOP_RATED_SELLER_DE))
                    .map(Boolean::valueOf).orElse(null);
        }
        return null;
    }

}