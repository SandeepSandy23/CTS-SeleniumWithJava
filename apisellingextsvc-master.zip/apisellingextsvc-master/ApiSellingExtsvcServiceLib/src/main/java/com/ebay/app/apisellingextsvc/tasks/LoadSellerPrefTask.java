package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.bof.sellerpref.ISellerPrefBof;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPref;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPrefFlags;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class LoadSellerPrefTask implements Task, ITaskResultInjectable {
    private Map<String, Object> resultMap = new HashMap<>();
    public static final String TASK_NAME = "LoadSellerPrefTask";
    private final ISellerPrefBof sellerPrefBof;
    private final String userId;

    public LoadSellerPrefTask(ISellerPrefBof sellerPrefBof, String userId) {
        this.sellerPrefBof = sellerPrefBof;
        this.userId = userId;
    }

    @Override
    public SellerPref call() {
        return loadSellerPref(userId);
    }

    private SellerPref loadSellerPref(String userId) {
        try {
            long sellerId = Long.parseLong(userId);
            SellerPref sellerPref = sellerPrefBof.findBySellerId(sellerId);

            printLog(sellerPref, sellerId);

            return sellerPref;
        } catch (NumberFormatException e) {
            CalLogger.warn("failed to parse sellerId=" + userId, e.getMessage());
        }

        return null;
    }

    private void printLog(SellerPref sellerPref, long sellerId) {
        if (sellerPref == null) {
            CalLogger.info("seller pref load result",  "seller pref result is null, sellerId=" + sellerId);
        } else {
            CalLogger.info("seller pref load result, ",  "require phone for shipping is "
                    + sellerPref.hasFlag(SellerPrefFlags.REQUIRE_PHONE_FOR_SHIPPING_MASK)
                    + ", sellerId=" + sellerId);
        }
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
