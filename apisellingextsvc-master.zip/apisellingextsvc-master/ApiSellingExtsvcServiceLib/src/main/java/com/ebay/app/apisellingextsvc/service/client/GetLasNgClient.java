package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.context.ListingsContext;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GetLasNgClient extends BaseGingerClient<ListingsContext, GetListingActivitiesByIdsResponse> {

    private static final Logger logger = LoggerFactory.getLogger(GetLasNgClient.class);

    private static final String CLIENT_ID = "lasng.lasngClient";

    private static final String PATH = "/lasngsvc/v1/listing_activity";

    public GetLasNgClient() {
        super(GetListingActivitiesByIdsResponse.class);
    }

    @Override
    public GingerClientResponse<GetListingActivitiesByIdsResponse> getGingerResponse(GingerClientRequest<ListingsContext> gingerRequest) {
        return processGetRequest(PATH, gingerRequest.getRequest().getQueryParams(), gingerRequest.getHeaders());
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
