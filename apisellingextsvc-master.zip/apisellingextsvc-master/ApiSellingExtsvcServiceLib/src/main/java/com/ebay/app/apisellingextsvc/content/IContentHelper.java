package com.ebay.app.apisellingextsvc.content;

public interface IContentHelper {

    /**
     * Return default content manager, site id is default to request site id. Use this when text need to be localized by request site id.
     */
    IContentManager getContentManager();

    /**
     * Return customized content manager. Use this when text need to be localized by arbitrary site id.
     */
    IContentManager getContentManager(Integer siteId);

    /**
     * Return content manager, site id is default to error language id. Use this when text need to be localized by error language id.
     */
    IContentManager getErrorContentManager();



}
