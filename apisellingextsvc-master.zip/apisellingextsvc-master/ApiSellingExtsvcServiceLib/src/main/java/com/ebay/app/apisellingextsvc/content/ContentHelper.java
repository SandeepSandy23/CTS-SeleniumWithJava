package com.ebay.app.apisellingextsvc.content;

import com.ebay.af.common.UserPreferences;
import com.ebay.globalenv.SiteEnum;
import com.ebay.globalenv.domain.DomainConfigurationFactory;
import com.ebay.globalenv.domain.DomainUserPreferences;
import com.ebay.permutation.IPermutation;
import com.ebay.permutation.Permutation;
import com.ebay.raptor.content.api.IContentBuilderFactory;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.UncheckedExecutionException;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import org.apache.commons.lang3.exception.ExceptionUtils;

import javax.annotation.Nonnull;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class ContentHelper implements IContentHelper {

    // todo, change to Cache to get cache state, LoadingCache does not have Cache state
    private static LoadingCache<Integer, IContentManager> contentManagerCache = null;

    private final IContentBuilderFactory contentBuilderFactory;

    private final Integer requestSiteId;
    private final Integer errorLanguageSiteId;

    private final Long contentCacheEvictTime;
    private final Integer contentCacheMaximumSize;

    /**
     * Only use at TradingAPIResponseErrorHandler.java
     */
    public ContentHelper(@Nonnull IContentBuilderFactory contentBuilderFactory,
                         @Nonnull Integer requestSiteId) {
        this.contentBuilderFactory = contentBuilderFactory;
        this.requestSiteId = requestSiteId; // not used
        this.errorLanguageSiteId = 0;
        this.contentCacheEvictTime = 3000L;
        this.contentCacheMaximumSize = 10;
    }

    public ContentHelper(@Nonnull IContentBuilderFactory contentBuilderFactory,
                         @Nonnull Integer requestSiteId,
                         @Nonnull Integer errorLanguageSiteId,
                         @Nonnull Long evictTime,
                         @Nonnull Integer contentCacheMaximumSize) {
        this.contentBuilderFactory = contentBuilderFactory;
        this.requestSiteId = requestSiteId;
        this.errorLanguageSiteId = errorLanguageSiteId;
        this.contentCacheEvictTime = evictTime;
        this.contentCacheMaximumSize = contentCacheMaximumSize;
        if (contentManagerCache == null) {
            initContentCache();
        }
    }

    public IContentManager getContentManager() {
        return getContent(requestSiteId);
    }

    public IContentManager getContentManager(Integer siteId) {
        return getContent(siteId);
    }

    public IContentManager getErrorContentManager() {
        return getContent(errorLanguageSiteId);
    }

    public IContentManager createContentManager(IContentBuilderFactory contentBuilderFactory, int siteId) {
        // todo IContentBuilderFactory may not able to be access from multithread, need test
        // copy from DefaultUserPreferencesCreator.java (implements UserPreferencesCreator)
        DomainUserPreferences dup = DomainConfigurationFactory.getInstance().getDefaultUserPrefs(siteId);
        UserPreferences userPref = new UserPreferences(dup.getCountry(), dup.getLanguage(), dup.getTimeZone(),
                dup.getTimeZoneNameStd(), dup.getTimeZoneNameSummer());

        SiteEnum siteEnum = SiteEnum.get(siteId);
        Locale locale = siteEnum.getLocale();
        // leave target to null at permutation, currently most target are EBAY_MARKET_PLACE refer to EbayPermutationSpec.java
        IPermutation permutation = Permutation.create(locale);
        return ContentManager.createContentManager(contentBuilderFactory.create(permutation, userPref, siteId));
    }


    private void initContentCache() {
        synchronized (this) {
            // Avoid Synchronized At Method Level, java PMD
            if (contentManagerCache == null) {
                // remove records that have been idle for XX second
                contentManagerCache = CacheBuilder.newBuilder()
                        .maximumSize(contentCacheMaximumSize)
                        .expireAfterAccess(contentCacheEvictTime, TimeUnit.MILLISECONDS)
                        .build(getLoader());
            }
        }
    }

    private CacheLoader<Integer, IContentManager> getLoader() {
        return new CacheLoader<Integer, IContentManager>() {
            @Override
            public IContentManager load(@Nonnull Integer siteId) {
                return createContentManager(contentBuilderFactory, siteId);
            }
        };
    }

    private IContentManager getContent(int siteId) {
        try {
            return contentManagerCache.getUnchecked(siteId);
        } catch (UncheckedExecutionException uncheckedExecutionException) {
            CalLogger.error("ContentHelper exception with siteId=" + siteId,
                    ExceptionUtils.getStackTrace(uncheckedExecutionException));
            // default to US
            return contentManagerCache.getUnchecked(0);
        }
    }
}
