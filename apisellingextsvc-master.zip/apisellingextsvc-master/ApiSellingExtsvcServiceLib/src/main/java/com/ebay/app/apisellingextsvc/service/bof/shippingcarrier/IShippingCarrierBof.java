package com.ebay.app.apisellingextsvc.service.bof.shippingcarrier;


public interface IShippingCarrierBof {
    String findCarrierNameByCarrierId(int carrierId);
}
