package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.service.invokers.model.ItemProfilesModel;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cos.las.type.ListingActivitiesResponse;
import com.ebay.cos.type.v3.core.listing.Listing;
import com.ebay.globalenv.SiteEnum;
import com.ebay.marketplace.selling.services.sellerprofilesitemmapservice.consumer.SellerProfilesItemMapServiceConsumer;
import com.ebay.marketplace.selling.v1.services.sellerprofilesitemmapservice.GetItemProfilesRequest;
import com.ebay.marketplace.selling.v1.services.sellerprofilesitemmapservice.GetItemProfilesResponse;
import com.ebay.marketplace.selling.v1.services.sellerprofilesitemmapservice.ItemProfile;
import com.ebay.marketplace.services.common.converter.GlobalIdConverter;
import com.ebay.platform.raptor.cosadaptor.exceptions.TokenCreationException;
import com.ebay.platform.raptor.cosadaptor.token.ISecureTokenManager;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.google.common.collect.Lists;
import ebay.apis.eblbasecomponents.SellerPaymentProfileType;
import ebay.apis.eblbasecomponents.SellerProfilesType;
import ebay.apis.eblbasecomponents.SellerReturnProfileType;
import ebay.apis.eblbasecomponents.SellerShippingProfileType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

public class GetItemProfilesTask implements Task<ItemProfilesModel>, ITaskResultInjectable {
    private Map<String, Object> resultMap = new HashMap<>();
    private final User user;
    private final ISecureTokenManager tokenManager;
    private final int siteId;
    private final Executor executor;

    private  ApiSellingExtSvcConfigValues configValues;

    public GetItemProfilesTask(User user,
            ISecureTokenManager tokenManager, int requestSiteId, ApiSellingExtSvcConfigValues configValues, Executor executor) {
        this.user = user;
        this.tokenManager = tokenManager;
        this.executor = executor;
        this.siteId = requestSiteId;
        this.configValues = configValues;
    }
    @Override
    public ItemProfilesModel call() {
        
        ListingActivitiesResponse lasResponse = (ListingActivitiesResponse) resultMap.get(ListingActivitiesResponse.class.getName());

        List<Long> itemIdsList = Optional.ofNullable(lasResponse)
                                         .map(ListingActivitiesResponse::getMembers)
                                         .map(Arrays::asList)
                                         .orElse(new ArrayList<>())
                                         .stream()
                                         .map(ListingActivitiesDetail::getListing)
                                         .map(Listing::getListingId)
                                         .map(Long::parseLong)
                                         .collect(Collectors.toList());

        if(itemIdsList.size() == 0){
            return  new ItemProfilesModel(new HashMap<>());
        }
        List<List<Long>> itemIdsBatch = Lists.partition(itemIdsList, configValues.getBpBatchSize());

        try {
            String token = tokenManager.getToken().getAccessToken();
            Map<Long, SellerProfilesType> itemToProfileMap = Optional.ofNullable(itemIdsBatch)
                                                                     .orElse(new ArrayList<>())
                                                                     .stream()
                                                                     .map(t -> CompletableFuture.supplyAsync(() -> getItemProfiles(t, token), executor))
                                                                     .collect(Collectors.toList())
                                                                     .stream()
                                                                     .map(CompletableFuture::join)
                                                                     .filter(Objects::nonNull)
                                                                     .map(GetItemProfilesResponse::getItemProfile)
                                                                     .map(this::createMapOfItemProfiles)
                                                                     .flatMap(t -> t.entrySet() .stream())
                                                                     .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
            return new ItemProfilesModel(itemToProfileMap);
        } catch (TokenCreationException e) {
            CalLogger.info("GetItemProfileTask: Token creation exception :",e.getMessage());
            return new ItemProfilesModel(new HashMap<>());
        } catch (RuntimeException e) {
            CalLogger.info("GetItemProfileTask: Exception while calling bpgetitemprofiles :",e.getMessage());
            return new ItemProfilesModel(new HashMap<>());
        }
    }

    private GetItemProfilesResponse getItemProfiles(List<Long> itemIds, String token) {
        SellerProfilesItemMapServiceConsumer consumer = null;
        try {
            consumer = new SellerProfilesItemMapServiceConsumer(ApiSellingExtSvcConstants.BP_ITEM_PROFILES_CONSUMER);
            consumer.getService() .setSessionTransportHeader(ApiSellingExtSvcConstants.HEADER_GLOBAL_ID, GlobalIdConverter.getInstance().encode(SiteEnum.get(siteId)));
            consumer.getService().setSessionTransportHeader(ApiSellingExtSvcConstants.HEADER_SECURITYID, user.getUserId());
            consumer.setAuthToken(token);  //token(bearer, iaf) can also be passed in "X-EBAY-SOA-SECURITY-TOKEN header
        } catch (ServiceException e) {
            CalLogger.info("GetItemProfilesTask: bp getitemprofiles call failed",e.getMessage());
            throw new RuntimeException(e);
        }
        GetItemProfilesRequest req = new GetItemProfilesRequest();
        req.getItemId().addAll(itemIds);
        req.setIncludeDetails(false);
        GetItemProfilesResponse response = consumer.getItemProfiles(req);
        return response;
    }

    private Map<Long, SellerProfilesType> createMapOfItemProfiles(List<ItemProfile> itemProfiles) {

        Map<Long, SellerProfilesType> itemIdPoliciesMap = new HashMap();
           Optional.ofNullable(itemProfiles).orElse(new ArrayList<>()).forEach(itemProfile -> {
               SellerProfilesType sellerPolicies = new SellerProfilesType();
               if (itemProfile.getPaymentProfile() != null && itemProfile.getPaymentProfile().getProfileId() != null) {
                   SellerPaymentProfileType paymentPolicy = new SellerPaymentProfileType();
                   paymentPolicy.setPaymentProfileID(itemProfile.getPaymentProfile().getProfileId());
                   paymentPolicy.setPaymentProfileName(itemProfile.getPaymentProfile().getProfileName());
                   sellerPolicies.setSellerPaymentProfile(paymentPolicy);
               }

               if (itemProfile.getShippingPolicyProfile() != null && itemProfile.getShippingPolicyProfile().getProfileId() != null) {
                   SellerShippingProfileType shippingPolicy = new SellerShippingProfileType();
                   shippingPolicy.setShippingProfileID(itemProfile.getShippingPolicyProfile().getProfileId());
                   shippingPolicy.setShippingProfileName(itemProfile.getShippingPolicyProfile().getProfileName());
                   sellerPolicies.setSellerShippingProfile(shippingPolicy);
               }

               if (itemProfile.getReturnPolicyProfile() != null && itemProfile.getReturnPolicyProfile().getProfileId() != null) {
                   SellerReturnProfileType returnPolicy = new SellerReturnProfileType();
                   returnPolicy.setReturnProfileID(itemProfile.getReturnPolicyProfile().getProfileId());
                   returnPolicy.setReturnProfileName(itemProfile.getReturnPolicyProfile().getProfileName());
                   sellerPolicies.setSellerReturnProfile(returnPolicy);
               }
               itemIdPoliciesMap.put(itemProfile.getItemId(), sellerPolicies);
           });
        return itemIdPoliciesMap;
    }


    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result))  resultMap.put(result.getClass().getName(), result);
    }
}
