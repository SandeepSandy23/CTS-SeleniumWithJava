package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.integ.dal.cache2.IndependantCacheKey;
import com.ebay.kernel.util.HashHelperFNV;
import com.ebay.kernel.util.JdkUtil;

class ShippingServiceCK implements IndependantCacheKey {
    private static final long serialVersionUID = -2668910434788037989L;
    private static int s_classNameHash = JdkUtil.forceInit(ShippingServiceCK.class).getName().hashCode();
    private int m_shippingServiceId;


    public ShippingServiceCK(int shippingServiceId) {
        this.m_shippingServiceId = shippingServiceId;
    }

    public boolean equals(Object other) {
        return other != null && other instanceof ShippingServiceCK;
    }

    public int hashCode() {
        int hash = HashHelperFNV.append(HashHelperFNV.start(), s_classNameHash);
        hash = HashHelperFNV.append(hash, this.m_shippingServiceId);
        return hash;
    }
}
