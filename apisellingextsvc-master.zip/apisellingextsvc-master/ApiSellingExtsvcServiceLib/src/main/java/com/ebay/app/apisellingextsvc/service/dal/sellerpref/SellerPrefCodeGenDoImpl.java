package com.ebay.app.apisellingextsvc.service.dal.sellerpref;

import com.ebay.af.common.flag.FlagMask;
import com.ebay.integ.dal.BaseDo3;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.persistence.DALVersion;

@DALVersion("3.0")
@SuppressWarnings({"PMD", "FindBugs"})
public class SellerPrefCodeGenDoImpl extends BaseDo3 implements SellerPref {

    // field offset declarations
    public static final int SELLERID = BaseDo3.NUM_FIELDS;
    public static final int SHIPPINGPREFSFLAGS = BaseDo3.NUM_FIELDS + 39 ;
    public static final int NUM_FIELDS = BaseDo3.NUM_FIELDS + 85;


    // attribute declarations
    public long  m_sellerId;
    public long  m_shippingPrefsFlags;

    public SellerPrefCodeGenDoImpl() {
        super(SellerPrefDAO.getInstance(), GenericMap.getInitializedMap(SellerPref.class));
    }

    public SellerPrefCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    /**
     * Return the total number of fields that are mapped.
     */
    public int getNumFields() {
        return NUM_FIELDS;
    }


    public long getSellerId() {
        loadValue(SELLERID);
        return m_sellerId;
    }

    public void setSellerId(long sellerId) {
        this.m_sellerId = sellerId;
        setDirty(SELLERID);
    }

    @Override
    public long getShippingPrefsFlags() {
        loadValue(SHIPPINGPREFSFLAGS);
        return this.m_shippingPrefsFlags;
    }

    @Override
    public void setShippingPrefsFlags(long shippingPrefsFlags) {
        this.m_shippingPrefsFlags = shippingPrefsFlags;
        setDirty(SHIPPINGPREFSFLAGS);
    }

    @Override
    protected long getDataValue(FlagMask flagMask) {
        return getShippingPrefsFlags();
    }

    @Override
    public boolean hasFlag(FlagMask flagMask) {
        return super.hasFlag(flagMask);
    }
}
