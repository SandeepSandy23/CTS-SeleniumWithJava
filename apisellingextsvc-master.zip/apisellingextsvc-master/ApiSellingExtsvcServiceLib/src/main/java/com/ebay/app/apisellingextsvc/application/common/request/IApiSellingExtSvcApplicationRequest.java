package com.ebay.app.apisellingextsvc.application.common.request;

import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.raptor.content.api.IContentBuilderFactory;
import com.ebay.raptor.orchestrationv2.task.ITaskOrchestrator;

import javax.ws.rs.core.HttpHeaders;

public interface IApiSellingExtSvcApplicationRequest {

    ContentResource getContentResource();

    IContentBuilderFactory getContentBuilderFactory();

    String getErrorLanguage();

    int getRequestSiteId();

    String getName();

    HttpHeaders getHeaders();

    ITaskOrchestrator getExecutor();

    String getCalName();

}
