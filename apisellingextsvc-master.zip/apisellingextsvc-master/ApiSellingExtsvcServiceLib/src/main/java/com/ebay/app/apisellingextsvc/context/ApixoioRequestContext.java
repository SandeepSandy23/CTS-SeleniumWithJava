package com.ebay.app.apisellingextsvc.context;

import javax.ws.rs.core.HttpHeaders;

public class ApixoioRequestContext {

    private final String requestBody;
    private final HttpHeaders headers;

    private ApixoioRequestContext(String requestBody,
                                  HttpHeaders headers) {
        this.requestBody = requestBody;
        this.headers = headers;
    }

    public static ApixoioRequestContext createGetRequestContext(String requestBody, HttpHeaders headers) {
        return new ApixoioRequestContext(requestBody, headers);
    }

    public String getRequestBody() {
        return requestBody;
    }

    public HttpHeaders getHeaders() {
        return headers;
    }

}
