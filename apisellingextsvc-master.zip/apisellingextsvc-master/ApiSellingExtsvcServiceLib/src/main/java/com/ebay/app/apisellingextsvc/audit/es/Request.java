package com.ebay.app.apisellingextsvc.audit.es;

import com.ebay.order.common.v1.DateTime;
import java.util.Date;
import java.util.Map;

public class Request {

    private DateTime date;

    private String esIndexName;
    private String payload;
    private Map<String, String> metadata;
    private String metadataStr;

    public Request(Date date, String esIndexName, String payload, Map<String, String> metadata, String metaDataStr) {
        this.date = new DateTime(date);
        this.esIndexName = esIndexName;
        this.payload = payload;
        this.metadata = metadata;
        this.metadataStr = metaDataStr;
    }

    public DateTime getDate() {
        return date;
    }

    public void setDate(DateTime date) {
        this.date = date;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, String> metadata) {
        this.metadata = metadata;
    }

    public String getEsIndexName() {
        return esIndexName;
    }

    public void setEsIndexName(String esIndexName) {
        this.esIndexName = esIndexName;
    }

    public String getMetadataStr() {
        return metadataStr;
    }

    public void setMetadataStr(String metadataStr) {
        this.metadataStr = metadataStr;
    }
}
