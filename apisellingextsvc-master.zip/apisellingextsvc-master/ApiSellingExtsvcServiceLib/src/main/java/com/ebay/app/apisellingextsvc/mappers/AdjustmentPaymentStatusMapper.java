package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.AdjustmentStatusType;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.PaymentTransactionStatusCodeType;

// for monetary.payment.status
public class AdjustmentPaymentStatusMapper {

    // checkout trans payment method
    private static final ImmutableMap<AdjustmentStatusType, PaymentTransactionStatusCodeType> mapName
            = new ImmutableMap.Builder<AdjustmentStatusType, PaymentTransactionStatusCodeType>()
            .put(AdjustmentStatusType.FAILED, PaymentTransactionStatusCodeType.FAILED)
            .put(AdjustmentStatusType.SUCCESS, PaymentTransactionStatusCodeType.SUCCEEDED)
            .put(AdjustmentStatusType.PENDING, PaymentTransactionStatusCodeType.PENDING)
            .build();

    private AdjustmentPaymentStatusMapper() {
    }

    public static PaymentTransactionStatusCodeType map(AdjustmentStatusType key) {
        return mapName.getOrDefault(key, PaymentTransactionStatusCodeType.CUSTOM_CODE);
    }

}
