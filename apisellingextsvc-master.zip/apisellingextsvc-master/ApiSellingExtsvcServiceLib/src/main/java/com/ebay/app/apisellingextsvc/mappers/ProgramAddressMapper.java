package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.order.common.v1.AddressType;
import com.ebay.order.common.v1.ProgramEnumType;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;

public class ProgramAddressMapper {

    private static final ImmutableMap<ProgramEnumType, AddressType> addressMap = ImmutableMap.<ProgramEnumType, AddressType>builder()
            .put(ProgramEnumType.DEFAULT, AddressType.BUYER_SHIPPING_ADDRESS)
            .put(ProgramEnumType.PICK_UP_DROP_OFF, AddressType.STORE_ADDRESS)
            .put(ProgramEnumType.PSA, AddressType.WAREHOUSE_ADDRESS)
            .put(ProgramEnumType.GLOBAL_SHIPPING_PROGRAM, AddressType.WAREHOUSE_ADDRESS)
            .put(ProgramEnumType.BOPIS, AddressType.BUYER_SHIPPING_ADDRESS)
            .put(ProgramEnumType.EXPORTS, AddressType.WAREHOUSE_ADDRESS)
            .build();

    private static final ImmutableSet<String> SHIPPING_PROGRAM_SET = ImmutableSet.<String>builder()
            .add(ProgramEnumType.EBAY_GUARANTEED_DELIVERY.name())
            .add(ProgramEnumType.BOPIS.name())
            .add(ProgramEnumType.GLOBAL_SHIPPING_PROGRAM.name())
            .add(ProgramEnumType.PICK_UP_DROP_OFF.name())
            .add(ProgramEnumType.EBAY_PLUS.name())
            .add(ProgramEnumType.LOCAL_PICKUP.name())
            .add(ProgramEnumType.GST.name())
            .add(ProgramEnumType.PSA.name())
            .add(ProgramEnumType.VAULT.name())
            .add(ProgramEnumType.EXPORTS.name())
            //.add(ProgramEnumType.EBAY_INTERNATIONAL_SHIPPING.name()); TODO: EBAY_INTERNATIONAL_SHIPPING no longer exists?
            .add(ProgramEnumType.DEFAULT.name())
            .add(ApiSellingExtSvcConstants.EBAY_MANAGED_SHIPPING)
    .build();

    private ProgramAddressMapper() {

    }

    public static AddressType mapAddress(ProgramEnumType input) {
        return addressMap.get(input);
    }

    public static boolean containShippingProgram(String program) {
        return SHIPPING_PROGRAM_SET.contains(program);
    }
}
