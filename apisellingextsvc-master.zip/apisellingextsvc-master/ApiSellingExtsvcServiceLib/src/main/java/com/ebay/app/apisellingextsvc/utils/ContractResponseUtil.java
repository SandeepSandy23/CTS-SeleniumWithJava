package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.ResponseSummaryType;

import java.util.Optional;

public class ContractResponseUtil {

    public static boolean isOrder(ContractResponseType contractResponse) {
        return contractResponse != null && contractResponse.getOrder() != null;
    }

    public static boolean isProformaOrder(ContractResponseType contractResponse) {
        return contractResponse != null && contractResponse.getProformaOrder() != null;
    }

    public static Integer getTotalCountSummary(ContractResponse contractResponse) {
       return Optional.ofNullable(contractResponse).map(ContractResponse::getSummary).map(ResponseSummaryType::getTotalCountSummary)
               .map(countMap -> countMap.getOrDefault(ApiSellingExtSvcConstants.SUMMARY_TOTAL_COUNT,0))
               .orElse(null);
    }
}
