package com.ebay.app.apisellingextsvc.builders;

import com.ebay.coms.type.v1.PromotionTypeEnumType;
import com.ebay.cos.type.v3.base.CurrencyCodeEnum;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.PromotionCS;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.EntityTotal;
import com.ebay.order.common.v1.LogisticsPlan;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.common.collect.ImmutableSet;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscount.SellerDiscountEntity;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign.SellerDiscountCampaign;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.LogisticUtil;
import com.ebay.app.apisellingextsvc.utils.TypeCastUtil;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.SellerDiscountType;
import ebay.apis.eblbasecomponents.SellerDiscountsType;
import org.apache.commons.collections.CollectionUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

public class SellerDiscountsBuilder extends BaseFacetBuilder<SellerDiscountsType> {

    private static final ImmutableSet<String> sellerDiscountSet = ImmutableSet.of(
            PromotionTypeEnumType.SELLER_DISCOUNTED_PROMOTIONAL_OFFER.value());

    private final LineItemXType lineItem;
    private final int trxVersion;
    private final String defaultCurrency;
    private final List<LogisticsPlan> logistics;



    public SellerDiscountsBuilder(Task<?> task,
                                  LineItemXType lineItem,
                                  int trxVersion,
                                  List<LogisticsPlan> logistics) {
        super(task);
        this.lineItem = lineItem;
        this.trxVersion = trxVersion;
        this.defaultCurrency = AmountTypeUtil.getCurrency(lineItem.getLineItemTotal());
        this.logistics = logistics;
    }


    @Override
    protected SellerDiscountsType doBuild() {
        // Get promotions from line item
        List<PromotionCS> sellerDiscountPromotions = getSellerDiscounts();
        if (CollectionUtils.isEmpty(sellerDiscountPromotions)) {
            return null;
        }
        // Get price lines from line item. Discount amounts get from price lines
        List<PriceLine> priceLineList = getPriceLines();
        SellerDiscountsType sellerDiscountsType = new SellerDiscountsType();
        // Get original item price from UNIT_COST
        sellerDiscountsType.setOriginalItemPrice(buildOriginalItemPrice());
        // Get original shipping price from SHIPPING_COST price line
        sellerDiscountsType.setOriginalItemShippingCost(buildOriginalItemShippingCost(priceLineList));
        // Get Original Shipping Service fropm oracle table
        // Deprecated as per discussion with Orders team
        // sellerDiscountsType.setOriginalShippingService(buildOriginalShippingService());
        // Build seller discount lines
        for (PromotionCS promotionCS : sellerDiscountPromotions) {
            sellerDiscountsType.getSellerDiscount().add(buildSellerDiscount(priceLineList, promotionCS));
        }
        return sellerDiscountsType;
    }

    private AmountType buildOriginalItemPrice() {
        return Optional.of(this.lineItem)
                .map(LineItemXType::getUnitCost)
                .map(AmountTypeUtil::getAmountType)
                .orElse(null);
    }

    private AmountType buildOriginalItemShippingCost(List<PriceLine> priceLineList) {
        return priceLineList.stream()
                .filter(p -> PricelineTypeEnum.SHIPPING_COST == p.getType())
                .map(PriceLine::getAmount)
                .map(AmountTypeUtil::getAmountType)
                .findFirst()
                .orElse(null);
    }

    private SellerDiscountType buildSellerDiscount(List<PriceLine> priceLineList, PromotionCS promotionCS) {
        SellerDiscountType sellerDiscountType = new SellerDiscountType();
        sellerDiscountType.setCampaignID(getCampaignID(promotionCS));
        // get Campaign Display Name from oracle table
        // Deprecated as per discussion with OrdersTeam
        // sellerDiscountType.setCampaignDisplayName(getCampaignDisplayName(sellerDiscountType.getCampaignID()));
        //Get discount amount value from price line
        sellerDiscountType.setItemDiscountAmount(getItemDiscount(priceLineList, sellerDiscountType.getCampaignID()));
        // Get shipping discount from SHIPPING_DISCOUNT price line
        sellerDiscountType.setShippingDiscountAmount(getShippingDiscount(priceLineList, sellerDiscountType.getCampaignID()));
        return sellerDiscountType;
    }

    private Long getCampaignID(PromotionCS promotionCS) {
        return TypeCastUtil.parseLong(promotionCS.getCode());
    }

    private AmountType getItemDiscount(List<PriceLine> priceLineList, Long campaignID) {
        /**
         * campaignID: 5 means shipping discount type
         */
        if (trxVersion >= VersionConstant.VERSION_SELLER_DISCOUNTS
                && campaignID.equals(ApiSellingExtSvcConstants.SHIPPING_DISCOUNT_TYPE)) {
            return AmountTypeUtil.getZeroAmountType(defaultCurrency);
        }

        /**
         * The dollar amount of the order line item discount.
         * The original purchase price (denoted in OriginalItemPrice) will be reduced by this value.
         * Prior to Version 895, this field worked a little differently.
         * Instead of this field showing the amount of the discount, it was actually showing the final item price after the discount was applied.
         * So, if an item price is 10.0 dollars and the discount is 2.0 dollars,
         * someone using Version 895 (and going forward) will see a value of '2.0' (amount of the discount) in this field,
         * but anyone using Version 893 or lower will see a value of '8.0' (item price after discount) in this field.
         */

        int purchaseQuantity = Optional.of(this.lineItem.getQuantityPurchased())
                .filter(quantity -> quantity > 0).orElse(ApiSellingExtSvcConstants.DEFAULT_PURCHASE_QUANTITY);

        Amount totalDiscount = getCostByType(priceLineList, PricelineTypeEnum.DISCOUNTED_ITEM_COST);
        String currencyName = Optional.ofNullable(totalDiscount.getCurrency()).map(CurrencyCodeEnum::name).orElse(defaultCurrency);

        if (trxVersion >= VersionConstant.VERSION_SME_CHANGES_ITEM_DISOCUNTS) {
            Amount totalItemCost = getCostByType(priceLineList, PricelineTypeEnum.ITEM_COST);
            BigDecimal result = BigDecimal.valueOf(totalItemCost.getValue())
                    .subtract(BigDecimal.valueOf(totalDiscount.getValue()))
                    .divide(BigDecimal.valueOf(purchaseQuantity), RoundingMode.HALF_UP);
            return AmountTypeUtil.getAmountType(currencyName, result.doubleValue());
        } else {
            BigDecimal result = BigDecimal.valueOf(totalDiscount.getValue()).divide(BigDecimal.valueOf(purchaseQuantity), RoundingMode.HALF_UP);
            return AmountTypeUtil.getAmountType(currencyName, result.doubleValue());
        }
    }

    private Amount getCostByType(List<PriceLine> priceLineList, PricelineTypeEnum pricelineTypeEnum) {
        return priceLineList.stream()
                .filter(item -> pricelineTypeEnum == item.getType())
                .map(PriceLine::getAmount)
                .findFirst()
                .orElse(new Amount(ApiSellingExtSvcConstants.ZERO_AMOUNT, CurrencyCodeEnum.valueOf(defaultCurrency)));

    }

    private AmountType getShippingDiscount(List<PriceLine> priceLineList, Long campaignID) {
        Optional<Amount> shippingDiscountOptional = priceLineList.stream()
                .filter(item -> PricelineTypeEnum.SHIPPING_DISCOUNT == item.getType())
                .map(PriceLine :: getAmount)
                .findFirst();
        if (!shippingDiscountOptional.isPresent() || BigDecimal.valueOf(shippingDiscountOptional.get().getValue()).compareTo(BigDecimal.ZERO) <= 0) {
            return null;
        }
        /**
         * campaignID: 5 means shipping discount type
         */
        if (trxVersion >= VersionConstant.VERSION_SELLER_DISCOUNTS
                && !campaignID.equals(ApiSellingExtSvcConstants.SHIPPING_DISCOUNT_TYPE)) {
            return AmountTypeUtil.getZeroAmountType(defaultCurrency);
        }

        return AmountTypeUtil.getAmountType(shippingDiscountOptional.get());
    }

    private List<PromotionCS> getSellerDiscounts() {
        return lineItem.getPromotionsCS().stream()
                .filter(Objects::nonNull)
                .filter(item -> sellerDiscountSet.contains(item.getType()))
                .collect(Collectors.toList());
    }

    private List<PriceLine> getPriceLines() {
        return Optional.ofNullable(lineItem)
                .map(LineItemXType::getLineItemTotal)
                .map(EntityTotal::getPriceLines)
                .orElse(Collections.emptyList());
    }
}
