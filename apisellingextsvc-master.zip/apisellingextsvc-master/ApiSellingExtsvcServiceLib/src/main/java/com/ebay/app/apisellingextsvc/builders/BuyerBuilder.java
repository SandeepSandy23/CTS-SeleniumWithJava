package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.UserConfigUtil;
import com.ebay.cos.type.v3.base.CountryCodeEnum;
import com.ebay.cosmos.UserCS;
import com.ebay.order.common.v1.OrderAddressType;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AddressType;
import ebay.apis.eblbasecomponents.BuyerType;
import ebay.apis.eblbasecomponents.CountryCodeType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.UserType;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public class BuyerBuilder extends BaseFacetBuilder<UserType> {
    private final String USERID_LAST_CHANGE = "USERID_LAST_CHANGE";
    private final UserCS user;
    private final List<DetailLevelCodeType> detailLevels;
    private final int trxVersion;
    private final ApiSellingExtSvcConfigValues configValues;
    private final Date lastTransactedDate;
    private final List<OrderAddressType> orderAddressTypeList;
    private final IContentHelper contentHelper;

    public BuyerBuilder(Task<?> task,
                        int trxVersion,
                        ApiSellingExtSvcConfigValues configValues,
                        IContentHelper contentHelper,
                        UserCS user,
                        Date lastTransactedDate,
                        List<OrderAddressType> orderAddressTypeList,
                        List<DetailLevelCodeType> detailLevels) {
        super(task);
        this.user = user;
        this.contentHelper = contentHelper;
        this.detailLevels = detailLevels;
        this.trxVersion = trxVersion;
        this.configValues = configValues;
        this.lastTransactedDate = lastTransactedDate;
        this.orderAddressTypeList = orderAddressTypeList;
    }


    @Override
    protected UserType doBuild() {
        UserType buyer = new UserType();

        buyer.setEmail(getBuyerEmail());
        buyer.setUserID(user.getUserIdentifier().getUserName());

        BuyerType buyerType = new BuyerType();
        AddressType addressType = new AddressType();

        if (null != orderAddressTypeList &&  !orderAddressTypeList.isEmpty()) {
            addressType.setPostalCode(orderAddressTypeList.stream().filter(orderAddressType -> null != orderAddressType.getAddress()).findFirst()
                    .map(OrderAddressType::getAddress).map(com.ebay.cos.type.v3.base.Address::getPostalCode).orElse(null));

            CountryCodeType countryCodeType = orderAddressTypeList.stream().filter(orderAddressType -> null != orderAddressType.getAddress()).findFirst()
                    .map(OrderAddressType::getAddress).map(com.ebay.cos.type.v3.base.Address::getCountry)
                    .map(CountryCodeEnum::toString).map(CountryCodeType::fromValue).orElse(CountryCodeType.ZZ);
            addressType.setCountry(countryCodeType);
            buyerType.setShippingAddress(addressType);
            buyer.setBuyerInfo(buyerType);
        }
        return buyer;
    }

    private String getBuyerEmail() {
        /**
         * If order is expired (Order’s creation date out of the date range to display email address):
         *      Return Invalid Request.
         * If order is not expired and Buyer’s alias email address from CosmosNG is not null:
         *      Return Buyer’s alias email address.
         * If order is not expired and Buyer’s alias email address from CosmosNG is null:
         *      Return Buyer’s email address.
         */
        if (UserConfigUtil.isEmailProtectionEnabled(configValues)
                && UserConfigUtil.isEmailToBeShownAsContactMember(configValues, lastTransactedDate)) {
            return ApiSellingExtSvcConstants.INVALID_REQUEST;
        }

        return Optional.ofNullable(user).map(UserCS::getAliasEmailAddress)
                .orElse(Optional.ofNullable(user).map(UserCS::getEmailAddress)
                        .orElse(null));
    }

}
