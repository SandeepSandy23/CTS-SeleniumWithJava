package com.ebay.app.apisellingextsvc.context;

import ebay.apis.eblbasecomponents.MyeBaySellingSummaryType;
import ebay.apis.eblbasecomponents.SellingSummaryType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Summary {

    public MyeBaySellingSummaryType myeBaySellingSummaryType;
    public SellingSummaryType sellingSummaryType;
}
