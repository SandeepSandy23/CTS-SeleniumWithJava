package com.ebay.app.apisellingextsvc.service.dal.saleaggregator;

import com.ebay.af.common.flag.FlagMask;

public class SaleAggregatorDoMock implements SaleAggregator {
    private String sellerProdId;

    private long itemId;

    private long sellerId;

    @Override
    public String getSellerProId() {
        return this.sellerProdId;
    }

    @Override
    public void setSellerProId(String sellerProdId) {
        this.sellerProdId = sellerProdId;
    }

    @Override
    public long getItemId() {
        return this.itemId;
    }

    @Override
    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    @Override
    public long getSellerId() {
        return this.sellerId;
    }

    @Override
    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    @Override
    public boolean equalsData(Object o) {
        return false;
    }

    @Override
    public boolean hasFlag(FlagMask flagMask) {
        return false;
    }

    @Override
    public void setFlag(FlagMask flagMask, boolean b) {

    }
}
