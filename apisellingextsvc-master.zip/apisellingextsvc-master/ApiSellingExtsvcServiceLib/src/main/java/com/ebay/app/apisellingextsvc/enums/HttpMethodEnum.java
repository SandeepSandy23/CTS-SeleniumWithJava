package com.ebay.app.apisellingextsvc.enums;

public enum HttpMethodEnum {
    POST,
    GET

}
