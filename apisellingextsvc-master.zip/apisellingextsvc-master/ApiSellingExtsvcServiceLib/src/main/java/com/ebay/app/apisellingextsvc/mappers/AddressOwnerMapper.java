package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.AddressOwnerCodeType;

public class AddressOwnerMapper {

    private static final ImmutableMap<String, AddressOwnerCodeType> mapName
            = new ImmutableMap.Builder<String, AddressOwnerCodeType>()
            .put(ApiSellingExtSvcConstants.EBAY, AddressOwnerCodeType.E_BAY)
            .put(ApiSellingExtSvcConstants.PAY_PAL, AddressOwnerCodeType.PAY_PAL)
            .build();

    private AddressOwnerMapper() {

    }

    //TODO: We are putting E_BAY as default for now,
    //TODO: May need to revisit this logic to see if we should set it to null
    public static AddressOwnerCodeType map(String input) {
        return mapName.getOrDefault(input, AddressOwnerCodeType.E_BAY);
    }
}
