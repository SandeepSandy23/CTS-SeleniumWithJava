package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;

public interface IAuditHandler<T> {
    void preAction(IServiceInvoker<String, String> apisellingioServiceInvoker);

    void doAudit(T var1);
}
