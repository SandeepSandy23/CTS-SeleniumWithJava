package com.ebay.app.apisellingextsvc.service.bof.sellerdiscountcampaign;

import com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign.SellerDiscountCampaign;

import java.util.List;

public interface ISellerDiscountCampaignBof {
    List<SellerDiscountCampaign> findCampaignsByIds(List<Long> campaignIds);
}
