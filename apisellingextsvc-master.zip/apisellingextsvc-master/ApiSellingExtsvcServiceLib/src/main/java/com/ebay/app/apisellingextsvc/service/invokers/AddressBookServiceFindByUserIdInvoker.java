package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.tide.app.addressbook.request.BulkFindAddressesByUserIdRequest;
import com.ebay.tide.app.addressbook.response.BulkFindAddressesByUserIdResponse;
import com.ebay.app.apisellingextsvc.service.client.AddressBookServiceFindByUserIdClient;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class AddressBookServiceFindByUserIdInvoker
      extends BaseServiceInvoker<BulkFindAddressesByUserIdRequest, BulkFindAddressesByUserIdResponse, BulkFindAddressesByUserIdRequest> {

    // use for mock
    public static final String NAME = "AddressBookServiceFindByUserIdInvoker";

    public AddressBookServiceFindByUserIdInvoker(TracerContext tracerContext) {
        super(NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<BulkFindAddressesByUserIdRequest, BulkFindAddressesByUserIdResponse> getGingerClient(
          BulkFindAddressesByUserIdRequest request) {
        return new AddressBookServiceFindByUserIdClient();
    }

    @Override
    protected GingerClientRequest<BulkFindAddressesByUserIdRequest> getGingerRequest(BulkFindAddressesByUserIdRequest request,
                                                                                     HttpHeaders httpHeaders) {
        GingerClientRequest<BulkFindAddressesByUserIdRequest> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(request);
        return gingerClientRequest;
    }

}
