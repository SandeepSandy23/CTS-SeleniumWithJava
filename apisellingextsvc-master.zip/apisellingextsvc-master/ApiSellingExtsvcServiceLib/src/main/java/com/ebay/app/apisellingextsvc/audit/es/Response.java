package com.ebay.app.apisellingextsvc.audit.es;
import com.fasterxml.jackson.databind.JsonNode;

public class Response {

    /**
     * The response we have.
     */
    private JsonNode actual;
    /**
     * The expected response;
     */
    private JsonNode expected;

    private String actualStr;

    private String expectedStr;

    public Response(JsonNode actual, JsonNode expected, String actualStr, String expectedStr) {
        this.actual = actual;
        this.expected = expected;
        this.actualStr = actualStr;
        this.expectedStr = expectedStr;
    }

    public JsonNode getActual() {
        return actual;
    }

    public void setActual(JsonNode actual) {
        this.actual = actual;
    }

    public JsonNode getExpected() {
        return expected;
    }

    public void setExpected(JsonNode expected) {
        this.expected = expected;
    }

    public String getActualStr() {
        return actualStr;
    }

    public void setActualStr(String actualStr) {
        this.actualStr = actualStr;
    }

    public String getExpectedStr() {
        return expectedStr;
    }

    public void setExpectedStr(String expectedStr) {
        this.expectedStr = expectedStr;
    }
}
