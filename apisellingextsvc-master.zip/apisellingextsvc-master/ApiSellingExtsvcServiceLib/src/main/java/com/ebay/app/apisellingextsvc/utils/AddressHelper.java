package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.enums.ContentBundleEnum;
import com.ebay.cos.type.v3.base.CountryCodeEnum;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.v1.Address;
import com.ebay.order.common.v1.AddressType;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.Order;
import com.ebay.order.common.v1.OrderAddressType;
import ebay.apis.eblbasecomponents.AddressOwnerCodeType;
import ebay.apis.eblbasecomponents.AddressUsageCodeType;
import ebay.apis.eblbasecomponents.CountryCodeType;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Optional;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.EVTN;

public class AddressHelper {
    public static final String EVTN_PREFIX = "ebay:";

    public static OrderAddressType getOrderAddressType(List<OrderAddressType> addresses,
                                                       AddressType addressTypeParams) {
        // First return Buyer shipping address, if not found then return the
        // Ware house address instead.

        OrderAddressType orderAddressType = Optional.ofNullable(addresses)
                .flatMap(address -> address.stream()
                        .filter(addressType -> addressTypeParams ==  addressType.getType())
                        .findFirst()).orElse(null);

        if (orderAddressType == null) {
            orderAddressType = Optional.ofNullable(addresses)
                    .flatMap(address -> address.stream()
                            .filter(addressType -> AddressType.WAREHOUSE_ADDRESS ==  addressType.getType())
                            .findFirst()).orElse(null);
        }

        return orderAddressType;
    }

    public static OrderAddressType getOrderAddressType(OrderCSXType order, AddressType addressTypeParam) {
        return Optional.ofNullable(order)
                .map(Order::getAddress)
                .flatMap(address -> address.stream()
                        .filter(addressType -> addressTypeParam == addressType.getType())
                        .findFirst()).orElse(null);
    }

    public static boolean isBuyerDataDeleted(OrderCSXType order) {
        boolean isBuyerDataDeleted = AttributeUtil.hasAttributeInsensitive(order.getAttributes(),
                ApiSellingExtSvcConstants.BUYER_USER_DATA_DELETED, Boolean.TRUE.toString());
        String buyerDataDeletedDate = AttributeUtil.findAttributeValue(order.getAttributes(),
                ApiSellingExtSvcConstants.BUYER_USER_DATA_DELETION_DATE);
        return isBuyerDataDeleted && StringUtils.isNotEmpty(buyerDataDeletedDate);
    }


    public static ebay.apis.eblbasecomponents.AddressType getAddressType(OrderCSXType order, OrderAddressType from,
                                                                         AddressType addressType,
                                                                         IContentHelper contentHelper) {

        ebay.apis.eblbasecomponents.AddressType shipAddress = new ebay.apis.eblbasecomponents.AddressType();
        if (from == null || from.getAddress() == null || isAddressEmpty(from.getAddress())) {
            if (!(isBuyerDataDeleted(order) && addressType == AddressType.BUYER_SHIPPING_ADDRESS)) {
                CalLogger.warn("ShippingAddressIsMissing", "order id is " + order.getOrderId() + ","
                        + "failed to get " + addressType + " address");
            }
            return shipAddress;
        }
        Optional.ofNullable(from.getName()).ifPresent(name -> shipAddress.setName(StringUtils.trim(name.getContent())));
        Address address = from.getAddress();
        if (address != null) {
            if (address.getCountry() != null) {
                shipAddress.setCountry(CountryCodeType.fromValue(address.getCountry().name()));
                String countryName = Optional.of(address).map(Address::getCountry)
                        .map(CountryCodeEnum::getAlpha3IsoCountryCode)
                        .map(key -> contentHelper.getContentManager().getText(ContentBundleEnum.CountryContent, key))
                        .orElse(null);
                shipAddress.setCountryName(countryName);
            }
            if (address.getStateOrProvince() != null) {
                shipAddress.setStateOrProvince(address.getStateOrProvince().trim());
            }
            if (address.getCity() != null) {
                shipAddress.setCityName(address.getCity().trim());
            }
            if (address.getAddressLine1() != null) {
                shipAddress.setStreet1(address.getAddressLine1().trim());
            }
            String address2 = getStreet2(address, order);
            if (address2 != null) {
                shipAddress.setStreet2(address2);
            }
            if (address.getPhone() != null) {
                shipAddress.setPhone(address.getPhone().trim());
            }
            if (address.getPostalCode() != null) {
                shipAddress.setPostalCode(address.getPostalCode().trim());
            }
        }

        if (from.getAddressId() != null) {
            shipAddress.setAddressID(from.getAddressId().getBaseIdentifier());
        }
        shipAddress.setReferenceID(AttributeUtil.findAttribute(order.getAttributes(), EVTN).map(Attribute::getValue)
                .orElse(null));
        shipAddress.setAddressOwner(AddressOwnerCodeType.E_BAY);
        shipAddress.setAddressUsage(AddressUsageCodeType.DEFAULT_SHIPPING);
        return shipAddress;
    }

    private static String getStreet2(Address address, OrderCSXType order) {
        String street2 = ObjectUtils.defaultIfNull(address.getAddressLine2(), "").trim();
        return appendEvtnAddress(street2, order);
    }

    private static String appendEvtnAddress(String shipAddress, OrderCSXType order) {
        String evtn = AttributeUtil.findAttribute(order.getAttributes(), EVTN).map(Attribute::getValue)
                .orElse(null);
        if (StringUtils.isNoneBlank(evtn) && evtn != null) {
            String ebayEvtn = EVTN_PREFIX + evtn;
            if (StringUtils.isEmpty(shipAddress)) {
                return ebayEvtn;
            } else {
                // avoid duplication as cosmos response may already contain EVTN
                if (!shipAddress.toLowerCase().contains(evtn.toLowerCase())) {
                    return shipAddress + StringUtils.SPACE + ebayEvtn;
                }
            }
        }
        return shipAddress;
    }

    private static boolean isAddressEmpty(Address address) {
        return address.getCountry() == null
                && address.getStateOrProvince() == null
                && address.getCity() == null
                && address.getAddressLine1() == null
                && address.getAddressLine2() == null
                && address.getPhone() == null
                && address.getPostalCode() == null
                && address.getName() == null
                && address.getType() == null
                && address.getEmail() == null
                && address.getAddressIdentifier() == null
                && address.getNationalRegion() == null
                && address.getWorldRegion() == null
                && address.getIsTransliterated() == null
                && address.getScript() == null
                && address.getTransliteratedFromScript() == null
                && address.getAddressType() == null;
    }
}
