package com.ebay.app.apisellingextsvc.service.dal.globaltablehostmap;

import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.ConstantToupleProvider;
import com.ebay.integ.dal.ddr.ToupleProviderRegistry;
import com.ebay.integ.dal.map.*;
import com.ebay.app.apisellingextsvc.service.dal.common.ReadSets;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

public class GlobalTableHostMapDAO extends BaseDao2 {

    private static final String FIND_BY_PHYSICAL_TABLE_NAME = "FIND_BY_PHYSICAL_TABLE_NAME";
    private static final MappingIncludesAttribute[] ourDDRHints = new MappingIncludesAttribute[0];
    private static volatile GlobalTableHostMapDAO instance;
    private static final String UHS_LOOKUP_HOSTNAME = "lookuputf8host";
    private static final String GLOBAL_TABLE_HOST_MAP = "GLOBAL_TABLE_HOST_MAP";
    private static final String UHS_LOGICAL_HOST = "UHS_LOGICAL_HOST";

    private static final AtomicBoolean initMap = new AtomicBoolean(false);

    public GlobalTableHostMap findByPhysicalTableName(String physicalTableName) throws FinderException {

        GlobalTableHostMapCodeGenDoImpl protoDO = new GlobalTableHostMapCodeGenDoImpl();
        protoDO.setPhysicalTableName(physicalTableName);
        QueryEngine queryEngine = new QueryEngine();
        protoDO.setLocalOnly(true);
        return (GlobalTableHostMap) queryEngine.readSingle(protoDO.getMap(), protoDO, FIND_BY_PHYSICAL_TABLE_NAME, ReadSets.FULL.getValue());
    }

    public static GlobalTableHostMapDAO getInstance() {
        if (instance == null) {
            synchronized (GlobalTableHostMapDAO.class) {
                if (instance == null) {
                    instance = new GlobalTableHostMapDAO();
                }
            }
        }
        return instance;
    }

    public void initMap() {

        if (!initMap.compareAndSet(false, true)) {
            return;
        }

        GenericMap<GlobalTableHostMap> map = GenericMap.getMap(GlobalTableHostMap.class);
        map = Optional.ofNullable(map).orElse(new GenericMap<>(GlobalTableHostMap.class));
        map.setDalVersion("3.0");

        ToupleProviderRegistry.getInstance().registerToupleProvider(GLOBAL_TABLE_HOST_MAP,
                new ConstantToupleProvider(GLOBAL_TABLE_HOST_MAP, UHS_LOOKUP_HOSTNAME));
        ToupleProviderRegistry.getInstance().registerToupleProvider(UHS_LOGICAL_HOST,
                new ConstantToupleProvider(UHS_LOGICAL_HOST, UHS_LOOKUP_HOSTNAME));

        map.setTableJoins(getTableJoins(map));
        map.setQueries(getRawQueries());
        map.setReadSets(getReadSets());
        map.init();
    }


    public static Query[] getRawQueries() {
        return new Query[]{new SelectQuery(FIND_BY_PHYSICAL_TABLE_NAME,
                ourDDRHints,
                new SelectStatement[]{new SelectStatement(
                        "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE PHYSICAL_TABLE_NAME = :m_physicalTableName AND (<JOIN/>)")})
        };
    }

    protected TableJoin[] getTableJoins(GenericMap<GlobalTableHostMap> map) {
        return new TableJoin[]{new TableJoin(new TableDef[]{map.getTableDef(GLOBAL_TABLE_HOST_MAP), map.getTableDef(UHS_LOGICAL_HOST)},
                "g.LOGICAL_HOST_ID=uhs.LOGICAL_HOST_ID")};
    }

    public static ReadSet[] getReadSets() {
        return new ReadSet[]{ new ReadSet(ReadSets.FULL.getValue(), null) };
    }
}
