package com.ebay.app.apisellingextsvc.service.dal.useraddress;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.service.dal.userlookup.UserLookupTupleProvider;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.ToupleProviderRegistry;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.integ.dal.map.MappingIncludesAttribute;
import com.ebay.integ.dal.map.Query;
import com.ebay.integ.dal.map.QueryEngine;
import com.ebay.integ.dal.map.ReadSet;
import com.ebay.integ.dal.map.SelectQuery;
import com.ebay.integ.dal.map.SelectStatement;
import com.ebay.persistence.DALVersion;

import java.util.Optional;

@DALVersion("3.0")
@SuppressWarnings({"PMD", "FindBugs"})
public class UserAddressDAO extends BaseDao2 {

    public static final String PrimaryKeyLookup = BaseMap2.PRIMARYKEYLOOKUP;

    private static MappingIncludesAttribute[] ourDDRHints;

    private static volatile UserAddressDAO instance;

    public UserAddress findByPrimaryKey(long addressId, long userId) throws FinderException {
        UserAddressCodeGenDoImpl protoDO = new UserAddressCodeGenDoImpl();
        protoDO.setId(addressId);
        protoDO.setUserId(userId);
        QueryEngine qe = new QueryEngine();
        protoDO.setLocalOnly(true);
        return (UserAddress) qe.readSingle(protoDO.getMap(), protoDO, PrimaryKeyLookup, ReadSets.FULL.value);
    }

    public static UserAddressDAO getInstance() {
        if (instance == null) {
            synchronized (UserAddressDAO.class) {
                if (instance == null) {
                    instance = new UserAddressDAO();
                }
            }
        }
        return instance;
    }

    public void initMap() {

        GenericMap<UserAddress> map = GenericMap.getMap(UserAddress.class);
        map = Optional.ofNullable(map).orElse(new GenericMap<>(UserAddress.class));
        map.setDalVersion("3.0");

        //todo need to load minHost and maxHost from global_table_host_map, and cache it local
        //https://jirap.corp.ebay.com/browse/TRXAPI-2122

        //todo add failover host to handle exception case
        //https://jirap.corp.ebay.com/browse/TRXAPI-2123

        UserLookupTupleProvider userLookupTupleProvider =
                new UserLookupTupleProvider("EBAY_USER_ADDRESSES",
                        "userread%host", ApiSellingExtSvcConstants.MIN_HOST,
                        ApiSellingExtSvcConstants.MAX_HOST, "m_userId");
        ToupleProviderRegistry.getInstance().registerToupleProvider("EBAY_USER_ADDRESSES", userLookupTupleProvider);

        initHintGroups(map);
        map.setQueries(getRawQueries());
        map.setReadSets(getReadSets());
        map.init();
    }

    public static void initHintGroups(@SuppressWarnings("unused") GenericMap<UserAddress> map) {
        ourDDRHints = new MappingIncludesAttribute[] { map.getLocalFieldMapping(UserAddressCodeGenDoImpl.USERID) };
    }

    public static Query[] getRawQueries() {
        return new Query[]{new SelectQuery(PrimaryKeyLookup,
                ourDDRHints,
                new SelectStatement[]{new SelectStatement(-1, "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE ID = :m_id")})
        };
    }

    public static ReadSet[] getReadSets() {
        return new ReadSet[]{ new ReadSet(ReadSets.FULL.value, null) };
    }

    public enum ReadSets {

        MATCHANY(-1), FULL(-2);
        private final int value;

        ReadSets(int v) {
            value = v;
        }
    }
}
