package com.ebay.app.apisellingextsvc.service.bof.shippingservice;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.dal.shippingservice.ShippingService;
import com.ebay.app.apisellingextsvc.service.dal.shippingservice.ShippingServiceDAO;

public class ShippingServiceBofImpl implements IShippingServiceBof {
    @Override
    public ShippingService findByServiceId(int serviceId) {
        try {
            return ShippingServiceDAO.getInstance().findByServiceId(serviceId);
        } catch (Exception e) {
            CalLogger.error("Shipping Service get error: ",
                    "cannot get Shipping Service with serviceId:" + serviceId);
        }

        return null;
    }
}
