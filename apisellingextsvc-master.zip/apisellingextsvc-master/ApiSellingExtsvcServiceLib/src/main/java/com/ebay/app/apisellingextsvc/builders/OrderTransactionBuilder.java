package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.CheckoutStatusUtil;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.GMESCosmosFieldUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.app.apisellingextsvc.utils.PriceLineAmountUtil;
import com.ebay.app.apisellingextsvc.utils.ProgramUtil;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.OrderTotal;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.LineItem;
import com.ebay.order.common.v1.LineItemSource;
import com.ebay.order.common.v1.LogisticsPlan;
import com.ebay.order.common.v1.LogisticsStep;
import com.ebay.order.common.v1.LogisticsStepTypeEnumType;
import com.ebay.order.common.v1.MarkedAsFulfilledLineItem;
import com.ebay.order.common.v1.PackageContentsType;
import com.ebay.order.common.v1.PackageType;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.order.common.v1.ShippingStepExtension;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.CompleteStatusCodeType;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.xml.datatype.XMLGregorianCalendar;
import java.util.Optional;

public class OrderTransactionBuilder extends AbstractOrderTransactionBuilder {
    protected final OrderCSXType order;
    protected final LineItemXType lineItem;
    protected final ApiSellingExtSvcConfigValues configValues;
    protected final SiteContext siteContext;

    public OrderTransactionBuilder(Task<?> task,
                                   OrderCSXType order,
                                   LineItemXType lineItem,
                                   SiteContext siteContext,
                                   ApiSellingExtSvcConfigValues configValues,
                                   int trxVersion) {

        super(task, trxVersion);
        this.order = order;
        this.lineItem = lineItem;
        this.siteContext = siteContext;
        this.configValues = configValues;
    }

    @Override
    protected TransactionType doBuild() {

        TransactionType transaction = super.doBuild();
        if(null != transaction.getTransactionID()) {
            CalLogger.info("OrderTransactionBuilder--> Transaction ID:", transaction.getTransactionID());
        }
        transaction.setTransactionID(lineItem.getSourceId().getTransactionId());
        transaction.setQuantityPurchased(lineItem.getQuantityPurchased());
        transaction.setOrderLineItemID(lineItem.getSourceId().getLookupKey());
        transaction.setCreatedDate(getCreatedDate(order.getCreationDate(), lineItem.getAttribute()));
        transaction.setPaidTime(PaymentUtil.getLatestPaidTime(order));
        transaction.setShippedTime(getShippedTime());
        return transaction;
    }

    private XMLGregorianCalendar getShippedTime() {

        String itemId = Optional.ofNullable(this.lineItem).map(LineItem::getSourceId).map(LineItemSource::getItemId).orElse(null);
        String transId = Optional.ofNullable(this.lineItem).map(LineItem::getSourceId).map(LineItemSource::getTransactionId).orElse(null);

        ShippingStepExtension shippingStep = Optional.ofNullable(order).map(OrderCSXType::getLogistics)
                .flatMap(logisticsPlans -> logisticsPlans.stream().findFirst())
                .map(LogisticsPlan::getSteps).filter(CollectionUtils::isNotEmpty)
                .flatMap(steps -> steps.stream().filter(step -> step.getStepType() == LogisticsStepTypeEnumType.SHIPPING).reduce((a, b) -> b))
                .map(LogisticsStep::getStepExtension)
                .map(LogisticsStep.StepExtension::getShippingStep)
                .orElse(null);
        XMLGregorianCalendar shippedDate = Optional.ofNullable(shippingStep)
                .map(ShippingStepExtension::getPackage).filter(CollectionUtils::isNotEmpty)
                .flatMap(packageTypes -> packageTypes.stream()
                        .filter(packageType -> filterPackageByItemIdAndTransId(itemId, transId, packageType)).findFirst())
                .map(PackageType::getShippedDate)
                .map(DateUtil::convertToXMLGregorianCalendar)
                .orElse(null);
        if (shippedDate == null) {
            return Optional.ofNullable(shippingStep)
                    .map(ShippingStepExtension::getMarkedAsFulfilledLineItem)
                    .flatMap(markedAsFulfilledLineItems -> markedAsFulfilledLineItems.stream()
                            .filter(lineItemIdentifier -> filterFulfillmentByItemIdAndTransId(itemId, transId, lineItemIdentifier)).findFirst())
                    .map(MarkedAsFulfilledLineItem::getShippedDate)
                    .map(DateUtil::convertToXMLGregorianCalendar)
                    .orElse(null);
        }
        return shippedDate;
    }

    private boolean filterPackageByItemIdAndTransId(String itemId, String transId, PackageType packageType) {
        return Optional.ofNullable(packageType)
                .map(PackageType::getPackageContents)
                .map(PackageContentsType::getPackageLineItemId).filter(CollectionUtils::isNotEmpty)
                .flatMap(packageLineItems -> packageLineItems.stream()
                        .filter(packageLineItemId ->
                                StringUtils.isNotEmpty(packageLineItemId.getItemId()) && StringUtils.isNotEmpty(packageLineItemId.getTransactionId()))
                        .filter(packageLineItemId ->
                                packageLineItemId.getItemId().equals(itemId) && packageLineItemId.getTransactionId().equals(transId)).findFirst())
                .isPresent();
    }

    private boolean filterFulfillmentByItemIdAndTransId(String itemId, String transId, MarkedAsFulfilledLineItem markedAsFulfilledLineItem) {
        return Optional.ofNullable(markedAsFulfilledLineItem)
                .map(MarkedAsFulfilledLineItem::getLineItemIdentifier)
                .filter(lineItemSource ->
                        StringUtils.isNotEmpty(lineItemSource.getItemId()) && StringUtils.isNotEmpty(lineItemSource.getTransactionId()))
                .filter(lineItemSource ->
                        lineItemSource.getItemId().equals(itemId) && lineItemSource.getTransactionId().equals(transId))
                .isPresent();
    }

    protected AmountType getActualCost(PricelineTypeEnum targetType) {
        if (isCheckOutCompleted(order) && configValues.enableSalesTaxOnboardingFeature) {
            return Optional.of(this.lineItem).map(LineItem::getLineItemTotal)
                    .flatMap(total -> total.getPriceLines().stream()
                            .filter(p -> targetType.equals(p.getType())).findFirst())
                    .map(PriceLine::getAmount).map(AmountTypeUtil::getAmountType)
                    .orElse(AmountTypeUtil.getDefaultZeroAmountType(order));
        }

        return AmountTypeUtil.getDefaultZeroAmountType(order);
    }

    private boolean isCheckOutCompleted(OrderCSXType order) {
        return CheckoutStatusUtil.orderCheckoutStatus(order.getOrderStates(), order.getAttributes())
                == CompleteStatusCodeType.COMPLETE;
    }

    /**
     * For transaction price. the logic is use discountedCost, if discountedCost is not there, then use unitCost
     */
    protected AmountType getTransactionPrice(Amount unitCost, Amount discountedCost, Amount depositItemFullUnitCost) {
        // deposit may be change
        if (depositItemFullUnitCost != null && depositItemFullUnitCost.getValue() != null) {
            return AmountTypeUtil.getAmountType(depositItemFullUnitCost);
        } else if (discountedCost != null && discountedCost.getValue() != null) {
            return AmountTypeUtil.getAmountType(discountedCost);
        } else {
            return AmountTypeUtil.getAmountType(unitCost);
        }
    }

    protected AmountType getTotalPrice() {
        return GMESCosmosFieldUtil.getOrderTotal(order);
    }
}
