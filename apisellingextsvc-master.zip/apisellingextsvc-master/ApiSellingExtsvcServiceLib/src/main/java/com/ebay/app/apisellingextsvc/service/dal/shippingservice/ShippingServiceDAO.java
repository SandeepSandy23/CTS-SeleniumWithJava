package com.ebay.app.apisellingextsvc.service.dal.shippingservice;


import com.ebay.integ.dal.dao.CacheableDao;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.map.QueryEngine;

import java.util.ArrayList;
import java.util.List;

public class ShippingServiceDAO extends CacheableDao {
    private static ShippingServiceDAO m_instance = new ShippingServiceDAO();

    protected ShippingServiceDAO() {
        super(ShippingServiceKeyManager.getInstance(), "ShippingService", ShippingServiceCacheBean.getInstance());
    }

    public static ShippingServiceDAO getInstance() {
        return m_instance;
    }

    public ShippingService findByServiceId(int serviceId) throws FinderException {
        ShippingServiceDoImpl protoDO = new ShippingServiceDoImpl(this, ShippingServiceMap.getInstance());
        List result = null;
        protoDO.setShippingServiceId(serviceId);
        result = (List)this.globalCacheFetchSingle(protoDO, ShippingServiceKeyManager.KEY_BY_PK_KEY);
        return result != null ? (ShippingService)result.get(0) : null;
    }

    public List findAllDirect2DB() throws FinderException {
        QueryEngine qe = new QueryEngine();
        ArrayList results = new ArrayList(5000);
        ShippingServiceDoImpl protoDO = new ShippingServiceDoImpl(this, ShippingServiceMap.getInstance());
        qe.readMultiple(results, ShippingServiceMap.getInstance(), protoDO, ShippingServiceCodeGenMap.FINDALL, -2);
        return results;
    }
}
