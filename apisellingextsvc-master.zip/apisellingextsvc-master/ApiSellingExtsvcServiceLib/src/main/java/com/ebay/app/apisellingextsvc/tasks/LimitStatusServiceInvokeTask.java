package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.rm.limit.enforcement.types.CheckSellingLimitStatusResponse;
import ebay.apis.eblbasecomponents.ErrorType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class LimitStatusServiceInvokeTask implements Task<CheckSellingLimitStatusResponse>, ITaskResultInjectable {

    private final Map<String, Object> resultMap = new HashMap<>();
    private final String userId;
    private final IServiceInvoker<String, CheckSellingLimitStatusResponse> limitStatusInvoker;
    private final List<ErrorType> errorList;

    public LimitStatusServiceInvokeTask(
            IServiceInvoker<String, CheckSellingLimitStatusResponse> limitStatusInvoker,
            List<ErrorType> errorList, String userId) {
        this.limitStatusInvoker = limitStatusInvoker;
        this.errorList = errorList;
        this.userId = userId;
    }

    @Override
    public CheckSellingLimitStatusResponse call() {
        return this.limitStatusInvoker.getResponse(userId, null);
    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}