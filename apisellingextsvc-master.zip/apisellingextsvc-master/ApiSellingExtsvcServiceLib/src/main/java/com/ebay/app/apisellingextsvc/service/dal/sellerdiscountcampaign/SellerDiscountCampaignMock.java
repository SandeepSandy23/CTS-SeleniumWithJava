package com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign;


import com.ebay.af.common.flag.FlagMask;

import java.util.Date;


public class SellerDiscountCampaignMock implements SellerDiscountCampaign {

    private String campaignName;
    private long sellerCampaignId;

    @Override
    public long getSellerCampaignId() {
        return this.sellerCampaignId;
    }

    @Override
    public void setSellerCampaignId(long var1) {
        this.sellerCampaignId = var1;
    }

    @Override
    public long getSellerId() {
        return 0;
    }

    @Override
    public void setSellerId(long var1) {

    }

    @Override
    public int getSiteId() {
        return 0;
    }

    @Override
    public void setSiteId(int var1) {

    }

    @Override
    public String getCampaignName() {
        return this.campaignName;
    }

    @Override
    public void setCampaignName(String var1) {
        this.campaignName = var1;
    }

    @Override
    public int getCampaignType() {
        return 0;
    }

    @Override
    public void setCampaignType(int var1) {

    }

    @Override
    public int getCampaignSubType() {
        return 0;
    }

    @Override
    public void setCampaignSubType(int var1) {

    }

    @Override
    public String getCampaignDesc() {
        return null;
    }

    @Override
    public void setCampaignDesc(String var1) {

    }

    @Override
    public int getCampaignStatus() {
        return 0;
    }

    @Override
    public void setCampaignStatus(int var1) {

    }

    @Override
    public double getBudgetAmount() {
        return 0;
    }

    @Override
    public void setBudgetAmount(double var1) {

    }

    @Override
    public double getRedeemedAmount() {
        return 0;
    }

    @Override
    public void setRedeemedAmount(double var1) {

    }

    @Override
    public String getCurrencyCode() {
        return null;
    }

    @Override
    public void setCurrencyCode(String var1) {

    }

    @Override
    public int getMarketingPriority() {
        return 0;
    }

    @Override
    public void setMarketingPriority(int var1) {

    }

    @Override
    public long getCampaignFlags01() {
        return 0;
    }

    @Override
    public void setCampaignFlags01(long var1) {

    }

    @Override
    public Date getStartDate() {
        return null;
    }

    @Override
    public void setStartDate(Date var1) {

    }

    @Override
    public Date getEndDate() {
        return null;
    }

    @Override
    public boolean equalsData(Object o) {
        return false;
    }

    @Override
    public boolean hasFlag(FlagMask flagMask) {
        return false;
    }

    @Override
    public void setFlag(FlagMask flagMask, boolean b) {

    }
}
