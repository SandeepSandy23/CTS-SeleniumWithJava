package com.ebay.app.apisellingextsvc.framework.outputselector;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CustomNode {

    /**
     * Primary name to make output selector
     */
    private final String fieldName;

    /**
     * Secondary name to make output selector.  XmlElement or XmlAttribute name
     */
    private final String xmlName;

    /**
     * Serialization only get the parent class not name.
     */
    private final Class<?> clazz;
    private final CustomNode parent;
    private final List<CustomNode> children = new ArrayList<>();

    /**
     * Root Node
     */

    public CustomNode(Class<?> clazz) {
        this.clazz = clazz;
        this.fieldName = clazz.getSimpleName().toLowerCase(Locale.US);
        this.xmlName = this.fieldName;
        this.parent = null;
    }

    public CustomNode(String fieldName, String xmlName, Class<?> clazz, CustomNode parent) {
        this.fieldName = fieldName;
        this.xmlName = xmlName;
        this.clazz = clazz;
        this.parent = parent;
    }


    public CustomNode getParent() {
        return parent;
    }


    public void addChild(CustomNode child) {
        this.children.add(child);
    }

    public List<CustomNode> getChildren() {
        return children;
    }

    public Class<?> getClazz() {
        return clazz;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getXmlName() {
        return xmlName;
    }

}
