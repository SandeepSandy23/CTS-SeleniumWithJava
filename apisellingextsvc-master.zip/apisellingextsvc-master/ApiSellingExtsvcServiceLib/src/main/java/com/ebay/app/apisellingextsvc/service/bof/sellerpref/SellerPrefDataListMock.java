package com.ebay.app.apisellingextsvc.service.bof.sellerpref;

import java.util.ArrayList;
import java.util.List;

public class SellerPrefDataListMock {

    private List<SellerPrefDataMock> sellerPrefDatas = new ArrayList<>();

    public List<SellerPrefDataMock> getSellerPrefDatas() {
        return sellerPrefDatas;
    }

    public void setSellerPrefDatas(List<SellerPrefDataMock> sellerPrefDatas) {
        this.sellerPrefDatas = sellerPrefDatas;
    }
}
