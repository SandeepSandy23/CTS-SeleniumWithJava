package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import com.ebay.app.apisellingextsvc.builders.gmes.GMESOrderTransactionArrayBuilder;
import com.ebay.app.apisellingextsvc.builders.OrderBuilder;
import com.ebay.app.apisellingextsvc.builders.PaginationResultBuilder;
import com.ebay.app.apisellingextsvc.builders.proforma.ProformaOrderBuilder;
import com.ebay.app.apisellingextsvc.builders.gmes.GMESProformaOrderTransactionArrayBuilder;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.service.invokers.model.ListingActivitiesByIdsModel;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.cos.las.type.BulkUserNoteResponse;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.OrderTransactionArrayType;
import ebay.apis.eblbasecomponents.OrderTransactionType;
import ebay.apis.eblbasecomponents.OrderType;
import ebay.apis.eblbasecomponents.PaginatedOrderTransactionArrayType;
import ebay.apis.eblbasecomponents.PaginationType;
import ebay.apis.eblbasecomponents.TransactionArrayType;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


public class GMESBuildOrderTransactionTask implements Task<PaginatedOrderTransactionArrayType>, ITaskResultInjectable {

    private final Map<String, Object> resultMap = new HashMap<>();
    private final int trxVersion;
    private final ApiSellingExtSvcConfigValues configValues;
    private final PaginationType paginationType;
    private final List<DetailLevelCodeType> detailLevels;
    private final ContentResource contentResource;
    private final Integer version;
    private final SiteContext siteContext;

    public GMESBuildOrderTransactionTask(GetMyeBaySellingRequest request,
                                         PaginationType paginationType,
                                         ContentResource contentResource) {

        this.trxVersion = request.trxVersion;
        this.configValues = request.getConfigValues();
        this.paginationType = paginationType;
        this.detailLevels = request.requestType.getDetailLevel();
        this.contentResource = contentResource;
        this.version = request.trxVersion;
        this.siteContext = request.siteContext;
    }

    @Override
    public PaginatedOrderTransactionArrayType call() {
        SellerProfileDataContext dataContext =
                (SellerProfileDataContext) resultMap.get(SellerProfileDataContext.class.getName());
        ContractResponse cosmosResponse = (ContractResponse) resultMap.get(ContractResponse.class.getName());
        ListingActivitiesByIdsModel listingActivitiesByIdsModel = (ListingActivitiesByIdsModel) resultMap.get(ListingActivitiesByIdsModel.class.getName());
        BulkUserNoteResponse bulkUserNoteResponse = (BulkUserNoteResponse) resultMap.get(BulkUserNoteResponse.class.getName());

        if (cosmosResponse == null || (CollectionUtils.isNotEmpty(cosmosResponse.getMembers()) &&
                listingActivitiesByIdsModel.getItemIdListingActivityMap().isEmpty())) {
            return null;
        }

        if (CollectionUtils.isNotEmpty(cosmosResponse.getMembers())) {

            PaginatedOrderTransactionArrayType soldItems = new PaginatedOrderTransactionArrayType();
            // set order transaction array
            OrderTransactionArrayType orderTransactionArrayType = new OrderTransactionArrayType();
            List<OrderTransactionType> orderTransactionList = new ArrayList<>();

            for (ContractResponseType member : cosmosResponse.getMembers()) {
                OrderTransactionType orderTransactionType = new OrderTransactionType();
                List<TransactionType> transactionType;
                OrderType orderType;
                if (ContractResponseUtil.isOrder(member)) {
                    transactionType = new GMESOrderTransactionArrayBuilder(this, member, trxVersion, contentResource.contentHelper, this.siteContext, detailLevels, configValues, listingActivitiesByIdsModel.getItemIdListingActivityMap(), bulkUserNoteResponse, version).build();

                    if (member.getOrder().getLineItemTypes().size() > 1) { // order = more than 1 line item
                        orderType = new OrderBuilder(this, trxVersion, configValues, member, this.siteContext).build();
                        orderType.setTransactionArray(new TransactionArrayType());
                        if (CollectionUtils.isNotEmpty(transactionType)) {
                            orderType.getTransactionArray().getTransaction().addAll(transactionType);
                        }
                        orderTransactionType.setOrder(orderType);
                    } else if (member.getOrder().getLineItemTypes().size() == 1) { // transaction = 1 line item
                        if (CollectionUtils.isNotEmpty(transactionType)) {
                            orderTransactionType.setTransaction(transactionType.get(0));
                        }
                    }
                } else if (ContractResponseUtil.isProformaOrder(member)) {
                    transactionType = new GMESProformaOrderTransactionArrayBuilder(this, member, trxVersion, contentResource.contentHelper,
                            detailLevels, configValues, siteContext,
                            listingActivitiesByIdsModel.getItemIdListingActivityMap(), bulkUserNoteResponse).build();
                    if (member.getProformaOrder().getLineItemTypes().size() > 1) { // order = more than 1 line item
                        orderType = new ProformaOrderBuilder(this, member, trxVersion, configValues).build();
                        orderType.setTransactionArray(new TransactionArrayType());
                        if (CollectionUtils.isNotEmpty(transactionType)) {
                            orderType.getTransactionArray().getTransaction().addAll(transactionType);
                        }
                        orderTransactionType.setOrder(orderType);
                    } else if (member.getProformaOrder().getLineItemTypes().size() == 1) { // transaction = 1 line item
                        if (CollectionUtils.isNotEmpty(transactionType)) {
                            orderTransactionType.setTransaction(transactionType.get(0));
                        }
                    }
                }
                orderTransactionList.add(orderTransactionType);
            }
            orderTransactionArrayType.getOrderTransaction().addAll(orderTransactionList);
            soldItems.setOrderTransactionArray(orderTransactionArrayType);
            // set pagination result
            soldItems.setPaginationResult(new PaginationResultBuilder().buildCosmosPagination(cosmosResponse, paginationType));
            return soldItems;

        }

     return null;

    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}