package com.ebay.app.apisellingextsvc.service.dal.shippingcarrier;

import com.ebay.integ.dal.cache2.KeyDefinition;
import com.ebay.integ.dal.cache2.KeyManager;
import com.ebay.integ.dal.cache2.SimpleCollectionKeyDefinition;
import com.ebay.kernel.util.JdkUtil;

public class ShippingCarrierKeyManager implements KeyManager {
    public static final int carrierEnumId = 0;

    private static final long serialVersionUID = 1L;
    private static volatile ShippingCarrierKeyManager m_instance = null;
    private KeyDefinition[] m_keyDefinitionList;

    private ShippingCarrierKeyManager() {
        this.init();
    }

    public static ShippingCarrierKeyManager getInstance() {
        if (m_instance == null) {
            synchronized (ShippingCarrierKeyManager.class) {
                if (m_instance == null) {
                    m_instance = new ShippingCarrierKeyManager();
                }
            }
        }
        return m_instance;
    }

    private void init() {
        String[] keyFieldNameList2 = new String[] {"m_carrierEnumId"};
        this.m_keyDefinitionList =
              new KeyDefinition[] {
                    new SimpleCollectionKeyDefinition(carrierEnumId, keyFieldNameList2, JdkUtil.forceInit(ShippingCarrierCodeGenDoImpl.class))};
    }

    public KeyDefinition getKeyDefinition(int id) {
        return this.m_keyDefinitionList[id];
    }

    public KeyDefinition[] getKeyDefinitionList() {
        return this.m_keyDefinitionList;
    }
}
