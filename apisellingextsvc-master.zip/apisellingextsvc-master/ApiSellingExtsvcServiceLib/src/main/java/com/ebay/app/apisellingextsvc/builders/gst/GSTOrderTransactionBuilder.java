package com.ebay.app.apisellingextsvc.builders.gst;

import com.ebay.app.apisellingextsvc.builders.ContainingOrderBuilder;
import com.ebay.app.apisellingextsvc.builders.DigitalDeliverSelectedBuilder;
import com.ebay.app.apisellingextsvc.builders.EBayCollectAndRemitTaxesBuilder;
import com.ebay.app.apisellingextsvc.builders.EbayCollectAndRemitTaxBuilder;
import com.ebay.app.apisellingextsvc.builders.MonetaryDetailsBuilder;
import com.ebay.app.apisellingextsvc.builders.MultiLegShippingDetailsBuilder;
import com.ebay.app.apisellingextsvc.builders.OrderAdjustmentAmountBuilder;
import com.ebay.app.apisellingextsvc.builders.OrderExternalTransactionBuilder;
import com.ebay.app.apisellingextsvc.builders.OrderShippingAddressBuilder;
import com.ebay.app.apisellingextsvc.builders.OrderShippingServiceSelectedBuilder;
import com.ebay.app.apisellingextsvc.builders.OrderTransactionBuilder;
import com.ebay.app.apisellingextsvc.builders.PaymentHoldDetailsBuilder;
import com.ebay.app.apisellingextsvc.builders.PickupMethodSelectedBuilder;
import com.ebay.app.apisellingextsvc.builders.ProgramBuilder;
import com.ebay.app.apisellingextsvc.builders.SellerDiscountsBuilder;
import com.ebay.app.apisellingextsvc.builders.TaxesBuilder;
import com.ebay.app.apisellingextsvc.builders.TransactionShippingDetailsBuilder;
import com.ebay.app.apisellingextsvc.builders.TransactionShippingServiceSelectedBuilder;
import com.ebay.app.apisellingextsvc.builders.VariationBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.service.bof.exchangerate.ExchangeRateBofImpl;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserInfo;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.LogisticUtil;
import com.ebay.app.apisellingextsvc.utils.MoneyExchangeHelper;
import com.ebay.app.apisellingextsvc.utils.OrderTotalFactory;
import com.ebay.app.apisellingextsvc.utils.ProgramUtil;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.lib.lasng.model.CoreInfo;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.Fees;
import com.ebay.order.common.v1.LineItem;
import com.ebay.order.common.v1.Order;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.order.common.v1.ProgramEnumType;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.AddressType;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.DepositTypeCodeType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.GiftSummaryType;
import ebay.apis.eblbasecomponents.PickupDetailsType;
import ebay.apis.eblbasecomponents.PickupMethodSelectedType;
import ebay.apis.eblbasecomponents.PickupOptionsType;
import ebay.apis.eblbasecomponents.ShippingServiceOptionsType;
import ebay.apis.eblbasecomponents.TransactionType;
import ebay.apis.eblbasecomponents.DepositTypeCodeType;
import ebay.apis.eblbasecomponents.TaxesType;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class GSTOrderTransactionBuilder extends OrderTransactionBuilder {
    private final boolean includeFinalValueFee;
    private final List<DetailLevelCodeType> detailLevels;
    private final ContractResponseType contractResponseType;
    private final Map<String, UserInfo> buyerResponseMap;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final IContentHelper contentHelper;
    private final boolean includeContainingOrder;
    private final Map<String, Double> feedbackPercentageMap;
    private final SellerProfileDataContext dataContext;
    private final Map<String, Item> svlsItemInfoMap;

    public GSTOrderTransactionBuilder(Task<?> task,
                                      ContractResponseType contractResponseType,
                                      OrderCSXType order,
                                      LineItemXType lineItem,
                                      SiteContext siteContext,
                                      IContentHelper contentHelper,
                                      List<DetailLevelCodeType> detailLevels,
                                      ApiSellingExtSvcConfigValues configValues,
                                      int trxVersion,
                                      SellerProfileDataContext dataContext,
                                      Map<String, UserInfo> buyerResponseMap,
                                      boolean includeFinalValueFee,
                                      boolean includeContainingOrder,
                                      Map<Long, ListingActivity> itemIdListingActivityMap,
                                      Map<String, Double> feedbackPercentageMap,
                                      Map<String, Item> svlsItemInfoMap) {
        super(task, order, lineItem, siteContext, configValues, trxVersion);
        this.contractResponseType = contractResponseType;
        this.contentHelper = contentHelper;
        this.detailLevels = detailLevels;
        this.buyerResponseMap = buyerResponseMap;
        this.includeFinalValueFee = includeFinalValueFee;
        this.includeContainingOrder = includeContainingOrder;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.feedbackPercentageMap = feedbackPercentageMap;
        this.svlsItemInfoMap = svlsItemInfoMap;
        this.dataContext = dataContext;
    }

    @Override
    protected TransactionType doBuild() {
        TransactionType transaction = super.doBuild();
        transaction.setGuaranteedShipping(isGuaranteedShipping());
        AmountType finalValueFee = getFinalValueFee();
        transaction.setPaymentHoldDetails(new PaymentHoldDetailsBuilder(task, order).build());
        transaction.setTransactionPrice(
                getTransactionPrice(lineItem.getUnitCost(), lineItem.getDiscountedCost(), lineItem.getDepositItemFullUnitCost()));
        transaction.setConvertedTransactionPrice(MoneyExchangeHelper.exchange(new ExchangeRateBofImpl(), transaction.getTransactionPrice(), siteContext.viewingSiteId));
        transaction.setExtendedOrderID(
                VersionConstant.isGreaterEqualThan(trxVersion, ApiSellingExtSvcConstants.COMPATIBILITY_LEVEL_893) ? order.getOrderId() : null);
        //COMS-11907 In new trading api, just set the transaction id to this field.
        transaction.setInventoryReservationID(transaction.getTransactionID());
        PickupMethodSelectedType pickupMethodSelectedType = new PickupMethodSelectedBuilder(task, order.getLogistics()).build();
        transaction.setLogisticsPlanType((pickupMethodSelectedType != null) ? LogisticUtil.getLogisticsPlanType(pickupMethodSelectedType, trxVersion) : null);
        transaction.setFinalValueFee(finalValueFee);
        transaction.setBestOfferSale(getBestOfferStatus(lineItem.getAttribute()));
        transaction.setEBayPlusTransaction(isEbayPlusTransaction(lineItem.getPrograms()));
        transaction.setTransactionSiteID(getTransactionSiteId(order.getAttributes(), ApiSellingExtSvcConstants.ATTR_CHECKOUT_SITE_ID));
        transaction.setGuaranteedDelivery(isGuaranteedDelivery(lineItem.getLineItemFlags()));
        transaction.setActualHandlingCost(getActualCost(PricelineTypeEnum.HANDLING_COST));
        transaction.setActualShippingCost(getActualCost(PricelineTypeEnum.SHIPPING_COST));
        transaction.setIntangibleItem(false); // Default to false
        transaction.setBuyerCheckoutMessage(getBuyerCheckoutMessage());
        if (transaction.getPaymentHoldDetails() != null) {
            transaction.getPaymentHoldDetails().setNumOfReqSellerActions(1);
        }
        transaction.setItem(new GSTOrderItemBuilder(task, lineItem, order.getLogistics(), configValues, finalValueFee, itemIdListingActivityMap,svlsItemInfoMap, detailLevels, contentHelper).build());
        transaction.setStatus(new GSTTransactionStatusBuilder(task, order, lineItem, trxVersion).build());
        transaction.setBuyer(new GSTBuyerBuilder(task, trxVersion, order, configValues, contentHelper,
                order.getBuyer(), lineItem.getDatePurchased().getValue(), dataContext, siteContext, buyerResponseMap, order.getAddress(), detailLevels, feedbackPercentageMap).build());
        String transactionSiteId = AttributeUtil.findAttributeValue(lineItem.getAttribute(), ApiSellingExtSvcConstants.ATTR_TRANS_SITE_ID);
        transaction.setBuyerGuaranteePrice(AmountTypeUtil.getAmountType(Integer.parseInt(transactionSiteId), ApiSellingExtSvcConstants.BUYER_GUARANTEE_PRICE));
        // Transaction Containers
        transaction.setVariation(new VariationBuilder(task, configValues,
                lineItem.getItemSkuDetails(), lineItem.getInventoryDetails(), lineItem.getAttribute(), lineItem.getTitle()).build());
        transaction.setEBayCollectAndRemitTax(new EbayCollectAndRemitTaxBuilder(task, order.getAttributes(), trxVersion).build());
        transaction.setShippingServiceSelected(new TransactionShippingServiceSelectedBuilder(task,
                trxVersion, order, lineItem).build());
        transaction.setGiftSummary(getGiftSummary());
        boolean isEbayCollectAndRemitTax = Optional.ofNullable(transaction)
                        .map(TransactionType::isEBayCollectAndRemitTax)
                        .orElse(false);

        if(!isEbayCollectAndRemitTax) {
            transaction.setTaxes(new TaxesBuilder(task, order, lineItem, trxVersion, order.getBuyer(), configValues).build());
        }
        else {
            transaction.setTaxes(new TaxesType());
        }
        transaction.setEBayCollectAndRemitTaxes(new EBayCollectAndRemitTaxesBuilder(task, order, lineItem, trxVersion,
                order.getBuyer(), configValues ).build());
        transaction.setShippingDetails(new TransactionShippingDetailsBuilder(task, order, lineItem, configValues, dataContext.getShippingCarrierBof(), trxVersion,
                itemIdListingActivityMap, svlsItemInfoMap).build());
        transaction.setSellerDiscounts(new SellerDiscountsBuilder(task, lineItem, trxVersion, order.getLogistics()).build());

        transaction.setMonetaryDetails(new MonetaryDetailsBuilder(task, order, detailLevels).build());
        transaction.getExternalTransaction().addAll(new OrderExternalTransactionBuilder(task, order,
                detailLevels, trxVersion).build());
        transaction.setInvoiceSentTime(getInvoiceSentTime());
        transaction.setPickupMethodSelected(pickupMethodSelectedType);
        transaction.setProgram(new ProgramBuilder(task, order, detailLevels).build());
        transaction.setDigitalDeliverySelected(new DigitalDeliverSelectedBuilder(task, order.getLogistics(), lineItem,
                trxVersion).build());
        transaction.setPickupDetails(getPickupDetails());
        if (transaction.getPickupDetails() != null) {
            transaction.setIsMultiLegShipping(false);
        }
        transaction.setIsMultiLegShipping(isMultiLegShipping(order.getLogistics()));
        transaction.setDepositType(getDepositType());

        //Containing Order
        String lineItemIdForFilter = CommonUtil.getLineItemIdForFilter(contractResponseType);
        if (includeContainingOrder)
            transaction.setContainingOrder(new ContainingOrderBuilder(task,contractResponseType).build());

        AddressType shipmentAddress = new OrderShippingAddressBuilder(task, order, siteContext, contentHelper).build();
        ShippingServiceOptionsType shippingServiceOptionsType = new OrderShippingServiceSelectedBuilder(task, order,
                lineItemIdForFilter, trxVersion).build();
        if (transaction.isIsMultiLegShipping() != null && transaction.isIsMultiLegShipping())
            transaction.setMultiLegShippingDetails(new MultiLegShippingDetailsBuilder(task, order.getLogistics(), order.getLineItemTypes(), dataContext.getShippingServiceBof(), shippingServiceOptionsType, shipmentAddress).build());
        // SOAPI-881 - Adding amounts and converted amount
        AmountType adjustmentAmount = new OrderAdjustmentAmountBuilder(task, order).build();
        AmountType amountPaid = OrderTotalFactory.getAmountPaid(task, order, configValues, trxVersion, "");
        transaction.setAdjustmentAmount(adjustmentAmount);
        transaction.setConvertedAdjustmentAmount(MoneyExchangeHelper.exchange(dataContext.getExchangeRateBof(), adjustmentAmount, siteContext.viewingSiteId));
        transaction.setAmountPaid(amountPaid);
        transaction.setConvertedAmountPaid(MoneyExchangeHelper.exchange(dataContext.getExchangeRateBof(), amountPaid, siteContext.viewingSiteId));

        return  transaction;
    }

    private XMLGregorianCalendar getInvoiceSentTime() {
        // https://jirap.corp.ebay.com/browse/LUXIBLES-1102
        List<Attribute> attribues =  Optional.ofNullable(this.lineItem).map(LineItem::getAttribute).orElse(null);
        return AttributeUtil.findAttribute(attribues, ApiSellingExtSvcConstants.INVOICE_TIME)
                .map(Attribute::getValue)
                .map(DateUtil::convertToXMLGregorianCalendar)
                .orElse(null);
    }

    private boolean getGift() {
        return Optional.ofNullable(this.lineItem).map(LineItem::getGiftSummary).orElse(null) != null;
    }

    private GiftSummaryType getGiftSummary() {
        Text giftMessage = Optional.ofNullable(this.lineItem)
                .map(LineItem::getGiftSummary)
                .map(com.ebay.order.common.v1.GiftSummaryType::getGiftMessage)
                .orElse(null);

        if (giftMessage != null) {
            GiftSummaryType summaryType = new GiftSummaryType();
            summaryType.setMessage(String.valueOf(giftMessage));
            return summaryType;
        }
        return null;
    }

    private PickupDetailsType getPickupDetails() {

        if(trxVersion < 831)
            return null;

        PickupDetailsType pickupDetailsType = new PickupDetailsType();
        PickupOptionsType pickupOptionsType = new PickupOptionsType();
        pickupOptionsType.setPickupPriority(ApiSellingExtSvcConstants.PICKUP_DEFAULT_PRIORITY);

        if (ProgramUtil.containsProgram(order, ProgramEnumType.PICK_UP_DROP_OFF)) {
            pickupOptionsType.setPickupMethod(ApiSellingExtSvcConstants.METHOD_CODE_PICKUP);
            pickupDetailsType.getPickupOptions().add(pickupOptionsType);
            return pickupDetailsType;
        }

        if (ProgramUtil.containsProgram(order, ProgramEnumType.BOPIS)) {
            pickupOptionsType.setPickupMethod(ApiSellingExtSvcConstants.BOPIS_PICKUP_METHOD);
            pickupDetailsType.getPickupOptions().add(pickupOptionsType);
            return pickupDetailsType;
        }

        return null;
    }

    private String getBuyerCheckoutMessage() {
        return Optional.of(order).map(OrderCSXType::getBuyerNotesToSeller).map(Text::getContent).orElse(null);
    }

    private String getExtendedOrderID() {
        return order.getOrderId();
    }

    private AmountType getFinalValueFee() {
        AmountType amountType = null;
        if (includeFinalValueFee && order.getFees() != null) {
            String lineItemId = lineItem.getLineItemId();
            Optional<PriceLine> priceLine = Optional.of(order).map(Order::getFees).map(Fees::getLineItems)
                    .flatMap(item -> item.stream()
                            .filter(i -> lineItemId.equals(i.getIdentifier().getExtendedIdentifier1()))
                            .flatMap(i -> i.getLineItemFeeTotal().getPriceLines().stream())
                            .filter(p -> PricelineTypeEnum.FINAL_VALUE_FEE_VARIABLE.equals(p.getType()))
                            .findFirst());
            if (priceLine.isPresent()) {
                amountType = AmountTypeUtil.getAmountType(priceLine.get().getAmount());
            }
        }
        return amountType;
    }

    private DepositTypeCodeType getDepositType() {
        boolean isMotorDepositItem = AttributeUtil.findAttribute(lineItem.getAttribute(), ApiSellingExtSvcConstants.MOTOR_DEPOSIT_ITEM)
                .map(Attribute::getValue).map(Boolean::parseBoolean).orElse(false);
        return isMotorDepositItem ? DepositTypeCodeType.OTHER_METHOD: DepositTypeCodeType.NONE;
    }

}