package com.ebay.app.apisellingextsvc.service.bof.shippingcarrier;

import java.util.List;

public class ShippingCarrierListMock {
    private List<ShippingCarrier> shippingCarriers;

    public List<ShippingCarrier> getShippingCarriers() {
        return shippingCarriers;
    }

    public void setShippingCarriers(
          List<ShippingCarrier> shippingCarriers) {
        this.shippingCarriers = shippingCarriers;
    }

    public static class ShippingCarrier implements com.ebay.app.apisellingextsvc.service.dal.shippingcarrier.ShippingCarrier {

        private int carrierEnumId;
        private String shippingCarrierName;

        public int getCarrierEnumId() {
            return carrierEnumId;
        }

        public void setCarrierEnumId(int carrierEnumId) {
            this.carrierEnumId = carrierEnumId;
        }

        public String getShippingCarrierName() {
            return shippingCarrierName;
        }

        public void setShippingCarrierName(String shippingCarrierName) {
            this.shippingCarrierName = shippingCarrierName;
        }
    }
}
