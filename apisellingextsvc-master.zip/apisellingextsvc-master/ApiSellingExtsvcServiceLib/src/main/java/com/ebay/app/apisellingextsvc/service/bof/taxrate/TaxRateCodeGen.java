package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import com.ebay.integ.dal.DalDOI;

import java.util.Date;

public interface TaxRateCodeGen extends DalDOI {
    int getSiteId();

    void setSiteId(int var1);

    int getCountryId();

    void setCountryId(int var1);

    double getTaxPercentage();

    void setTaxPercentage(double var1);

    Date getEffectiveDate();

    void setEffectiveDate(Date var1);

    Date getTerminationDate();

    void setTerminationDate(Date var1);

    String getUserState();

    void setUserState(String var1);
}
