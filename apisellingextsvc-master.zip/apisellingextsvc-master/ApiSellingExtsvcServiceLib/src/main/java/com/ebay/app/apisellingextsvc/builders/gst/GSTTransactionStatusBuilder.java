package com.ebay.app.apisellingextsvc.builders.gst;

import com.ebay.app.apisellingextsvc.builders.TransactionStatusBuilder;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.mappers.InquiryStatusMapper;
import com.ebay.app.apisellingextsvc.mappers.ReturnStatusMapper;
import com.ebay.app.apisellingextsvc.utils.CheckoutStatusUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.InquiryStatusTypeEnum;
import com.ebay.order.common.v1.ReturnStatusTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.BuyerPaymentMethodCodeType;
import ebay.apis.eblbasecomponents.CheckoutStatusCodeType;
import ebay.apis.eblbasecomponents.CompleteStatusCodeType;
import ebay.apis.eblbasecomponents.InquiryStatusCodeType;
import ebay.apis.eblbasecomponents.PaymentStatusCodeType;
import ebay.apis.eblbasecomponents.ReturnStatusCodeType;
import ebay.apis.eblbasecomponents.TransactionStatusType;

import javax.annotation.Nonnull;

public class GSTTransactionStatusBuilder extends TransactionStatusBuilder {

    private final InquiryStatusTypeEnum inquiryStatus;
    private final ReturnStatusTypeEnum returnStatus;
    private OrderCSXType order;
    private ProformaOrderXType proformaOrderXType;
    private final int trxVersion;

    public GSTTransactionStatusBuilder(Task task,
                                       OrderCSXType order,
                                       @Nonnull LineItemXType lineItem,
                                       int trxVersion) {
        super(task, order);
        inquiryStatus = lineItem.getInquiryStatus();
        returnStatus = lineItem.getReturnStatus();
        this.order = order;
        this.trxVersion = trxVersion;
    }

    public GSTTransactionStatusBuilder(Task task,
                                       ProformaOrderXType order,
                                       @Nonnull ProformaOrderLineItemXType lineItem,
                                       int trxVersion) {
        super(task, order);
        inquiryStatus = lineItem.getInquiryStatus();
        returnStatus = lineItem.getReturnStatus();
        this.proformaOrderXType = order;
        this.trxVersion = trxVersion;
    }

    @Override
    protected TransactionStatusType doBuild() {
        TransactionStatusType status = super.doBuild();
        if (VersionConstant.isGreaterEqualThan(trxVersion, VersionConstant.SHOW_TRANS_INQUIRY_STATUS_VERSION)) {
            status.setInquiryStatus(getInquiryStatus());
            status.setReturnStatus(getReturnStatus(trxVersion));

            boolean isInquiryStatusEmptyOrInvalid = status.getInquiryStatus() == null
                    || status.getInquiryStatus() == InquiryStatusCodeType.INVALID
                    || status.getInquiryStatus() == InquiryStatusCodeType.NOT_APPLICABLE;
            ;

            boolean isReturnStatusEmptyOrInvalid = status.getReturnStatus() == null
                    || status.getReturnStatus() == ReturnStatusCodeType.INVALID
                    || status.getReturnStatus() == ReturnStatusCodeType.NOT_APPLICABLE;

            //in apixoio, if ebay_checkout_trans.post_transaction_statu is 0 or -1, then set both field as NOT_APPLICABLE
            if (isInquiryStatusEmptyOrInvalid && isReturnStatusEmptyOrInvalid) {
                status.setInquiryStatus(InquiryStatusCodeType.NOT_APPLICABLE);
                status.setReturnStatus(ReturnStatusCodeType.NOT_APPLICABLE);
            }
        }

        if (order != null) {
            CompleteStatusCodeType checkoutStatus = CheckoutStatusUtil.orderCheckoutStatus(
                    order.getOrderStates(), order.getAttributes());
            status.setCompleteStatus(checkoutStatus);
            status.setCheckoutStatus(CheckoutStatusUtil.checkoutStatusCode(checkoutStatus));
            status.setBuyerSelectedShipping(null);
            status.setLastTimeModified(DateUtil.getLastModifiedTime(order, null));
            status.setPaymentMethodUsed(PaymentUtil.getPaymentMethod(order.getPayments(), order, null, trxVersion));
            status.setPaymentInstrument(PaymentUtil.getPaymentInstrument(order.getPayments(), trxVersion));
            // SOAPI-864 : Add default values for deprecated fields. Default value - false
            status.setIntegratedMerchantCreditCardEnabled(false);
            status.setEBayPaymentStatus(PaymentUtil.getPaymentStatusCodeType(order.getPayments()));
            status.setBuyerSelectedShipping(true);
        } else if (proformaOrderXType != null) {
            status.setCompleteStatus(CompleteStatusCodeType.INCOMPLETE);
            status.setCheckoutStatus(CheckoutStatusCodeType.CHECKOUT_INCOMPLETE);
            status.setBuyerSelectedShipping(null);
            status.setLastTimeModified(DateUtil.getLastModifiedTime(null, proformaOrderXType));
            status.setPaymentMethodUsed(BuyerPaymentMethodCodeType.NONE);
            status.setPaymentInstrument(PaymentUtil.getPaymentInstrument(proformaOrderXType.getPayments(), trxVersion));
            // SOAPI-864 : Add default values for deprecated fields
            status.setIntegratedMerchantCreditCardEnabled(false);
            status.setEBayPaymentStatus(PaymentStatusCodeType.NO_PAYMENT_FAILURE);
            status.setBuyerSelectedShipping(false);
        }

        return status;
    }

    /**
     * This field gives the status of a buyer's Item Not Received (INR) Inquiry. This field is only returned if the buyer has created an INR Inquiry
     * through the site or through the Post-Order API.
     */
    private InquiryStatusCodeType getInquiryStatus() {
        return InquiryStatusMapper.map(inquiryStatus);
    }

    private ReturnStatusCodeType getReturnStatus(int trxVersion) {
        return ReturnStatusMapper.map(returnStatus, trxVersion);
    }
}
