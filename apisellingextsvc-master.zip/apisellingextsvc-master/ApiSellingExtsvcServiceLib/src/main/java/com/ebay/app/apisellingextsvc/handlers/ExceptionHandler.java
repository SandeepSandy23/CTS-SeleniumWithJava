package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.common.exception.ApplicationException;
import com.ebay.app.apisellingextsvc.content.IContentManager;
import com.ebay.app.apisellingextsvc.context.ErrorMessage;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import ebay.apis.eblbasecomponents.ErrorParameterType;
import ebay.apis.eblbasecomponents.ErrorType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import javax.ws.rs.core.Response;

import org.apache.commons.collections.CollectionUtils;

public class ExceptionHandler {
    private static final List<String> REPLACEABLE_VALUE = Arrays.asList("replaceable_value_1", "replaceable_value_2",  "replaceable_value_3");

    public static ApplicationException getException(ErrorType error) {
        return new ApplicationException(Response.Status.OK, error);
    }

    public static ApplicationException getException(ApplicationError error,  IContentManager contentManager) {
        return new ApplicationException(Response.Status.OK, getError(error, contentManager, null, (String) null));
    }
    /**
     * Application will terminate with throw Exception
     */

    public static void throwException(ApplicationError error, IContentManager contentManager) {
        throw getException(getError(error, contentManager, null, (String) null));
    }

    /**
     * Application will terminate with throw Exception
     */

    public static void throwException(ApplicationError error, IContentManager contentManager, List<String> replaceStr,
                                      String... errorParameterTypeList) {
        throw getException(getError(error, contentManager, replaceStr, errorParameterTypeList));
    }

    public static void throwException(ApplicationError error, IContentManager contentManager, String replaceStr, String... errorParameterTypeList) {
        throw getException(getError(error, contentManager, Collections.singletonList(replaceStr), errorParameterTypeList));
    }

    public static void logException(List<ErrorType> errorTypeList, ApplicationError error, IContentManager contentManager) {
        errorTypeList.add(getError(error, contentManager, null, (String) null));
    }

    public static void logException(List<ErrorType> errorTypeList, ApplicationError error, IContentManager contentManager, String replaceStr,
                                    String... errorParameterTypeList) {
        errorTypeList.add(getError(error, contentManager, Collections.singletonList(replaceStr), errorParameterTypeList));
    }

    public static void logException(List<ErrorType> errorTypeList, ApplicationError error, IContentManager contentManager, List<String> replaceStr,
                                    String... errorParameterTypeList) {
        errorTypeList.add(getError(error, contentManager, replaceStr, errorParameterTypeList));
    }

    private static ErrorType getError(ApplicationError appError, IContentManager contentManager, List<String> replaceStr,
                                      String... errorParameterTypeList) {
        ErrorType err = new ErrorType();
        err.setErrorCode(appError.getErrorCode());
        // todo localization, replace value does not need to translate
        Map<String, String> replaceMap = new ConcurrentHashMap<>();
        if (CollectionUtils.isNotEmpty(replaceStr)) {
            for (int i = 0; i < Math.min(replaceStr.size(), REPLACEABLE_VALUE.size()); i++) {
                // May replace multiple value in the future
                replaceMap.put(REPLACEABLE_VALUE.get(i), replaceStr.get(i));
            }
        }
        ErrorMessage errorMessage = contentManager.getErrorMessage(appError.getContentKey(), replaceMap);
        err.setShortMessage(errorMessage.shortMessage);
        err.setLongMessage(errorMessage.longMessage);

        err.setSeverityCode(appError.getSeverityCode());
        err.setErrorClassification(appError.getErrorClassificationCodeType());
        if (errorParameterTypeList != null && errorParameterTypeList.length != 0) {
            int id = 0;
            for (String s : errorParameterTypeList) {
                if (s != null) {
                    err.getErrorParameters().add(getErrorParameterType(id++, s));
                }
            }
        }
        return err;
    }

    private static ErrorParameterType getErrorParameterType(int id, String val) {
        ErrorParameterType errParam = new ErrorParameterType();
        errParam.setParamID(String.valueOf(id));
        errParam.setValue(val);
        return errParam;
    }
}
