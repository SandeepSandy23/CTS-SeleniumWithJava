package com.ebay.app.apisellingextsvc.builders.gst;

import com.ebay.app.apisellingextsvc.builders.BuyerBuilder;
import com.ebay.app.apisellingextsvc.builders.OrderShippingAddressBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.enums.ContentBundleEnum;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.Address;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.IndividualIdentityProfile;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserInfo;
import com.ebay.app.apisellingextsvc.utils.AddressHelper;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.EiasTokenUtil;
import com.ebay.app.apisellingextsvc.utils.SitePolicyUtil;
import com.ebay.app.apisellingextsvc.utils.TypeCastUtil;
import com.ebay.app.apisellingextsvc.utils.UserUtil;
import com.ebay.app.apisellingextsvc.utils.VatStatusUtil;
import com.ebay.app.apisellingextsvc.utils.XmlUtil;
import com.ebay.cos.type.v3.base.CountryCodeEnum;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.UserCS;
import com.ebay.globalenv.policy.SitePolicy;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.Identifier;
import com.ebay.order.common.v1.OrderAddressType;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AddressType;
import ebay.apis.eblbasecomponents.BuyerType;
import ebay.apis.eblbasecomponents.CountryCodeType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.TaxIdentifierType;
import ebay.apis.eblbasecomponents.UserType;
import ebay.apis.eblbasecomponents.ValueTypeCodeType;
import org.apache.commons.lang3.StringUtils;
import shaded.com.nimbusds.oauth2.sdk.util.MapUtils;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

public class GSTBuyerBuilder extends BuyerBuilder {
    private final String USERID_LAST_CHANGE = "USERID_LAST_CHANGE";
    private final UserCS user;
    private final int trxVersion;
    private final ApiSellingExtSvcConfigValues configValues;
    private final SellerProfileDataContext dataContext;
    private final List<OrderAddressType> orderAddressTypeList;
    private final IContentHelper contentHelper;
    private final Map<String, UserInfo> buyerResponseMap;
    private final Map<String, Double> feedbackPercentageMap;
    private final SiteContext siteContext;
    private final OrderCSXType order;

    public GSTBuyerBuilder(Task<?> task,
                           int trxVersion,
                           OrderCSXType order,
                           ApiSellingExtSvcConfigValues configValues,
                           IContentHelper contentHelper,
                           UserCS user,
                           Date lastTransactedDate,
                           SellerProfileDataContext dataContext,
                           SiteContext siteContext,
                           Map<String, UserInfo> buyerResponseMap,
                           List<OrderAddressType> orderAddressTypeList,
                           List<DetailLevelCodeType> detailLevels,
                           Map<String, Double> feedbackPercentageMap) {
        super(task, trxVersion, configValues, contentHelper, user, lastTransactedDate, orderAddressTypeList, detailLevels);
        this.user = user;
        this.order = order;
        this.contentHelper = contentHelper;
        this.trxVersion = trxVersion;
        this.configValues = configValues;
        this.dataContext = dataContext;
        this.orderAddressTypeList = orderAddressTypeList;
        this.buyerResponseMap = buyerResponseMap;
        this.feedbackPercentageMap = feedbackPercentageMap;
        this.siteContext = siteContext;
    }

    @Override
    protected UserType doBuild() {
        UserType buyer = super.doBuild();
        if (buyer == null) return null;
        String buyerId = user.getUserIdentifier().getUserId();
        UserInfo userInfo = buyerResponseMap.get(buyerId);
        buyer.setAboutMePage(Boolean.FALSE);
        buyer.setEIASToken(Optional.ofNullable(userInfo).map(UserInfo::getInternalId).map(EiasTokenUtil::encode).orElse(null));
        buyer.setFeedbackScore(user.getFeedbackScore());
        if (MapUtils.isNotEmpty(feedbackPercentageMap) && feedbackPercentageMap.get(buyerId) != null) {
            buyer.setPositiveFeedbackPercent(TypeCastUtil.setDoubleWithSingleDecimal(feedbackPercentageMap.get(buyerId)).floatValue());
        }
        buyer.setEBayGoodStanding(Boolean.TRUE);
        buyer.setNewUser(UserUtil.isNewUser(Optional.ofNullable(userInfo).map(UserInfo::getCreationDate).orElse(null), null));
        //Adding deprecated fields - Remove these fields after deco team informed to clients
        buyer.setIDVerified(Boolean.FALSE); //Using default value
        //Registration address to be shown only for DE registered buyer
        if (userInfo != null && userInfo.getRegistrationSiteId().equals(configValues.siteApprovedForBuyerRegistrationAddress))
            buyer.setRegistrationAddress(populateGSTRegisteredAddress(userInfo));

        buyer.setRegistrationDate(Optional.ofNullable(userInfo).map(UserInfo::getCreationDate).map(DateUtil::convertToXMLGregorianCalendar)
                .orElse(null));
        buyer.setSite(UserUtil.getUserSite(userInfo));
        buyer.setStatus(UserUtil.getUserStatus(userInfo));
        buyer.setUserIDChanged(UserUtil.isUserIdChanged(userInfo, USERID_LAST_CHANGE));
        String userIdLastChangedDate = UserUtil.getValueFromExtensions(userInfo, USERID_LAST_CHANGE);
        buyer.setUserIDLastChanged(UserUtil.getUserIdLastChangedDate(userIdLastChangedDate));

        if (VersionConstant.isGreaterEqualThan(trxVersion, VersionConstant.VERSION_SME_CHANGES)) {
            buyer.setUserFirstName(XmlUtil.cleanInvalidXmlChars(user.getFirstName(), StringUtils.SPACE));
            buyer.setUserLastName(XmlUtil.cleanInvalidXmlChars(user.getLastName(), StringUtils.SPACE));
        }

        if (dataContext != null && VersionConstant.isGreaterEqualThan(trxVersion, VersionConstant.VERSION_BUYER_VATSTATUS)) {
            buyer.setVATStatus(VatStatusUtil.getVatStatusForUser(dataContext.getTaxRateBof(), configValues, user));
        }

        if (userInfo != null && configValues.taxIdentifierList.contains(userInfo.getRegistrationSiteId()) &&
            buyer.getBuyerInfo() != null && buyer.getBuyerInfo().getBuyerTaxIdentifier() != null) {
            setBuyerTaxIdentifier(buyer.getBuyerInfo());
        }
        if (buyer.getBuyerInfo() != null && buyer.getBuyerInfo().getShippingAddress() != null) {
            setBuyerShippingAddress(buyer.getBuyerInfo());
        }
        buyer.setUserAnonymized(Boolean.FALSE); //Default false
        return buyer;
    }

    private void setBuyerShippingAddress(BuyerType buyerType) {
        OrderAddressType buyerAddressType =
                AddressHelper.getOrderAddressType(order.getAddress(), com.ebay.order.common.v1.AddressType.BUYER_SHIPPING_ADDRESS);
        buyerType.setShippingAddress(handleDefaultProgramShippingAddress(buyerAddressType));
    }

    private AddressType handleDefaultProgramShippingAddress(OrderAddressType from) {
        AddressType shipAddress = AddressHelper.getAddressType(order, from,
                com.ebay.order.common.v1.AddressType.BUYER_SHIPPING_ADDRESS, this.contentHelper);
        shipAddress.setPhone(formatPhone(shipAddress.getPhone()));
        if (from != null && isMarkPhoneAsInvalidRequest(from)) {
            shipAddress.setPhone(ApiSellingExtSvcConstants.INVALID_REQUEST);
        }
        return shipAddress;
    }

    private String formatPhone(String phoneNumber) {
        if (phoneNumber != null && phoneNumber.indexOf(ApiSellingExtSvcConstants.VERTICAL_LINE) > -1) {
            return phoneNumber.replace(ApiSellingExtSvcConstants.VERTICAL_LINE, ApiSellingExtSvcConstants.SPACE);
        }
        return phoneNumber;
    }

    private void setBuyerTaxIdentifier(BuyerType buyerType) {
        TaxIdentifierType taxIdentifierType = new TaxIdentifierType();
        Optional.ofNullable(user).map(UserCS::getTaxIdentifiers)
                .map(Collection::stream)
                .flatMap(Stream::findFirst)
                .ifPresent(identifier -> {
                    taxIdentifierType.setType(ValueTypeCodeType.valueOf(identifier.getType()));
                    taxIdentifierType.setID(identifier.getId());
                });
        buyerType.getBuyerTaxIdentifier().add(taxIdentifierType);
    }

    private AddressType populateGSTRegisteredAddress(UserInfo userInfo) {
        //Registration address taken from userRead response
        Address addressFromUserRead = Optional.ofNullable(userInfo).map(UserInfo::getIndividualIdentityProfile).map(IndividualIdentityProfile::getAddress)
                .orElse(null);
        if (addressFromUserRead == null) return null;
        AddressType addressType = new AddressType();
        String name = String.join(" ", Optional.of(userInfo).map(UserInfo::getIndividualIdentityProfile).map(IndividualIdentityProfile::getFirstName).orElse(null),
                Optional.of(userInfo).map(UserInfo::getIndividualIdentityProfile).map(IndividualIdentityProfile::getLastName).orElse(null));
        addressType.setName(name);
        //As per old API response, the registration address shows both street & street1 as same info.
        String streetName = Optional.of(addressFromUserRead).map(Address::getAddressLine1).orElse(null);
        addressType.setStreet(streetName);
        addressType.setStreet1(streetName);
        addressType.setCityName(Optional.of(addressFromUserRead).map(Address::getCity).orElse(null));
        addressType.setCountry(Optional.of(addressFromUserRead).map(Address::getCountry).map(CountryCodeType::fromValue)
                .orElse(CountryCodeType.ZZ));
        addressType.setCountryName(Optional.of(addressFromUserRead).map(Address::getCountry).map(CountryCodeEnum::fromValue)
                .map(CountryCodeEnum::getAlpha3IsoCountryCode)
                .map(key -> this.contentHelper.getContentManager().getText(ContentBundleEnum.CountryContent, key)).orElse(null));
        addressType.setPhone(ApiSellingExtSvcConstants.INVALID_REQUEST);
        addressType.setPostalCode(Optional.of(addressFromUserRead).map(Address::getPostalCode).orElse(null));
        return addressType;
    }

    private boolean isMarkPhoneAsInvalidRequest(OrderAddressType from) {
        try {
            return isPrivateContactInfoShow(siteContext.viewingSiteId, getBuyerRegisterSiteId())
                    && (!dataContext.isSellerRequirePhoneNumber() || !isBuyerAllowShowPhoneNumber(from));
        } catch (Exception e) {
            CalLogger.warn(OrderShippingAddressBuilder.class.getSimpleName(), e.getMessage());
        }
        return false;
    }

    private Integer getBuyerRegisterSiteId() {
        //this attribute is added in this ticket, https://jirap.corp.ebay.com/browse/COSMOS-7627
        //it merged to master in 2022/11/09, so it may produce mismatch if order create date is before this time.
        return Optional.of(order.getBuyer().getAttributes())
                .flatMap(x -> x.stream()
                        .filter(y -> y.getName().equals(ApiSellingExtSvcConstants.BUYER_REGISTRATION_SITE_ID))
                        .map(Attribute::getValue)
                        .map(Integer::parseInt).findFirst())
                .orElse(0);
    }

    private boolean isBuyerAllowShowPhoneNumber(OrderAddressType from) {
        return Optional.ofNullable(from)
                .map(OrderAddressType::getAddressId)
                .map(Identifier::getBaseIdentifier)
                .map(StringUtils::trim)
                .map(dataContext.getUserAddressIdShowPhoneMap()::get)
                .orElse(false);

    }

    public boolean isPrivateContactInfoShow(int siteId, int registerSiteId) {
        SitePolicy sitePolicy = SitePolicyUtil.getSitePolicy(siteId);
        SitePolicy regSitePolicy = SitePolicyUtil.getSitePolicy(registerSiteId);
        return regSitePolicy.antiSpamEnabled() || sitePolicy.antiSpamEnabled();
    }
}
