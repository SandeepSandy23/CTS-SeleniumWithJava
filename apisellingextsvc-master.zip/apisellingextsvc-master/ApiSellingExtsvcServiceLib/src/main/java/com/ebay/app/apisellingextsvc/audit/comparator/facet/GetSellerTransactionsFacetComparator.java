package com.ebay.app.apisellingextsvc.audit.comparator.facet;

import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.fasterxml.jackson.databind.JsonNode;

    public class GetSellerTransactionsFacetComparator extends BaseMapComparator {

        private static final String TRANSACTION_ID = "TransactionID";

        public GetSellerTransactionsFacetComparator(ExtensiveComparator comparator) {
            super(comparator);
        }

        @Override
        protected String getMapKey(JsonNode jsonNode) {
            return getValue(jsonNode.get(TRANSACTION_ID));
        }

        @Override
        public boolean qualified(JsonNode org, JsonNode tar, String path) {
            return org.isArray() && tar.isArray() && path.endsWith("Transaction");
        }


    }
