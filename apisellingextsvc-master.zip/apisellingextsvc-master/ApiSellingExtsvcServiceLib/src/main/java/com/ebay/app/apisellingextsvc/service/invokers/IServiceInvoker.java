package com.ebay.app.apisellingextsvc.service.invokers;

import javax.ws.rs.core.HttpHeaders;

public interface IServiceInvoker<T, V> {
    V getResponse(T var1, HttpHeaders var2);

}
