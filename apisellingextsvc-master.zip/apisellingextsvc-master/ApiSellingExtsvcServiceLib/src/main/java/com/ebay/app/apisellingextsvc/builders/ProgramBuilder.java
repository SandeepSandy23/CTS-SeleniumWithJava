package com.ebay.app.apisellingextsvc.builders;


import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.OrderStateTypeCS;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.*;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Optional;

public class ProgramBuilder extends BaseFacetBuilder<TransactionProgramType> {
    private OrderCSXType order;
    private ProformaOrderXType proformaOrder;
    private final List<DetailLevelCodeType> detailLevels;

    public ProgramBuilder(Task<?> task,
                          OrderCSXType order,
                          @Nullable List<DetailLevelCodeType> detailLevels) {
        super(task);
        this.order = order;
        this.detailLevels = detailLevels;
    }

    public ProgramBuilder(Task<?> task,
                          ProformaOrderXType proformaOrder,
                          @Nullable List<DetailLevelCodeType> detailLevels) {
        super(task);
        this.proformaOrder = proformaOrder;
        this.detailLevels = detailLevels;
    }


    @Override
    protected TransactionProgramType doBuild() {
        TransactionProgramType transactionProgram = null;
        if (CommonUtil.shouldExposeOnlyForReturnAll(detailLevels)) {
            transactionProgram = new TransactionProgramType();
            if (proformaOrder != null) {
                return transactionProgram;
            }
            getAuthenticityVerification().ifPresent(transactionProgram::setAuthenticityVerification);
            getFulfillment().ifPresent(transactionProgram::setFulfillment);
        }
        return transactionProgram;
    }

    private Optional<AuthenticityVerificationType> getAuthenticityVerification() {
        Optional<AuthenticityVerificationType> optionalAuthenticityVerification = Optional.empty();
        Optional<ProgramType> psaProgram = order.getPrograms().stream()
                .filter(programType -> programType.getName().equals(ApiSellingExtSvcConstants.PROGRAM_PSA)).findFirst();

        if (psaProgram.isPresent()) {
            AuthenticityVerificationType authenticityVerification = new AuthenticityVerificationType();
            authenticityVerification.setStatus(Optional.ofNullable(order.getOrderStates())
                    .map(OrderStateTypeCS::getAuthenticityVerificationStatus)
                    .orElse(ApiSellingExtSvcConstants.PENDING));

            psaProgram.get().getAttributes().stream()
                    .filter(attribute -> attribute.getName().equals(ApiSellingExtSvcConstants.ATTR_REASON))
                    .map(Attribute::getValue)
                    .findFirst()
                    .ifPresent(authenticityVerification::setOutcomeReason);

            optionalAuthenticityVerification = Optional.of(authenticityVerification);
        }

        return optionalAuthenticityVerification;
    }

    private Optional<FulfillmentType> getFulfillment() {
        Optional<FulfillmentType> optionalFulfillment = Optional.empty();
        Optional<ProgramType> fulfillmentProgram = order.getPrograms().stream()
                .filter(programType -> programType.getName().equals(ApiSellingExtSvcConstants.FULFILLMENT))
                .findFirst();
        Optional<Attribute> faultVasSubTypeNameOptional = order.getPrograms().stream()
                .filter(programType -> ProgramEnumType.VAULT.name().equals(programType.getName()))
                .flatMap(programType -> programType.getSpecifics().stream()
                        .filter(attribute -> attribute.getName().equals(ApiSellingExtSvcConstants.VAS_SUB_TYPE_NAME)))
                .findFirst();

        if (fulfillmentProgram.isPresent()) {
            FulfillmentType fulfillment = new FulfillmentType();
            fulfillmentProgram.get().getAttributes().stream()
                    .filter(attribute -> attribute.getName().equals(ApiSellingExtSvcConstants.FULFILLMENT_BY))
                    .map(Attribute::getValue)
                    .findFirst()
                    .ifPresent(fulfillment::setFulfillmentBy);
            fulfillmentProgram.map(ProgramType::getExternalId).map(Identifier::getIdentifier).ifPresent(fulfillment::setFulfillmentRefId);
            optionalFulfillment = Optional.of(fulfillment);
        } else if (faultVasSubTypeNameOptional.isPresent()) {
            String vasSubTypeValue = faultVasSubTypeNameOptional.get().getValue();
            if (vasSubTypeValue.equals(ApiSellingExtSvcConstants.INTRA_VAULT_TRANSFER)
                    || vasSubTypeValue.equals(ApiSellingExtSvcConstants.FULFILLMENT_FROM_VAULT)) {
                FulfillmentType fulfillment = new FulfillmentType();
                fulfillment.setFulfillmentBy(ApiSellingExtSvcConstants.EBAY);
                optionalFulfillment = Optional.of(fulfillment);
            }
        }
        return optionalFulfillment;
    }
}
