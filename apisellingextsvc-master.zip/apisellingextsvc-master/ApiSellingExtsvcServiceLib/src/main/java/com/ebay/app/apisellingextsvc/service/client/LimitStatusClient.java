package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.rm.limit.enforcement.types.CheckSellingLimitStatusResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LimitStatusClient extends BaseGingerClient<String, CheckSellingLimitStatusResponse> {

    private static final Logger logger = LoggerFactory.getLogger(CheckSellingLimitStatusResponse.class);

    private static final String CLIENT_ID = "slnglmenf.limit";

    private static final String PATH = "/user/%s/check_selling_limit_status";

    public LimitStatusClient() {
        super(CheckSellingLimitStatusResponse.class);
    }

    @Override
    public GingerClientResponse<CheckSellingLimitStatusResponse> getGingerResponse(GingerClientRequest<String> gingerRequest) {
        String path = String.format(PATH, gingerRequest.getRequest());
        return processPostRequest(path, gingerRequest);
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}