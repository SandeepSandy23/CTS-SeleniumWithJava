package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.application.common.request.GetSellerTransactionsRequest;
import com.ebay.app.apisellingextsvc.tasks.filter.IFilter;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Objects;

public class FilterRequestTask implements BaseTask<GetSellerTransactionsRequest> {

    private final List<IFilter> filters;
    private GetSellerTransactionsRequest request;

    public FilterRequestTask(
            @Nonnull List<IFilter> filters) {
        this.filters = filters;
    }

    @Override
    public GetSellerTransactionsRequest call() throws Exception {

        if(isPreConditionMet()) {
            filters.forEach(IFilter::doFilter);
        }

        return null;
    }


    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) {
            this.request = (GetSellerTransactionsRequest) result;
        }
    }
}
