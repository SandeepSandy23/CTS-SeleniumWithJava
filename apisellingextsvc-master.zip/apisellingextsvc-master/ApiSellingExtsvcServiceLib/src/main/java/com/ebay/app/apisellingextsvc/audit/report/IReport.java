package com.ebay.app.apisellingextsvc.audit.report;

public interface IReport<T> {
    void report(String var1, String var2, String var3, String var4, boolean var5);

    T collect();
}