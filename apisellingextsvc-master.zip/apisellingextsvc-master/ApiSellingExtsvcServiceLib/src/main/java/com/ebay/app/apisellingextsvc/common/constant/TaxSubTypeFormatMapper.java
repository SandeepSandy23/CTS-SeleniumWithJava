package com.ebay.app.apisellingextsvc.common.constant;

import com.google.common.collect.ImmutableMap;

public class TaxSubTypeFormatMapper {

    private static final ImmutableMap<String, String> mapName
            = new ImmutableMap.Builder<String, String>()
            .put(TaxSubTypeConstants.ABN, TaxSubTypeConstants.ABN_FORMAT)
            .put(TaxSubTypeConstants.IRD, TaxSubTypeConstants.IRD_FORMAT)
            .put(TaxSubTypeConstants.VOEC, TaxSubTypeConstants.VOEC_FORMAT)
            .put(TaxSubTypeConstants.GST, TaxSubTypeConstants.GST_FORMAT)
            .put(TaxSubTypeConstants.IOSS, TaxSubTypeConstants.IOSS_FORMAT)
            .build();

    private static final ImmutableMap<String, String> formatMapName
            = new ImmutableMap.Builder<String, String>()
            .put(TaxSubTypeConstants.ABN_FORMAT, TaxSubTypeConstants.ABN)
            .put(TaxSubTypeConstants.IRD_FORMAT, TaxSubTypeConstants.IRD)
            .put(TaxSubTypeConstants.VOEC_FORMAT, TaxSubTypeConstants.VOEC)
            .put(TaxSubTypeConstants.GST_FORMAT, TaxSubTypeConstants.GST)
            .put(TaxSubTypeConstants.IOSS_FORMAT, TaxSubTypeConstants.IOSS)
            .build();

    private TaxSubTypeFormatMapper() {

    }

    public static String map(String taxSubType) {
        return mapName.getOrDefault(taxSubType, ApiSellingExtSvcConstants.EMPTY_STRING);
    }


    public static String mapNameWithFormat(String format) {
        return formatMapName.getOrDefault(format, ApiSellingExtSvcConstants.EMPTY_STRING);
    }
}
