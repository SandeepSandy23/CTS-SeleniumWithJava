package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.ListingsContext;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.app.apisellingextsvc.utils.Headers;
import com.ebay.app.apisellingextsvc.utils.ListingsActivityServiceUtil;
import com.ebay.cos.las.type.ListingActivitiesResponse;
import com.ebay.globalenv.SiteEnum;
import com.ebay.raptor.kernel.util.GlobalIdConverter;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;
import org.apache.commons.lang3.ObjectUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * <pre>
 * <a href="https://github.corp.ebay.com/Selling/lasng/blob/master/lasngService/src/main/resources/api/openapi.yaml">Selling lasng</a>
 * POST https://lasng.vip.qa.ebay.com/lasngsvc/v1/listing_activity/get_by_ids
 * Headers
 * 1. Authorization
 * 2. X-EBAY-C-ENDUSERCTX
 *
 * if user ctx is buyer, return 400
 * </pre>
 */
public class ListingActivitiesTask implements Task<ListingActivitiesResponse>, ITaskResultInjectable {

    private Map<String, Object> resultMap = new HashMap<>();
    private final User user;
    private final IServiceInvoker<ListingsContext, ListingActivitiesResponse> listingInvoker;
    private final List<ErrorType> errorList;

    private final ListingsContext listingsContext;
    private final HttpHeaders requestHeaders;

    public ListingActivitiesTask(
            IServiceInvoker<ListingsContext, ListingActivitiesResponse> listingInvoker,
            List<ErrorType> errorList,
            HttpHeaders headers,
            User user, ListingsContext listingsContext) {
        this.listingInvoker = listingInvoker;
        this.errorList = errorList;
        this.user = user;
        this.requestHeaders = headers;
        this.listingsContext = listingsContext;
    }

    @Override
    public ListingActivitiesResponse call() {
        return this.listingInvoker.getResponse(listingsContext,
                ListingsActivityServiceUtil.buildLASHeaders(requestHeaders, user.getUserName(), user.getUserId()));
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result))  resultMap.put(result.getClass().getName(), result);
    }
}
