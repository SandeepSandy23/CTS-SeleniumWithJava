package com.ebay.app.apisellingextsvc.audit.reporter;

import java.util.HashMap;
import com.ebay.app.apisellingextsvc.audit.model.ReportPattern;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.ebay.app.apisellingextsvc.audit.es.GroupMismatch;
import com.ebay.app.apisellingextsvc.audit.es.Mismatch;
import java.util.Map;

public abstract class BaseAuditReporter implements IReport<Map<String, GroupMismatch>> {

    private final ReportPattern reportPattern;
    private final Map<String, GroupMismatch> result = new HashMap<>();

    protected BaseAuditReporter(String patternPath) {
        reportPattern = ReportPattern.create(patternPath);
    }

    @Override
    public void report(String key, String path, String org, String tar, boolean success) {
        if (!success && reportPattern != null) {
            Mismatch mismatch = new Mismatch(path, tar, org, key);
            String groupName = reportPattern.getMatchName(path);

            result.putIfAbsent(groupName, new GroupMismatch(groupName));
            result.get(groupName).getMismatches().add(mismatch);
        }
    }

    @Override
    public Map<String, GroupMismatch> collect() {
        return result;
    }
}
