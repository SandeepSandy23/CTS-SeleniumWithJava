package com.ebay.app.apisellingextsvc.common.json;


import com.ebay.cos.type.v3.base.Text;
import com.ebay.kernel.calwrapper.CalEvent;
import com.ebay.kernel.calwrapper.CalEventFactory;
import com.ebay.marketplace.services.ErrorSeverity;
import com.ebay.order.common.views.Views;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
import com.fasterxml.jackson.databind.introspect.AnnotationIntrospectorPair;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector;

import java.io.IOException;
import java.util.Optional;

/*
 * The CustomObjectMapper included 2 setting
 * DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES = false
 * DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL = true
 * This remove dependency coupling from COMS data type where new properties and unrecognized new ENUM field (if presented) will be
 * gracefully escaped.
 * As recommended by jackson documentation, keep ObjectMapper as singleton for better performance
 */
// @Configuration
public class CustomObjectMapper extends ObjectMapper {

    private static final long serialVersionUID = 1L;
    private static final CustomObjectMapper instance = new CustomObjectMapper();

    private CustomObjectMapper() {
        super();
        super.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
        super.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        super.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        // super.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true);
        super.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        super.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        super.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS, true);
        // super.enable(SerializationFeature.WRITE_ENUMS_USING_TO_STRING);
        // super.enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING);
        super.setConfig(super.getSerializationConfig().withView(Views.CosmosView.class));
        super.registerModule(new JavaTimeModule()); // to deserialize java.time.LocalDateTime from LASNG svc - listing activity
        super.configOverride(Optional.class)
                .setIncludeAsProperty(JsonInclude.Value.construct(JsonInclude.Include.NON_EMPTY, null));

        super.configOverride(Optional.class)
                .setIncludeAsProperty(JsonInclude.Value.construct(JsonInclude.Include.NON_NULL, null));

        AnnotationIntrospector primary = new JaxbAnnotationIntrospector(TypeFactory.defaultInstance());
        AnnotationIntrospector secondary = new JacksonAnnotationIntrospector();
        AnnotationIntrospector pair = new AnnotationIntrospectorPair(primary, secondary);
        super.setAnnotationIntrospector(pair);
        super.addHandler(new DeserializationProblemHandler() {
            @Override
            public boolean handleUnknownProperty(DeserializationContext ctxt, JsonParser jp,
                                                 JsonDeserializer<?> deserializer, Object beanOrClass, String propertyName) throws IOException {
                CalEvent calWarning = CalEventFactory.create(ErrorSeverity.WARNING.name());
                calWarning.setName("UnknownJsonProperty");
                calWarning.addData("UnknownProperty for " + beanOrClass.getClass().getName(), propertyName);
                calWarning.setStatus("1");
                calWarning.completed();
                return false;
            }
        });

        SimpleModule module = new SimpleModule();
        module.setDeserializerModifier(new BeanDeserializerModifier() {
            @Override
            public JsonDeserializer<?> modifyEnumDeserializer(DeserializationConfig config, JavaType type,
                                                              BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
                return deserializer;
            }
        });
        module.addKeyDeserializer(Text.class, new TextDeserializer());
        module.addKeySerializer(Text.class, new TextSerializer());
        super.registerModule(module);
    }

    public static CustomObjectMapper getInstance() {
        return instance;
    }

    static class TextDeserializer extends KeyDeserializer {

        @Override
        public Object deserializeKey(final String key, final DeserializationContext ctxt) throws IOException {
            return key;
        }
    }

    static class TextSerializer extends JsonSerializer<Text> {

        @Override
        public void serialize(Text value, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
            jsonGenerator.writeFieldName(value.getContent());
        }
    }


}
