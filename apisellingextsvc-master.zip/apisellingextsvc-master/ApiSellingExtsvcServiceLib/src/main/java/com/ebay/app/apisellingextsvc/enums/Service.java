package com.ebay.app.apisellingextsvc.enums;

public enum Service {
    USER_READ_SERVICE,
}
