package com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign;


import com.ebay.af.common.flag.FlagMask;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;

public class SellerDiscountCampaignDoImpl extends SellerDiscountCampaignCodeGenDoImpl implements SellerDiscountCampaign {
    private static final long serialVersionUID = 1L;

    public SellerDiscountCampaignDoImpl() {
        super(SellerDiscountCampaignDAO.getInstance(), GenericMap.getInitializedMap(SellerDiscountCampaign.class));
    }

    public SellerDiscountCampaignDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    protected long getDataValue(FlagMask flagMask) {
        int dataId = flagMask.getDataId();
        return dataId == 0 ? this.getCampaignFlags01() : super.getDataValue(flagMask);
    }

    protected void setDataValue(FlagMask flagMask, long value) {
        int dataId = flagMask.getDataId();
        if (dataId == 0) {
            this.setCampaignFlags01(value);
        } else {
            super.setDataValue(flagMask, value);
        }

    }
}

