package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.StoreEditEntityClient.StoreEditEntityResponse;
import com.ebay.app.apisellingextsvc.service.client.model.StoreEditEntityClient.StoreEditEntityServiceClient;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class StoreEditEntityServiceInvoker extends BaseServiceInvoker<String, StoreEditEntityResponse, String> {
    public static final String NAME = "StoreEditEntityServiceInvoker";
    public StoreEditEntityServiceInvoker(TracerContext tracerContext) {
        super( NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<String, StoreEditEntityResponse> getGingerClient(String request) {
        return new StoreEditEntityServiceClient();
    }

    @Override
    public GingerClientRequest<String> getGingerRequest(String request, HttpHeaders httpHeaders) {
        GingerClientRequest<String> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(request);
        return gingerClientRequest;
    }

}
