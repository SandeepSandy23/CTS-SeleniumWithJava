package com.ebay.app.apisellingextsvc.service.dal.itemhost;

public class ItemHostInfoHolder {
    public ItemHostInfo[] m_rangeSortedArray;

    public ItemHostInfoHolder(ItemHostInfo[] rangeSortedArray) {
        this.m_rangeSortedArray = rangeSortedArray;
    }
}
