package com.ebay.app.apisellingextsvc.application.common.request;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.ContentHelper;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.context.EnvironmentContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import com.ebay.app.apisellingextsvc.handlers.ExceptionHandler;
import com.ebay.app.apisellingextsvc.mappers.ErrorLanguageSiteIdMapper;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.app.apisellingextsvc.utils.TaskOrchestrationUtil;
import com.ebay.globalenv.SiteEnum;
import com.ebay.raptor.content.api.IContentBuilderFactory;
import com.ebay.raptor.orchestrationv2.task.ITaskOrchestrator;
import com.ebay.raptor.orchestrationv2.task.TaskOrchestratorFactory;
import ebay.apis.eblbasecomponents.AbstractRequestType;
import ebay.apis.eblbasecomponents.ErrorType;
import lombok.Getter;
import org.apache.commons.lang3.math.NumberUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executor;

/**
 * Base request
 */
@Getter
public abstract class BaseApplicationRequest implements IApiSellingExtSvcApplicationRequest, AutoCloseable{

    private AbstractRequestType requestType;
    private static final String DEFAULT_CAL_NAME = "DEF_CAL";
    public User user;
    public final IContentBuilderFactory contentBuilderFactory;
    public final HttpHeaders headers;
    public final List<ErrorType> errorList;
    public final ApiSellingExtSvcConfigValues configValues;
    public final EnvironmentContext environmentContext;
    public Integer trxVersion;
    public SiteContext siteContext;
    public ITaskOrchestrator orchestrator;
    public ContentResource contentResource = new ContentResource();
    private TracerContext tracerContext;
    private Executor executor;

    protected BaseApplicationRequest(HttpHeaders headers,
                                     User user,
                                     IContentBuilderFactory contentBuilderFactory,
                                     ApiSellingExtSvcConfigValues configValues,
                                     EnvironmentContext environmentContext, TracerContext tracerContext, AbstractRequestType requestType) {
        this.headers = headers;
        this.user = user;
        this.errorList = new ArrayList<>();
        this.orchestrator = TaskOrchestrationUtil.getDefaultOrchestrator();
        this.contentBuilderFactory = contentBuilderFactory;
        this.configValues = configValues;
        this.environmentContext = environmentContext;
        this.tracerContext = tracerContext;
        this.requestType = requestType;
        this.trxVersion = null; // Assuredly nonnull: Population is done in BaseRequestValidatorFilter before trxVersion is ever used
        populateSiteAndContentManager();

    }

    @Override
    public ITaskOrchestrator getExecutor() {
        return this.orchestrator;
    }

    @Override
    public HttpHeaders getHeaders() {
        return headers;
    }

    @Override
    public String getCalName() {
        if (siteContext == null) {
            return DEFAULT_CAL_NAME;
        }
        return SiteEnum.get(siteContext.viewingSiteId).getName();
    }

    @Override
    public void close() throws Exception {
        orchestrator.shutdown();
        TaskOrchestratorFactory.reset();
    }


    @Override
    public ContentResource getContentResource() {
        return contentResource;
    }

    @Override
    public IContentBuilderFactory getContentBuilderFactory() {
        return this.contentBuilderFactory;
    }

    @Override
    public int getRequestSiteId() {
        return siteContext != null ? siteContext.viewingSiteId : ApiSellingExtSvcConstants.DEFAULT_SITE_ID;
    }


    private String getMeaningfulValue(String val) {
        return val != null ? val : "null";
    }

    private void populateSiteAndContentManager() {

        // if the error language is specified, need to use it for error content
        Integer errorLangId = 0;
        if (getErrorLanguage() != null) {
            errorLangId = ErrorLanguageSiteIdMapper.map(getErrorLanguage());
        }
        String siteId = getMeaningfulValue(HeaderUtil.getSiteId(headers));
        if (!NumberUtils.isDigits(siteId)) {
            // throw exception here and return, no need to set content manager anymore.
            // set a null value string, otherwise localization cannot display null value.
            // if no error language specified, default to site 0 - en_US
            ContentHelper cn = new ContentHelper(this.contentBuilderFactory, 0, errorLangId,
                                                 configValues.contentCacheEvictTime,
                                                 configValues.contentCacheMaximumSize);
            ExceptionHandler.throwException(ApplicationError.INVALID_HEADER,
                                            cn.getErrorContentManager(),
                                            Arrays.asList(ApiSellingExtSvcConstants.X_EBAY_API_SITE_ID, siteId),
                                            ApiSellingExtSvcConstants.X_EBAY_API_SITE_ID, siteId);
        }

        Integer siteInteger = NumberUtils.createInteger(siteId);
        this.siteContext = SiteContext.create(siteInteger);
        this.contentResource.contentHelper = new ContentHelper(this.contentBuilderFactory, siteInteger,
                                                               errorLangId,
                                                               configValues.contentCacheEvictTime, configValues.contentCacheMaximumSize);
    }

    public void setExecutor(Executor executor) {
        this.executor = executor;
    }
}