package com.ebay.app.apisellingextsvc.service.dal.shippingcarrier;

import com.ebay.integ.dal.DalRuntimeException;
import com.ebay.integ.dal.dao.CacheableDao;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.ConstantToupleProvider;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.integ.dal.map.MappingIncludesAttribute;
import com.ebay.integ.dal.map.Query;
import com.ebay.integ.dal.map.QueryEngine;
import com.ebay.integ.dal.map.ReadSet;
import com.ebay.integ.dal.map.ReadableMapping;
import com.ebay.integ.dal.map.SelectQuery;
import com.ebay.integ.dal.map.SelectSetParms;
import com.ebay.integ.dal.map.SelectStatement;
import com.ebay.integ.dal.map.TableJoin;
import com.ebay.app.apisellingextsvc.service.dal.common.ReadSets;
import org.apache.commons.collections.CollectionUtils;

import java.util.LinkedList;
import java.util.List;

public class ShippingCarrierDAO extends CacheableDao {

    private static boolean m_mapInitialized = false;
    private static GenericMap<ShippingCarrier> s_map;
    private static final String FIND_ALL = "FIND_ALL";

    private static ShippingCarrierCodeGenDoImpl s_noFetchProtoDO;
    private static MappingIncludesAttribute[] m_ourDDRHints;
    private static volatile ShippingCarrierDAO m_instance = null;

    protected ShippingCarrierDAO() {
        super(ShippingCarrierKeyManager.getInstance(), "ShippingCarrier", ShippingCarrierCacheBean.getInstance());
        if (!m_mapInitialized) {
            initMap();
        }
    }

    public static ShippingCarrierDAO getInstance() {
        if (m_instance == null) {
            synchronized (ShippingCarrierDAO.class) {
                if (m_instance == null) {
                    m_instance = new ShippingCarrierDAO();
                }
            }
        }
        return m_instance;
    }

    public static void initMap() {
        if (m_mapInitialized) {
            return;
        }
        GenericMap<ShippingCarrier> map = GenericMap.getMap(ShippingCarrier.class);
        if (map == null) {
            map = new GenericMap<>(ShippingCarrier.class);
        }
        s_map = map;
        map.setDalVersion("3.0");
        m_mapInitialized = true;
        try {
            map.registerToupleProvider(new ConstantToupleProvider("SHIPPING_CARRIER", "lookuputf8host"));
        } catch (NullPointerException var2) {
            throw new DalRuntimeException("DAL not properly initialized.");
        }

        s_noFetchProtoDO = new ShippingCarrierCodeGenDoImpl(ShippingCarrierDAO.getInstance(), map);
        initHintGroups(map);
        map.setTableJoins(new TableJoin[0]);
        map.setQueries(getRawQueries());
        map.setReadSets(getReadSets(map));
        map.init();
    }

    private static void initHintGroups(GenericMap<ShippingCarrier> map) {
        m_ourDDRHints = new MappingIncludesAttribute[] {map
              .getLocalFieldMapping(ShippingCarrierCodeGenDoImpl.SHIPPINGCARRIERID)};
    }


    private static ReadSet[] getReadSets(GenericMap<ShippingCarrier> map) {
        ReadableMapping carrierEnumId = (ReadableMapping) map.getLocalFieldMapping(ShippingCarrierCodeGenDoImpl.CARRIERENUMID);
        ReadableMapping shippingCarrierName = (ReadableMapping) map.getLocalFieldMapping(ShippingCarrierCodeGenDoImpl.SHIPPINGCARRIERNAME);
        return new ReadSet[] {
              new ReadSet(ReadSets.MATCHANY.getValue(), new ReadableMapping[] {carrierEnumId, shippingCarrierName})};
    }

    private static Query[] getRawQueries() {
        return new Query[] {
              new SelectQuery(
                    FIND_ALL,
                    m_ourDDRHints,
                    new SelectStatement[] {new SelectStatement(
                          ReadSets.MATCHANY.getValue(),
                          "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> ")}, -1,
                    new SelectSetParms(4000, 2000, 2000, s_noFetchProtoDO))
        };
    }


    public List<ShippingCarrier> findAllDirect2DBSortedByShippingCarrier() throws FinderException {
        QueryEngine qe = new QueryEngine();
        List<ShippingCarrier> results = new LinkedList<>();
        ShippingCarrierCodeGenDoImpl protoDO = new ShippingCarrierCodeGenDoImpl(this, s_map);
        protoDO.setReadOnlyHint(true);
        qe.readMultiple(results, s_map, protoDO, FIND_ALL, ReadSets.FULL.getValue());
        return results;
    }

    public ShippingCarrier findCarrierNameByEnumId(int shippingCarrierId) throws FinderException {
        ShippingCarrierCodeGenDoImpl protoDO = new ShippingCarrierCodeGenDoImpl(this, s_map);
        protoDO.setCarrierEnumId(shippingCarrierId);
        protoDO.setReadOnlyHint(true);
        List<ShippingCarrier> result = (List<ShippingCarrier>)this.globalCacheFetchSingle(protoDO, ShippingCarrierKeyManager.carrierEnumId);
        return CollectionUtils.isNotEmpty(result) ? result.get(0) : null;
    }
}
