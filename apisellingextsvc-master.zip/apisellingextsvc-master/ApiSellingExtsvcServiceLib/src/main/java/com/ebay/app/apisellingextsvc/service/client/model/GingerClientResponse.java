package com.ebay.app.apisellingextsvc.service.client.model;

import java.util.Map;

public class GingerClientResponse<Q> {

    private GingerResponseType responseType = GingerResponseType.FAILURE;

    private Map<String, String> diagnosticHolder;

    private Q response;

    public Q getResponse() {
        return response;
    }

    public void setResponse(Q response) {
        this.response = response;
    }

    public GingerResponseType getResponseType() {
        return responseType;
    }

    public void setResponseType(GingerResponseType responseType) {
        this.responseType = responseType;
    }

    public Map<String, String> getDiagnosticHolder() {
        return diagnosticHolder;
    }

    public void setDiagnosticHolder(Map<String, String> diagnosticHolder) {
        this.diagnosticHolder = diagnosticHolder;
    }

}
