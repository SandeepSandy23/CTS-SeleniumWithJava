package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.context.ListingsContext;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.cos.las.type.ListingActivitiesResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ListingsClient extends BaseGingerClient<ListingsContext, ListingActivitiesResponse> {
    private static final Logger logger = LoggerFactory.getLogger(LasngClient.class);

    private static final String CLIENT_ID = "las.lasClient";

    private static final String PATH = "/laservice/mlas/v1/listingactivities";

    public ListingsClient() {
        super(ListingActivitiesResponse.class);
    }

    @Override
    public GingerClientResponse<ListingActivitiesResponse> getGingerResponse(GingerClientRequest<ListingsContext> gingerRequest) {
        return processGetRequest(PATH, gingerRequest.getRequest().getQueryParams(), gingerRequest.getHeaders());
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }

}
