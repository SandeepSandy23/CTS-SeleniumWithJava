package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.enums.ContentBundleEnum;
import com.ebay.app.apisellingextsvc.mappers.ListingTypeMapper;
import com.ebay.app.apisellingextsvc.service.bof.exchangerate.ExchangeRateBofImpl;
import com.ebay.app.apisellingextsvc.service.invokers.model.BulkUserInfoModel;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.ListingCodeTypeUtil;
import com.ebay.app.apisellingextsvc.utils.MoneyExchangeHelper;
import com.ebay.app.apisellingextsvc.utils.NumberUtil;
import com.ebay.app.apisellingextsvc.utils.SiteUtils;
import com.ebay.app.apisellingextsvc.utils.UserUtil;
import com.ebay.app.apisellingextsvc.utils.ViewItemURLUtil;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cos.las.type.Note;
import com.ebay.cos.las.type.NoteType;
import com.ebay.cos.type.v3.base.Amount;
import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.cos.type.v3.base.MarketplaceIdEnum;
import com.ebay.cos.type.v3.base.Property;
import com.ebay.cos.type.v3.base.PropertyValue;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.base.TimeDuration;
import com.ebay.cos.type.v3.core.listing.DiscountPrice;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.listing.ItemVariation;
import com.ebay.cos.type.v3.core.listing.Listing;
import com.ebay.cos.type.v3.core.listing.PriceSettings;
import com.ebay.cos.type.v3.core.listing.QuantityAndAvailability;
import com.ebay.cos.type.v3.core.listing.QuantityAndAvailabilityByLogisticsPlans;
import com.ebay.cos.type.v3.core.listing.lifecycle.ListingDurationEnum;
import com.ebay.cos.type.v3.core.listing.lifecycle.ListingLifecycle;
import com.ebay.cos.type.v3.core.listing.tradingSummary.ItemVariationTradingSummary;
import com.ebay.cos.type.v3.core.listing.tradingSummary.TradingSummary;
import com.ebay.cos.type.v3.core.user.relationshipWithListing.NegotiationType;
import com.ebay.cos.type.v3.core.user.relationshipWithListing.OfferType;
import com.ebay.cos.type.v3.core.user.relationshipWithListing.UnifiedOffer;
import com.ebay.cos.type.v3.core.user.relationshipWithListing.UserToItemVariationRelationshipSummary;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.BestOfferDetailsType;
import ebay.apis.eblbasecomponents.FeedbackRatingStarCodeType;
import ebay.apis.eblbasecomponents.ItemListCustomizationType;
import ebay.apis.eblbasecomponents.ItemPolicyViolationType;
import ebay.apis.eblbasecomponents.ItemType;
import ebay.apis.eblbasecomponents.ListingDetailsType;
import ebay.apis.eblbasecomponents.ListingTypeCodeType;
import ebay.apis.eblbasecomponents.PictureDetailsType;
import ebay.apis.eblbasecomponents.PromotionalSaleDetailsType;
import ebay.apis.eblbasecomponents.ReasonHideFromSearchCodeType;
import ebay.apis.eblbasecomponents.SellingStatusType;
import ebay.apis.eblbasecomponents.UserType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.text.CaseUtils;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.ACTUAL_END_DATE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.BRACKET_LEFT;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.BRACKET_RIGHT;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.COLON;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.COMMA;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.DOT;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.FEEDBACK_SCORE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.GMES_DEFAULT_NUMBER_OF_DAYS;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.PROMO_SALE_END_TIME;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.PROMO_SALE_START_TIME;
import static com.ebay.app.apisellingextsvc.utils.DateUtil.convertToXMLGregorianCalendar;
import static com.ebay.cos.type.v3.core.user.relationshipWithListing.OfferType.BUYER_COUNTER_OFFER;
import static com.ebay.cos.type.v3.core.user.relationshipWithListing.OfferType.BUYER_OFFER;
import static com.ebay.cos.type.v3.core.user.relationshipWithListing.OfferType.SELLER_COUNTER_OFFER;

public class ListingActivitiesUtil {

    private static final HashSet<OfferType> bestOfferTypes = new HashSet<>(Arrays.asList(BUYER_OFFER,
            BUYER_COUNTER_OFFER, SELLER_COUNTER_OFFER));
    public static Long getWatchCount(ListingActivitiesDetail listingActivity) {
        return Optional.of(listingActivity).map(ListingActivitiesDetail::getListing)
                .map(Listing::getTradingSummary)
                .map(TradingSummary::getWatchCount)
                .map(Long::valueOf)
                .orElse(null);
    }

    public static String getTitle(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getTitle).map(Text::getContent).orElse(null);
    }

    public static String getSKU(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getListingSKU)
                .orElse(null);
    }

    public static SellingStatusType getSellingStatus(ListingActivitiesDetail listingActivity,
                                                     BulkUserInfoModel bulkUserInfoModel) {
        SiteContext listedMarketPlaceSiteContext = SiteContext.create(SiteUtils.getSiteId(ListingActivitiesUtil.getMarketPlaceListedOn(listingActivity)));
        SellingStatusType sellingStatusType = new SellingStatusType();
        Optional<ItemVariation> itemVariation = getItemVariation(listingActivity);
        Integer bidCount = itemVariation.map(ItemVariation::getItemVariationTradingSummary)
                .map(ItemVariationTradingSummary::getBidCount).orElse(null);
        Long bidderCount = itemVariation.map(ItemVariation::getItemVariationTradingSummary)
                .map(ItemVariationTradingSummary::getUniqueBidderCount)
                .map(Long::valueOf).orElse(null);
        if (null != bidCount && bidCount > 0) {
            sellingStatusType.setBidCount(bidCount);
        }
        if (null != bidderCount && bidderCount > 0) {
            sellingStatusType.setBidderCount(bidderCount);
        }
        ListingTypeCodeType listingFormat = getListingCodeType(listingActivity);
        Pair<AmountType, AmountType> currentPrices = getCurrentPrices(listingActivity, listingFormat);
        sellingStatusType.setCurrentPrice(currentPrices.getKey());
        if (!ListingCodeTypeUtil.isClassifiedAdType(listingFormat)) {
            sellingStatusType.setConvertedCurrentPrice(currentPrices.getValue());
        }
        UserType userType = new UserType();
        String userID = itemVariation.map(ItemVariation::getItemVariationTradingSummary)
                .map(ItemVariationTradingSummary::getHighBidderUsername)
                .orElse(null);
        Integer feedbackScore = Optional.ofNullable(bulkUserInfoModel)
                .map(BulkUserInfoModel::getUserInfoData)
                .map(stringUserInfoMap -> stringUserInfoMap.get(userID))
                .map(userInfo -> UserUtil.getValueFromExtensions(userInfo, FEEDBACK_SCORE))
                .map(java.lang.Integer::parseInt).orElse(0);
        if (feedbackScore > 0) {
            userType.setFeedbackScore(feedbackScore);
            userType.setFeedbackRatingStar(getFeebackRatingStar(feedbackScore));
            sellingStatusType.setHighBidder(userType);
        }
        userType.setUserID(userID);
        sellingStatusType.setPromotionalSaleDetails(getPromotionalSaleDetails(listingActivity, listedMarketPlaceSiteContext));
        if (getSoldQuantity(listingActivity) > 0) {
            sellingStatusType.setQuantitySold(getSoldQuantity(listingActivity));
        }
        setReserveMet(listingFormat, sellingStatusType, listingActivity);
        return sellingStatusType;
    }

    private static void setReserveMet(ListingTypeCodeType listingFormat, SellingStatusType sellingStatusType,
                                      ListingActivitiesDetail listingActivitiesDetail) {
        Boolean reserveMet = isReserveMet(listingActivitiesDetail);
        if (listingFormat.equals(ListingTypeCodeType.CHINESE)) {
            if (reserveMet == null || reserveMet) {
                sellingStatusType.setReserveMet(Boolean.TRUE);
            } else {
                sellingStatusType.setReserveMet(Boolean.FALSE);
            }
        }
    }

    private static PromotionalSaleDetailsType getPromotionalSaleDetails(ListingActivitiesDetail listingActivity,
                                                                        SiteContext siteContext) {
        PromotionalSaleDetailsType promotionalSaleDetailsType = new PromotionalSaleDetailsType();
        Optional<ItemVariation> itemVariation = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getItemVariations)
                .flatMap(itemVariations -> itemVariations.stream()
                        .filter(itemVariant -> (itemVariant.getPriceSettings() != null
                                && Boolean.TRUE.equals(itemVariant.getPriceSettings().getPromotionalPriceAvailable())))
                        .findFirst());
        DiscountPrice discountPrice = itemVariation.map(ItemVariation::getPriceSettings)
                .map(PriceSettings::getDiscountPrice)
                .flatMap(discountPrices -> discountPrices.stream().findFirst())
                .orElse(null);
        setPromotionSaleDetails(promotionalSaleDetailsType, discountPrice, siteContext);
        if (promotionalSaleDetailsType.getOriginalPrice() != null) {
            return promotionalSaleDetailsType;
        }
        return null;
    }

    private static void setPromotionSaleDetails(PromotionalSaleDetailsType promotionalSaleDetailsType,
                                                DiscountPrice discountPrice, SiteContext siteContext) {
        Amount originalPrice = Optional.ofNullable(discountPrice).map(DiscountPrice::getSuggestedRetailPrice).orElse(null);
        XMLGregorianCalendar startTime = getCalendarTime(discountPrice, PROMO_SALE_START_TIME);
        XMLGregorianCalendar endTime = getCalendarTime(discountPrice, PROMO_SALE_END_TIME);
        promotionalSaleDetailsType.setOriginalPrice(getAmountTypes(originalPrice, null).getKey());
        promotionalSaleDetailsType.setStartTime(startTime);
        promotionalSaleDetailsType.setEndTime(endTime);
    }

    private static XMLGregorianCalendar getCalendarTime(DiscountPrice discountPrice, String propertyValue) {
        return Optional.ofNullable(discountPrice).map(DiscountPrice::getDiscountProperties)
                .flatMap(properties -> properties.stream().filter(property -> property.getPropertyName().equals(propertyValue)).findFirst())
                .map(Property::getPropertyValues)
                .flatMap(propertyValues -> propertyValues.stream().findFirst())
                .map(PropertyValue::getDatetimeValue)
                .map(DateTime::getValue)
                .map(DateUtil::convertToSimpleDateFormat)
                .map(DateUtil::convertToXMLGregorianCalendar)
                .orElse(null);
    }

    private static FeedbackRatingStarCodeType getFeebackRatingStar(Integer feedBackScore) {
        if (feedBackScore >= 0 && feedBackScore <= 9) {
            return FeedbackRatingStarCodeType.NONE;
        } else if (feedBackScore >= 10 && feedBackScore <= 49) {
            return FeedbackRatingStarCodeType.YELLOW;
        } else if (feedBackScore >= 50 && feedBackScore <= 99) {
            return FeedbackRatingStarCodeType.BLUE;
        } else if (feedBackScore >= 100 && feedBackScore <= 499) {
            return FeedbackRatingStarCodeType.TURQUOISE;
        } else if (feedBackScore >= 500 && feedBackScore <= 999) {
            return FeedbackRatingStarCodeType.PURPLE;
        } else if (feedBackScore >= 1000 && feedBackScore <= 4999) {
            return FeedbackRatingStarCodeType.RED;
        } else if (feedBackScore >= 5000 && feedBackScore <= 9999) {
            return FeedbackRatingStarCodeType.GREEN;
        } else if (feedBackScore >= 10000 && feedBackScore <= 24999) {
            return FeedbackRatingStarCodeType.YELLOW_SHOOTING;
        } else if (feedBackScore >= 25000 && feedBackScore <= 49999) {
            return FeedbackRatingStarCodeType.TURQUOISE_SHOOTING;
        } else if (feedBackScore >= 50000 && feedBackScore <= 99999) {
            return FeedbackRatingStarCodeType.PURPLE_SHOOTING;
        } else if (feedBackScore >= 100000 && feedBackScore <= 499999) {
            return FeedbackRatingStarCodeType.RED_SHOOTING;
        } else if (feedBackScore >= 500000 && feedBackScore <= 999999) {
            return FeedbackRatingStarCodeType.GREEN_SHOOTING;
        } else if (feedBackScore >= 1000000) {
            return FeedbackRatingStarCodeType.SILVER_SHOOTING;
        }
        return FeedbackRatingStarCodeType.NONE;
    }

    private static Boolean isReserveMet(ListingActivitiesDetail listingActivity) {
        return getItemVariation(listingActivity).map(ItemVariation::getItemVariationTradingSummary)
                .map(ItemVariationTradingSummary::getReservePriceMet).orElse(null);
    }

    public static Pair<AmountType, AmountType> getCurrentPrices(ListingActivitiesDetail listingActivity,
                                              ListingTypeCodeType listingTypeCodeType) {
        if (listingTypeCodeType.equals(ListingTypeCodeType.FIXED_PRICE_ITEM)) {
            return ListingActivitiesUtil.getLowestAvailableVariationPrice(listingActivity);
        } else if (listingTypeCodeType.equals(ListingTypeCodeType.CHINESE) || listingTypeCodeType.equals(ListingTypeCodeType.PERSONAL_OFFER)) {
            Amount amount = getItemVariation(listingActivity).map(ItemVariation::getItemVariationTradingSummary)
                    .map(ItemVariationTradingSummary::getCurrentBidPrice).orElse(null);
            return getAmountTypes(amount, null);
        } else if (ListingCodeTypeUtil.isClassifiedAdType(listingTypeCodeType)) {
            return getLowestFixedPrices(listingActivity);
        }
        return new ImmutablePair<>(null, null);
    }

    public static Pair<AmountType, AmountType> getLowestFixedPrices(ListingActivitiesDetail listingActivity) {
        Amount amount = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getLowestFixedPrice).orElse(null);
        return getAmountTypes(amount, null);
    }

    public static Pair<AmountType, AmountType> getLowestAvailableVariationPrice(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getItemVariations)
                .map(variationList -> variationList.stream()
                        .filter(itemVariation -> Optional.of(itemVariation)
                                .map(ItemVariation::getQuantityAndAvailabilityByLogisticsPlans)
                                .map(Collection::stream)
                                .flatMap(Stream::findFirst)
                                .map(QuantityAndAvailabilityByLogisticsPlans::getQuantityAndAvailability)
                                .map(QuantityAndAvailability::getAvailableQuantity)
                                .map(availableQuantity -> availableQuantity > 0).orElse(false))).orElse(Stream.empty())
                .map(ItemVariation::getPriceSettings)
                .map(PriceSettings::getLowestFixedPrice)
                .min(Comparator.comparing(Amount::getValue))
                .map(amount -> getAmountTypes(amount, null))
                .orElseGet(() -> getLowestFixedPrices(listingActivity));
    }

    public static Pair<AmountType, AmountType> getBuyItNowPrices(ListingActivitiesDetail listingActivity) {
        ListingTypeCodeType listingType = ListingActivitiesUtil.getListingCodeType(listingActivity);
        if (!ListingCodeTypeUtil.isClassifiedAdType(listingType)) {
            if (listingType.equals(ListingTypeCodeType.PERSONAL_OFFER)) {
                return ListingActivitiesUtil.getCurrentPrices(listingActivity, listingType);
            } else {
                return ListingActivitiesUtil.getLowestAvailableVariationPrice(listingActivity);
            }
        }
        return Pair.of(null, null);
    }

    /** Returns Amount as key, then Converted Amount as value (if applicable) */
    public static Pair<AmountType, AmountType> getAmountTypes(Amount amount, AmountType defaultAmount) {
        if (amount == null) {
            return new ImmutablePair<>(defaultAmount, null);
        }

        List<AmountType> amountTypes = new ArrayList<>(2);
        if (amount.getConvertedFromCurrency() != null && amount.getConvertedFromValue() != null) {
            amountTypes.add(AmountTypeUtil.getAmountType(amount.getConvertedFromCurrency().name(), NumberUtil.roundToCent(amount.getConvertedFromValue())));
        }
        amountTypes.add(AmountTypeUtil.getAmountType(amount.getCurrency().name(), NumberUtil.roundToCent(amount.getValue())));
        return new ImmutablePair<>(amountTypes.get(0), amountTypes.size() == 2 ? amountTypes.get(1) : null);
    }

    public static ReasonHideFromSearchCodeType getReasonHideFromSearch(ListingActivitiesDetail listingActivity) {
        Boolean isDuplicateListing = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getIsDuplicateAuctionListing).orElse(Boolean.FALSE);
        Integer availableQty = getAvailableQuantity(listingActivity);
        if (isDuplicateListing) {
            return ReasonHideFromSearchCodeType.DUPLICATE_LISTING;
        } else if (availableQty == 0) {
            return ReasonHideFromSearchCodeType.OUT_OF_STOCK;
        }
        return null;
    }

    public static Integer getQuantity(ListingActivitiesDetail listingActivity) {
        return getQuantityAndAvailability(listingActivity)
                .map(QuantityAndAvailability::getListedQuantity).orElse(null);
    }

    public static Integer getAvailableQuantity(ListingActivitiesDetail listingActivity) {
        return getQuantityAndAvailability(listingActivity)
                .map(QuantityAndAvailability::getAvailableQuantity).orElse(0);
    }

    private static Integer getSoldQuantity(ListingActivitiesDetail listingActivity) {
        return getQuantityAndAvailability(listingActivity)
                .map(QuantityAndAvailability::getSoldQuantity).orElse(0);
    }

    private static Optional<QuantityAndAvailability> getQuantityAndAvailability(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getTradingSummary)
                .map(TradingSummary::getQuantityAndAvailabilityByLogisticsPlans)
                .map(QuantityAndAvailabilityByLogisticsPlans::getQuantityAndAvailability);
    }

    public static PictureDetailsType getPictureDetails(ListingActivitiesDetail listingActivity) {
        String imageUrl = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getImages)
                .flatMap(imageList -> imageList.stream().findFirst())
                .map(Image::getImageURL).orElse(null);
        PictureDetailsType pictureDetailsType = new PictureDetailsType();
        List<String> pictureUrl = Collections.singletonList(imageUrl);
        pictureDetailsType.getPictureURL().addAll(pictureUrl);
        return pictureDetailsType;
    }

    public static Integer getNewLeadCount(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getTradingSummary)
                .map(TradingSummary::getUnansweredQuestionCount).orElse(0);
    }

    public static Integer getLeadCount(ListingActivitiesDetail listingActivity) {
        return listingActivity.getLeadCount();
    }

    public static ListingTypeCodeType getListingCodeType(ListingActivitiesDetail listingActivity) {
        ListingTypeCodeType listingTypeCodeType = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getFormat)
                .map(listingFormatEnum -> ListingTypeMapper.map(listingFormatEnum.name())).orElse(ListingTypeCodeType.UNKNOWN);

        if (ListingCodeTypeUtil.isClassifiedAdType(listingTypeCodeType)) {
            long categoryId = getMetaCategoryId(listingActivity);
            if (categoryId == ApiSellingExtSvcConstants.REAL_ESTATE_CATEGORY_ID) {
                return ListingTypeCodeType.AD_TYPE;
            } else {
                return ListingTypeCodeType.LEAD_GENERATION;
            }
        }
        return listingTypeCodeType;
    }

    public static String getListingDuration(ListingActivitiesDetail listingActivity) {
        Enum<ListingDurationEnum> duration = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getListingLifecycle)
                .map(ListingLifecycle::getListingDuration)
                .orElse(null);
        if (duration != null) {
            return !Objects.equals(duration.toString(), "GTC") ?
                    CaseUtils.toCamelCase(duration.toString(), true, ' ') : duration.toString();
        }
        return null;
    }

    public static Boolean getRelistedAlready(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getListingLifecycle)
                .map(ListingLifecycle::getRelistedAlready).orElse(false);
    }

    public static ListingDetailsType getListingDetails(ItemType itemType, ListingActivitiesDetail listingActivity) {
        SiteContext listedMarketPlaceSiteContext = SiteContext.create(SiteUtils.getSiteId(ListingActivitiesUtil.getMarketPlaceListedOn(listingActivity)));
        ListingDetailsType listingDetailsType = new ListingDetailsType();
        if (!ListingCodeTypeUtil.isClassifiedAdType(ListingActivitiesUtil.getListingCodeType(listingActivity))) {
            listingDetailsType.setConvertedBuyItNowPrice(getBuyItNowPrices(listingActivity).getValue());
        }
        listingDetailsType.setConvertedReservePrice(getReservePrices(listingActivity).getValue());
        listingDetailsType.setConvertedStartPrice(getStartPrices(listingActivity).getValue());
        listingDetailsType.setStartTime(getStartTime(listingActivity));
        String listingSite = String.valueOf(listedMarketPlaceSiteContext.viewingSiteId);
        listingDetailsType.setViewItemURL(ViewItemURLUtil.getViewItemUrl(itemType.getItemID(), itemType.getTitle(), listingSite));
        listingDetailsType.setViewItemURLForNaturalSearch(ViewItemURLUtil.buildViewItemURLForNaturalSearch(listingActivity, itemType.getItemID(), itemType.getTitle(), listingSite));
        if (Stream.of(listingDetailsType.getStartTime(), listingDetailsType.getViewItemURL(),
                        listingDetailsType.getViewItemURLForNaturalSearch())
                .allMatch(Objects::nonNull)) {
            return listingDetailsType;
        }
        return null;
    }

    private static XMLGregorianCalendar getStartTime(ListingActivitiesDetail listingActivity) {
        DateTime scheduledDateTime = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getListingLifecycle)
                .map(ListingLifecycle::getScheduledStartDate).orElse(null);
        return convertToXMLGregorianCalendar(scheduledDateTime);
    }

   public static XMLGregorianCalendar getActualEndTime(ListingActivitiesDetail listingActivity) {
        DateTime actualEndTime = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getListingLifecycle)
                .map(ListingLifecycle::getActualEndDate).orElse(null);
        return convertToXMLGregorianCalendar(actualEndTime);
    }

    public static Pair<AmountType, AmountType> getStartPrices(ListingActivitiesDetail listingActivity) {
        Amount amount;
        Optional<ItemVariation> itemVariation = getItemVariation(listingActivity);
        Optional<PriceSettings> priceSettings = itemVariation.map(ItemVariation::getPriceSettings);
        ListingTypeCodeType listingTypeCodeType = getListingCodeType(listingActivity);
        if (ListingCodeTypeUtil.isClassifiedAdType(listingTypeCodeType)) {
            amount = priceSettings.map(PriceSettings::getLowestFixedPrice).orElse(null);
        } else if (listingTypeCodeType.equals(ListingTypeCodeType.CHINESE)) {
            amount = priceSettings.map(PriceSettings::getStartingBidPrice).orElse(null);
        } else if (listingTypeCodeType.equals(ListingTypeCodeType.PERSONAL_OFFER)) {
            amount = itemVariation.map(ItemVariation::getItemVariationTradingSummary)
                    .map(ItemVariationTradingSummary::getCurrentBidPrice).orElse(null);
        } else {
            return new ImmutablePair<>(null, null);
        }

        AmountType defaultAmount = getZeroAmountType(getListedMarketplaceSiteContext(listingActivity));
        return getAmountTypes(amount, defaultAmount);
    }

    public static Pair<AmountType, AmountType> getReservePrices(ListingActivitiesDetail listingActivity) {
        ListingTypeCodeType listingTypeCodeType = getListingCodeType(listingActivity);
        if (!listingTypeCodeType.equals(ListingTypeCodeType.CHINESE) && !listingTypeCodeType.equals(ListingTypeCodeType.PERSONAL_OFFER) ) {
            return new ImmutablePair<>(null, null);
        }
        Amount amount = getItemVariation(listingActivity)
                .map(ItemVariation::getPriceSettings)
                .map(PriceSettings::getAuctionReservePrice).orElse(null);

        AmountType defaultAmount = getZeroAmountType(getListedMarketplaceSiteContext(listingActivity));
        return getAmountTypes(amount, defaultAmount);
    }


    public static boolean isItemHideFromSearch(ListingActivitiesDetail listingActivity) {
        return getReasonHideFromSearch(listingActivity) != null;
    }

    public static BestOfferDetailsType getBestOfferDetails(ListingActivitiesDetail listingActivity) {
        BestOfferDetailsType bestOfferDetailsType = new BestOfferDetailsType();
        Optional<List<UnifiedOffer>> unifiedOfferList = getItemVariation(listingActivity).map(ItemVariation::getUserToItemVariationRelationshipSummary)
                .map(UserToItemVariationRelationshipSummary::getOffers)
                .filter(CollectionUtils::isNotEmpty);

        if (unifiedOfferList.isPresent()) {
            unifiedOfferList = Optional.of(unifiedOfferList.get().stream()
                    .filter(unifiedOfferStream -> (unifiedOfferStream.getNegotiationType().equals(NegotiationType.BEST_OFFER)
                            && bestOfferTypes.contains(unifiedOfferStream.getOfferType())))
                    .collect(Collectors.toList()));
            if (unifiedOfferList.get().size() > 0) {
                bestOfferDetailsType.setBestOfferCount(unifiedOfferList.get().size());
                return bestOfferDetailsType;
            }
        }
        return null;
    }

    public static String getItemId(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getListingId).orElse("null");
    }

    public static Duration getTimeLeft(ListingActivitiesDetail listingActivity) throws DatatypeConfigurationException {
        Optional<Long> endTime = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getListingLifecycle)
                .map(ListingLifecycle::getTimeRemaining)
                .map(TimeDuration::getValue);
        if (endTime.isPresent()) {
            return getDuration(endTime.get());
        }
        return null;
    }

    public static Duration getDuration(Long endTime) throws DatatypeConfigurationException {
        Duration duration = DatatypeFactory.newInstance().newDuration(endTime * 1000L); // convert to milliseconds
        BigInteger years = null;
        if (duration.getYears() != 0) {
            years = new BigInteger(String.valueOf(duration.getYears()));
        }
        BigInteger months = null;
        if (duration.getMonths() != 0) {
            months = new BigInteger(String.valueOf(duration.getYears()));
        }
        BigInteger days = null;
        if (duration.getDays() != 0) {
            days = new BigInteger(String.valueOf(duration.getDays()));
        }
        BigInteger hours = null;
        if (duration.getHours() != 0) {
            hours = new BigInteger(String.valueOf(duration.getHours()));
        }
        BigInteger minutes = null;
        if (duration.getMinutes() != 0) {
            minutes = new BigInteger(String.valueOf(duration.getMinutes()));
        }
        BigDecimal seconds = null;
        if (duration.getSeconds() != 0) {
            seconds = BigDecimal.valueOf(duration.getSeconds(), 0);
        }
        return endTime > 0L ? DatatypeFactory.newInstance().newDuration(true, years, months, days, hours,
                minutes, seconds) :
                DatatypeFactory.newInstance().newDuration("PT0S");
    }

    private static Optional<ItemVariation> getItemVariation(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getItemVariations)
                .flatMap(itemVariations -> itemVariations.stream().findFirst());
    }

    public static String getEBayNotes(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getNotes)
                .flatMap(notes -> Arrays.stream(notes).filter(note -> NoteType.SYSTEM.equals(note.getType())).findFirst())
                .filter(Objects::nonNull)
                .map(Note::getMessage).orElse(null);
    }

    public static ItemPolicyViolationType getPolicyViolationNotes(ListingActivitiesDetail listingActivity, IContentHelper contentHelper) {
        return Optional.ofNullable(listingActivity)
            .map(ListingActivitiesDetail::getNotes)
            .flatMap(notes -> Arrays.stream(notes).filter(note -> NoteType.SYSTEM.equals(note.getType()) && "PolicyViolation".equals(note.getName())).findFirst())
            .map(note -> {
                ItemPolicyViolationType itemPolicyViolation = new ItemPolicyViolationType();
                itemPolicyViolation.setPolicyText(contentHelper.getContentManager().getText(ContentBundleEnum.MessageContent, "POLICY_VIOLATION"));
                return itemPolicyViolation;
            })
            .orElse(null);
    }

    public static String getPrivateNotes(ListingActivitiesDetail listingActivity) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getNotes)
                .flatMap(notes -> Arrays.stream(notes).filter(note -> NoteType.USER.equals(note.getType())).findFirst())
                .filter(Objects::nonNull)
                .map(Note::getMessage).orElse(null);
    }

    public static String getUpdatedFilterDate(ItemListCustomizationType itemListCustomizationType, String requestType) {
        TimeZone timeZone = TimeZone.getDefault();
        Calendar startDateCalendar;
        Calendar endDateCalendar = DateUtil.getCalendarNow();
        String endDate = DateUtil.convert(endDateCalendar);
        String startDate;
        if (null != itemListCustomizationType.getDurationInDays()) {
            int duration = itemListCustomizationType.getDurationInDays();
            startDateCalendar = DateUtil.getDateWithOffset(duration, timeZone);
        } else {
            startDateCalendar = DateUtil.getDateWithOffset(GMES_DEFAULT_NUMBER_OF_DAYS, timeZone);
        }
        startDate = DateUtil.convert(startDateCalendar);
        return requestType + COMMA + ACTUAL_END_DATE + COLON + BRACKET_LEFT + startDate + DOT + DOT + endDate + BRACKET_RIGHT;
    }

    public static AmountType getClassifiedAdPayPerLeadFee(ListingActivitiesDetail listingActivity) {
        return getZeroAmountType(getListedMarketplaceSiteContext(listingActivity));
    }

    public static MarketplaceIdEnum getMarketPlaceListedOn(ListingActivitiesDetail listingActivity) {
        return Optional.of(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getMarketplaceListedOn)
                .orElse(MarketplaceIdEnum.EBAY_US);
    }

    private static SiteContext getListedMarketplaceSiteContext(ListingActivitiesDetail listingActivity) {
        return SiteContext.create(SiteUtils.getSiteId(ListingActivitiesUtil.getMarketPlaceListedOn(listingActivity)));
    }

    private static AmountType getZeroAmountType(SiteContext siteContext) {
        String siteCurrency = SiteUtils.getSiteCurrency(String.valueOf(siteContext.viewingSiteId)).name();
        return AmountTypeUtil.getZeroAmountType(siteCurrency);
    }

    private static long getMetaCategoryId(ListingActivitiesDetail listingActivity) {
        return Optional.of(listingActivity).map(ListingActivitiesDetail::getMetaCategoryId).orElse(0L);
    }

    public static AmountType getConvertedAmount(AmountType amountType, int siteId) {
        if (amountType == null || SiteUtils.getSiteCurrency(String.valueOf(siteId)).equals(amountType.getCurrencyID())) {
            return null;
        }
        AmountType convertedAmountType = MoneyExchangeHelper.exchange(new ExchangeRateBofImpl(), amountType, siteId);
        if (convertedAmountType != null && convertedAmountType.getValue() != 0) {
            return convertedAmountType;
        }
        return null;
    }
}
