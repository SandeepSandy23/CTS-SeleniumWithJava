package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import com.ebay.integ.dal.cache2.KeyDefinition;
import com.ebay.integ.dal.cache2.KeyManager;
import com.ebay.integ.dal.cache2.SimpleCollectionKeyDefinition;
import com.ebay.kernel.util.JdkUtil;

public class TaxRateKeyManager implements KeyManager {
    public static final int COLLECTION_KEY = 0;
    private static final long serialVersionUID = 7029078791248902999L;
    private static final TaxRateKeyManager m_Instance = new TaxRateKeyManager();
    private KeyDefinition[] m_keyDefinitionList;

    private TaxRateKeyManager() {
        this.init();
    }

    public static TaxRateKeyManager getInstance() {
        return m_Instance;
    }

    private void init() {
        String[] keyFieldNameList = new String[]{"m_siteId", "m_countryId"};
        KeyDefinition[] keyDefinitionList = new KeyDefinition[]{
                new SimpleCollectionKeyDefinition(0, keyFieldNameList, JdkUtil.forceInit(TaxRateDoImpl.class))};
        this.m_keyDefinitionList = keyDefinitionList;
    }

    public KeyDefinition[] getKeyDefinitionList() {
        return this.m_keyDefinitionList;
    }

    public KeyDefinition getKeyDefinition(int id) {
        return this.m_keyDefinitionList[id];
    }
}
