package com.ebay.app.apisellingextsvc.utils;

import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.EntityTotal;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.ItemListCustomizationType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Collection;
import java.util.List;
import java.util.Objects;

/**
 * Cannot think any better name
 */
public class CommonUtil {

    /**
     * check whether we should expose field only for return all detail level
     *
     * @param detailLevels detailLevel list
     * @return only return true when ReturnAll is set to DetailLevel; otherwise return false
     */
    public static boolean shouldExposeOnlyForReturnAll(List<DetailLevelCodeType> detailLevels) {
        if (CollectionUtils.isEmpty(detailLevels)) {
            return false;
        }
        return detailLevels.contains(DetailLevelCodeType.RETURN_ALL);
    }

    /**
     * Check the Include precondition for GMES containers
     *
     * @param itemListCustomizationType
     * @param detailLevels
     * @return If ReturnAll, then return true unless Include:false.
     * Otherwise, return true unless container is null
     */
    public static boolean isRequiredContainer(ItemListCustomizationType itemListCustomizationType, List<DetailLevelCodeType> detailLevels) {
        boolean required = CommonUtil.shouldExposeOnlyForReturnAll(detailLevels);
        if (itemListCustomizationType != null) {
            required = itemListCustomizationType.isInclude() == null || Boolean.TRUE.equals(itemListCustomizationType.isInclude());
        }
        return required;
    }

    /**
     * check whether we should expose field only for return all detail level
     *
     * @param detailLevels detailLevel list
     * @return return true when ReturnAll is set to DetailLevel or not send ReturnAll; otherwise return false
     */
    public static boolean shouldExposeForReturnAllOrEmpty(List<DetailLevelCodeType> detailLevels) {
        if (CollectionUtils.isEmpty(detailLevels)) {
            return true;
        }
        return detailLevels.contains(DetailLevelCodeType.RETURN_ALL);
    }

    public static String getLineItemIdForFilter(ContractResponseType contractResponseType) {
        boolean isPartialRequest = OrderBuilderUtil.onlyNeedPartialOrder(contractResponseType, contractResponseType.getOrder().getLineItemTypes().size());
        // partial request & orderLevel, use lineItemId for filter
        String lineItemIdForFilter = null;
        if (isPartialRequest) {
            String requestLookupKey = OrderBuilderUtil.getRequestLookupKey(contractResponseType);
            String lineItemIdMatchRequestLookupKey = contractResponseType.getOrder().getLineItemTypes().stream()
                    .filter(Objects::nonNull)
                    .filter(itemXType -> Objects.nonNull(itemXType.getSourceId()))
                    .filter(itemXType -> Objects.equals(itemXType.getSourceId().getLookupKey(), requestLookupKey))
                    .map(itemXType -> itemXType.getLineItemId()).findFirst().orElse(null);
            lineItemIdForFilter = lineItemIdMatchRequestLookupKey;
        }
        return lineItemIdForFilter;
    }

    public static Long getProformaLineItemIdForFilter(ContractResponseType contractResponseType) {
        boolean isPartialRequest = OrderBuilderUtil.onlyNeedPartialOrder(contractResponseType, contractResponseType.getProformaOrder().getLineItemTypes().size());
        // partial request & orderLevel, use lineItemId for filter
        Long lineItemIdForFilter = null;
        if (isPartialRequest) {
            String requestLookupKey = OrderBuilderUtil.getRequestLookupKey(contractResponseType);
            Long lineItemIdMatchRequestLookupKey = contractResponseType.getProformaOrder().getLineItemTypes().stream()
                    .filter(Objects::nonNull)
                    .filter(itemXType -> Objects.nonNull(itemXType.getSourceId()))
                    .filter(itemXType -> Objects.equals(itemXType.getSourceId().getLookupKey(), requestLookupKey))
                    .map(itemXType -> itemXType.getLineItemId()).findFirst().orElse(null);
            lineItemIdForFilter = lineItemIdMatchRequestLookupKey;
        }
        return lineItemIdForFilter;
    }

    public static <T> T findFirst(List<T> list) {
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0);
        }
        return null;
    }
}
