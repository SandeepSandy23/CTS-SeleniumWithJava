package com.ebay.app.apisellingextsvc.service.dal.sellerpref;

import com.ebay.integ.dal.DalDOI;
import com.ebay.persistence.Column;
import com.ebay.persistence.Table;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Table(name = "EBAY_SELLER_PREF")
public interface SellerPref extends DalDOI {

    @Id
    @Column(name = "SELLER_ID")
    long getSellerId();

    void setSellerId(long sellerId);

    @Column(name = "SHIPPING_PREFS_FLAGS")
    long getShippingPrefsFlags();

    void setShippingPrefsFlags(long shippingPrefsFlags);
}
