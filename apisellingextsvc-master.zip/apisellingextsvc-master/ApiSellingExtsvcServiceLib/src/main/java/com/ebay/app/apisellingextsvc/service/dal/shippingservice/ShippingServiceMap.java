package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.FieldMapping;
import com.ebay.integ.dal.map.Query;
import com.ebay.integ.dal.map.ReadSet;
import com.ebay.integ.dal.map.UpdateSet;

public class ShippingServiceMap extends ShippingServiceCodeGenMap {
    private static ShippingServiceMap m_instance = new ShippingServiceMap();
    private FieldMapping[] m_builtFieldMappings = null;
    private FieldMapping[] m_ourFieldMappings = null;
    private ReadSet[] m_builtReadSets = null;
    private UpdateSet[] m_builtUpdateSets = null;

    protected ShippingServiceMap() {
    }

    public static BaseMap2 getInstance() {
        return m_instance;
    }

    protected String getDeveloper() {
        return "Subha Guhan";
    }

    protected String getModDate() {
        return "06/28/05";
    }

    protected FieldMapping[] getFieldMappings() {
        if (this.m_builtFieldMappings == null) {
            this.m_ourFieldMappings = new FieldMapping[0];
            this.m_builtFieldMappings = this.appendMappings(super.getFieldMappings(), this.m_ourFieldMappings);
        }

        return this.m_builtFieldMappings;
    }

    protected ReadSet[] getReadSets() {
        if (this.m_builtReadSets == null) {
            ReadSet[] readSets = new ReadSet[0];
            this.m_builtReadSets = this.appendReadSets(super.getReadSets(), super.getFieldMappings(), readSets, this.m_ourFieldMappings);
        }

        return this.m_builtReadSets;
    }

    protected UpdateSet[] getUpdateSets() {
        if (this.m_builtUpdateSets == null) {
            UpdateSet[] updateSets = new UpdateSet[0];
            this.m_builtUpdateSets = this.appendUpdateSets(super.getUpdateSets(), super.getFieldMappings(), updateSets, this.m_ourFieldMappings);
        }

        return this.m_builtUpdateSets;
    }

    protected Query[] getRawQueries() {
        Query[] queries = new Query[0];
        queries = this.mergeQuerySets(super.getRawQueries(), queries);
        return queries;
    }

}