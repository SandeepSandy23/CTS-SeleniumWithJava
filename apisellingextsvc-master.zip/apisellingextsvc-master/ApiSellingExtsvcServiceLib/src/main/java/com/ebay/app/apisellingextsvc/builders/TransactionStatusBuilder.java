package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.utils.PaymentHoldStatusUtil;
import com.ebay.cosmos.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.TransactionStatusType;

public class TransactionStatusBuilder extends BaseFacetBuilder<TransactionStatusType> {

    private final OrderStateTypeCS orderStates;

    public TransactionStatusBuilder(Task task, OrderCSXType order) {
        super(task);
        orderStates = order.getOrderStates();
    }

    public TransactionStatusBuilder(Task task, ProformaOrderXType order) {
        super(task);
        orderStates = order.getOrderStates();
    }

    @Override
    protected TransactionStatusType doBuild() {
        TransactionStatusType statusType = new TransactionStatusType();
        //https://jirap.corp.ebay.com/browse/TRXAPI-2100
        statusType.setPaymentHoldStatus(PaymentHoldStatusUtil.getPaymentHoldStatus(orderStates));

        return statusType;
    }
}
