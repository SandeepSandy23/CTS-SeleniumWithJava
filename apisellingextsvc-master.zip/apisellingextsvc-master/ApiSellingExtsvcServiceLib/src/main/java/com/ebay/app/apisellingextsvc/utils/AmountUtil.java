package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.order.common.base.Amount;
import org.apache.commons.lang3.ObjectUtils;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

/**
 * Util class for amount type
 */
public final class AmountUtil {

    private AmountUtil() {
        // sonar - Class should define a constructor.
    }

    @SafeVarargs
    public static BigDecimal sum(List<Amount>... amountList) {
        return Arrays.stream(amountList).flatMap(Collection::stream).filter(Objects::nonNull)
              .map(amount -> ObjectUtils.defaultIfNull(amount.getConvertedFromValue(), amount.getValue())).filter(Objects::nonNull)
              .map(BigDecimal::new).reduce(BigDecimal::add).orElse(ApiSellingExtSvcConstants.ZERO_AMOUNT_BIG_DECIMAL);
    }
}
