package com.ebay.app.apisellingextsvc.enums;

public enum ContentBundleEnum {
    ErrorContent,
    ItemContent,
    CountryContent,
    MessageContent
}
