package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.order.common.v1.ReturnStatusTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.ReturnStatusCodeType;

// for transaction.status.return status
public class ReturnStatusMapper {

    private static final ImmutableMap<ReturnStatusTypeEnum, ReturnStatusCodeType> mapName
            = new ImmutableMap.Builder<ReturnStatusTypeEnum, ReturnStatusCodeType>()
            .put(ReturnStatusTypeEnum.INVALID, ReturnStatusCodeType.INVALID)
            .put(ReturnStatusTypeEnum.DEFAULT, ReturnStatusCodeType.NOT_APPLICABLE)
            .put(ReturnStatusTypeEnum.RETURN_REQUEST_PENDING_APPROVAL, ReturnStatusCodeType.RETURN_REQUEST_PENDING_APPROVAL)
            .put(ReturnStatusTypeEnum.RETURN_REQUEST_REJECTED, ReturnStatusCodeType.RETURN_REQUEST_REJECTED)
            .put(ReturnStatusTypeEnum.RETURN_OPEN, ReturnStatusCodeType.RETURN_OPEN)
            .put(ReturnStatusTypeEnum.RETURN_SHIPPED, ReturnStatusCodeType.RETURN_SHIPPED)
            .put(ReturnStatusTypeEnum.RETURN_DELIVERED, ReturnStatusCodeType.RETURN_DELIVERED)
            .put(ReturnStatusTypeEnum.RETURN_CLOSED_WITH_REFUND, ReturnStatusCodeType.RETURN_CLOSED_WITH_REFUND)
            .put(ReturnStatusTypeEnum.RETURN_ESCALATED, ReturnStatusCodeType.RETURN_ESCALATED)
            .put(ReturnStatusTypeEnum.RETURN_CLOSED_NO_REFUND, ReturnStatusCodeType.RETURN_CLOSED_NO_REFUND)
            .put(ReturnStatusTypeEnum.RETURN_ESCALATED_PENDING_BUYER, ReturnStatusCodeType.RETURN_ESCALATED_PENDING_BUYER)
            .put(ReturnStatusTypeEnum.RETURN_ESCALATED_PENDING_SELLER, ReturnStatusCodeType.RETURN_ESCALATED_PENDING_SELLER)
            .put(ReturnStatusTypeEnum.RETURN_ESCALATED_PENDING_CS, ReturnStatusCodeType.RETURN_ESCALATED_PENDING_CS)
            .put(ReturnStatusTypeEnum.RETURN_ESCALATED_CLOSED_WITH_REFUND, ReturnStatusCodeType.RETURN_ESCALATED_CLOSED_WITH_REFUND)
            .put(ReturnStatusTypeEnum.RETURN_ESCALATED_CLOSED_NO_REFUND, ReturnStatusCodeType.RETURN_ESCALATED_CLOSED_NO_REFUND)
            .put(ReturnStatusTypeEnum.RETURN_REQUEST_PENDING, ReturnStatusCodeType.RETURN_REQUEST_PENDING)
            .put(ReturnStatusTypeEnum.RETURN_REQUEST_CLOSED_WITH_REFUND, ReturnStatusCodeType.RETURN_REQUEST_CLOSED_WITH_REFUND)
            .put(ReturnStatusTypeEnum.RETURN_REQUEST_CLOSED_NO_REFUND, ReturnStatusCodeType.RETURN_REQUEST_CLOSED_NO_REFUND)
            .put(ReturnStatusTypeEnum.RETURN_REQUEST_CLOSED_ESCALATED, ReturnStatusCodeType.RETURN_CLOSED_ESCALATED)
            .put(ReturnStatusTypeEnum.NOT_APPLICABLE, ReturnStatusCodeType.NOT_APPLICABLE)
            .build();

    private static final ImmutableMap<ReturnStatusTypeEnum, ReturnStatusCodeType> returnStatusMap =
            new ImmutableMap.Builder<ReturnStatusTypeEnum, ReturnStatusCodeType>()
                    .put(ReturnStatusTypeEnum.RETURN_REQUEST_PENDING, ReturnStatusCodeType.RETURN_OPEN)
                    .put(ReturnStatusTypeEnum.RETURN_REQUEST_CLOSED_WITH_REFUND, ReturnStatusCodeType.RETURN_CLOSED_WITH_REFUND)
                    .put(ReturnStatusTypeEnum.RETURN_REQUEST_CLOSED_NO_REFUND, ReturnStatusCodeType.RETURN_CLOSED_NO_REFUND)
                    .build();

    private ReturnStatusMapper() {
    }

    public static ReturnStatusCodeType map(ReturnStatusTypeEnum key, int trxVersion) {

        if (trxVersion >= ApiSellingExtSvcConstants.COMPATIBILITY_LEVEL_887) {
            return mapName.get(key);
        }

        return returnStatusMap.get(key);
    }

}
