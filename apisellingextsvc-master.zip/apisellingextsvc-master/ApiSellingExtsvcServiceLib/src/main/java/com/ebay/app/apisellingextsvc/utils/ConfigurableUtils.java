package com.ebay.app.apisellingextsvc.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class ConfigurableUtils {

    /*
     * Validates the outputselector tags against the loaded map for any
     * typos in the requested element tags
     */
    public static Map validate(Map map, ArrayList parsedOutputSelectors) {
        HashMap errorsList = new HashMap();
        for(int i = 0; i < parsedOutputSelectors.size(); i++) {
            String listItem = (String)parsedOutputSelectors.get(i);
            String [] list = listItem.split("\\.");
            String leafNode = null;
            for(int j =0; j < list.length; j++) {
                boolean flag = false;
                leafNode = list[j];
                if(!map.containsKey(leafNode.toLowerCase())) {
                    flag = true;
                }
                if(flag) {
                    errorsList.put(listItem, leafNode);
                }
            }
        }
        return errorsList;
    }

    /*
     *  Parses the output selectorlist and returns an arraylist
     */
    public static ArrayList parseOutputSelectors(String[] outputSelector) {
        ArrayList list = new ArrayList();
        for(int i =0; i<outputSelector.length; i++ ) {
            String x = outputSelector[i];
            if(!containsEmptyString(x) && notContainsMultipleStrings(x)){
                list.add(x);
            }
            else {
                String temp[] = x.split(",");
                for(int j =0; j<temp.length; j++) {
                    String y = temp[j];
                    if(!containsEmptyString(y.trim())) {
                        list.add(y);
                    }
                }
            }
        }
        return list;
    }

    /*
     * Checks for Empty Strings
     */
    public static boolean containsEmptyString(String tag) {
        boolean isEmpty  = false;
        if("".equals(tag)) {
            isEmpty = true;
        }
        return isEmpty;
    }

    /*
     * Checks for MultipleStrings
     */

    public static boolean notContainsMultipleStrings(String tag) {
        boolean isMultipleStrings = false;
        int index = tag.indexOf(",");
        if(index == -1) {
            isMultipleStrings = true;
        }
        return isMultipleStrings;

    }
}