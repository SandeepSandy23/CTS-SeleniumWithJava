package com.ebay.app.apisellingextsvc.service.dal.userlookup;

import com.ebay.integ.dal.BaseDo3;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.persistence.DALVersion;

@DALVersion("3.0")
@SuppressWarnings({"PMD", "FindBugs"})
public class UserLookupCodeGenDoImpl extends BaseDo3 implements UserLookup {

    public static final int USERID = 0;
    public static final int HOSTID01 = 5;

    public long m_userId;
    public int m_hostId01;

    public UserLookupCodeGenDoImpl() {
        super(UserLookupDAO.getInstance(), GenericMap.getInitializedMap(UserLookup.class));
    }

    public UserLookupCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    @Override
    public long getUserId() {
        loadValue(USERID);
        return m_userId;
    }


    @Override
    public void setUserId(long userId) {
        this.m_userId = userId;
        setDirty(USERID);
    }

    @Override
    public int getHostId01() {
        loadValue(HOSTID01);
        return this.m_hostId01;
    }

    @Override
    public void setHostId01(int hostId) {
        setDirty(HOSTID01);
        this.m_hostId01 = hostId;
    }

    @Override
    public int getNumFields() {
        return 35;
    }
}
