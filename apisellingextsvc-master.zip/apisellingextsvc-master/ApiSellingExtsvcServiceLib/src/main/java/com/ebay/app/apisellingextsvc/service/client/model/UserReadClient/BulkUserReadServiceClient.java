package com.ebay.app.apisellingextsvc.service.client.model.UserReadClient;

import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Component
public class BulkUserReadServiceClient extends BaseGingerClient<String, UserReadResponse> {
    private static final Logger logger = LoggerFactory.getLogger(BulkUserReadServiceClient.class);
    private static final String USER_READ_BULK_CLIENT = "identity.BulkUserReadSvc";
    private static final String PATH = "/user/graphql";

    public BulkUserReadServiceClient() {
        super(UserReadResponse.class);
    }

    @Override
    public GingerClientResponse<UserReadResponse> getGingerResponse(GingerClientRequest<String> gingerClientRequest) {
        return processPostRequest(PATH, gingerClientRequest.getHeaders(), gingerClientRequest,true);
    }

    @Override
    public String getTargetBase() {
        return USER_READ_BULK_CLIENT;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
