package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import java.io.Serializable;
import java.util.Comparator;

public class ItemHostInfoByRangeStartComparator implements Comparator, Serializable {
    ItemHostInfoByRangeStartComparator() {
    }

    public int compare(Object arg0, Object arg1) {
        long itemHostInfo1 = ((ItemHostInfo) arg0).getRangeStart();
        long itemHostInfo2 = ((ItemHostInfo) arg1).getRangeStart();
        if (itemHostInfo1 == itemHostInfo2) {
            return 0;
        } else {
            return itemHostInfo1 < itemHostInfo2 ? -1 : 1;
        }
    }

}
