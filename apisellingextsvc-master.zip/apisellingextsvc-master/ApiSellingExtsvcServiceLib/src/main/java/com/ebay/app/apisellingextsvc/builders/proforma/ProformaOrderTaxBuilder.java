package com.ebay.app.apisellingextsvc.builders.proforma;

import com.ebay.app.apisellingextsvc.builders.BaseFacetBuilder;
import com.ebay.app.apisellingextsvc.utils.TaxUtil;
import com.ebay.cosmos.OrderTotal;
import com.ebay.order.common.v1.Attribute;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.*;

import java.util.List;

// TODO: 10/11/22 Need to integrate with TaxesBuilder 
public class ProformaOrderTaxBuilder extends BaseFacetBuilder<TaxesType> {
    private final OrderTotal orderTotal;
    private final List<Attribute> orderAttributes;

    public ProformaOrderTaxBuilder(Task<?> task,
                                   OrderTotal orderTotal,
                                   List<Attribute> orderAttributes) {
        super(task);
        this.orderTotal = orderTotal;
        this.orderAttributes = orderAttributes;
    }

    @Override
    protected TaxesType doBuild() {
        if (missingTaxType()) {
            return null;
        }
        return null;
    }

    private boolean missingTaxType() {
        return !TaxUtil.isTaxTypeExist(orderAttributes);
    }

    private TaxesType buildTax() {
        return null;
    }
}
