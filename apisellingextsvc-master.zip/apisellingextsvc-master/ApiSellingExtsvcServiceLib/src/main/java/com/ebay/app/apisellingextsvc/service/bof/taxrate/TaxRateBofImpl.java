package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;

import java.util.Date;

public class TaxRateBofImpl implements ITaxRateBof {
    @Override
    public TaxRate findActiveTaxRate(int siteId, int countryId, Date inputDate) {
        try {
            TaxRate taxRate = TaxRateDAO.getInstance().findActiveTaxRate(siteId, countryId, inputDate);
            if (taxRate != null) {
                return taxRate;
            }
        } catch (Exception e) {
            CalLogger.error("Tax rate get error: ",
                    "cannot get active tax rate with countryId:" + countryId
                            + " siteId:" + siteId + " requestDate:" + inputDate);
        }
        return null;
    }
}
