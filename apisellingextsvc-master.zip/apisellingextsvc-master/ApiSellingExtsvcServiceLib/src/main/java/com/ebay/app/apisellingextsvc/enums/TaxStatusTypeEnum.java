package com.ebay.app.apisellingextsvc.enums;

import brave.internal.Nullable;

public enum TaxStatusTypeEnum {
    NOTAPPLIEDYET("NotAppliedYet", 0),
    PENDING("Pending", 1),
    GRANTED("Granted", 2),
    DENIED("Denied", 3),
    DELETEDBYCS("DeletedByCS", 4),
    DELETEDBYUSER("DeletedByuser", 5),
    UNVERIFIED("Unverified", 6),
    VERIFIED("Verified", 7),
    VATVERIFIED("VATVerified", 8);

    private final String name;
    private final int intValue;

    TaxStatusTypeEnum(String name, int intValue) {
        this.name = name;
        this.intValue = intValue;
    }

    @Nullable
    public static TaxStatusTypeEnum getByIntValue(Integer intValue) {
        if (intValue == null) {
            return null;
        }
        for (TaxStatusTypeEnum c: values()) {
            if (c.intValue == intValue) {
                return c;
            }
        }
        return null;
    }
}
