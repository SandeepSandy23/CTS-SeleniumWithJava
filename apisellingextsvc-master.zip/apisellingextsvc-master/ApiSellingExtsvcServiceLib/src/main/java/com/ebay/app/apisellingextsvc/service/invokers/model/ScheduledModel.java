package com.ebay.app.apisellingextsvc.service.invokers.model;

import ebay.apis.eblbasecomponents.PaginatedItemArrayType;
import lombok.AllArgsConstructor;
import lombok.Getter;


/**
 * wrapper class to differentiate data in orchestrator dependency
 *
 */
@Getter
public class ScheduledModel extends ResponseModel{

    public ScheduledModel(PaginatedItemArrayType scheduleList) {
        super(scheduleList);
    }
}
