package com.ebay.app.apisellingextsvc.audit.comparator.facet;

import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.Optional;

public class SoldOrderFacetComparator extends BaseMapComparator {

    private static final String ORDER_KEY = "OrderID";
    private static final String TRANSACTION_KEY = "TransactionID";

    public SoldOrderFacetComparator(ExtensiveComparator comparator) {
        super(comparator);
    }

    @Override
    protected String getMapKey(JsonNode jsonNode) {
        if(jsonNode.get("Order") != null)
            return getValue(jsonNode.get("Order").get(ORDER_KEY));
        if(jsonNode.get("Transaction") != null)
            return getValue(jsonNode.get("Transaction").get(TRANSACTION_KEY));
        else
            return null;
    }

    @Override
    public boolean qualified(JsonNode org, JsonNode tar, String path) {
        return org.isArray() && tar.isArray()
                && path.endsWith("root.SoldList.OrderTransactionArray.OrderTransaction");
    }
}
