package com.ebay.app.apisellingextsvc.service.dal.saleaggregator;

import com.ebay.integ.dal.BaseDo3;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.persistence.DALVersion;

@DALVersion("3.0")
public class SaleAggregatorCodeGenDoImpl extends BaseDo3 implements SaleAggregator {
    public static final int ITEMID = 14;
    public static final int SELLERPROID = 30;
    public static final int SELLERID = 24;
    public static final int NUM_FIELDS = BaseDo3.NUM_FIELDS + 67;
    public String m_sellerProId;
    public long m_itemId;

    public long m_sellerId;

    public SaleAggregatorCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public SaleAggregatorCodeGenDoImpl() {
        super(SaleAggregatorDAO.getInstance(), GenericMap.getInitializedMap(SaleAggregator.class));
    }

    @Override
    public String getSellerProId() {
        loadValue(SELLERPROID);
        return m_sellerProId;
    }

    @Override
    public void setSellerProId(String sellerProId) {
        m_sellerProId = sellerProId;
        setDirty(SELLERPROID);
    }

    @Override
    public long getItemId() {
        loadValue(ITEMID);
        return m_itemId;
    }

    @Override
    public void setItemId(long itemId) {
        m_itemId = itemId;
        setDirty(ITEMID);
    }

    @Override
    public long getSellerId() {
        loadValue(SELLERID);
        return m_sellerId;
    }

    @Override
    public void setSellerId(long sellerId) {
        m_sellerId = sellerId;
        setDirty(SELLERID);
    }


    @Override
    public int getNumFields() {
        return NUM_FIELDS;
    }
}
