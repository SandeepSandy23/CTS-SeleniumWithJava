package com.ebay.app.apisellingextsvc.service.invokers.model;

import ebay.apis.eblbasecomponents.PaginatedItemArrayType;

/**
 * wrapper class to differentiate data in orchestrator dependency
 *
 */
public class UnsoldModel extends ResponseModel{

    public UnsoldModel(PaginatedItemArrayType unsoldList) {
        super(unsoldList);
    }
}
