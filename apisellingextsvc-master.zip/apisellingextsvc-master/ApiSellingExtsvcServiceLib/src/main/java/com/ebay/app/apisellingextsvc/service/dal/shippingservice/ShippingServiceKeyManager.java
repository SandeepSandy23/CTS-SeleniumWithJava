package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.integ.dal.cache2.KeyDefinition;
import com.ebay.integ.dal.cache2.KeyManager;
import com.ebay.kernel.util.JdkUtil;

public class ShippingServiceKeyManager implements KeyManager {
    public static final int KEY_BY_PK_KEY = 0;
    private static final long serialVersionUID = 5912877736673155877L;
    private static ShippingServiceKeyManager m_Instance = new ShippingServiceKeyManager();
    private KeyDefinition[] m_keyDefinitionList;

    private ShippingServiceKeyManager() {
        this.init();
    }

    public static ShippingServiceKeyManager getInstance() {
        return m_Instance;
    }

    private void init() {
        KeyDefinition[] keyDefinitionList = new KeyDefinition[]{
                new ShippingServiceCKD(KEY_BY_PK_KEY, JdkUtil.forceInit(ShippingServiceDoImpl.class))
        };
        this.m_keyDefinitionList = keyDefinitionList;
    }

    public KeyDefinition[] getKeyDefinitionList() {
        return this.m_keyDefinitionList;
    }

    public KeyDefinition getKeyDefinition(int id) {
        return this.m_keyDefinitionList[id];
    }
}
