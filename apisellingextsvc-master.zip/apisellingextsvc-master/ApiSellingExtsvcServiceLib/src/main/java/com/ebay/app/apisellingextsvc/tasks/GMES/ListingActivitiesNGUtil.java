package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.lib.lasng.model.CoreInfo;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.lib.lasng.model.PricingInfo;
import com.ebay.lib.lasng.model.VariationInfo;
import ebay.apis.eblbasecomponents.AmountType;

import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;

public class ListingActivitiesNGUtil {
    public static AmountType getLowestAvailableVariationPrice(ListingActivity listingActivityNG) {
        String currency = getCurrency(listingActivityNG);
        return Optional.ofNullable(listingActivityNG)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getVariations)
                .map(variationInfos -> variationInfos.stream()
                        .filter(itemVariation -> Optional.of(itemVariation)
                                .map(VariationInfo::getAvailableQty)
                                .map(availableQuantity -> availableQuantity > 0).orElse(false))).orElse(Stream.empty())
                .map(VariationInfo::getPrice)
                .min(Comparator.naturalOrder())
                .map(price -> AmountTypeUtil.getAmountType(currency, price))
                .orElse(null);
    }

    public static AmountType getCurrentPrice(ListingActivity listingActivityNG) {
        String currency = getCurrency(listingActivityNG);
        return Optional.ofNullable(listingActivityNG).map(ListingActivity::getCore)
                .map(CoreInfo::getPrice)
                .map(PricingInfo::getCurrentPrice)
                .map(price -> AmountTypeUtil.getAmountType(currency, price))
                .orElse(null);
    }

    public static AmountType getReservePrice(ListingActivity listingActivityNG) {
        String currency = getCurrency(listingActivityNG);
        return Optional.ofNullable(listingActivityNG).map(ListingActivity::getCore)
                .map(CoreInfo::getPrice)
                .map(PricingInfo::getReservePrice)
                .map(price -> AmountTypeUtil.getAmountType(currency, price))
                .orElse(null);
    }

    public static AmountType getStartPrice(ListingActivity listingActivityNG) {
        String currency = getCurrency(listingActivityNG);
        return Optional.ofNullable(listingActivityNG)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getPrice)
                .map(PricingInfo::getStartPrice)
                .map(price -> AmountTypeUtil.getAmountType(currency, price))
                .orElse(null);
    }

    public static AmountType getBuyItNowPrice(ListingActivity listingActivityNG) {
        String currency = getCurrency(listingActivityNG);
        return Optional.ofNullable(listingActivityNG)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getPrice)
                .map(PricingInfo::getBuyItNowPrice)
                .map(price -> AmountTypeUtil.getAmountType(currency, price))
                .orElse(null);
    }

    public static CoreInfo.FormatEnum getFormat(ListingActivity listingActivityNG) {
        return Optional.ofNullable(listingActivityNG)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getFormat)
                .orElse(null);
    }

    public static String getCurrency(ListingActivity listingActivityNG) {
        return Optional.ofNullable(listingActivityNG).map(ListingActivity::getCore)
                .map(CoreInfo::getPrice)
                .map(PricingInfo::getCurrency).orElse(null);
    }
}
