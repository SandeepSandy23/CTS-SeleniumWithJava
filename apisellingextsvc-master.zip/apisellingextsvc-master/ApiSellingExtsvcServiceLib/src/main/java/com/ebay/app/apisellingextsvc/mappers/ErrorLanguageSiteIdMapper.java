package com.ebay.app.apisellingextsvc.mappers;

import com.google.common.collect.ImmutableMap;

public class ErrorLanguageSiteIdMapper {

    private static final ImmutableMap<String, Integer> mapName
            = new ImmutableMap.Builder<String, Integer>()
            .put("en_US", 0)
            .put("de_DE", 77)
            .build();

    private ErrorLanguageSiteIdMapper() {
    }

    public static Integer map(String errorLanguage) {
        return mapName.getOrDefault(errorLanguage, 0);
    }

}
