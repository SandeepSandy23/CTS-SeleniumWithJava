package com.ebay.app.apisellingextsvc.service.bof.sellerdiscountcampaign;

import com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign.SellerDiscountCampaignMock;

import java.util.List;

public class SellerDiscountCampaignListMock {

    private List<SellerDiscountCampaignMock> sellerDiscountCampaignMockList;

    public List<SellerDiscountCampaignMock> getSellerDiscountCampaignMockList() {
        return sellerDiscountCampaignMockList;
    }

    public void setSellerDiscountCampaignMockList(List<SellerDiscountCampaignMock> sellerDiscountCampaignMockList) {
        this.sellerDiscountCampaignMockList = sellerDiscountCampaignMockList;
    }
}
