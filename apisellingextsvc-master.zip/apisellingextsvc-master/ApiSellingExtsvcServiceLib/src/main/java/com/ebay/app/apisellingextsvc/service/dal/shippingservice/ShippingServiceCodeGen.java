package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.integ.dal.DalDOI;

import java.util.Date;

public interface ShippingServiceCodeGen extends DalDOI {
    int getShippingServiceId();

    void setShippingServiceId(int var1);

    int getSiteId();

    void setSiteId(int var1);

    String getLocalizedName();

    void setLocalizedName(String var1);

    String getServiceNameSuperscript();

    void setServiceNameSuperscript(String var1);

    int getCarrierId();

    void setCarrierId(int var1);

    String getDescription();

    void setDescription(String var1);

    int getGeneric();

    void setGeneric(int var1);

    int getDisplayOrderFlatRate();

    void setDisplayOrderFlatRate(int var1);

    int getDomestic();

    void setDomestic(int var1);

    int getFlatRate();

    void setFlatRate(int var1);

    int getCalculatedRate();

    void setCalculatedRate(int var1);

    int getFreight();

    void setFreight(int var1);

    int getFastShipping();

    void setFastShipping(int var1);

    int getLocalShipping();

    void setLocalShipping(int var1);

    int getCodShipping();

    void setCodShipping(int var1);

    int getBppShipping();

    void setBppShipping(int var1);

    int getMinDeliveryTime();

    void setMinDeliveryTime(int var1);

    int getMaxDeliveryTime();

    void setMaxDeliveryTime(int var1);

    int getMaxWeightLimit();

    void setMaxWeightLimit(int var1);

    int getMaxWeightLimitUnits();

    void setMaxWeightLimitUnits(int var1);

    int getEnabled();

    void setEnabled(int var1);

    String getConnShipServiceName();

    void setConnShipServiceName(String var1);

    int getFlags();

    void setFlags(int var1);

    int getTrainIntroduced();

    void setTrainIntroduced(int var1);

    Date getCreationDate();

    void setCreationDate(Date var1);

    Date getLastModifiedDate();

    void setLastModifiedDate(Date var1);

    String getApiSoapServiceCode();

    void setApiSoapServiceCode(String var1);

    String getCarrierServiceCode();

    void setCarrierServiceCode(String var1);

    int getAreDimReqd();

    void setAreDimReqd(int var1);

    int getDisplayOrderCalcRate();

    void setDisplayOrderCalcRate(int var1);

    String getValidPackageTypeList();

    void setValidPackageTypeList(String var1);

    Date getDeprecateMsgStartDate();

    void setDeprecateMsgStartDate(Date var1);

    Date getDeprecateEffectiveDate();

    void setDeprecateEffectiveDate(Date var1);

    int getMappedToShippingServiceId();

    void setMappedToShippingServiceId(int var1);

    int getDeprecateMsgType();

    void setDeprecateMsgType(int var1);

    int getIsWeightRequired();

    void setIsWeightRequired(int var1);

    int getCostCapGroup();

    void setCostCapGroup(int var1);

    String getShippingServiceToken();

    void setShippingServiceToken(String var1);

    int getSourceCountry();

    void setSourceCountry(int var1);

    int getVerifyPhoneNumber();

    void setVerifyPhoneNumber(int var1);
}
