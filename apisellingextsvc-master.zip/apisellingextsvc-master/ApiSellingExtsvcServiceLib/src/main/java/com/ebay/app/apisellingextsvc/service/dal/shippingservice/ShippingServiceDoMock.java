package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.af.common.flag.FlagMask;

import java.util.Date;

public class ShippingServiceDoMock implements ShippingService {
    private int shippingServiceId;
    private String apiSoapServiceCode;
    private int trainIntroduced;
    private int siteId;
    private String localizedName;
    private String serviceNameSuperscript;
    private int carrierId;
    private String description;
    private int generic;
    private int displayOrderFlatRate;
    private int domestic;
    private int flatRate;
    private int calculatedRate;
    private int freight;
    private int fastShipping;
    private int localShipping;
    private int codShipping;
    private int bppShipping;
    private int minDeliveryTime;
    private int maxDeliveryTime;
    private int maxWeightLimit;
    private int maxWeightLimitUnits;
    private int enabled;
    private String connShipServiceName;
    private int flags;
    private Date creationDate;
    private Date lastModifiedDate;
    private String carrierServiceCode;
    private int areDimReqd;
    private int displayOrderCalcRate;
    private String validPackageTypeList;
    private Date deprecateMsgStartDate;
    private Date deprecateEffectiveDate;
    private int mappedToShippingServiceId;
    private int deprecateMsgType;
    private int isWeightRequired;
    private int costCapGroup;
    private String shippingServiceToken;
    private int sourceCountry;
    private int verifyPhoneNumber;

    @Override
    public int getShippingServiceId() {
        return shippingServiceId;
    }

    @Override
    public void setShippingServiceId(int shippingServiceId) {
        this.shippingServiceId = shippingServiceId;
    }

    @Override
    public int getSiteId() {
        return siteId;
    }

    @Override
    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    @Override
    public String getLocalizedName() {
        return localizedName;
    }

    @Override
    public void setLocalizedName(String localizedName) {
        this.localizedName = localizedName;
    }

    @Override
    public String getServiceNameSuperscript() {
        return serviceNameSuperscript;
    }

    @Override
    public void setServiceNameSuperscript(String serviceNameSuperscript) {
        this.serviceNameSuperscript = serviceNameSuperscript;
    }

    @Override
    public int getCarrierId() {
        return carrierId;
    }

    @Override
    public void setCarrierId(int carrierId) {
        this.carrierId = carrierId;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int getGeneric() {
        return generic;
    }

    @Override
    public void setGeneric(int generic) {
        this.generic = generic;
    }

    @Override
    public int getDisplayOrderFlatRate() {
        return displayOrderFlatRate;
    }

    @Override
    public void setDisplayOrderFlatRate(int displayOrderFlatRate) {
        this.displayOrderFlatRate = displayOrderFlatRate;
    }

    @Override
    public int getDomestic() {
        return domestic;
    }

    @Override
    public void setDomestic(int domestic) {
        this.domestic = domestic;
    }

    @Override
    public int getFlatRate() {
        return flatRate;
    }

    @Override
    public void setFlatRate(int flatRate) {
        this.flatRate = flatRate;
    }

    @Override
    public int getCalculatedRate() {
        return calculatedRate;
    }

    @Override
    public void setCalculatedRate(int calculatedRate) {
        this.calculatedRate = calculatedRate;
    }

    @Override
    public int getFreight() {
        return freight;
    }

    @Override
    public void setFreight(int freight) {
        this.freight = freight;
    }

    @Override
    public int getFastShipping() {
        return fastShipping;
    }

    @Override
    public void setFastShipping(int fastShipping) {
        this.fastShipping = fastShipping;
    }

    @Override
    public int getLocalShipping() {
        return localShipping;
    }

    @Override
    public void setLocalShipping(int localShipping) {
        this.localShipping = localShipping;
    }

    @Override
    public int getCodShipping() {
        return codShipping;
    }

    @Override
    public void setCodShipping(int codShipping) {
        this.codShipping = codShipping;
    }

    @Override
    public int getBppShipping() {
        return bppShipping;
    }

    @Override
    public void setBppShipping(int bppShipping) {
        this.bppShipping = bppShipping;
    }

    @Override
    public int getMinDeliveryTime() {
        return minDeliveryTime;
    }

    @Override
    public void setMinDeliveryTime(int minDeliveryTime) {
        this.minDeliveryTime = minDeliveryTime;
    }

    @Override
    public int getMaxDeliveryTime() {
        return maxDeliveryTime;
    }

    @Override
    public void setMaxDeliveryTime(int maxDeliveryTime) {
        this.maxDeliveryTime = maxDeliveryTime;
    }

    @Override
    public int getMaxWeightLimit() {
        return maxWeightLimit;
    }

    @Override
    public void setMaxWeightLimit(int maxWeightLimit) {
        this.maxWeightLimit = maxWeightLimit;
    }

    @Override
    public int getMaxWeightLimitUnits() {
        return maxWeightLimitUnits;
    }

    @Override
    public void setMaxWeightLimitUnits(int maxWeightLimitUnits) {
        this.maxWeightLimitUnits = maxWeightLimitUnits;
    }

    @Override
    public int getEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(int enabled) {
        this.enabled = enabled;
    }

    @Override
    public String getConnShipServiceName() {
        return connShipServiceName;
    }

    @Override
    public void setConnShipServiceName(String connShipServiceName) {
        this.connShipServiceName = connShipServiceName;
    }

    @Override
    public int getFlags() {
        return flags;
    }

    @Override
    public void setFlags(int flags) {
        this.flags = flags;
    }

    @Override
    public int getTrainIntroduced() {
        return trainIntroduced;
    }

    @Override
    public void setTrainIntroduced(int trainIntroduced) {
        this.trainIntroduced = trainIntroduced;
    }

    @Override
    public Date getCreationDate() {
        return creationDate;
    }

    @Override
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    @Override
    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    @Override
    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @Override
    public String getApiSoapServiceCode() {
        return apiSoapServiceCode;
    }

    @Override
    public void setApiSoapServiceCode(String apiSoapServiceCode) {
        this.apiSoapServiceCode = apiSoapServiceCode;
    }

    @Override
    public String getCarrierServiceCode() {
        return carrierServiceCode;
    }

    @Override
    public void setCarrierServiceCode(String carrierServiceCode) {
        this.carrierServiceCode = carrierServiceCode;
    }

    @Override
    public int getAreDimReqd() {
        return areDimReqd;
    }

    @Override
    public void setAreDimReqd(int areDimReqd) {
        this.areDimReqd = areDimReqd;
    }

    @Override
    public int getDisplayOrderCalcRate() {
        return displayOrderCalcRate;
    }

    @Override
    public void setDisplayOrderCalcRate(int displayOrderCalcRate) {
        this.displayOrderCalcRate = displayOrderCalcRate;
    }

    @Override
    public String getValidPackageTypeList() {
        return validPackageTypeList;
    }

    @Override
    public void setValidPackageTypeList(String validPackageTypeList) {
        this.validPackageTypeList = validPackageTypeList;
    }

    @Override
    public Date getDeprecateMsgStartDate() {
        return deprecateMsgStartDate;
    }

    @Override
    public void setDeprecateMsgStartDate(Date deprecateMsgStartDate) {
        this.deprecateMsgStartDate = deprecateMsgStartDate;
    }

    @Override
    public Date getDeprecateEffectiveDate() {
        return deprecateEffectiveDate;
    }

    @Override
    public void setDeprecateEffectiveDate(Date deprecateEffectiveDate) {
        this.deprecateEffectiveDate = deprecateEffectiveDate;
    }

    @Override
    public int getMappedToShippingServiceId() {
        return mappedToShippingServiceId;
    }

    @Override
    public void setMappedToShippingServiceId(int mappedToShippingServiceId) {
        this.mappedToShippingServiceId = mappedToShippingServiceId;
    }

    @Override
    public int getDeprecateMsgType() {
        return deprecateMsgType;
    }

    @Override
    public void setDeprecateMsgType(int deprecateMsgType) {
        this.deprecateMsgType = deprecateMsgType;
    }

    @Override
    public int getIsWeightRequired() {
        return isWeightRequired;
    }

    @Override
    public void setIsWeightRequired(int isWeightRequired) {
        this.isWeightRequired = isWeightRequired;
    }

    @Override
    public int getCostCapGroup() {
        return costCapGroup;
    }

    @Override
    public void setCostCapGroup(int costCapGroup) {
        this.costCapGroup = costCapGroup;
    }

    @Override
    public String getShippingServiceToken() {
        return shippingServiceToken;
    }

    @Override
    public void setShippingServiceToken(String shippingServiceToken) {
        this.shippingServiceToken = shippingServiceToken;
    }

    @Override
    public int getSourceCountry() {
        return sourceCountry;
    }

    @Override
    public void setSourceCountry(int sourceCountry) {
        this.sourceCountry = sourceCountry;
    }

    @Override
    public int getVerifyPhoneNumber() {
        return verifyPhoneNumber;
    }

    @Override
    public void setVerifyPhoneNumber(int verifyPhoneNumber) {
        this.verifyPhoneNumber = verifyPhoneNumber;
    }

    @Override
    public boolean equalsData(Object o) {
        return false;
    }

    @Override
    public boolean hasFlag(FlagMask flagMask) {
        return false;
    }

    @Override
    public void setFlag(FlagMask flagMask, boolean b) {

    }
}
