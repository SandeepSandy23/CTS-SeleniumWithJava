package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.FundingHeldStatusType;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.PaymentHoldStatusCodeType;

// for transaction.status.payment hold status and order. payment hold status
public class PaymentHoldStatusMapper {

    private static final ImmutableMap<FundingHeldStatusType, PaymentHoldStatusCodeType> mapName
            = new ImmutableMap.Builder<FundingHeldStatusType, PaymentHoldStatusCodeType>()
             .put(FundingHeldStatusType.UNKNOWN, PaymentHoldStatusCodeType.CUSTOM_CODE)
             .put(FundingHeldStatusType.NOT_HELD, PaymentHoldStatusCodeType.NONE)
             .put(FundingHeldStatusType.HELD_PENDING, PaymentHoldStatusCodeType.CUSTOM_CODE)
             .put(FundingHeldStatusType.HELD, PaymentHoldStatusCodeType.PAYMENT_HOLD)
             .put(FundingHeldStatusType.RELEASE_PENDING, PaymentHoldStatusCodeType.RELEASE_PENDING)
             .put(FundingHeldStatusType.RELEASED, PaymentHoldStatusCodeType.RELEASED)
             .put(FundingHeldStatusType.RELEASE_CONFIRMED, PaymentHoldStatusCodeType.RELEASE_CONFIRMED)
             .put(FundingHeldStatusType.RELEASE_FAILED, PaymentHoldStatusCodeType.RELEASE_FAILED)
             .put(FundingHeldStatusType.DEFAULT, PaymentHoldStatusCodeType.CUSTOM_CODE)
            .build();

    private PaymentHoldStatusMapper() {
    }

    public static PaymentHoldStatusCodeType map(FundingHeldStatusType key) {
        return mapName.getOrDefault(key, PaymentHoldStatusCodeType.NONE);
    }

}
