package com.ebay.app.apisellingextsvc.service.dal.sellerpref;

import com.ebay.af.common.flag.BaseMaskBackingFlag;
import com.ebay.af.common.flag.FlagMask;

public class SellerPrefFlags extends BaseMaskBackingFlag {

    public static final FlagMask REQUIRE_PHONE_FOR_SHIPPING_MASK =
            FlagMask.createFlagMask("RequirePhoneForShipping", 10, 0x00200000);

    public SellerPrefFlags(int id, String name) {
        super(id, name);
    }
}
