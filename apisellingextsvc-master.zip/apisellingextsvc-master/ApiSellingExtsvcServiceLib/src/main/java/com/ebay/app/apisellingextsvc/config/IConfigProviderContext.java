package com.ebay.app.apisellingextsvc.config;

import java.util.List;

public interface IConfigProviderContext {
    void getShowDiagMessages(List<String> var1);
}