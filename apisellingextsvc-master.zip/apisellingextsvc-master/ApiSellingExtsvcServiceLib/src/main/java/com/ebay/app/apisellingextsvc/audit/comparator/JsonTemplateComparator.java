package com.ebay.app.apisellingextsvc.audit.comparator;

import com.ebay.app.apisellingextsvc.audit.model.Excludes;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.ebay.app.apisellingextsvc.common.helper.DateHelper;
import com.ebay.app.apisellingextsvc.common.helper.FileHelper;
import com.ebay.app.apisellingextsvc.common.logger.DummyLogger;
import com.ebay.app.apisellingextsvc.common.logger.ILogger;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

public abstract class JsonTemplateComparator {
    public static final ObjectMapper objectMapper = new ObjectMapper();
    public static final Boolean DEBUG = false;
    private static final String basePath = "./src/test/resources/";
    private static final Long TIME_DIFF_ACCURANCY = 60000L;

    protected final JsonNode pattern;
    final Excludes excludes;
    private final ILogger logger;

    public JsonTemplateComparator(String filePath, String excludeFile) {
        this(DummyLogger.getInstance(), filePath, (String)excludeFile);
    }

    public JsonTemplateComparator(String filePath, List<String> excludeFieldList) {
        this(DummyLogger.getInstance(), filePath, (List)excludeFieldList);
    }

    public JsonTemplateComparator(ILogger logger, String filePath, String excludeFile) {
        this.logger = logger;

        try {
            InputStream is = FileHelper.readResourceFileAsStream(filePath);
            if (is == null) {
                throw new RuntimeException("File" + filePath + " not exists!");
            }

            this.pattern = objectMapper.readTree(is);
            this.logger.warn("template[" + filePath + "] loaded:");
        } catch (Exception var6) {
            throw new RuntimeException("Error reading file:" + filePath);
        }

        try {
            this.excludes = Excludes.create(excludeFile, logger);
        } catch (Exception var5) {
            throw new RuntimeException("Error reading file:" + excludeFile);
        }
    }

    public JsonTemplateComparator(ILogger logger, String filePath, List<String> excludeFieldList) {
        this.logger = logger;

        try {
            InputStream is = FileHelper.readResourceFileAsStream(filePath);
            if (is == null) {
                throw new RuntimeException("File" + filePath + " not exists!");
            }

            this.pattern = objectMapper.readTree(is);
            this.logger.warn("template[" + filePath + "] loaded:");
        } catch (Exception var6) {
            throw new RuntimeException("Error reading file:" + filePath);
        }

        try {
            this.excludes = Excludes.create(excludeFieldList, logger);
        } catch (Exception var5) {
            throw new RuntimeException("Error getting exclude fields from excludeFileList.");
        }
    }

    public boolean compare(JsonNode org, JsonNode tar, IReport report) {
        boolean res = this.compareNode(org, tar, this.pattern, "root", "N/A", report);
        return res;
    }

    boolean compareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        try {
            JsonNodeType nodeType = pattern.getNodeType();
            boolean success;
            if (org != null && tar != null) {
                if (!org.isNull() && !tar.isNull()) {
                    if (pattern.isValueNode()) {
                        if (pattern.isTextual()) {
                            if (!org.textValue().equals(tar.textValue())) {
                                success = this.excludes.contains(path);
                                if (!success && Pattern.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}.*", org.textValue()) && Pattern.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}.*", tar.textValue())) {
                                    long orgDate = this.getTimeInMs(org.textValue());
                                    long tarDate = this.getTimeInMs(tar.textValue());
                                    long diff = Math.abs(orgDate - tarDate);
                                    if (diff < TIME_DIFF_ACCURANCY) {
                                        success = true;
                                    }
                                }

                                this.printDiff(key, path, org.asText(), tar.asText(), success, report);
                                return success;
                            } else {
                                return true;
                            }
                        } else if (pattern.isNumber()) {
                            if (!this.sameNumberValue(org.numberValue(), tar.numberValue(), pattern)) {
                                success = this.excludes.contains(path);
                                this.printDiff(key, path, org.numberValue().toString(), tar.numberValue().toString(), success, report);
                                return success;
                            } else {
                                return true;
                            }
                        } else if (pattern.isBoolean()) {
                            if (org.booleanValue() != tar.booleanValue()) {
                                success = this.excludes.contains(path);
                                this.printDiff(key, path, String.valueOf(org.booleanValue()), String.valueOf(tar.booleanValue()), success, report);
                                return success;
                            } else {
                                return true;
                            }
                        } else {
                            return true;
                        }
                    } else {
                        boolean res;
                        Boolean childResult;
                        if (pattern.isArray()) {
                            if (org.isArray() && tar.isArray()) {
                                childResult = this.compareArray(org, tar, pattern, path, key, report);
                                if (childResult != null) {
                                    return childResult;
                                } else {
                                    int i;
                                    String tempPath;
                                    if (org.size() != tar.size()) {
                                        res = this.excludes.contains(path);
                                        this.printDiff(key, path, "size(" + org.size() + ")", "size(" + tar.size() + ")", res, report);

                                        for(i = 0; i < org.size() && i < tar.size(); ++i) {
                                            tempPath = path + "[" + i + "]";
                                            this.compareNode(org.get(i), tar.get(i), pattern.get(0), tempPath, key, report);
                                        }

                                        return res;
                                    } else {
                                        res = true;

                                        for(i = 0; i < org.size(); ++i) {
                                            tempPath = path + "[" + i + "]";
                                            boolean child = this.compareNode(org.get(i), tar.get(i), pattern.get(0), tempPath, key, report);
                                            res = res && child;
                                        }

                                        return res;
                                    }
                                }
                            } else {
                                this.printDiff(key, path, org, tar, false, report);
                                return false;
                            }
                        } else if (!pattern.isObject()) {
                            this.logger.error(nodeType.toString());
                            return false;
                        } else if (org.isObject() && tar.isObject()) {
                            childResult = this.compareObject(org, tar, pattern, path, key, report);
                            if (childResult != null) {
                                return childResult;
                            } else {
                                res = this.excludes.contains(path);
                                if (!res) {
                                    Iterator<String> facetNameIter = pattern.fieldNames();

                                    boolean childRes;
                                    boolean child;
                                    for(childRes = true; facetNameIter.hasNext(); childRes = childRes && child) {
                                        String name = (String)facetNameIter.next();
                                        child = this.compareNode(org.get(name), tar.get(name), pattern.get(name), path + "." + name, key, report);
                                    }

                                    res = childRes;
                                }

                                return res;
                            }
                        } else {
                            this.printDiff(key, path, org, tar, false, report);
                            return false;
                        }
                    }
                } else if (org.isNull() && tar.isNull()) {
                    this.printInfo(key, path, "null", "null", report);
                    return true;
                } else {
                    success = this.excludes.contains(path);
                    this.printDiff(key, path, org.isNull() ? "null" : org.toString(), tar.isNull() ? "null" : tar.toString(), success, report);
                    return success;
                }
            } else if (org == null && tar == null || org != null && org.isNull() || tar != null && tar.isNull()) {
                this.printInfo(key, path, "missing", "missing", report);
                return true;
            } else if (!pattern.isArray() || (org == null || !org.isArray() || org.size() != 0) && (tar == null || !tar.isArray() || tar.size() != 0)) {
                success = this.excludes.contains(path);
                this.printDiff(key, path, org == null ? "missing" : org.toString(), tar == null ? "missing" : tar.toString(), success, report);
                return success;
            } else {
                this.printInfo(key, path, org == null ? "missing" : org.toString(), tar == null ? "missing" : tar.toString(), report);
                return true;
            }
        } catch (Exception var15) {
            System.out.println("Exception: " + var15.getMessage() + " path: " + path);
            return false;
        }
    }

    void printDiff(String key, String path, JsonNode org, JsonNode tar, boolean success, IReport report) {
        this.printDiff(key, path, org.getNodeType().name(), tar.getNodeType().name(), success, report);
    }

    void printDiff(String key, String path, String org, String tar, boolean success, IReport report) {
        this.logger.error("[" + key + "]" + path + ": Expected " + tar + " but found " + org + (success ? "" : " --- failing"));
        if (report != null) {
            report.report(key, path, org, tar, success);
        }

    }

    void printInfo(String key, String path, String org, String tar, IReport report) {
        if (DEBUG) {
            this.logger.warn("[" + key + "]" + path + ": Expected " + tar + " and found " + org);
            if (report != null) {
                report.report(key, path, org, tar, false);
            }
        }

    }

    protected Boolean compareArray(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        return null;
    }

    protected Boolean compareObject(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        return null;
    }

    String getValue(JsonNode node) {
        return node == null ? null : node.toString();
    }

    String getValueString(JsonNode node) {
        return node == null ? null : node.asText();
    }

    private long getTimeInMs(String date) {
        return DateHelper.parseDateString(date).getTime();
    }

    private boolean sameNumberValue(Number org, Number tar, JsonNode pattern) {
        if (!pattern.isNumber()) {
            return false;
        } else if (org.equals(tar)) {
            return true;
        } else if (pattern.isInt()) {
            return org.intValue() == tar.intValue();
        } else if (pattern.isLong()) {
            return org.longValue() == tar.longValue();
        } else if (pattern.isFloat()) {
            return org.floatValue() == tar.floatValue();
        } else if (pattern.isDouble()) {
            return org.doubleValue() == tar.doubleValue();
        } else {
            return false;
        }
    }
}

