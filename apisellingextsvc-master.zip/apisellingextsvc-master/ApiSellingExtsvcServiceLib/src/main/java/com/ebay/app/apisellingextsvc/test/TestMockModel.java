//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.ebay.app.apisellingextsvc.test;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonSetter;

import java.util.List;

public class TestMockModel {
    private String name;
    private Object mockData;
    private List<MultiValuedParam> params;

    public TestMockModel() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getMockData() {
        return this.mockData;
    }

    @JsonSetter("mockData")
    @JsonAlias({"mockDataFilename"})
    public void setMockData(Object mockData) {
        this.mockData = mockData;
    }

    public List<MultiValuedParam> getParams() {
        return this.params;
    }

    @JsonSetter("params")
    @JsonAlias({"validations"})
    public void setParams(List<MultiValuedParam> params) {
        this.params = params;
    }
}
