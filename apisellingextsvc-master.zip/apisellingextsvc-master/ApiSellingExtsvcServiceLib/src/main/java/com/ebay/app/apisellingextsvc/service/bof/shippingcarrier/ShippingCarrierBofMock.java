package com.ebay.app.apisellingextsvc.service.bof.shippingcarrier;

import com.ebay.app.apisellingextsvc.test.TestMock;
import com.ebay.app.apisellingextsvc.test.TestMockHolder;

import java.util.Map;
import java.util.stream.Collectors;

public class ShippingCarrierBofMock implements IShippingCarrierBof {

    public static final String SHIPPING_CARRIER_MOCK_NAME_PREFIX = "IShippingCarrierBof";
    private final Map<Integer, String> shippingCarrierMap;

    public ShippingCarrierBofMock(TestMock mock) {

        ShippingCarrierListMock shippingServiceListMock = TestMockHolder.getMock(mock, ShippingCarrierListMock.class);
        shippingCarrierMap = shippingServiceListMock.getShippingCarriers()
              .stream().collect(Collectors.toMap(
                    ShippingCarrierListMock.ShippingCarrier::getCarrierEnumId,
                    ShippingCarrierListMock.ShippingCarrier::getShippingCarrierName));
    }

    @Override
    public String findCarrierNameByCarrierId(int carrierId) {
        return shippingCarrierMap.get(carrierId);
    }
}
