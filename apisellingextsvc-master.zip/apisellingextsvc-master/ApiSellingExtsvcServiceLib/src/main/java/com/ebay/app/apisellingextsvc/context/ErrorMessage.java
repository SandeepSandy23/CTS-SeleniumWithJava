package com.ebay.app.apisellingextsvc.context;

public class ErrorMessage {

    public final String longMessage;
    public final String shortMessage;

    public ErrorMessage(String shortMessage, String longMessage) {
        this.shortMessage = shortMessage;
        this.longMessage = longMessage;
    }
}
