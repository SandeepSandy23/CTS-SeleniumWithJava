package com.ebay.app.apisellingextsvc.tasks.audit;

import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.ebay.app.apisellingextsvc.audit.es.ESResponse;
import com.ebay.app.apisellingextsvc.audit.es.Report;
import com.ebay.app.apisellingextsvc.audit.es.Request;
import com.ebay.app.apisellingextsvc.audit.es.Response;
import com.ebay.app.apisellingextsvc.audit.reporter.BaseAuditReporter;
import com.ebay.app.apisellingextsvc.common.json.CustomObjectMapper;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.utils.Headers;
import com.ebay.raptor.orchestrationv2.task.AsyncTask;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.commons.lang3.StringUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public abstract class BaseApiSellingExtAuditTask implements AsyncTask<ESResponse>, ITaskResultInjectable {

    protected final Object oldTradingApi;
    protected ApiSellingExtSvcConfigValues configValue;
    private final Object newTradingApi;
    private final IServiceInvoker<Report, ESResponse> esServiceInvoker;
    protected final HttpHeaders headers;


    protected BaseApiSellingExtAuditTask( Object newTradingApi, Object oldTradingApi,
                                         IServiceInvoker<Report, ESResponse> esServiceInvoker, HttpHeaders headers,
                                         ApiSellingExtSvcConfigValues configValue) {
        this.newTradingApi = newTradingApi;
        this.oldTradingApi = oldTradingApi;
        this.esServiceInvoker = esServiceInvoker;
        this.headers = headers;
        this.configValue = configValue;
    }

    @Override
    public CompletableFuture<ESResponse> call() {
        Report report = generateReport();
        return CompletableFuture.supplyAsync(() ->
                this.esServiceInvoker.getResponse(report, new Headers()));
    }

    @Override
    public void addResult(Object o) {}

    protected abstract   void populateRequest(Report report);

    protected abstract ExtensiveComparator getResponseComparator();

    protected abstract BaseAuditReporter getAuditReporter();

    protected abstract String getUrl();

    protected abstract String getPayload();

    protected abstract String getESDocName();

    private Report generateReport() {
        Report report = new Report();
        populateRequest(report);

        JsonNode org = CustomObjectMapper.getInstance().convertValue(newTradingApi, JsonNode.class);
        JsonNode tar = getOldTradingApiResponseToJsonNode();

        populateResponse(org, tar,newTradingApi,oldTradingApi,report);
        populateDifference(org, tar, report);

        return report;
    }

    protected abstract void populateResponse(JsonNode org, JsonNode tar,Object orgStr, Object tarStr, Report report);

    private JsonNode getOldTradingApiResponseToJsonNode() {
        if (oldTradingApi instanceof String) {
            try {
                return CustomObjectMapper.getInstance().readTree((String) oldTradingApi);
            } catch (JsonProcessingException e) {
                CalLogger.warn(getClass().getSimpleName(), e.getMessage());
                return null;
            }
        }
        return CustomObjectMapper.getInstance().convertValue(oldTradingApi, JsonNode.class);
    }


    private void populateDifference(JsonNode org, JsonNode tar, Report report) {
        BaseAuditReporter auditReporter = getAuditReporter();
        getResponseComparator().compare(org, tar, auditReporter);
        report.setResult(auditReporter.collect());
    }

}
