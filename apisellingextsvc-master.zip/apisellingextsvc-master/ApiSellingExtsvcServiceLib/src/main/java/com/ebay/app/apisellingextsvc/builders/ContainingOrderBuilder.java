package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.mappers.CancelStatusMapper;
import com.ebay.app.apisellingextsvc.mappers.OrderStatusMapper;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.cosmos.ContractIdentifier;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.OrderStateTypeCS;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.OrderCreatorTypeEnumType;
import com.ebay.order.common.v1.ProgramEnumType;
import com.ebay.order.common.v1.ProgramType;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.CancelStatusCodeType;
import ebay.apis.eblbasecomponents.OrderStatusCodeType;
import ebay.apis.eblbasecomponents.OrderType;
import ebay.apis.eblbasecomponents.ShippingDetailsType;
import ebay.apis.eblbasecomponents.TradingRoleCodeType;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Objects;
import java.util.Optional;


public class ContainingOrderBuilder extends BaseFacetBuilder<OrderType> {
    protected OrderCSXType order;
    protected ProformaOrderXType proformaOrder;
    protected String orderId;
    protected String extendedOrderId;
    protected List<ProgramType> programs;
    protected OrderStateTypeCS orderStates;
    protected Long orderLineItemCount;
    protected TradingRoleCodeType orderCreateType;
    protected ShippingDetailsType shippingDetailsType;

    public ContainingOrderBuilder(Task<?> task,
                                  @Nonnull ContractResponseType contractResponseType) {
        super(task);
        if (ContractResponseUtil.isOrder(contractResponseType)) {
            this.order = contractResponseType.getOrder();
            this.orderId = order.getOrderId();
            this.extendedOrderId = orderId;
            this.programs = order.getPrograms();
            this.orderStates = order.getOrderStates();
            this.orderLineItemCount = getOrderLineItemCount(order);
            this.orderCreateType = getOrderUserRole(order);
            this.shippingDetailsType = getShippingDetailsType(Optional.of(order)
                    .map(OrderCSXType::getAttributes).orElse(null));
        } else if (ContractResponseUtil.isProformaOrder(contractResponseType)) {
            this.proformaOrder = contractResponseType.getProformaOrder();
            this.orderId = getProformaOrderId(contractResponseType);
            this.programs = proformaOrder.getPrograms();
            this.orderStates = proformaOrder.getOrderStates();
            this.orderCreateType = getProformaUserRole(proformaOrder);
            this.shippingDetailsType = getShippingDetailsType(Optional.of(proformaOrder)
                    .map(ProformaOrderXType::getAttributes).orElse(null));
        }
    }

    @Override
    protected OrderType doBuild() {
        OrderType orderType = new OrderType();
        orderType.setOrderID(orderId);
        orderType.setOrderStatus(getOrderStatus());
        orderType.setCancelStatus(getCancelStatus());
        orderType.setExtendedOrderID(extendedOrderId);
        orderType.setContainseBayPlusTransaction(isEbayPlusTransaction());
        orderType.setOrderLineItemCount(orderLineItemCount);
        orderType.setCreatingUserRole(orderCreateType);
        orderType.setShippingDetails(shippingDetailsType);
        return orderType;
    }

    private TradingRoleCodeType getOrderUserRole(OrderCSXType order) {
        return Optional.of(order).map(OrderCSXType::getOrderCreatorType).map(OrderCreatorTypeEnumType::name)
                .map(String::toLowerCase).map(StringUtils::capitalize)
                .map(TradingRoleCodeType::fromValue).orElse(null);
    }

    private TradingRoleCodeType getProformaUserRole(ProformaOrderXType proformaOrder) {
        return Optional.ofNullable(proformaOrder).map(ProformaOrderXType::getCreator)
                        .map(OrderCreatorTypeEnumType::name)
                        .map(String::toLowerCase).map(StringUtils::capitalize)
                        .map(TradingRoleCodeType::fromValue).orElse(null);
    }

    private ShippingDetailsType getShippingDetailsType(List<Attribute> attributes) {
        ShippingDetailsType shippingDetailsType = new ShippingDetailsType();
        Integer salesRecordNumber = Optional.ofNullable(attributes)
                .map(att -> AttributeUtil.findAttributeValue(att, ApiSellingExtSvcConstants.ATTR_SALES_RECORD_NUMBER))
                .filter(StringUtils::isNumeric)
                .map(Integer::new).orElse(null);
        shippingDetailsType.setSellingManagerSalesRecordNumber(salesRecordNumber);
        return shippingDetailsType;
    }

    private CancelStatusCodeType getCancelStatus() {
        return Optional.ofNullable(orderStates)
                .map(OrderStateTypeCS::getCancelStatus)
                .map(CancelStatusMapper::map).orElse(null);
    }

    private Boolean isEbayPlusTransaction() {
        return Optional.ofNullable(programs)
                .map(programTypes -> programTypes.stream()
                        .anyMatch(programType -> Objects.equals(programType.getName(), ProgramEnumType.EBAY_PLUS.name())))
                .orElse(null);
    }

    private Long getOrderLineItemCount(OrderCSXType order) {
        return Optional.ofNullable(order)
                .map(OrderCSXType::getLineItemTypes)
                .map(List::size)
                .map(Integer::longValue)
                .orElse(null);
    }

    private OrderStatusCodeType getOrderStatus() {
        return Optional.ofNullable(orderStates)
                .map(OrderStateTypeCS::getOrderStatus)
                .map(status -> OrderStatusMapper.map(status, orderStates.getFundingStatus()))
                .orElse(null);
    }

    private String getProformaOrderId(ContractResponseType contractResponseType) {
       return Optional.of(contractResponseType)
                .map(ContractResponseType::getIdentifier)
                .map(ContractIdentifier::getPublicContractId)
                .orElse(null);
    }
}
