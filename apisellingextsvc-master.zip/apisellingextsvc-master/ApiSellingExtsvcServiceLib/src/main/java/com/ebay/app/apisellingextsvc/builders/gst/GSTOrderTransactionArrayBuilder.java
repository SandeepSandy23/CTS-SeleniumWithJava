package com.ebay.app.apisellingextsvc.builders.gst;

import com.ebay.app.apisellingextsvc.builders.BaseTransactionArrayTypeBuilder;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.service.bof.saleaggregator.ISaleAggregatorBof;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserInfo;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GSTOrderTransactionArrayBuilder extends BaseTransactionArrayTypeBuilder {

    private final OrderCSXType order;
    private final int trxVersion;
    private final List<DetailLevelCodeType> detailLevels;
    private final ApiSellingExtSvcConfigValues configValues;
    private final SellerProfileDataContext dataContext;
    private final SiteContext siteContext;
    private final ContractResponseType contractResponseType;
    private final Map<String, UserInfo> buyerResponseMap;
    private final boolean includeFinalValueFee;
    private final boolean includeContainingOrder;
    private final ISaleAggregatorBof saleAggregatorBof;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final Map<String, Double> feedbackPercentageMap;
    private final IContentHelper contentHelper;
    private final Map<String, Item> svlsItemInfoMap;

    // GetOrders: num of lineitem == number of transaction in transaction array, multiple order -> multiple order in order array
    // GetItemTransaction: - no need to build item container
    public GSTOrderTransactionArrayBuilder(Task<?> task,
                                           @Nonnull ContractResponseType contractResponseType,
                                           int trxVersion,
                                           SiteContext siteContext,
                                           IContentHelper contentHelper,
                                           List<DetailLevelCodeType> detailLevels,
                                           ApiSellingExtSvcConfigValues configValues,
                                           Map<String, UserInfo> buyerResponseMap,
                                           SellerProfileDataContext dataContext,
                                           boolean includeFinalValueFee,
                                           boolean includeContainingOrder,
                                           ISaleAggregatorBof saleAggregatorBof,
                                           Map<Long, ListingActivity> itemIdListingActivityMap,
                                           Map<String, Double> feedbackPercentageMap,
                                           Map<String, Item> svlsItemInfoMap) {

        super(task, contractResponseType);
        this.order =  contractResponseType.getOrder();
        this.contractResponseType = contractResponseType;
        this.trxVersion = trxVersion;
        this.siteContext = siteContext;
        this.contentHelper = contentHelper;
        this.detailLevels = detailLevels;
        this.configValues = configValues;
        this.dataContext = dataContext;
        this.buyerResponseMap = buyerResponseMap;
        this.includeFinalValueFee = includeFinalValueFee;
        this.includeContainingOrder = includeContainingOrder;
        this.saleAggregatorBof = saleAggregatorBof;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.feedbackPercentageMap = feedbackPercentageMap;
        this.svlsItemInfoMap = svlsItemInfoMap;
    }

    @Override
    protected List<TransactionType> doBuild() {
        List<TransactionType> transactionTypeList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(order.getLineItemTypes())) {
            for (LineItemXType lineItem : order.getLineItemTypes()) {
                if (lineItem != null && shouldBuildTransaction(order.getLineItemTypes().size(), lineItem.getSourceId())) {
                    transactionTypeList.add(new GSTOrderTransactionBuilder(task, contractResponseType, order, lineItem, siteContext, contentHelper,
                        detailLevels, configValues, trxVersion, dataContext, buyerResponseMap, includeFinalValueFee, includeContainingOrder,
                            itemIdListingActivityMap, feedbackPercentageMap, svlsItemInfoMap).build());
                }
            }
        }

        return transactionTypeList;
    }
}
