package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.lib.lasng.model.ListingLifecycle;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.ListingStatusCodeType;

public class ListingStatusMapper {

    private static final ImmutableMap<ListingLifecycle.StatusEnum, ListingStatusCodeType> mapName
          = new ImmutableMap.Builder<ListingLifecycle.StatusEnum, ListingStatusCodeType>()
          .put(ListingLifecycle.StatusEnum.ACTIVE, ListingStatusCodeType.ACTIVE)
          .put(ListingLifecycle.StatusEnum.SCHEDULED, ListingStatusCodeType.CUSTOM_CODE)
          .put(ListingLifecycle.StatusEnum.ENDED, ListingStatusCodeType.ENDED)
          .put(ListingLifecycle.StatusEnum.SUSPENDED, ListingStatusCodeType.CUSTOM_CODE)
          .put(ListingLifecycle.StatusEnum.ADMIN_ENDED, ListingStatusCodeType.CUSTOM_CODE)
          .build();

    private ListingStatusMapper() {
    }

    public static ListingStatusCodeType map(ListingLifecycle.StatusEnum statusEnum) {
        return mapName.getOrDefault(statusEnum, ListingStatusCodeType.CUSTOM_CODE);
    }
}