package com.ebay.app.apisellingextsvc.audit.comparator.facet;


import com.ebay.app.apisellingextsvc.audit.comparator.BaseFacetComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Objects;

public class ItemTitleFacetComparator extends BaseFacetComparator {

    private static final String TITLE = "Title";

    public ItemTitleFacetComparator(ExtensiveComparator comparator) {
        super(comparator);
    }

    @Override
    public boolean qualified(JsonNode org, JsonNode tar, String path) {
        return org.isObject() && tar.isObject()
                && path.endsWith(".Item");
    }

    @Override
    public boolean compare(JsonNode org, JsonNode tar, String path, JsonNode pattern, String key, IReport report) {
        JsonNode orgTitleNode = org.get(TITLE);
        JsonNode tarTitleNode = tar.get(TITLE);
        //not null
        if (orgTitleNode == null
                || tarTitleNode == null
                || !orgTitleNode.isTextual()
                || !tarTitleNode.isTextual()) {
            return compareNode(org, tar, pattern, path, key, report);
        }
        String orgTitle = orgTitleNode.textValue();
        String tarTitle = tarTitleNode.textValue();
        if (Objects.equals(orgTitle, tarTitle)) {
            return true;
        }

        // same length
        if (orgTitle.length() == tarTitle.length()) {
            int orgIndex = orgTitleNode.textValue().indexOf("[");
            int tarIndex = tarTitleNode.textValue().indexOf("[");
            //variation title
            if (orgIndex != -1 && tarIndex != -1
                    && Objects.equals(orgTitle.substring(0, orgIndex), tarTitle.substring(0, tarIndex))) {
                char[] orgChars = orgTitle.substring(orgIndex, orgTitle.length() - 1).toCharArray();
                char[] tarChars = tarTitle.substring(tarIndex, tarTitle.length() - 1).toCharArray();
                //sort and equals
                Arrays.sort(orgChars);
                Arrays.sort(tarChars);
                boolean equals = Arrays.equals(orgChars, tarChars);
                //if not equals will not ignore mismatch
                if (equals) {
                    return true;
                }
            }
        }
        this.printDiff(key, path, orgTitle, tarTitle, false, report);
        return false;
    }

}
