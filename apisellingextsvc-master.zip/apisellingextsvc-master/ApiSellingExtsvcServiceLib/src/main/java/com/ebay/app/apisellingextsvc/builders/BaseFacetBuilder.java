package com.ebay.app.apisellingextsvc.builders;

import com.ebay.raptor.orchestrationv2.task.Task;

public abstract class BaseFacetBuilder<T> implements IFacetBuilder<T> {

    protected Task<?> task;

    public BaseFacetBuilder(Task<?> task) {
        this.task = task;
    }

    @Override
    public T build() {
        try {
            return doBuild();
        } catch (Exception e) {
            throw e;
        } catch (Throwable t) {
            return defaultReturn();
        }
    }

    protected abstract T doBuild();

    protected T defaultReturn() {
        return null;
    }

}
