package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.service.client.FeedBackSvcClient.FeedBackSvcClient;
import com.ebay.app.apisellingextsvc.service.client.FeedBackSvcClient.FeedbackResponseData;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.model.FeedBackPercentageModel;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.ProformaOrderCS;
import com.ebay.order.common.v1.Order;
import com.ebay.order.common.v1.UserIdentifier;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import ebay.apis.eblbasecomponents.ErrorType;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class FeedBackServiceInvokeTask implements Task<FeedBackPercentageModel>, ITaskResultInjectable {
    private final Executor executor;
    private final Map<String, Object> resultMap = new HashMap<>();
    private static Logger logger = LoggerFactory.getLogger(FeedBackSvcClient.class);
    private final IServiceInvoker<String, String> fdbkServiceInvoker;
    private final HttpHeaders headers;
    private final String sellerId;
    private final ApiSellingExtSvcConfigValues configValues;

    public FeedBackServiceInvokeTask(
            IServiceInvoker<String, String> fdbkServiceInvoker,String sellerId,
            List<ErrorType> errorList, HttpHeaders headers, ApiSellingExtSvcConfigValues configValues,
            Executor executor) {
        this.fdbkServiceInvoker = fdbkServiceInvoker;
        this.sellerId = sellerId;
        this.headers = headers;
        this.configValues = configValues;
        this.executor = executor;
    }

    @Override
    public FeedBackPercentageModel call() {
        ContractResponse contractResponse = (ContractResponse)resultMap.get(ContractResponse.class.getName());
        List<List<String>> userSegmentList = buildUserSegment(contractResponse);
        List<String> feedbackResponse = Optional.of(userSegmentList)
                .orElse(new ArrayList<>())
                .stream()
                .map(t -> CompletableFuture.supplyAsync(() -> this.fdbkServiceInvoker.getResponse(buildQuery(t), headers),executor))
                .collect(Collectors.toList()).stream()
                .map(CompletableFuture::join)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        return new FeedBackPercentageModel(buildFeedBackPercentageMap(feedbackResponse));
    }

    private Map<String, Double> buildFeedBackPercentageMap(List<String> feedbackResponse) {
        if (CollectionUtils.isEmpty(feedbackResponse)) return new HashMap<>();
        Map<String, Double> feedbackPercentageMap = new HashMap<>();
        for (String response: feedbackResponse) {
            Gson gson = new Gson();
            JsonObject feedbackObject = (JsonObject) JsonParser.parseString(response).getAsJsonObject().get("data");
            if (feedbackObject != null) {
                feedbackObject.entrySet().forEach(entry -> {
                    if (gson.fromJson(entry.getValue(), FeedbackResponseData.class)
                                    .getOverallRatingSummaryDistribution() != null) {
                        feedbackPercentageMap.put(entry.getKey().substring(8),
                                gson.fromJson(entry.getValue(), FeedbackResponseData.class)
                                        .getOverallRatingSummaryDistribution()
                                        .getPositiveFeedbackReceivedPercentNonRepeatedNeutralExcluded());
                    }
                });
            }
        }
        return feedbackPercentageMap;
    }

    private List<List<String>> buildUserSegment(ContractResponse contractResponse) {
        List<String> userIds = new ArrayList<>(buildUserIdSet(contractResponse));
        int partitionSize = configValues.feedback_users_max_limit;
        Collection<List<String>> partitionedList = IntStream.range(0, userIds.size())
                .boxed()
                .collect(Collectors.groupingBy(partition -> (partition / partitionSize),
                        Collectors.mapping(userIds::get, Collectors.toList())))
                .values();
        return new ArrayList<>(partitionedList);
    }

    private String buildQuery(List<String> userIdSet) {
        StringBuilder feedbackRequestQuery = (new StringBuilder()).append("query {\n");
        List<String> userIds = new ArrayList<>(userIdSet);
        for (String id: userIds) {
            String queryWithUserIds = "user_id_" + id + ":userFeedbackInternal(userFeedbackInternalInput: { " +
                    "oracleUserId: \"" + id +  "\"" +
                    "}) {\n " +
                    "overallRatingSummaryDistribution(ratingSummaryInput: { " +
                    "userFeedbackTimeDuration : DAYS_365 }) {\n " +
                    "positiveFeedbackReceivedPercentNonRepeatedNeutralExcluded" +
                    "}\n" +
                    "}\n";
            feedbackRequestQuery.append(queryWithUserIds);
        }
        return feedbackRequestQuery.append("}").toString();
    }

    private Set<String> buildUserIdSet(ContractResponse contractResponse) {
        Set<String> idSet = new LinkedHashSet<>();
        idSet.add(sellerId);
        List<ContractResponseType> contractResponseTypeList = Optional.ofNullable(contractResponse).map(ContractResponse::getMembers)
                                                                      .orElse(Collections.emptyList());
        for (ContractResponseType contractResponseType: contractResponseTypeList) {
            if (Optional.ofNullable(contractResponseType).map(ContractResponseType::getOrder).isPresent()) {
                Optional.of(contractResponseType).map(ContractResponseType::getOrder)
                        .map(Order::getBuyer)
                        .map(com.ebay.order.common.v1.User::getUserIdentifier)
                        .map(UserIdentifier::getUserId)
                        .ifPresent(idSet::add);
            } else if (Optional.ofNullable(contractResponseType).map(ContractResponseType::getProformaOrder).isPresent()) {
                Optional.of(contractResponseType).map(ContractResponseType::getProformaOrder)
                        .map(ProformaOrderCS::getBuyerCS)
                        .map(com.ebay.order.common.v1.User::getUserIdentifier)
                        .map(UserIdentifier::getUserId)
                        .ifPresent(idSet::add);
            }
        }
        return idSet;
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
