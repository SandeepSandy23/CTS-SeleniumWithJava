package com.ebay.app.apisellingextsvc.utils;


import javax.ws.rs.core.*;
import java.util.*;

public class Headers implements HttpHeaders {
    private MultivaluedHashMap headers = new MultivaluedHashMap();

    public Headers() {
    }

    public void add(String name, String value) {
        if (value != null) {
            String[] values = value.split(",");
            List<String> vl = new ArrayList(values.length);

            for (int i = 0; i < values.length; ++i) {
                vl.add(values[i]);
            }

            this.headers.put(name, vl);
        }

    }

    public void add(String name, List<String> header) {
        this.headers.put(name, header);
    }

    public List<String> getRequestHeader(String name) {
        return this.headers.get(name);
    }

    public String getHeaderString(String name) {
        List<String> values = this.getRequestHeader(name);
        if (values != null) {
            StringBuilder sb = new StringBuilder();
            int i = 0;

            for (Iterator var5 = values.iterator(); var5.hasNext(); ++i) {
                String val = (String) var5.next();
                if (i > 0) {
                    sb.append(',');
                }

                sb.append(val);
            }

            return sb.toString();
        } else {
            return null;
        }
    }

    public MultivaluedMap<String, String> getRequestHeaders() {
        return this.headers;
    }

    public List<MediaType> getAcceptableMediaTypes() {
        return null;
    }

    public List<Locale> getAcceptableLanguages() {
        return null;
    }

    public MediaType getMediaType() {
        return null;
    }

    public Locale getLanguage() {
        return null;
    }

    public Map<String, Cookie> getCookies() {
        return null;
    }

    public Date getDate() {
        return null;
    }

    public int getLength() {
        return -1;
    }

}