package com.ebay.app.apisellingextsvc.service.dal.sellerdiscount;


import com.ebay.integ.dal.BaseDo3;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.persistence.DALVersion;

import java.util.Date;

@DALVersion("3.0")
public class SellerDiscountEntityCodeGenDoImpl extends BaseDo3 implements SellerDiscountEntity {
    public static final long serialVersionUID = 1L;
    public static final int SELLERDISCOUNTENTITYID = 0;
    public static final int PARTITIONKEY = 1;
    public static final int BUYERID = 2;
    public static final int SELLERID = 3;
    public static final int CHECKOUTCARTID = 4;
    public static final int ITEMID = 5;
    public static final int TRANSACTIONID = 6;
    public static final int ORDERID = 7;
    public static final int TRANSACTIONQUANTITY = 8;
    public static final int ORIGINALITEMPRICE = 9;
    public static final int ITEMPRICE = 10;
    public static final int SHIPPINGFEE = 11;
    public static final int SHIPPINGDISCOUNTAMOUNT = 12;
    public static final int CURRENCYID = 13;
    public static final int ORIGINALSHIPPINGSERVICE = 14;
    public static final int PROMOSHIPPINGSERVICE = 15;
    public static final int DISCOUNTSTATUS = 16;
    public static final int SELLERCAMPAIGNID = 17;
    public static final int RULEINSTANCEID = 18;
    public static final int PRIMARYITEMID = 19;
    public static final int CREATIONDATE = 20;
    public static final int LASTMODIFIEDDATE = 21;
    public static final int SELLERPRODUCTBUNDLEID = 22;
    public static final int DEBUGINFO = 23;
    public static final int TITLE = 24;
    public static final int TRANSACTIONDATE = 25;
    public static final int FLAGS01 = 26;
    public static final int SELLERPRODUCT = 27;
    public static final int PROCESSEDFLAG = 28;
    public static final int OFFERCHECKSUMID = 29;
    public static final int OFFERTIER = 30;
    public static final int OFFERRANK = 31;
    public static final int OFFERTYPE = 32;
    public static final int OFFERSUBTYPE = 33;
    public static final int SHIPPINGDISCOUNTSTATUS = 34;
    public static final int OFFERMESSAGE = 35;
    public static final int OFFERCONDITIONALMESSAGE = 36;
    public static final int NUM_FIELDS = 37;
    public static final int NUM_SUBOBJECT_FIELDS = 0;
    public String m_offerConditionalMessage;
    public String m_offerMessage;
    public int m_shippingDiscountStatus;
    public int m_offerSubType;
    public int m_offerType;
    public int m_offerRank;
    public String m_offerTier;
    public long m_offerchecksumid;
    public int m_processedFlag;
    public String m_sellerProduct;
    public long m_flags01;
    public Date m_transactionDate;
    public String m_title;
    public String m_debugInfo;
    public long m_sellerProductBundleId;
    public Date m_lastModifiedDate;
    public Date m_creationDate;
    public long m_primaryItemId;
    public long m_ruleInstanceId;
    public long m_sellerCampaignId;
    public int m_discountStatus;
    public int m_promoShippingService;
    public int m_originalShippingService;
    public int m_currencyId;
    public double m_shippingDiscountAmount;
    public double m_shippingFee;
    public double m_itemPrice;
    public double m_originalItemPrice;
    public long m_transactionQuantity;
    public long m_orderId;
    public long m_transactionId;
    public long m_itemId;
    public long m_checkoutCartId;
    public long m_sellerId;
    public long m_buyerId;
    public int m_partitionKey;
    public long m_sellerDiscountEntityId;

    public SellerDiscountEntityCodeGenDoImpl() {
        super(SellerDiscountEntityDAO.getInstance(), GenericMap.getInitializedMap(SellerDiscountEntity.class));
    }

    public SellerDiscountEntityCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public String getOfferConditionalMessage() {
        this.loadValue(36);
        return this.m_offerConditionalMessage;
    }

    public void setOfferConditionalMessage(String p_offerConditionalMessage) {
        this.m_offerConditionalMessage = p_offerConditionalMessage;
        this.setDirty(36);
    }

    public String getOfferMessage() {
        this.loadValue(35);
        return this.m_offerMessage;
    }

    public void setOfferMessage(String p_offerMessage) {
        this.m_offerMessage = p_offerMessage;
        this.setDirty(35);
    }

    public int getShippingDiscountStatus() {
        this.loadValue(34);
        return this.m_shippingDiscountStatus;
    }

    public void setShippingDiscountStatus(int p_shippingDiscountStatus) {
        this.m_shippingDiscountStatus = p_shippingDiscountStatus;
        this.setDirty(34);
    }

    public int getOfferSubType() {
        this.loadValue(33);
        return this.m_offerSubType;
    }

    public void setOfferSubType(int p_offerSubType) {
        this.m_offerSubType = p_offerSubType;
        this.setDirty(33);
    }

    public int getOfferType() {
        this.loadValue(32);
        return this.m_offerType;
    }

    public void setOfferType(int p_offerType) {
        this.m_offerType = p_offerType;
        this.setDirty(32);
    }

    public int getOfferRank() {
        this.loadValue(31);
        return this.m_offerRank;
    }

    public void setOfferRank(int p_offerRank) {
        this.m_offerRank = p_offerRank;
        this.setDirty(31);
    }

    public String getOfferTier() {
        this.loadValue(30);
        return this.m_offerTier;
    }

    public void setOfferTier(String p_offerTier) {
        this.m_offerTier = p_offerTier;
        this.setDirty(30);
    }

    public long getOfferchecksumid() {
        this.loadValue(29);
        return this.m_offerchecksumid;
    }

    public void setOfferchecksumid(long p_offerchecksumid) {
        this.m_offerchecksumid = p_offerchecksumid;
        this.setDirty(29);
    }

    public int getProcessedFlag() {
        this.loadValue(28);
        return this.m_processedFlag;
    }

    public void setProcessedFlag(int p_processedFlag) {
        this.m_processedFlag = p_processedFlag;
        this.setDirty(28);
    }

    public String getSellerProduct() {
        this.loadValue(27);
        return this.m_sellerProduct;
    }

    public void setSellerProduct(String p_sellerProduct) {
        this.m_sellerProduct = p_sellerProduct;
        this.setDirty(27);
    }

    public long getFlags01() {
        this.loadValue(26);
        return this.m_flags01;
    }

    public void setFlags01(long p_flags01) {
        this.m_flags01 = p_flags01;
        this.setDirty(26);
    }

    public Date getTransactionDate() {
        this.loadValue(25);
        return this.m_transactionDate;
    }

    public void setTransactionDate(Date p_transactionDate) {
        this.m_transactionDate = p_transactionDate;
        this.setDirty(25);
    }

    public String getTitle() {
        this.loadValue(24);
        return this.m_title;
    }

    public void setTitle(String p_title) {
        this.m_title = p_title;
        this.setDirty(24);
    }

    public String getDebugInfo() {
        this.loadValue(23);
        return this.m_debugInfo;
    }

    public void setDebugInfo(String p_debugInfo) {
        this.m_debugInfo = p_debugInfo;
        this.setDirty(23);
    }

    public long getSellerProductBundleId() {
        this.loadValue(22);
        return this.m_sellerProductBundleId;
    }

    public void setSellerProductBundleId(long p_sellerProductBundleId) {
        this.m_sellerProductBundleId = p_sellerProductBundleId;
        this.setDirty(22);
    }

    public Date getLastModifiedDate() {
        this.loadValue(21);
        return this.m_lastModifiedDate;
    }

    public void setLastModifiedDate(Date p_lastModifiedDate) {
        this.m_lastModifiedDate = p_lastModifiedDate;
        this.setDirty(21);
    }

    public Date getCreationDate() {
        this.loadValue(20);
        return this.m_creationDate;
    }

    public void setCreationDate(Date p_creationDate) {
        this.m_creationDate = p_creationDate;
        this.setDirty(20);
    }

    public long getPrimaryItemId() {
        this.loadValue(19);
        return this.m_primaryItemId;
    }

    public void setPrimaryItemId(long p_primaryItemId) {
        this.m_primaryItemId = p_primaryItemId;
        this.setDirty(19);
    }

    public long getRuleInstanceId() {
        this.loadValue(18);
        return this.m_ruleInstanceId;
    }

    public void setRuleInstanceId(long p_ruleInstanceId) {
        this.m_ruleInstanceId = p_ruleInstanceId;
        this.setDirty(18);
    }

    public long getSellerCampaignId() {
        this.loadValue(17);
        return this.m_sellerCampaignId;
    }

    public void setSellerCampaignId(long p_sellerCampaignId) {
        this.m_sellerCampaignId = p_sellerCampaignId;
        this.setDirty(17);
    }

    public int getDiscountStatus() {
        this.loadValue(16);
        return this.m_discountStatus;
    }

    public void setDiscountStatus(int p_discountStatus) {
        this.m_discountStatus = p_discountStatus;
        this.setDirty(16);
    }

    public int getPromoShippingService() {
        this.loadValue(15);
        return this.m_promoShippingService;
    }

    public void setPromoShippingService(int p_promoShippingService) {
        this.m_promoShippingService = p_promoShippingService;
        this.setDirty(15);
    }

    public int getOriginalShippingService() {
        this.loadValue(14);
        return this.m_originalShippingService;
    }

    public void setOriginalShippingService(int p_originalShippingService) {
        this.m_originalShippingService = p_originalShippingService;
        this.setDirty(14);
    }

    public int getCurrencyId() {
        this.loadValue(13);
        return this.m_currencyId;
    }

    public void setCurrencyId(int p_currencyId) {
        this.m_currencyId = p_currencyId;
        this.setDirty(13);
    }

    public double getShippingDiscountAmount() {
        this.loadValue(12);
        return this.m_shippingDiscountAmount;
    }

    public void setShippingDiscountAmount(double p_shippingDiscountAmount) {
        this.m_shippingDiscountAmount = p_shippingDiscountAmount;
        this.setDirty(12);
    }

    public double getShippingFee() {
        this.loadValue(11);
        return this.m_shippingFee;
    }

    public void setShippingFee(double p_shippingFee) {
        this.m_shippingFee = p_shippingFee;
        this.setDirty(11);
    }

    public double getItemPrice() {
        this.loadValue(10);
        return this.m_itemPrice;
    }

    public void setItemPrice(double p_itemPrice) {
        this.m_itemPrice = p_itemPrice;
        this.setDirty(10);
    }

    public double getOriginalItemPrice() {
        this.loadValue(9);
        return this.m_originalItemPrice;
    }

    public void setOriginalItemPrice(double p_originalItemPrice) {
        this.m_originalItemPrice = p_originalItemPrice;
        this.setDirty(9);
    }

    public long getTransactionQuantity() {
        this.loadValue(8);
        return this.m_transactionQuantity;
    }

    public void setTransactionQuantity(long p_transactionQuantity) {
        this.m_transactionQuantity = p_transactionQuantity;
        this.setDirty(8);
    }

    public long getOrderId() {
        this.loadValue(7);
        return this.m_orderId;
    }

    public void setOrderId(long p_orderId) {
        this.m_orderId = p_orderId;
        this.setDirty(7);
    }

    public long getTransactionId() {
        this.loadValue(6);
        return this.m_transactionId;
    }

    public void setTransactionId(long p_transactionId) {
        this.m_transactionId = p_transactionId;
        this.setDirty(6);
    }

    public long getItemId() {
        this.loadValue(5);
        return this.m_itemId;
    }

    public void setItemId(long p_itemId) {
        this.m_itemId = p_itemId;
        this.setDirty(5);
    }

    public long getCheckoutCartId() {
        this.loadValue(4);
        return this.m_checkoutCartId;
    }

    public void setCheckoutCartId(long p_checkoutCartId) {
        this.m_checkoutCartId = p_checkoutCartId;
        this.setDirty(4);
    }

    public long getSellerId() {
        this.loadValue(3);
        return this.m_sellerId;
    }

    public void setSellerId(long p_sellerId) {
        this.m_sellerId = p_sellerId;
        this.setDirty(3);
    }

    public long getBuyerId() {
        this.loadValue(2);
        return this.m_buyerId;
    }

    public void setBuyerId(long p_buyerId) {
        this.m_buyerId = p_buyerId;
        this.setDirty(2);
    }

    public int getPartitionKey() {
        this.loadValue(1);
        return this.m_partitionKey;
    }

    public void setPartitionKey(int p_partitionKey) {
        this.m_partitionKey = p_partitionKey;
        this.setDirty(1);
    }

    public long getSellerDiscountEntityId() {
        this.loadValue(0);
        return this.m_sellerDiscountEntityId;
    }

    public void setSellerDiscountEntityId(long p_sellerDiscountEntityId) {
        this.m_sellerDiscountEntityId = p_sellerDiscountEntityId;
        this.setDirty(0);
    }

    public void setAutoIncFieldValue(long p_sellerDiscountEntityId) {
        this.m_sellerDiscountEntityId = p_sellerDiscountEntityId;
    }

    public String getEntityIdColumnSwitcher() {
        return (String)this.getHashValue("entityIdColumnSwitcher");
    }

    public void setEntityIdColumnSwitcher(String entityIdColumnSwitcher) {
        this.setHashValue("entityIdColumnSwitcher", entityIdColumnSwitcher);
    }

    public int getNumFields() {
        return 37;
    }

    public int getNumSubObjects() {
        return 0;
    }
}
