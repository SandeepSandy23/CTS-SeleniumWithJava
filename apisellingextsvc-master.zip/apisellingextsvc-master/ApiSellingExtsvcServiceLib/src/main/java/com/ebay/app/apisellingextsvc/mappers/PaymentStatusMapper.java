package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.FundingStatusTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.PaymentTransactionStatusCodeType;

// for monetary.payment.status
public class PaymentStatusMapper {

    // checkout trans payment method
    private static final ImmutableMap<FundingStatusTypeEnum, PaymentTransactionStatusCodeType> mapName
            = new ImmutableMap.Builder<FundingStatusTypeEnum, PaymentTransactionStatusCodeType>()
            .put(FundingStatusTypeEnum.NOT_FUNDED, PaymentTransactionStatusCodeType.FAILED)
            .put(FundingStatusTypeEnum.FUNDED, PaymentTransactionStatusCodeType.SUCCEEDED)
            .put(FundingStatusTypeEnum.PENDING, PaymentTransactionStatusCodeType.PENDING)
            .build();

    private PaymentStatusMapper() {
    }

    public static PaymentTransactionStatusCodeType map(FundingStatusTypeEnum key) {
        return mapName.getOrDefault(key, PaymentTransactionStatusCodeType.CUSTOM_CODE);
    }

}
