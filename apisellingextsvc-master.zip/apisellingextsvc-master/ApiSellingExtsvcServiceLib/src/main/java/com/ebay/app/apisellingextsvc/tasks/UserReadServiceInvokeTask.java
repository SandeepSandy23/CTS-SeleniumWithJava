package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import com.ebay.app.apisellingextsvc.handlers.ExceptionHandler;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.User;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserInfo;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserReadResponse;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import ebay.apis.eblbasecomponents.ErrorType;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class UserReadServiceInvokeTask implements Task<UserReadResponse>, ITaskResultInjectable {

    private static final ImmutableSet<String> invalidUserStatuses = ImmutableSet.of(
            "SUSPENDED","DELETED","GHOST","INMAINTENANCE","MERGED","CCVERIFY","UNKNOWN","REGCODEMAILOUT","CCVERIFY_HALFOPTIN");

    private final IServiceInvoker<String, UserReadResponse> userReadServiceInvoker;
    private final List<ErrorType> errorList;
    private final HttpHeaders headers;
    private final String sellerId;
    private final ContentResource errorContent;

    public UserReadServiceInvokeTask(
            IServiceInvoker<String, UserReadResponse> userReadServiceInvoker,
            List<ErrorType> errorList, HttpHeaders headers, String sellerId, ContentResource errorContent) {
        this.userReadServiceInvoker = userReadServiceInvoker;
        this.errorList = errorList;
        this.headers = headers;
        this.sellerId = sellerId;
        this.errorContent = errorContent;
    }

    @Override
    public UserReadResponse call() {
        UserReadResponse userReadResponse = this.userReadServiceInvoker.getResponse(buildQuery(sellerId), headers);
        Optional<UserInfo> userInfo = Optional.ofNullable(userReadResponse).map(UserReadResponse::getData).map(User::getUser).map(Collection::stream).flatMap(Stream::findFirst);
        String accountStatus = userInfo.map(UserInfo::getUserAccountStatus).orElse("");
        if (invalidUserStatuses.contains(accountStatus)) {
            String userName = userInfo.map(UserInfo::getUsername).orElse("UNKNOWN_USER_NAME");
            CalLogger.error("User Account Error", "The user (" + userName + ") account status was " + accountStatus + ".");
            ExceptionHandler.throwException(ApplicationError.USER_ACCOUNT_ERROR, errorContent.contentHelper.getErrorContentManager());
        }
        return userReadResponse;
    }

    private String buildQuery(String sellerId) {
        StringBuilder query = (new StringBuilder()).append("query userQuery {\n");
        query.append("user(id:\"").append(sellerId).append("\") {\nlegacyUserId\nuserAccountName\nuserAccountType");

        getProfileQuery().forEach(it -> query.append("\n").append(it));

        // Closing query
        query.append("\n}\n}");

        return query.toString();
    }

    private List<String> getProfileQuery() {
        List<String> responseFields = new ArrayList<>();
        responseFields.add("registrationSiteId");
        responseFields.add("registrationMarketPlaceId");
        responseFields.add("countryOfResidence");
        responseFields.add("userAccountStatus");
        responseFields.add("userAccountCreationDate");
        responseFields.add("individualIdentityProfile {");
        responseFields.add("firstName");
        responseFields.add("lastName");
        responseFields.add("email");
//        Userread bulksvc is not supporting these fields as of now.
//        responseFields.add("creationDate");
//        responseFields.add("lastModifiedDate");
        responseFields.add("address {");
        addressInfo(responseFields);
        responseFields.add("}");
        responseFields.add("businessIdentityProfile {");
        responseFields.add("businessEmail");
        responseFields.add("businessAddress {");
        addressInfo(responseFields);
        responseFields.add("}");
        responseFields.add("extensions(namespace: [\"SELLING\",\"PAYMENT\", \"TRUST\", \"IDENTITY\", \"BILLING\"]) { key  value type }");

        return responseFields;
    }

    static void addressInfo(List<String> responseFields) {
        responseFields.add("addressLine1");
        responseFields.add("addressLine2");
        responseFields.add("city");
        responseFields.add("stateOrProvince");
        responseFields.add("postalCode");
        responseFields.add("country");
        responseFields.add("}");
    }

    @Override
    public void addResult(Object o) {}

}
