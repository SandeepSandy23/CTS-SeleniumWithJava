
package com.ebay.app.apisellingextsvc.enums;

import ebay.apis.eblbasecomponents.ErrorClassificationCodeType;
import ebay.apis.eblbasecomponents.SeverityCodeType;

public enum ApplicationError {

    // https://developer.ebay.com/devzone/XML/docs/Reference/ebay/Errors/ErrorMessages.htm

    OUTPUT_SELECTOR_INVALID("21915461", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    PARAM_OUT_OF_RANGE("9", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_USER("35", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_ITEMID_TXNID_OR_FEEDBACK_ALREADY_LEFT("55", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    EXCEED_MODIFIED_DATE("406", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    AUTH_TOKEN_INVALID("931", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    AUTH_TOKEN_EXPIRED("932", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_MOD_DATE_FROM("1054", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    SYSTEM_ERROR("10007", SeverityCodeType.ERROR, ErrorClassificationCodeType.SYSTEM_ERROR),
    EMPTY_TAG("10009", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),

    INVALID_HEADER("10012", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),

    INVALID_ITEM_ID_TRANSACTION_ID("20822", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_SHIPPING_STATUS("20823", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_PAGINATION_INPUT("340", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),

    INVALID_PAYMENT_STATUS("20824", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    ITEMID_HAS_MORE_THAN_ONE_TRANSACTION("21150", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_DATE_RANGE("219018", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    EXCEED_CREATE_DATE("21916186", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    INPUT_DATA_MISSING("21917149", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_ORDER_LINE_IDS("21917182", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_ORDER_LINE_ITEM_ID("21917129", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    NO_DATA_IN_COMPLETE_SALE("21147", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    PARTIAL_ERROR("16101", SeverityCodeType.WARNING, ErrorClassificationCodeType.SYSTEM_ERROR),
    DATA_TRUNCATED("21366", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    DURATION_IN_DAYS_OUT_OF_RANGE("21360", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    UNSUPPORTED_FIELD("21361", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    INVALID_SORT("21362", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    ENTRIES_PER_PAGE_OUT_OF_RANGE("21363", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    PAGE_NUMBER_OUT_OF_RANGE("21364", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    INCOMPATIBLE_SCHEMA_VERSION("14004", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    USER_ACCOUNT_ERROR("21930", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR),
    COMPATIBILITY_HEADER_MISMATCH("21926", SeverityCodeType.WARNING, ErrorClassificationCodeType.REQUEST_ERROR),
    UNSUPPORTED_COMPATABILITY("520", SeverityCodeType.ERROR, ErrorClassificationCodeType.REQUEST_ERROR);

    private final String errorCode;
    private final SeverityCodeType severityCode;
    private final ErrorClassificationCodeType errorClassificationCodeType;

    ApplicationError(String errorCode, SeverityCodeType severityCode, ErrorClassificationCodeType errorClassificationCodeType) {
        this.errorCode = errorCode;
        this.severityCode = severityCode;
        this.errorClassificationCodeType = errorClassificationCodeType;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public SeverityCodeType getSeverityCode() {
        return severityCode;
    }

    public ErrorClassificationCodeType getErrorClassificationCodeType() {
        return errorClassificationCodeType;
    }

    public String getContentKey() {
        return this.name();
    }
}
