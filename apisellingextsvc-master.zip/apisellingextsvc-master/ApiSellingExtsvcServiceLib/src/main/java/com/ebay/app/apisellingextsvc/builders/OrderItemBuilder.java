package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.mappers.ListingTypeMapper;
import com.ebay.app.apisellingextsvc.tasks.GMES.ListingActivitiesNGUtil;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.ItemTitleUtil;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.lib.lasng.model.AdditionalAttributesInfo;
import com.ebay.lib.lasng.model.BuyingInfo;
import com.ebay.lib.lasng.model.CoreInfo;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.lib.lasng.model.ListingLifecycle;
import com.ebay.lib.lasng.model.PricingInfo;
import com.ebay.lib.lasng.model.QuantityInfo;
import com.ebay.lib.lasng.model.VariationInfo;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.EntityTotal;
import com.ebay.order.common.v1.InventorySKUInfo;
import com.ebay.order.common.v1.LineItemSource;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.CountryCodeType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.ItemType;
import ebay.apis.eblbasecomponents.ListingDetailsType;
import ebay.apis.eblbasecomponents.ListingTypeCodeType;
import ebay.apis.eblbasecomponents.SellingStatusType;

import javax.xml.datatype.XMLGregorianCalendar;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import static com.ebay.app.apisellingextsvc.utils.DateUtil.getXmlGregorianCalendar;

public class OrderItemBuilder extends BaseFacetBuilder<ItemType> {

    private static final Pattern PRIMARY_CATEGORY_PATTER = Pattern.compile("(\\d+)]$");
    private static final String ITEM_APPLICATION_DATA = "ITEM_APPLICATION_DATA";
    private static final String ITEM_LOCATION = "ITEM_LOCATION";
    private final ApiSellingExtSvcConfigValues configValues;
    private final List<Attribute> attribute;
    private final InventorySKUInfo inventoryDetails;
    private final LineItemSource sourceId;

    protected final ListingActivity listingActivity;
    private final List<Attribute> itemSkuDetails;
    private final Text title;
    private final List<DetailLevelCodeType> detailLevels;
    private final EntityTotal entityTotal;
    private final Amount discountedCost;

    protected  Item item;

    public OrderItemBuilder(Task task,
                            LineItemXType lineItem,
                            ApiSellingExtSvcConfigValues configValues,
                            Map<Long, ListingActivity> itemIdListingActivityMap,
                            Map<String, Item> svlsItemInfoMap,
                            List<DetailLevelCodeType> detailLevels) {
        super(task);
        this.configValues = configValues;
        discountedCost = lineItem.getDiscountedCost();
        attribute = lineItem.getAttribute();
        inventoryDetails = lineItem.getInventoryDetails();
        sourceId = lineItem.getSourceId();
        listingActivity = getListingActivity(sourceId, itemIdListingActivityMap);
        if(svlsItemInfoMap !=null) {
            item = getItem(sourceId, svlsItemInfoMap);
        }
        itemSkuDetails = lineItem.getItemSkuDetails();
        this.title = lineItem.getTitle();
        this.detailLevels = detailLevels;
        this.entityTotal = lineItem.getLineItemTotal();
    }

    public OrderItemBuilder(Task task,
                            ProformaOrderLineItemXType lineItem,
                            ApiSellingExtSvcConfigValues configValues,
                            Map<Long, ListingActivity> itemIdListingActivityMap,
                            Map<String, Item> svlsItemInfoMap,
                            List<DetailLevelCodeType> detailLevels) {
        super(task);
        this.configValues = configValues;
        discountedCost = null;
        attribute = lineItem.getAttribute();
        inventoryDetails = lineItem.getInventoryDetails();
        sourceId = lineItem.getSourceId();
        listingActivity = getListingActivity(sourceId, itemIdListingActivityMap);
        if(svlsItemInfoMap !=null) {
            item = getItem(sourceId, svlsItemInfoMap);
        }
        itemSkuDetails = lineItem.getItemSkuDetails();
        this.title = lineItem.getTitle();
        this.detailLevels = detailLevels;
        this.entityTotal = lineItem.getLineItemTotal();
    }

    @Override
    protected ItemType doBuild() {
        ItemType itemType = new ItemType();
        itemType.setCountry(getItemCountry());
        String itemId = getItemId();
        if( null != itemId ) {
            CalLogger.info("OrderItemBuilder--> Item ID: ",itemId);
        }
        itemType.setItemID(itemId);
        itemType.setSKU(getSKU());
        itemType.setListingType(getListingType());
        itemType.setSellingStatus(getSellingStatus());
        Long variationId = getVariationId();
        if (null != variationId && variationId != 0 ) {
            VariationInfo variationInfo = getVariationInfo(variationId,listingActivity);
            itemType.setQuantity(getAvailableVariationQuantity(variationInfo) + getSoldVariationQuantity(variationInfo));
        } else {
            itemType.setQuantity(getAvailableQuantity() + getSoldQuantity());
        }

        if (CommonUtil.shouldExposeForReturnAllOrEmpty(detailLevels)) {
            itemType.setBuyItNowPrice(getBuyItNowPrice());
            itemType.setListingDetails(getListingDetails());
            itemType.setTitle(getItemTitle());
        }

        return itemType;
    }

    private CountryCodeType getItemCountry() {
        String country = AttributeUtil.findAttribute(attribute, ITEM_LOCATION).map(Attribute::getValue).orElse(null);

        try {
            if (country != null) {
                CountryCodeType countryCodeType = CountryCodeType.fromValue(country);
                return countryCodeType;
            }

        } catch (Exception e) {
            return null;
        }
        return null;
    }

    private String getApplicationData() {
        return AttributeUtil.findAttribute(attribute, ITEM_APPLICATION_DATA).map(Attribute::getValue).orElse(null);
    }

    private ListingTypeCodeType getListingType() {
        return ListingTypeMapper.map(AttributeUtil.findAttribute(attribute, ApiSellingExtSvcConstants.ATTR_SALE_TYPE).map(Attribute::getValue).orElse(null));
    }

    protected Integer getAvailableQuantity() {
        return Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getQuantity)
                .map(QuantityInfo::getAvailableQty).orElse(0);
    }

    protected Integer getSoldQuantity() {
        return Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getQuantity)
                .map(QuantityInfo::getSoldQty).orElse(0);
    }

    protected Integer getAvailableVariationQuantity(VariationInfo variationInfo) {
        return Optional.ofNullable(variationInfo).map(VariationInfo::getAvailableQty).orElse(0);
    }

    protected Integer getSoldVariationQuantity(VariationInfo variationInfo) {
        return Optional.ofNullable(variationInfo).map(VariationInfo::getSoldQty).orElse(0);
    }

    protected Long getVariationId() {
        return Optional.ofNullable(sourceId).map(LineItemSource::getVariationId).map(Long::parseLong).orElse(null);
    }

    protected  VariationInfo getVariationInfo( Long variationId , ListingActivity listingActivity) {
        return  Optional.ofNullable(listingActivity)
                         .map(ListingActivity::getCore)
                         .map(CoreInfo::getVariations)
                         .flatMap(variations -> variations.stream()
                         .filter(variation -> variationId.equals(variation.getVariationId()))
                         .findAny()).orElse(null);
    }

    protected Integer getBidCount() {
        return Optional.ofNullable(listingActivity).map(ListingActivity::getAdditionalAttributes)
                .map(AdditionalAttributesInfo::getBuyingInfo)
                .map(BuyingInfo::getBidCount).orElse(null);
    }

    protected ListingDetailsType getListingDetails() {
        ListingDetailsType listingDetailsType = new ListingDetailsType();
        Optional<LocalDateTime> endTime = Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getLifecycle).map(ListingLifecycle::getEndTime);
        Optional<LocalDateTime> startTime = Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getLifecycle).map(ListingLifecycle::getStartTime);
        XMLGregorianCalendar xmlGregorianCalendarEndTime = getXmlGregorianCalendar(endTime);
        XMLGregorianCalendar xmlGregorianCalendarStartTime = getXmlGregorianCalendar(startTime);
        listingDetailsType.setEndTime(xmlGregorianCalendarEndTime);
        listingDetailsType.setStartTime(xmlGregorianCalendarStartTime);
        return listingDetailsType;
    }


    public Boolean hasReservePrice() {
        Double reservePrice = Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore).map(CoreInfo::getPrice)
                .map(PricingInfo::getReservePrice)
                .orElse(null);

        return (reservePrice != null && reservePrice !=0.0) ? Boolean.TRUE: Boolean.FALSE;
    }

    /**
     * CurrentPrice - Return COSMOS UNIT_COST for all formats
     *
     * @return
     */
    protected AmountType getCurrentPrice() {
        if (discountedCost != null) {
            return AmountTypeUtil.getAmountType(discountedCost);
        }

        return Optional.ofNullable(entityTotal)
                .map(EntityTotal::getPriceLines)
                .orElse(new ArrayList<>())
                .stream().filter(priceLine -> PricelineTypeEnum.UNIT_COST == priceLine.getType())
                .findFirst()
                .map(PriceLine::getAmount)
                .map((AmountTypeUtil::getAmountType)).orElse(null);
    }

    /**
     * BuyItNowPrice - Format is Auction then BuyItNowPrice, format is Fixed then 0
     *
     * @return
     */
    protected AmountType getBuyItNowPrice() {
        CoreInfo.FormatEnum format = ListingActivitiesNGUtil.getFormat(listingActivity);
        if (CoreInfo.FormatEnum.AUCTION.equals(format)) {
            return ListingActivitiesNGUtil.getBuyItNowPrice(listingActivity);
        } else if (CoreInfo.FormatEnum.FIXED_PRICE.equals(format)) {
            return AmountTypeUtil.getZeroAmountType(ListingActivitiesNGUtil.getCurrency(listingActivity));
        }
        return null;
    }

    protected String getItemTitle() {
        if (title != null) {
            return ItemTitleUtil.truncateString(this.title.getContent(), configValues.varTitleSizeLimit);
        }
        return null;
    }

    protected String getItemId() {
        return Optional.ofNullable(sourceId).map(LineItemSource::getItemId).orElse(null);
    }

    protected String getSKU() {
        // https://jirap.corp.ebay.com/browse/LUXIBLES-1103
        Optional<String> sku = AttributeUtil.findAttribute(attribute, ApiSellingExtSvcConstants.SKU).map(Attribute::getValue);
        if (sku.isPresent()) {
            return sku.get();
        }
        if (inventoryDetails != null) {
            return inventoryDetails.getSellerProvidedSKUId();
        }
        sku = AttributeUtil.findAttribute(attribute, ApiSellingExtSvcConstants.ATTR_SELLER_PRODUCT_ID).map(Attribute::getValue);
        if (sku.isPresent()) {
            return sku.get();
        }
        return null;
    }

    private SellingStatusType getSellingStatus() {
        SellingStatusType sellingStatusType = new SellingStatusType();
        sellingStatusType.setCurrentPrice(Optional.ofNullable(ListingActivitiesNGUtil.getLowestAvailableVariationPrice(listingActivity))
                .orElse(ListingActivitiesNGUtil.getCurrentPrice(listingActivity)));
        Long variationId = getVariationId();
        if (null != variationId && variationId != 0) {
            VariationInfo variationInfo = getVariationInfo(variationId,listingActivity);
            sellingStatusType.setQuantitySold(getSoldVariationQuantity(variationInfo));
        } else {
            sellingStatusType.setQuantitySold(getSoldQuantity());
        }
        return sellingStatusType;
    }

    private static ListingActivity getListingActivity(LineItemSource sourceId, Map<Long, ListingActivity> itemIdListingActivityMap) {
        Long itemId = Optional.ofNullable(sourceId).map(LineItemSource::getItemId).map(Long::parseLong).orElse(null);
        return itemIdListingActivityMap.get(itemId);
    }

    private static Item getItem(LineItemSource sourceId, Map<String, Item> svlsItemInfoMap) {
        String itemId = Optional.ofNullable(sourceId).map(LineItemSource::getItemId).orElse(null);
        return svlsItemInfoMap.get(itemId);
    }

}