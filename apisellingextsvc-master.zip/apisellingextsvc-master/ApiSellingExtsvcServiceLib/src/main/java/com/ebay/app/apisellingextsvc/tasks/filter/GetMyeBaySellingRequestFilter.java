package com.ebay.app.apisellingextsvc.tasks.filter;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.content.IContentManager;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import com.ebay.app.apisellingextsvc.framework.outputselector.OutputSelectorGenerator;
import com.ebay.app.apisellingextsvc.handlers.ExceptionHandler;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.ConfigurableUtils;
import com.ebay.app.apisellingextsvc.utils.GMESSortValidationUtil;
import com.google.common.collect.ImmutableSet;
import ebay.apis.eblbasecomponents.GetMyeBaySellingRequestType;
import ebay.apis.eblbasecomponents.GetMyeBaySellingResponseType;
import ebay.apis.eblbasecomponents.ItemListCustomizationType;
import ebay.apis.eblbasecomponents.PaginationType;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.MAX_TOTAL_ENTRIES;

public class GetMyeBaySellingRequestFilter implements IFilter {

    private static final ImmutableSet<String> INVALID_LISTING_TYPE_LISTS = ImmutableSet.<String>builder()
            .add(ApiSellingExtSvcConstants.DELETED_FROM_SOLD_LIST_NAME, ApiSellingExtSvcConstants.DELETED_FROM_UNSOLD_LIST_NAME, ApiSellingExtSvcConstants.SCHEDULED_LIST_NAME, ApiSellingExtSvcConstants.SELLING_SUMMARY_NAME, ApiSellingExtSvcConstants.SOLD_LIST_NAME, ApiSellingExtSvcConstants.UNSOLD_LIST_NAME).build();
    private static final ImmutableSet<String> INVALID_INCLUDE_NOTES_LISTS = ImmutableSet.<String>builder()
            .add(ApiSellingExtSvcConstants.SELLING_SUMMARY_NAME).build();
    private static final ImmutableSet<String> INVALID_PAGINATION_LISTS = ImmutableSet.<String>builder()
            .add(ApiSellingExtSvcConstants.SELLING_SUMMARY_NAME).build();
    private static final ImmutableSet<String> INVALID_SORT_LISTS = ImmutableSet.<String>builder()
            .add(ApiSellingExtSvcConstants.SELLING_SUMMARY_NAME).build();
    private static final ImmutableSet<String> INVALID_DURATION_IN_DAYS_LISTS = ImmutableSet.<String>builder()
            .add(ApiSellingExtSvcConstants.ACTIVE_LIST_NAME,  ApiSellingExtSvcConstants.SCHEDULED_LIST_NAME, ApiSellingExtSvcConstants.SCHEDULED_LIST_NAME).build();
    private static final ImmutableSet<String> INVALID_ORDER_STATUS_FILTER_LISTS = ImmutableSet.<String>builder()
            .add(ApiSellingExtSvcConstants.ACTIVE_LIST_NAME, ApiSellingExtSvcConstants.DELETED_FROM_SOLD_LIST_NAME, ApiSellingExtSvcConstants.DELETED_FROM_UNSOLD_LIST_NAME, ApiSellingExtSvcConstants.SCHEDULED_LIST_NAME, ApiSellingExtSvcConstants.SELLING_SUMMARY_NAME, ApiSellingExtSvcConstants.UNSOLD_LIST_NAME).build();

    private final HashMap<String, ItemListCustomizationType> nameToContainer;
    private final ContentResource contentResource;
    private final GetMyeBaySellingRequestType request;
    private final ApiSellingExtSvcConfigValues configValues;

    public GetMyeBaySellingRequestFilter(
            ApiSellingExtSvcConfigValues configValues,
            GetMyeBaySellingRequestType request,
            ContentResource contentResource) {
        this.contentResource = contentResource;
        this.request = request;
        this.configValues = configValues;
        nameToContainer = new HashMap<>();
        request.setActiveList(addContainerIfIncluded(request.getActiveList(), ApiSellingExtSvcConstants.ACTIVE_LIST_NAME));
        request.setDeletedFromSoldList(addContainerIfIncluded(request.getDeletedFromSoldList(), ApiSellingExtSvcConstants.DELETED_FROM_SOLD_LIST_NAME));
        request.setDeletedFromUnsoldList(addContainerIfIncluded(request.getDeletedFromUnsoldList(), ApiSellingExtSvcConstants.DELETED_FROM_UNSOLD_LIST_NAME));
        request.setScheduledList(addContainerIfIncluded(request.getScheduledList(), ApiSellingExtSvcConstants.SCHEDULED_LIST_NAME));
        request.setSellingSummary(addContainerIfIncluded(request.getSellingSummary(), ApiSellingExtSvcConstants.SELLING_SUMMARY_NAME));
        request.setSoldList(addContainerIfIncluded(request.getSoldList(), ApiSellingExtSvcConstants.SOLD_LIST_NAME));
        request.setUnsoldList(addContainerIfIncluded(request.getUnsoldList(), ApiSellingExtSvcConstants.UNSOLD_LIST_NAME));
    }

    private ItemListCustomizationType addContainerIfIncluded(ItemListCustomizationType container, String containerName) {
        if (container == null && CommonUtil.shouldExposeOnlyForReturnAll(request.getDetailLevel())) {
            container = new ItemListCustomizationType();
        }
        if (container != null && CommonUtil.isRequiredContainer(container, request.getDetailLevel())) {
            nameToContainer.put(containerName, container);
        }
        return container;
    }

    @Override
    public void doFilter() {
        IContentManager errorContentManager = contentResource.contentHelper.getErrorContentManager();
        doUnSupportedFieldsFiltering(errorContentManager);
        doPaginationFiltering(errorContentManager);
        doDurationInDaysFiltering(errorContentManager);
        doSortFiltering(errorContentManager);
        doOutputSelectorFiltering(errorContentManager);
        setDefaultFields();
        checkTotalEntriesOverflow();
    }

    private void checkFieldValid(IContentManager errorContentManager) {
        String outputSelector[] = request.getOutputSelector().toArray(new String[0]);

        ArrayList parsedOS = ConfigurableUtils.parseOutputSelectors(outputSelector);
        Map errorsList = ConfigurableUtils.validate(OutputSelectorGenerator.getGraphMap(parsedOS, GetMyeBaySellingResponseType.class).getMap(), parsedOS);

        if (!CollectionUtils.isEmpty(errorsList) && !CollectionUtils.isEmpty(errorsList.values())) {
            String[] valuesArray = (String[]) errorsList.values().toArray(new String[0]);
            CalLogger.error("Request Filter Error", "One or more of the output selectors is incorrect." + errorsList.values().toString());
            ExceptionHandler.throwException(ApplicationError.OUTPUT_SELECTOR_INVALID, errorContentManager, Collections.EMPTY_LIST, valuesArray);
        }
    }

    private void doOutputSelectorFiltering(IContentManager errorContentManager) {
        if(CollectionUtils.isEmpty(request.getOutputSelector())) {
            return;
        }
        checkFieldValid(errorContentManager);
    }

    private void doSortFiltering(IContentManager errorContentManager) {
        for (String containerName : nameToContainer.keySet()) {
            if (!GMESSortValidationUtil.isValidSort(containerName, nameToContainer.get(containerName).getSort())) {
                CalLogger.error("Request Filter Error", "Invalid sort used in " + containerName);
                ExceptionHandler.throwException(ApplicationError.INVALID_SORT, errorContentManager, containerName, containerName);
            }
        }
    }

    private void doDurationInDaysFiltering(IContentManager errorContentManager) {
        for (String containerName : nameToContainer.keySet()) {
            Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::getDurationInDays).ifPresent(durationInDays -> {
                if (durationInDays < ApiSellingExtSvcConstants.MINIMUM_DURATION_IN_DAYS || durationInDays > ApiSellingExtSvcConstants.MAXIMUM_DURATION_IN_DAYS) {
                    CalLogger.error("Request Filter Error", "DurationInDays out of range for " + containerName);
                    ExceptionHandler.throwException(ApplicationError.DURATION_IN_DAYS_OUT_OF_RANGE, errorContentManager,
                            Arrays.asList(containerName, String.valueOf(ApiSellingExtSvcConstants.MINIMUM_DURATION_IN_DAYS), String.valueOf(ApiSellingExtSvcConstants.MAXIMUM_DURATION_IN_DAYS)),
                            containerName, String.valueOf(ApiSellingExtSvcConstants.MINIMUM_DURATION_IN_DAYS), String.valueOf(ApiSellingExtSvcConstants.MAXIMUM_DURATION_IN_DAYS));
                }
            });
        }
    }

    private void doPaginationFiltering(IContentManager errorContentManager) {
        for (String containerName : nameToContainer.keySet()) {
            Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::getPagination).ifPresent(paginationType -> {
                if (paginationType.getEntriesPerPage() != null) {
                    if (paginationType.getEntriesPerPage() < ApiSellingExtSvcConstants.MINIMUM_ENTRIES_PER_PAGE || paginationType.getEntriesPerPage() > ApiSellingExtSvcConstants.MAXIMUM_ENTRIES_PER_PAGE) {
                        CalLogger.error("Request Filter Error", "EntriesPerPage out of range for " + containerName);
                        ExceptionHandler.throwException(ApplicationError.ENTRIES_PER_PAGE_OUT_OF_RANGE, errorContentManager,
                                Arrays.asList(containerName, String.valueOf(ApiSellingExtSvcConstants.MINIMUM_ENTRIES_PER_PAGE), String.valueOf(ApiSellingExtSvcConstants.MAXIMUM_ENTRIES_PER_PAGE)),
                                containerName, String.valueOf(ApiSellingExtSvcConstants.MINIMUM_ENTRIES_PER_PAGE), String.valueOf(ApiSellingExtSvcConstants.MAXIMUM_ENTRIES_PER_PAGE));
                    }
                }
                if (paginationType.getPageNumber() != null) {
                    if (paginationType.getPageNumber() < ApiSellingExtSvcConstants.MINIMUM_PAGE_NUMBER) {
                        CalLogger.error("Request Filter Error", "PageNumber out of range for " + containerName);
                        ExceptionHandler.throwException(ApplicationError.PAGE_NUMBER_OUT_OF_RANGE, errorContentManager, containerName, containerName);
                    }
                }
            });
        }
    }

    private void checkTotalEntriesOverflow() {
        for (String containerName : nameToContainer.keySet()) {
            Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::getPagination).ifPresent(paginationType -> {
                int entriesPerPage = paginationType.getEntriesPerPage();
                int pageNumber = paginationType.getPageNumber();
                int lastPageNumber = (int) Math.ceil((double) MAX_TOTAL_ENTRIES / entriesPerPage);
                int lastEntriesPerPage = MAX_TOTAL_ENTRIES - entriesPerPage * (lastPageNumber - 1);
                try {
                    if(Math.multiplyExact(entriesPerPage, pageNumber) > MAX_TOTAL_ENTRIES){
                        paginationType.setPageNumber(lastPageNumber);
                        paginationType.setEntriesPerPage(lastEntriesPerPage);
                    }
                }catch(ArithmeticException e) {
                    paginationType.setPageNumber(lastPageNumber);
                    paginationType.setEntriesPerPage(lastEntriesPerPage);
                }
            });
        }
    }
    private void doUnSupportedFieldsFiltering(IContentManager errorContentManager) {
        for (String containerName : INVALID_LISTING_TYPE_LISTS) {
            if (Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::getListingType).isPresent()) {
                CalLogger.error("Request Filter Error", "ListingType invalid for " + containerName);
                ExceptionHandler.throwException(ApplicationError.UNSUPPORTED_FIELD, errorContentManager, Arrays.asList("ListingType", containerName), containerName);
            }
        }

        for (String containerName : INVALID_INCLUDE_NOTES_LISTS) {
            if (Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::isIncludeNotes).isPresent()) {
                CalLogger.error("Request Filter Error", "IncludeNotes invalid for " + containerName);
                ExceptionHandler.throwException(ApplicationError.UNSUPPORTED_FIELD, errorContentManager, Arrays.asList("IncludeNotes", containerName), containerName);
            }
        }

        for (String containerName : INVALID_PAGINATION_LISTS) {
            if (Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::getPagination).isPresent()) {
                CalLogger.error("Request Filter Error", "Pagination invalid for " + containerName);
                ExceptionHandler.throwException(ApplicationError.UNSUPPORTED_FIELD, errorContentManager, Arrays.asList("Pagination", containerName), containerName);
            }
        }

        for (String containerName : INVALID_SORT_LISTS) {
            if (Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::getSort).isPresent()) {
                CalLogger.error("Request Filter Error", "Sort invalid for " + containerName);
                ExceptionHandler.throwException(ApplicationError.UNSUPPORTED_FIELD, errorContentManager, Arrays.asList("Sort", containerName), containerName);
            }
        }

        for (String containerName : INVALID_DURATION_IN_DAYS_LISTS) {
            if (Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::getDurationInDays).isPresent()) {
                CalLogger.error("Request Filter Error", "DurationInDays invalid for " + containerName);
                ExceptionHandler.throwException(ApplicationError.UNSUPPORTED_FIELD, errorContentManager, Arrays.asList("DurationInDays", containerName), containerName);
            }
        }

        for (String containerName : INVALID_ORDER_STATUS_FILTER_LISTS) {
            if (Optional.ofNullable(nameToContainer.get(containerName)).map(ItemListCustomizationType::getOrderStatusFilter).isPresent()) {
                CalLogger.error("Request Filter Error", "OrderStatusFilter invalid for " + containerName);
                ExceptionHandler.throwException(ApplicationError.UNSUPPORTED_FIELD, errorContentManager, Arrays.asList("OrderStatusFilter", containerName), containerName);
            }
        }
    }

    private void setDefaultFields() {
        for (String containerName : nameToContainer.keySet()) {
            ItemListCustomizationType container = nameToContainer.get(containerName);
            if (containerName.equals(ApiSellingExtSvcConstants.SELLING_SUMMARY_NAME)) {
                continue;
            }

            //Pagination
            if (container.getPagination() == null) {
                container.setPagination(new PaginationType());
            }

            //EntriesPerPage
            if (container.getPagination().getEntriesPerPage() == null) {
                container.getPagination().setEntriesPerPage(ApiSellingExtSvcConstants.GMES_DEFAULT_ENTRIES_PER_PAGE);
            }

            //PageNumber
            if (container.getPagination().getPageNumber() == null) {
                container.getPagination().setPageNumber(ApiSellingExtSvcConstants.MINIMUM_PAGE_NUMBER);
            }

            //IncludeNotes
            if (container.isIncludeNotes() == null) {
                container.setIncludeNotes(ApiSellingExtSvcConstants.DEFAULT_INCLUDE_NOTES);
            }
        }

        //HideVariations
        if (request.isHideVariations() == null) {
            request.setHideVariations(ApiSellingExtSvcConstants.DEFAULT_HIDE_VARIATIONS);
        }
    }
}
