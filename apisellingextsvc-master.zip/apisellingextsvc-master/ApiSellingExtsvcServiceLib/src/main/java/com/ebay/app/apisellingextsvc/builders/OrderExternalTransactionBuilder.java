package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.mappers.AdjustmentPaymentStatusMapper;
import com.ebay.app.apisellingextsvc.utils.*;
import com.ebay.cos.type.v3.base.CurrencyCodeEnum;
import com.ebay.cosmos.AdjustmentTypeCS;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.ExternalTransactionType;
import org.apache.commons.collections.CollectionUtils;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


public class OrderExternalTransactionBuilder extends BaseFacetBuilder<List<ExternalTransactionType>> {

    private final OrderCSXType order;

    private final List<DetailLevelCodeType> detailLevels;

    private final int trxVersion;

    public OrderExternalTransactionBuilder(Task<?> task, OrderCSXType order,
                                           List<DetailLevelCodeType> detailLevels, int trxVersion) {
        super(task);
        this.order = order;
        this.detailLevels = detailLevels;
        this.trxVersion = trxVersion;
    }

    @Override
    protected List<ExternalTransactionType> doBuild() {

        if (CommonUtil.shouldExposeOnlyForReturnAll(detailLevels)) {
            List<ExternalTransactionType> typeList = new ArrayList<>();
            typeList.add(buildExternalTransactionType());
            List<ExternalTransactionType> refundTransactions = buildRefundExternalTransactions();
            if (refundTransactions != null) {
                typeList.addAll(refundTransactions);
            }
            return typeList;
        }

        return new ArrayList<>();
    }

    private ExternalTransactionType buildExternalTransactionType() {
        ExternalTransactionType type = new ExternalTransactionType();
        type.setExternalTransactionID(getExternalTransactionId());
        XMLGregorianCalendar paymentTime = PaymentUtil.getPaymentTime(order);
        if (paymentTime != null) {
            paymentTime.setMillisecond(0);
            type.setExternalTransactionTime(paymentTime);
        }
        type.setFeeOrCreditAmount(PaymentUtil.getFeeOrCreditAmount(order));

        //https://jirap.corp.ebay.com/browse/TRXAPI-2032
        if (trxVersion >= ApiSellingExtSvcConstants.COMPATIBILITY_LEVEL_827) {
            type.setExternalTransactionStatus(PaymentUtil.getPaymentStatus(order));
        }

        type.setPaymentOrRefundAmount(getPaymentOrRefundAmount());
        return type;
    }

    private AmountType getPaymentOrRefundAmount() {
        if (PaymentUtil.hasEbayCollectedTax(order.getAttributes())) {
            if (AttributeUtil.isTaxIncludeInSellerDistribution(order.getAttributes())) {
                return PaymentUtil.getOrderTotal(order).map(AmountTypeUtil::getAmountType).orElse(null);
            } else {
                return getSellerPaymentAmount();
            }
        } else {
            return PaymentUtil.getOrderTotal(order).map(AmountTypeUtil::getAmountType).orElse(null);
        }

    }

    private List<ExternalTransactionType> buildRefundExternalTransactions() {
        List<ExternalTransactionType> res = null;

        if (order != null && CollectionUtils.isNotEmpty(order.getAdjustmentsCS())) {
            for (AdjustmentTypeCS adjustment : order.getAdjustmentsCS()) {
                if (adjustment != null && AdjustmentTypeEnumType.REFUND.equals(adjustment.getAdjustmentType())
                        && adjustment.getTypeExtension() != null
                        && adjustment.getTypeExtension().getPaymentAdjustment() != null
                        && CollectionUtils.isNotEmpty(adjustment.getTypeExtension().getPaymentAdjustment().getCollection())) {
                    DateTime adjTime = adjustment.getAdjustmentDate();
                    AdjustmentStatusType adjStatus = adjustment.getStatus();
                    for (CollectionType collection : adjustment.getTypeExtension().getPaymentAdjustment().getCollection()) {
                        if (collection != null && ApiSellingExtSvcConstants.COLLECTION_TYPE_SELLER.equals(collection.getType())) {
                            if (res == null) {
                                res = new ArrayList<>();
                            }
                            res.add(buildRefundExternalTransactionType(collection, adjTime, adjStatus));
                        }
                    }
                }
            }
        }

        return res;
    }

    private ExternalTransactionType buildRefundExternalTransactionType(CollectionType collection, DateTime adjTime, AdjustmentStatusType adjStatus) {
        ExternalTransactionType res = new ExternalTransactionType();
        if (adjTime != null) {
            res.setExternalTransactionTime(DateUtil.convertToXMLGregorianCalendar(adjTime));
        }
        if (adjStatus != null && trxVersion >= ApiSellingExtSvcConstants.COMPATIBILITY_LEVEL_827) {
            res.setExternalTransactionStatus(AdjustmentPaymentStatusMapper.map(adjStatus));
        }
        if (collection != null && collection.getTotalAmount() != null
                && collection.getTotalAmount().getAmount() != null) {
            AmountType absRefundAmount = AmountTypeUtil.getAmountType(collection.getTotalAmount().getAmount());
            res.setPaymentOrRefundAmount(AmountTypeUtil.negate(absRefundAmount));
        }
        return res;
    }

    private AmountType getSellerPaymentAmount() {
        Optional<Amount> orderTotalAmount = PaymentUtil.getOrderTotal(order);
        CurrencyCodeEnum currency = orderTotalAmount.map(Amount::getCurrency).orElse(null);
        BigDecimal orderTotal = orderTotalAmount.map(Amount::getValue).map(BigDecimal::new).orElse(null);
        if (orderTotal != null && AttributeUtil.isTaxExcludeInSellerDistribution(order.getAttributes())) {
            Optional<BigDecimal> taxAmount = PaymentUtil.getTaxAmount(order.getPayments());
            if (taxAmount.isPresent()) {
                orderTotal = orderTotal.subtract(taxAmount.get()).setScale(ApiSellingExtSvcConstants.SCALE_OF_DECIMAL, RoundingMode.HALF_UP);
            }
        }
        if (currency != null && orderTotal != null) {
            return AmountTypeUtil.getAmountType(currency.name(), orderTotal.doubleValue());
        } else {
            return null;
        }
    }

    private String getExternalTransactionId() {
        return PaymentUtil.getFirstPaymentOrderTransactions(order).map(
                PaymentOrderTransaction::getPaymentProviderTransactionId).orElse(null);
    }
}
