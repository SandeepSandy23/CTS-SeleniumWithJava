package com.ebay.app.apisellingextsvc.audit.comparator.facet;

import com.ebay.app.apisellingextsvc.audit.comparator.IJsonNodeComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.api.GetSellerTransactionsComparator;
import com.fasterxml.jackson.databind.JsonNode;
import com.ebay.app.apisellingextsvc.audit.report.IReport;


import java.util.Objects;

public class StateOrProvinceComparator implements IJsonNodeComparator {

    public static final String DOT = ".";
    public static final String EMPTY = "";
    private final GetSellerTransactionsComparator
            comparator;

    public StateOrProvinceComparator(GetSellerTransactionsComparator comparator) {
        this.comparator = comparator;
    }

    @Override
    public boolean customCompareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        if (Objects.equals(org, tar)) {
            return true;
        }
        if (!pattern.isTextual()) {
            return comparator.defaultCompareNode(org, tar, pattern, path, key, report);
        }

        boolean result = Objects.equals(normalize(org), normalize(tar));
        if (!result) {
            comparator.printDiff(key, path, String.valueOf(org), String.valueOf(tar), result, report);
        }
        return result;
    }

    private String normalize(JsonNode org) {
        return org.textValue().replace(DOT, EMPTY).toLowerCase();
    }


}
