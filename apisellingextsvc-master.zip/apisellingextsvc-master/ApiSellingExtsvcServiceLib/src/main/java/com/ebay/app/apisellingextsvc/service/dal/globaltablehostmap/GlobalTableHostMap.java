package com.ebay.app.apisellingextsvc.service.dal.globaltablehostmap;

import com.ebay.persistence.Column;
import com.ebay.persistence.SecondaryTable;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@SecondaryTable(name = "UHS_LOGICAL_HOST", alias = "uhs")
@Table(name = "GLOBAL_TABLE_HOST_MAP")
public interface GlobalTableHostMap {

    @Column(name = "PHYSICAL_TABLE_NAME")
    String getPhysicalTableName();

    void setPhysicalTableName(String var1);

    @Column(name = "LOGICAL_HOST_ID")
    int getLogicalHostId();

    void setLogicalHostId(int var1);

    @Column(name = "LOGICAL_HOST_NAME", table = "UHS_LOGICAL_HOST")
    String getLogicalHostName();

    void setLogicalHostName(String var1);

    @Column(name = "MIN_HOST_NUM", table = "UHS_LOGICAL_HOST")
    short getMinHostNum();

    void setMinHostNum(short var1);

    @Column(name = "MAX_HOST_NUM", table = "UHS_LOGICAL_HOST")
    short getMaxHostNum();

    void setMaxHostNum(short var1);
}
