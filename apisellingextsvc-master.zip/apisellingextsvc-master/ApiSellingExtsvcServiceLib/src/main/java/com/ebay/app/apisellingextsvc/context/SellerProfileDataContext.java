
package com.ebay.app.apisellingextsvc.context;

import com.ebay.app.apisellingextsvc.service.bof.exchangerate.ExchangeRateBofImpl;
import com.ebay.app.apisellingextsvc.service.bof.exchangerate.IExchangeRateBof;
import com.ebay.app.apisellingextsvc.service.bof.shippingcarrier.IShippingCarrierBof;
import com.ebay.app.apisellingextsvc.service.bof.shippingcarrier.ShippingCarrierBofImpl;
import com.ebay.app.apisellingextsvc.service.bof.shippingservice.IShippingServiceBof;
import com.ebay.app.apisellingextsvc.service.bof.shippingservice.ShippingServiceBofImpl;
import com.ebay.app.apisellingextsvc.service.bof.taxrate.ITaxRateBof;
import com.ebay.app.apisellingextsvc.service.bof.taxrate.TaxRateBofImpl;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscount.SellerDiscountEntity;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign.SellerDiscountCampaign;
import com.ebay.tide.app.addressbook.AccountAddress;

import java.util.Map;

public class SellerProfileDataContext {

    private boolean isSellerRequirePhoneNumber;
    private Map<String, Boolean> userAddressIdShowPhoneMap;
    private Map<String, SellerDiscountEntity> sellerDiscountMap;
    private Map<Long, SellerDiscountCampaign> sellerDiscountCampaignMap;
    private ITaxRateBof taxRateBof;
    private IShippingServiceBof shippingServiceBof;
    private IExchangeRateBof exchangeRateBof;
    private IShippingCarrierBof shippingCarrierBof;
    private Map<String, AccountAddress> commitmentAddresses;
    private Map<Long, String> sellerProdMap;
    private SiteContext siteContext;

    public SellerProfileDataContext(TaxRateBofImpl taxRateBof,
                                    ShippingServiceBofImpl shippingServiceBof,
                                    ShippingCarrierBofImpl shippingCarrierBof,
                                    ExchangeRateBofImpl exchangeRateBof) {
        this.taxRateBof = taxRateBof;
        this.shippingServiceBof = shippingServiceBof;
        this.shippingCarrierBof = shippingCarrierBof;
        this.exchangeRateBof = exchangeRateBof;
    }

    public SellerProfileDataContext() {}

    public boolean isSellerRequirePhoneNumber() {
        return this.isSellerRequirePhoneNumber;
    }

    public void setSellerRequirePhoneNumber(boolean isSellerRequirePhoneNumber) {
        this.isSellerRequirePhoneNumber = isSellerRequirePhoneNumber;
    }

    public Map<String, SellerDiscountEntity> getSellerDiscountMap() {
        return sellerDiscountMap;
    }

    public void setSellerDiscountMap(Map<String, SellerDiscountEntity> sellerDiscountMap) {
        this.sellerDiscountMap = sellerDiscountMap;
    }

    public Map<Long, SellerDiscountCampaign> getSellerDiscountCampaignMap() {
        return sellerDiscountCampaignMap;
    }

    public void setSellerDiscountCampaignMap(Map<Long, SellerDiscountCampaign> sellerDiscountCampaignMap) {
        this.sellerDiscountCampaignMap = sellerDiscountCampaignMap;
    }

    public ITaxRateBof getTaxRateBof() {
        return taxRateBof;
    }

    public void setTaxRateBof(ITaxRateBof taxRateBof) {
        this.taxRateBof = taxRateBof;
    }

    public IShippingServiceBof getShippingServiceBof() {
        return shippingServiceBof;
    }

    public void setShippingServiceBof(IShippingServiceBof shippingServiceBof) {
        this.shippingServiceBof = shippingServiceBof;
    }

    public IExchangeRateBof getExchangeRateBof() {
        return exchangeRateBof;
    }

    public void setExchangeRateBof(IExchangeRateBof exchangeRateBof) {
        this.exchangeRateBof = exchangeRateBof;
    }

    public IShippingCarrierBof getShippingCarrierBof() {
        return shippingCarrierBof;
    }

    public void setShippingCarrierBof(IShippingCarrierBof shippingCarrierBof) {
        this.shippingCarrierBof = shippingCarrierBof;
    }

    public Map<Long, String> getSellerProdMap() {
        return sellerProdMap;
    }

    public void setSellerProdMap(Map<Long, String> sellerProdMap) {
        this.sellerProdMap = sellerProdMap;
    }

    public Map<String, AccountAddress> getCommitmentAddresses() {
        return commitmentAddresses;
    }

    public void setCommitmentAddresses(Map<String, AccountAddress> commitmentAddresses) {
        this.commitmentAddresses = commitmentAddresses;
    }

    public Map<String, Boolean> getUserAddressIdShowPhoneMap() {
        return userAddressIdShowPhoneMap;
    }

    public void setUserAddressIdShowPhoneMap(Map<String, Boolean> userAddressIdShowPhoneMap) {
        this.userAddressIdShowPhoneMap = userAddressIdShowPhoneMap;
    }

    public void setSiteContext(SiteContext siteContext) {
        this.siteContext = siteContext;
    }

    public SiteContext getSiteContext() {
        return this.siteContext;
    }
}