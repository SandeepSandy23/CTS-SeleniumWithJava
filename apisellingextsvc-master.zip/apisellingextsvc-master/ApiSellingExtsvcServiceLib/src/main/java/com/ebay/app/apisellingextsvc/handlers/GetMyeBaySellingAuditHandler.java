package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import com.ebay.app.apisellingextsvc.application.common.response.GetMyeBaySellingResponse;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.enums.APITypeEnum;
import com.ebay.app.apisellingextsvc.service.invokers.ESServiceInvoker;
import com.ebay.app.apisellingextsvc.tasks.audit.GetMyeBaySellingAuditTask;
import com.ebay.app.apisellingextsvc.utils.AuditUtil;
import com.ebay.app.apisellingextsvc.utils.TaskOrchestrationUtil;
import com.ebay.app.apisellingextsvc.utils.XmlUtil;

public final class GetMyeBaySellingAuditHandler extends ApiSellingExtAuditHandler<GetMyeBaySellingResponse> {

    private final GetMyeBaySellingRequest request;

    public GetMyeBaySellingAuditHandler(GetMyeBaySellingRequest request) {
        super(request);
        this.request = request;
        this.httpHeaders = createRequestHeader(request.headers);
        this.configValue = this.request.configValues;
    }

    @Override
    public void doAudit(GetMyeBaySellingResponse response) {
        // skip output selector audit, because it's done during serialization.
        if (apisellingioResponseFuture != null && response!=null) {

            String apisellingioXmlResponseString= (String) TaskOrchestrationUtil.safeGet(apisellingioResponseFuture);
            CalLogger.info("old response string : ", apisellingioXmlResponseString);

            String apisellingextsvcXmlResponseString= (String) XmlUtil.writeAsString(response);
            CalLogger.info("new response string: ", apisellingextsvcXmlResponseString);

            GetMyeBaySellingResponse apisellingextsvcXmlResponse = response;
            GetMyeBaySellingResponse apisellingioXmlResponse = XmlUtil.readResponseString(apisellingioXmlResponseString, GetMyeBaySellingResponse.class);

            if (isEmptyResponse(apisellingioXmlResponse) ||  isEmptyResponse(apisellingextsvcXmlResponse) || AuditUtil.shouldSkipAuditForGMES(apisellingioXmlResponse,response)) {
                CalLogger.info("GMES_Audit_skipped", "true");
                return;
            }
            //TODO  sort order.

            GetMyeBaySellingAuditTask auditTask = new GetMyeBaySellingAuditTask(response, apisellingioXmlResponse,
                      request.requestType,
                      new ESServiceInvoker(this.request.getTracerContext(),this.configValue), this.httpHeaders, configValue);

            request.orchestrator.execute(auditTask);
        }
    }

    private boolean isEmptyResponse(GetMyeBaySellingResponse getMyeBaySellingResponse) {
        return getMyeBaySellingResponse.getScheduledList() == null &&
                getMyeBaySellingResponse.getActiveList() == null &&
                getMyeBaySellingResponse.getUnsoldList() == null &&
                getMyeBaySellingResponse.getDeletedFromUnsoldList() == null &&
                getMyeBaySellingResponse.getSoldList() == null &&
                getMyeBaySellingResponse.getDeletedFromSoldList() == null &&
                getMyeBaySellingResponse.getSellingSummary() == null &&
                getMyeBaySellingResponse.getSummary() == null;
    }


    @Override
    protected String createRequestBody() {
        return XmlUtil.writeRequestAsString(request.requestType, APITypeEnum.GetMyeBaySelling);
    }

}
