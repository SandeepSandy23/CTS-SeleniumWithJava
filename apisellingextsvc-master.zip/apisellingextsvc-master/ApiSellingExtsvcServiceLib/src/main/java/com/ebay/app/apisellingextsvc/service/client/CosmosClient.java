package com.ebay.app.apisellingextsvc.service.client;


import com.ebay.app.apisellingextsvc.context.FindContractV2RequestContext;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.cosmos.ContractResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CosmosClient extends BaseGingerClient<FindContractV2RequestContext, ContractResponse> {

    private static final Logger logger = LoggerFactory.getLogger(CosmosClient.class);

    private static final String CLIENT_ID = "cosmos.findcontract";

    public CosmosClient() {
        super(ContractResponse.class);
    }

    @Override
    public GingerClientResponse<ContractResponse> getGingerResponse(GingerClientRequest<FindContractV2RequestContext> gingerRequest) {
        return processGetRequest(gingerRequest.getRequest().getParamString(), null, gingerRequest.getHeaders());
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
