package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.FieldMapping;
import com.ebay.integ.dal.map.FullFieldMapping;
import com.ebay.integ.dal.map.MappingIncludesAttribute;
import com.ebay.integ.dal.map.Query;
import com.ebay.integ.dal.map.ReadSet;
import com.ebay.integ.dal.map.ReadableMapping;
import com.ebay.integ.dal.map.SelectQuery;
import com.ebay.integ.dal.map.SelectStatement;
import com.ebay.integ.dal.map.TableDef;
import com.ebay.integ.dal.map.TableJoin;
import com.ebay.integ.dal.map.UpdateSet;
import com.ebay.integ.dal.map.UpdateableMapping;

public abstract class ShippingServiceCodeGenMap extends BaseMap2 {
    public static final String FINDALL = "FINDALL";
    private static TableDef m_shipping_serviceTable = new TableDef("shipping_service", "ships");
    public FullFieldMapping m_shippingServiceIdFm;
    public FullFieldMapping m_siteIdFm;
    public FullFieldMapping m_localizedNameFm;
    public FullFieldMapping m_serviceNameSuperscriptFm;
    public FullFieldMapping m_carrierIdFm;
    public FullFieldMapping m_descriptionFm;
    public FullFieldMapping m_genericFm;
    public FullFieldMapping m_displayOrderFlatRateFm;
    public FullFieldMapping m_domesticFm;
    public FullFieldMapping m_flatRateFm;
    public FullFieldMapping m_calculatedRateFm;
    public FullFieldMapping m_freightFm;
    public FullFieldMapping m_fastShippingFm;
    public FullFieldMapping m_localShippingFm;
    public FullFieldMapping m_codShippingFm;
    public FullFieldMapping m_bppShippingFm;
    public FullFieldMapping m_minDeliveryTimeFm;
    public FullFieldMapping m_maxDeliveryTimeFm;
    public FullFieldMapping m_maxWeightLimitFm;
    public FullFieldMapping m_maxWeightLimitUnitsFm;
    public FullFieldMapping m_enabledFm;
    public FullFieldMapping m_connShipServiceNameFm;
    public FullFieldMapping m_flagsFm;
    public FullFieldMapping m_trainIntroducedFm;
    public FullFieldMapping m_creationDateFm;
    public FullFieldMapping m_lastModifiedDateFm;
    public FullFieldMapping m_apiSoapServiceCodeFm;
    public FullFieldMapping m_carrierServiceCodeFm;
    public FullFieldMapping m_areDimReqdFm;
    public FullFieldMapping m_displayOrderCalcRateFm;
    public FullFieldMapping m_validPackageTypeListFm;
    public FullFieldMapping m_deprecateMsgStartDateFm;
    public FullFieldMapping m_deprecateEffectiveDateFm;
    public FullFieldMapping m_mappedToShippingServiceIdFm;
    public FullFieldMapping m_deprecateMsgTypeFm;
    public FullFieldMapping m_isWeightRequiredFm;
    public FullFieldMapping m_costCapGroupFm;
    public FullFieldMapping m_shippingServiceTokenFm;
    public FullFieldMapping m_sourceCountryFm;
    public FullFieldMapping m_verifyPhoneNumberFm;
    protected final MappingIncludesAttribute[] m_ourDDRHints;
    private FieldMapping[] m_builtFieldMappings;
    private FieldMapping[] m_ourFieldMappings;
    private ReadSet[] m_builtReadSets;
    private UpdateSet[] m_builtUpdateSets;

    protected ShippingServiceCodeGenMap() {
        this.m_shippingServiceIdFm = new FullFieldMapping("m_shippingServiceId", 0,
                m_shipping_serviceTable, "SHIPPING_SERVICE_ID");
        this.m_siteIdFm = new FullFieldMapping("m_siteId", 1,
                m_shipping_serviceTable, "SITE_ID");
        this.m_localizedNameFm = new FullFieldMapping("m_localizedName", 2,
                m_shipping_serviceTable, "LOCALIZED_NAME");
        this.m_serviceNameSuperscriptFm = new FullFieldMapping("m_serviceNameSuperscript", 3,
                m_shipping_serviceTable, "SERVICE_NAME_SUPERSCRIPT");
        this.m_carrierIdFm = new FullFieldMapping("m_carrierId", 4,
                m_shipping_serviceTable, "CARRIER_ID");
        this.m_descriptionFm = new FullFieldMapping("m_description", 5,
                m_shipping_serviceTable, "DESCRIPTION");
        this.m_genericFm = new FullFieldMapping("m_generic", 6,
                m_shipping_serviceTable, "GENERIC_TYPE");
        this.m_displayOrderFlatRateFm = new FullFieldMapping("m_displayOrderFlatRate", 7,
                m_shipping_serviceTable, "DISPLAY_ORDER_FLAT_RATE");
        this.m_domesticFm = new FullFieldMapping("m_domestic", 8,
                m_shipping_serviceTable, "IS_DOMESTIC");
        this.m_flatRateFm = new FullFieldMapping("m_flatRate", 9,
                m_shipping_serviceTable, "IS_RATE_FLAT");
        this.m_calculatedRateFm = new FullFieldMapping("m_calculatedRate", 10,
                m_shipping_serviceTable, "IS_RATE_CALCULATED");
        this.m_freightFm = new FullFieldMapping("m_freight", 11,
                m_shipping_serviceTable, "IS_FREIGHT");
        this.m_fastShippingFm = new FullFieldMapping("m_fastShipping", 12,
                m_shipping_serviceTable, "IS_FAST_SHIPPING");
        this.m_localShippingFm = new FullFieldMapping("m_localShipping", 13,
                m_shipping_serviceTable, "IS_LOCAL_SHIPPING");
        this.m_codShippingFm = new FullFieldMapping("m_codShipping", 14,
                m_shipping_serviceTable, "IS_COD_SHIPPING");
        this.m_bppShippingFm = new FullFieldMapping("m_bppShipping", 15,
                m_shipping_serviceTable, "IS_BPP_SHIPPING");
        this.m_minDeliveryTimeFm = new FullFieldMapping("m_minDeliveryTime", 16,
                m_shipping_serviceTable, "MIN_DELIVERY_TIME_HOURS");
        this.m_maxDeliveryTimeFm = new FullFieldMapping("m_maxDeliveryTime", 17,
                m_shipping_serviceTable, "MAX_DELIVERY_TIME_HOURS");
        this.m_maxWeightLimitFm = new FullFieldMapping("m_maxWeightLimit", 18,
                m_shipping_serviceTable, "MAX_WEIGHT_LIMIT");
        this.m_maxWeightLimitUnitsFm = new FullFieldMapping("m_maxWeightLimitUnits", 19,
                m_shipping_serviceTable, "MAX_WEIGHT_LIMIT_UNITS");
        this.m_enabledFm = new FullFieldMapping("m_enabled", 20,
                m_shipping_serviceTable, "IS_ENABLED");
        this.m_connShipServiceNameFm = new FullFieldMapping("m_connShipServiceName", 21,
                m_shipping_serviceTable, "CONN_SHIP_SERVICE_NAME");
        this.m_flagsFm = new FullFieldMapping("m_flags", 22,
                m_shipping_serviceTable, "flags");
        this.m_trainIntroducedFm = new FullFieldMapping("m_trainIntroduced", 23,
                m_shipping_serviceTable, "TRAIN_INTRODUCED");
        this.m_creationDateFm = new FullFieldMapping("m_creationDate", 24,
                m_shipping_serviceTable, "CREATION_DATE");
        this.m_lastModifiedDateFm = new FullFieldMapping("m_lastModifiedDate", 25,
                m_shipping_serviceTable, "LAST_MODIFIED_DATE");
        this.m_apiSoapServiceCodeFm = new FullFieldMapping("m_apiSoapServiceCode", 26,
                m_shipping_serviceTable, "EBAY_API_SOAP_SERVICE_CODE");
        this.m_carrierServiceCodeFm = new FullFieldMapping("m_carrierServiceCode", 27,
                m_shipping_serviceTable, "CARRIER_SERVICE_CODE");
        this.m_areDimReqdFm = new FullFieldMapping("m_areDimReqd", 28,
                m_shipping_serviceTable, "ARE_DIMENSIONS_REQUIRED");
        this.m_displayOrderCalcRateFm = new FullFieldMapping("m_displayOrderCalcRate", 29,
                m_shipping_serviceTable, "DISPLAY_ORDER_CALC_RATE");
        this.m_validPackageTypeListFm = new FullFieldMapping("m_validPackageTypeList", 30,
                m_shipping_serviceTable, "VALID_PACKAGE_TYPE_LIST");
        this.m_deprecateMsgStartDateFm = new FullFieldMapping("m_deprecateMsgStartDate", 31,
                m_shipping_serviceTable, "DEPRECATE_MSG_START_DATE");
        this.m_deprecateEffectiveDateFm = new FullFieldMapping("m_deprecateEffectiveDate", 32,
                m_shipping_serviceTable, "DEPRECATE_EFFECTIVE_DATE");
        this.m_mappedToShippingServiceIdFm = new FullFieldMapping("m_mappedToShippingServiceId", 33,
                m_shipping_serviceTable, "MAPPED_TO_SHIPPING_SERVICE_ID");
        this.m_deprecateMsgTypeFm = new FullFieldMapping("m_deprecateMsgType", 34,
                m_shipping_serviceTable, "DEPRECATE_MSG_TYPE");
        this.m_isWeightRequiredFm = new FullFieldMapping("m_isWeightRequired", 35,
                m_shipping_serviceTable, "IS_WEIGHT_REQUIRED");
        this.m_costCapGroupFm = new FullFieldMapping("m_costCapGroup", 36,
                m_shipping_serviceTable, "COST_CAP_GROUP");
        this.m_shippingServiceTokenFm = new FullFieldMapping("m_shippingServiceToken", 37,
                m_shipping_serviceTable, "SHIPPING_SERVICE_TOKEN");
        this.m_sourceCountryFm = new FullFieldMapping("m_sourceCountry", 38,
                m_shipping_serviceTable, "SOURCE_COUNTRY");
        this.m_verifyPhoneNumberFm = new FullFieldMapping("m_verifyPhoneNumber", 39,
                m_shipping_serviceTable, "VERIFY_PHONE_NUMBER");
        this.m_ourDDRHints = new MappingIncludesAttribute[0];
        this.m_builtFieldMappings = null;
        this.m_ourFieldMappings = null;
        this.m_builtReadSets = null;
        this.m_builtUpdateSets = null;
    }

    protected Class getDOClassToMap() {
        return ShippingServiceDoImpl.class;
    }

    public MappingIncludesAttribute[] getOurDDRHints() {
        return this.m_ourDDRHints;
    }

    protected TableDef[] getTableDefs() {
        TableDef[] tableDefs = new TableDef[]{m_shipping_serviceTable};
        return tableDefs;
    }

    protected TableJoin[] getTableJoins() {
        TableJoin[] tableJoins = new TableJoin[0];
        return tableJoins;
    }

    protected void initFieldMappings() {
        super.initFieldMappings();
    }

    protected FieldMapping[] getFieldMappings() {
        if (this.m_builtFieldMappings == null) {
            this.m_ourFieldMappings = new FieldMapping[]{this.m_shippingServiceIdFm, this.m_siteIdFm,
                    this.m_localizedNameFm, this.m_serviceNameSuperscriptFm, this.m_carrierIdFm,
                    this.m_descriptionFm, this.m_genericFm, this.m_displayOrderFlatRateFm, this.m_domesticFm,
                    this.m_flatRateFm, this.m_calculatedRateFm, this.m_freightFm, this.m_fastShippingFm,
                    this.m_localShippingFm, this.m_codShippingFm, this.m_bppShippingFm, this.m_minDeliveryTimeFm,
                    this.m_maxDeliveryTimeFm, this.m_maxWeightLimitFm, this.m_maxWeightLimitUnitsFm,
                    this.m_enabledFm, this.m_connShipServiceNameFm, this.m_flagsFm, this.m_trainIntroducedFm,
                    this.m_creationDateFm, this.m_lastModifiedDateFm, this.m_apiSoapServiceCodeFm, this.m_carrierServiceCodeFm,
                    this.m_areDimReqdFm, this.m_displayOrderCalcRateFm, this.m_validPackageTypeListFm, this.m_deprecateMsgStartDateFm,
                    this.m_deprecateEffectiveDateFm, this.m_mappedToShippingServiceIdFm, this.m_deprecateMsgTypeFm,
                    this.m_isWeightRequiredFm, this.m_costCapGroupFm, this.m_shippingServiceTokenFm, this.m_sourceCountryFm,
                    this.m_verifyPhoneNumberFm};
            this.m_builtFieldMappings = this.appendMappings(super.getFieldMappings(), this.m_ourFieldMappings);
        }

        return this.m_builtFieldMappings;
    }

    protected ReadSet[] getReadSets() {
        if (this.m_builtReadSets == null) {
            ReadSet[] readSets = new ReadSet[]{new ReadSet(-2, (ReadableMapping[])null)};
            this.m_builtReadSets = this.appendReadSets(super.getReadSets(), super.getFieldMappings(), readSets,
                    this.m_ourFieldMappings);
        }

        return this.m_builtReadSets;
    }

    protected UpdateSet[] getUpdateSets() {
        if (this.m_builtUpdateSets == null) {
            UpdateSet[] updateSets = new UpdateSet[]{new UpdateSet(-2, (UpdateableMapping[])null)};
            this.m_builtUpdateSets = this.appendUpdateSets(super.getUpdateSets(), super.getFieldMappings(), updateSets,
                    this.m_ourFieldMappings);
        }

        return this.m_builtUpdateSets;
    }

    protected Query[] getRawQueries() {
        Query[] queries = new Query[]{new SelectQuery(FINDALL, this.m_ourDDRHints, new SelectStatement[]{new SelectStatement(-1,
                "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> ORDER BY SITE_ID, DISPLAY_ORDER_FLAT_RATE ASC")})};
        queries = this.mergeQuerySets(super.getRawQueries(), queries);
        return queries;
    }
}