package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.common.exception.ApplicationException;
import com.ebay.app.apisellingextsvc.utils.Headers;

import javax.ws.rs.core.HttpHeaders;

public abstract class ApiSellingExtApplicationHandler<T> implements BaseApplicationHandler<T> {

    private final HttpHeaders headers;

    public ApiSellingExtApplicationHandler(HttpHeaders headers) {
        this.headers = headers;
    }

    protected T handleException( ApplicationException t) {
        return null;
    }

    @Override
    public void setResponseHeaders(Headers responseHeaders) {
    }
}
