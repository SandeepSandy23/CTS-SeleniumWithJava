package com.ebay.app.apisellingextsvc.service.client.model.UserReadClient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserReadErrorResponse {

    @JsonProperty("errorId")
    private Long errorId;

    @JsonProperty("domain")
    private String domain;

    @JsonProperty("subdomain")
    private String subdomain;

    @JsonProperty("category")
    private String category;

    @JsonProperty("message")
    private String message;

    @JsonProperty("longMessage")
    private String longMessage;

}
