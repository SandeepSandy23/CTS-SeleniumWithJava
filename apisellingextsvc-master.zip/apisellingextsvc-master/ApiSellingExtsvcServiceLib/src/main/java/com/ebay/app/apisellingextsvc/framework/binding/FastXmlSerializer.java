package com.ebay.app.apisellingextsvc.framework.binding;

import com.ctc.wstx.api.WstxOutputProperties;
import com.ctc.wstx.stax.WstxOutputFactory;
import com.ebay.errorlibrary.system.ErrorDomain;
import com.ebay.errorlibrary.system.coreruntime.ErrorConstants;
import com.ebay.soaframework.common.exceptions.ErrorUtils;
import com.ebay.soaframework.common.exceptions.ServiceException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

public class FastXmlSerializer {

    public static void serialize(XmlMapper XML_MAPPER, Object response, XMLStreamWriter out) throws ServiceException {
        XMLOutputFactory xmlOutputFactory = WstxOutputFactory.newFactory();
        xmlOutputFactory.setProperty(XMLOutputFactory.IS_REPAIRING_NAMESPACES, Boolean.TRUE);
        xmlOutputFactory.setProperty(WstxOutputProperties.P_USE_DOUBLE_QUOTES_IN_XML_DECL, Boolean.TRUE);
        try {
            XML_MAPPER.writeValue(out, response);
            out.flush();
            out.close();
        } catch (Exception e) {
            throw new ServiceException(ErrorUtils.createErrorData(ErrorConstants.SVC_DATA_SERIALIZATION_ERROR,
                    ErrorDomain.CoreRuntime.toString(), new String[]{e.toString()}), e);
        }
    }
}
