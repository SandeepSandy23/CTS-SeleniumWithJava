package com.ebay.app.apisellingextsvc.context;

public class EnvironmentContext {

    public static final String DEV = "Dev";
    public static final String FEATURE = "Feature";
    public static final String STAGING = "QA";
    public static final String PREPROD = "Pre-Production";
    public static final String SANDBOX = "sandbox";
    public static final String PROD = "Production";

    private final String poolType;
    private final boolean mockData;

    private EnvironmentContext(String poolType, boolean mockData) {
        this.poolType = poolType;
        this.mockData = mockData;
    }

    public static EnvironmentContext create(String poolType) {
        return new EnvironmentContext(poolType, false);
    }

    public static EnvironmentContext create(String poolType, boolean mockData) {
        return new EnvironmentContext(poolType, mockData);
    }

    public String getPoolType() {
        return poolType;
    }

    public boolean isMockData() {
        return mockData;
    }
}
