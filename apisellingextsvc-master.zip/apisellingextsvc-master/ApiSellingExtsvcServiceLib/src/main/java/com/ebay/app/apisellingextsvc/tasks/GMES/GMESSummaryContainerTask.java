package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.ListingsContext;
import com.ebay.app.apisellingextsvc.context.Summary;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.invokers.CosmosSummaryServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.LimitStatusServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.ListingActivitiesInvoker;
import com.ebay.app.apisellingextsvc.tasks.LimitStatusServiceInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.ListingActivitiesTask;
import com.ebay.app.apisellingextsvc.tasks.cosmos.CosmosSummaryInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.cosmos.GMESCosmosRequestTask;
import com.ebay.app.apisellingextsvc.utils.TaskOrchestrationUtil;
import com.ebay.app.apisellingextsvc.utils.TracerUtil;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.raptor.orchestrationv2.task.TaskConfiguration;
import com.google.common.collect.ImmutableList;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.ItemListCustomizationType;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.context.Scope;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.GET_MYEBAY_SELLING;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.LISTING_ACTIVE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_COMPLETE_LISTING;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_FIELDGROUP;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_FILTER;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_SELLER_TYPE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_SELLER_TYPE_VALUE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_USECASE;

public class GMESSummaryContainerTask implements Task<Summary>, ITaskResultInjectable {

    private final Map<String, Object> resultMap = new HashMap<>();
    private final GetMyeBaySellingRequest request;
    private final Executor executor;
    private final List<DetailLevelCodeType> detailLevels;

    public GMESSummaryContainerTask(GetMyeBaySellingRequest request,
                                    Executor executor,
                                    List<DetailLevelCodeType> detailLevels) {

        this.request = request;
        this.executor = executor;
        this.detailLevels = detailLevels;
    }

    @Override
    public Summary call() {
        if (!isPreConditionMet()) return null;
        Span openTeleChildSpan = TracerUtil.getOpenTeleChildSpan(this.getClass().getSimpleName(), this.request.getTracerContext());
        io.opentracing.Span openTracerChildSpan = TracerUtil.getOpenTracerChildSpan(this.getClass().getSimpleName(), this.request.getTracerContext());

        TracerContext updatedParentTracerContext = new TracerContext(this.request.getTracerContext().getOpenTeleTracer(),
                openTeleChildSpan,
                this.request.getTracerContext().getOpenTracingTracer(),
                openTracerChildSpan);
        try (Scope scope = TracerUtil.startOpenTeleChildSpan(openTeleChildSpan, this.request.getTracerContext()); io.opentracing.Scope tracerScope =
                TracerUtil.startOpenTracerChildSpan(openTracerChildSpan, this.request.getTracerContext())) {
            GMESCosmosRequestTask cosmosRequestTask = new GMESCosmosRequestTask(request.requestType, request.getHeaders(), this.request.getUser(), this.request.getConfigValues(), ApiSellingExtSvcConstants.SUMMARY);
            CosmosSummaryInvokeTask cosmosInvokeTask = new CosmosSummaryInvokeTask(new CosmosSummaryServiceInvoker(updatedParentTracerContext), request.getErrorList());
            LimitStatusServiceInvokeTask limitStatusServiceInvokeTask = new LimitStatusServiceInvokeTask(new LimitStatusServiceInvoker(updatedParentTracerContext), request.getErrorList(), request.getUser().getUserId());
            ImmutableList<Pair<String, Object>> queryParams = ImmutableList.of(
                    ImmutablePair.of(QUERY_PARAM_FIELDGROUP, QUERY_PARAM_COMPLETE_LISTING),
                    ImmutablePair.of(QUERY_PARAM_SELLER_TYPE, QUERY_PARAM_SELLER_TYPE_VALUE),
                    ImmutablePair.of(QUERY_PARAM_FILTER, LISTING_ACTIVE),
                    ImmutablePair.of(QUERY_PARAM_USECASE, GET_MYEBAY_SELLING),
                    ImmutablePair.of("limit", 1),
                    ImmutablePair.of("offset", 0));
            ListingsContext listingsContext = new ListingsContext(queryParams, request.getHeaders());
            ListingActivitiesTask listingActivitiesTask = new ListingActivitiesTask(
                    new ListingActivitiesInvoker(updatedParentTracerContext), request.getErrorList(), request.getHeaders(), this.request.getUser(), listingsContext);
            GMESBuildSummaryTask summaryContainerTask = new GMESBuildSummaryTask(request);

            TaskConfiguration cosmosInvokeConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosRequestTask);
            TaskConfiguration summaryContainerConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask,
                    limitStatusServiceInvokeTask, listingActivitiesTask);

            request.orchestrator.execute(limitStatusServiceInvokeTask);
            request.orchestrator.execute(listingActivitiesTask);
            request.orchestrator.execute(cosmosRequestTask);
            request.orchestrator.execute(cosmosInvokeTask, cosmosInvokeConfig);

            CompletableFuture<Summary> getSummaryContainerCompletableFuture = request.orchestrator.execute(summaryContainerTask, summaryContainerConfig);
            return (Summary) TaskOrchestrationUtil.safeGet(getSummaryContainerCompletableFuture);
        } finally {
            openTeleChildSpan.end();
            openTracerChildSpan.finish();
        }
    }

    /**
     * Summary container is always returned unless SellingSummary include == false or (SellingSummary is null and version >= 605)
     */
    private Boolean isPreConditionMet() {
        if (request.requestType.getSellingSummary() == null && request.getTrxVersion() >= this.request.getConfigValues().summaryMaxVersion) {
            return false;
        }
        return Optional.ofNullable(request.requestType.getSellingSummary())
                .map(ItemListCustomizationType::isInclude)
                .orElse(true);
    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }

    private Scope getOpenTeleSpan() {
        return this.request.getTracerContext()
                .getOpenTeleParentSpan()
                .makeCurrent();
    }

    private io.opentracing.Scope createTracerSpan() {
        return this.request.getTracerContext()
                .getOpenTracingTracer()
                .scopeManager()
                .activate(this.request.getTracerContext().getOpenTracingParentSpan(), true);
    }

}
