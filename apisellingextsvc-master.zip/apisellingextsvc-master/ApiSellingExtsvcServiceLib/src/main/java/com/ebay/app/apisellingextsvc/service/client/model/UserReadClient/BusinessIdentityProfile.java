package com.ebay.app.apisellingextsvc.service.client.model.UserReadClient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessIdentityProfile  {
    @JsonProperty("businessEmail")
    private String email;

    @JsonProperty("businessAddress")
    private Address address;

}
