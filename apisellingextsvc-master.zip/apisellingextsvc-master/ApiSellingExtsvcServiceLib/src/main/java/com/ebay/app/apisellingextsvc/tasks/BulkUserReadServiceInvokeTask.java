package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.BulkUserReadServiceClient;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.User;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserInfo;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserReadResponse;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.model.BulkUserInfoModel;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cos.las.type.ListingActivitiesResponse;
import com.ebay.cos.type.v3.core.listing.ItemVariation;
import com.ebay.cos.type.v3.core.listing.Listing;
import com.ebay.cos.type.v3.core.listing.tradingSummary.ItemVariationTradingSummary;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.ProformaOrderCS;
import com.ebay.order.common.v1.Order;
import com.ebay.order.common.v1.UserIdentifier;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class BulkUserReadServiceInvokeTask implements Task<BulkUserInfoModel>, ITaskResultInjectable {

    private final Executor executor;
    private Map<String, Object> resultMap = new HashMap<>();

    private static Logger logger = LoggerFactory.getLogger(BulkUserReadServiceClient.class);
    private final IServiceInvoker<String, UserReadResponse> userReadServiceBulkInvoker;
    private final HttpHeaders headers;
    private final ApiSellingExtSvcConfigValues configValues;
    private final Boolean isActiveList;

    public BulkUserReadServiceInvokeTask(
            IServiceInvoker<String, UserReadResponse> userReadServiceBulkInvoker,
            List<ErrorType> errorList, HttpHeaders headers, ApiSellingExtSvcConfigValues configValues,
            Executor executor,
            Boolean isActiveList) {
        this.userReadServiceBulkInvoker = userReadServiceBulkInvoker;
        this.headers = headers;
        this.configValues = configValues;
        this.executor = executor;
        this.isActiveList = isActiveList;
    }

    @Override
    public BulkUserInfoModel call() {
        List<List<String>> userSegmentList;
        if (isActiveList) {
            userSegmentList = buildUserSegment(null, (ListingActivitiesResponse)resultMap.get(ListingActivitiesResponse.class.getName()));
        } else {
            userSegmentList = buildUserSegment((ContractResponse)resultMap.get(ContractResponse.class.getName()), null);
        }
        Stream<UserInfo> userInfoStream = Optional.ofNullable(userSegmentList)
                                                          .orElse(new ArrayList<>())
                                                          .stream()
                                                          .map(t -> CompletableFuture.supplyAsync(() -> this.userReadServiceBulkInvoker.getResponse(buildQueryForBulkCall(t, isActiveList), headers), executor))
                                                          .collect(Collectors.toList()).stream()
                                                          .map(CompletableFuture::join)
                                                          .filter(Objects::nonNull)
                                                          .map(UserReadResponse::getData)
                                                          .collect(Collectors.toList())
                                                          .stream()
                                                          .map(User::getUser).flatMap(Collection::stream);
        Map<String, UserInfo> userIduserInfoMap;
        if (isActiveList) {
            return new BulkUserInfoModel(userInfoStream.collect(Collectors.toMap(UserInfo::getUsername, Function.identity())));
        }
            userIduserInfoMap = userInfoStream.collect(Collectors.toMap(UserInfo::getInternalId, Function.identity()));
        return new BulkUserInfoModel(userIduserInfoMap);
    }

    private List<List<String>> buildUserSegment(ContractResponse contractResponse, ListingActivitiesResponse listingActivitiesResponse) {
        List<String> userIds;
        if (contractResponse != null) {
            userIds = new ArrayList<>(buildBuyerIdSet(contractResponse));
        } else {
            userIds = new ArrayList<>(buildBuyerIdSet(listingActivitiesResponse));
        }
        int partitionSize = configValues.users_max_limit;
        Collection<List<String>> partitionedList = IntStream.range(0, userIds.size())
                .boxed()
                .collect(Collectors.groupingBy(partition -> (partition / partitionSize),
                        Collectors.mapping(userIds::get, Collectors.toList())))
                .values();
        return new ArrayList<>(partitionedList);
    }

    private Set<String> buildBuyerIdSet(ListingActivitiesResponse listingActivitiesResponse) {
        Set<String> idSet = new HashSet<>();
        ListingActivitiesDetail[] listingActivitiesResponseList = Optional.ofNullable(listingActivitiesResponse).map(ListingActivitiesResponse::getMembers)
                .orElse(new ListingActivitiesDetail[0]);
        for (ListingActivitiesDetail listingActivitiesDetail : listingActivitiesResponseList) {
            Optional.ofNullable(listingActivitiesDetail)
                    .map(ListingActivitiesDetail::getListing)
                    .map(Listing::getItemVariations)
                    .flatMap(itemVariations -> itemVariations.stream().findFirst())
                    .map(ItemVariation::getItemVariationTradingSummary)
                    .map(ItemVariationTradingSummary::getHighBidderUsername)
                    .ifPresent(idSet::add);
        }
        return idSet;
    }

    private Set<String> buildBuyerIdSet(ContractResponse contractResponse) {
        Set<String> idSet = new HashSet<>();
        List<ContractResponseType> contractResponseTypeList = Optional.ofNullable(contractResponse).map(ContractResponse::getMembers)
                                                                      .orElse(Collections.emptyList());
        for (ContractResponseType contractResponseType: contractResponseTypeList) {
            if (Optional.ofNullable(contractResponseType).map(ContractResponseType::getOrder).isPresent()) {
                Optional.of(contractResponseType).map(ContractResponseType::getOrder)
                        .map(Order::getBuyer)
                        .map(com.ebay.order.common.v1.User::getUserIdentifier)
                        .map(UserIdentifier::getUserId)
                        .ifPresent(idSet::add);
            } else if (Optional.ofNullable(contractResponseType).map(ContractResponseType::getProformaOrder).isPresent()) {
                Optional.of(contractResponseType).map(ContractResponseType::getProformaOrder)
                        .map(ProformaOrderCS::getBuyerCS)
                        .map(com.ebay.order.common.v1.User::getUserIdentifier)
                        .map(UserIdentifier::getUserId)
                        .ifPresent(idSet::add);
            }
        }
        return idSet;
    }

    private String buildQueryForBulkCall(List<String> userIds, Boolean isActiveList) {
        String usrId = String.join("\",\"",userIds);
        StringBuilder query = (new StringBuilder()).append("{\n");
        if (isActiveList) {
            query.append("user(account_names:[\"").append(usrId).append("\"])").append("{\nlegacyUserId\nuserAccountName\nuserAccountType");
        } else {
            query.append("user(ids:[\"").append(usrId).append("\"])").append("{\nlegacyUserId\nuserAccountName\nuserAccountType");
        }
        getProfileQuery().forEach(it -> query.append("\n").append(it));
        // Closing query
        query.append("\n}\n}");
        return query.toString();
    }

    private List<String> getProfileQuery() {
        List<String> responseFields = new ArrayList<>();
        responseFields.add("registrationSiteId");
        responseFields.add("registrationMarketPlaceId");
        responseFields.add("userAccountStatus");
        responseFields.add("userAccountCreationDate");
        responseFields.add("individualIdentityProfile {");
        responseFields.add("firstName");
        responseFields.add("lastName");
        responseFields.add("email");
        //Userread bulksvc is not supporting these fields as of now.
//        responseFields.add("creationDate");
//        responseFields.add("lastModifiedDate");
        responseFields.add("address {");
        responseFields.add("addressLine1");
        responseFields.add("addressLine2");
        responseFields.add("city");
        responseFields.add("stateOrProvince");
        responseFields.add("postalCode");
        responseFields.add("country");
        responseFields.add("}");
        responseFields.add("}");
        responseFields.add("extensions(namespace: [\"IDENTITY\", \"SELLING\", \"PAYMENT\", \"TRUST\", \"FEEDBACK\"]) { key  value type }");
        return responseFields;
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
