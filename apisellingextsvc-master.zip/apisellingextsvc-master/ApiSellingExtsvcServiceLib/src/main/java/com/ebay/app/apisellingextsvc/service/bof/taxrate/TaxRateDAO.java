package com.ebay.app.apisellingextsvc.service.bof.taxrate;


import com.ebay.integ.dal.dao.CacheableDao;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.map.QueryEngine;

import java.util.*;

public class TaxRateDAO extends CacheableDao {
    private static final TaxRateDAO m_instance = new TaxRateDAO();

    protected TaxRateDAO() {
        super(TaxRateKeyManager.getInstance(), "TaxRate", TaxRateCacheBean.getInstance());
    }

    public static TaxRateDAO getInstance() {
        return m_instance;
    }

    public List findTaxRates(int _siteId, int _countryId) throws FinderException {
        TaxRateDoImpl protoDO = new TaxRateDoImpl(this, TaxRateMap.getInstance());
        protoDO.setSiteId(_siteId);
        protoDO.setCountryId(_countryId);
        List result = (List)this.globalCacheFetchMultiple(protoDO, 0);
        return result;
    }

    public TaxRate findActiveTaxRate(int _siteId, int _countryId, Date _inputDate) throws FinderException {
        TaxRate result = null;
        if (_inputDate == null) {
            return null;
        } else {
            List taxRateList = this.findTaxRates(_siteId, _countryId);
            if (taxRateList.size() == 0) {
                return null;
            } else {
                Iterator taxRatesIterator = taxRateList.iterator();

                while (taxRatesIterator.hasNext()) {
                    TaxRate curTaxRate = (TaxRate)taxRatesIterator.next();
                    if (curTaxRate.isEffective(_inputDate)) {
                        result = curTaxRate;
                        break;
                    }
                }

                return result;
            }
        }
    }

    public TaxRate findActiveTaxRate(int _siteId, int _countryId, String state, Date _inputDate) throws FinderException {
        TaxRate result = null;
        if (_inputDate == null) {
            return null;
        } else {
            List taxRateList = this.findTaxRates(_siteId, _countryId);
            if (taxRateList.size() == 0) {
                return null;
            } else {
                Iterator taxRatesIterator = taxRateList.iterator();

                while (taxRatesIterator.hasNext()) {
                    TaxRate curTaxRate = (TaxRate)taxRatesIterator.next();
                    if (curTaxRate.isEffective(_inputDate) && curTaxRate.getUserState() != null && curTaxRate.getUserState().equals(state)) {
                        result = curTaxRate;
                        break;
                    }

                    if (curTaxRate.isEffective(_inputDate) && curTaxRate.getUserState() == null) {
                        result = curTaxRate;
                    }
                }

                return result;
            }
        }
    }

    public List findAllDirect2DB() throws FinderException {
        QueryEngine qe = new QueryEngine();
        TaxRateDoImpl protoDO = new TaxRateDoImpl(this, TaxRateMap.getInstance());
        List result = new ArrayList();
        qe.readMultiple(result, TaxRateMap.getInstance(), protoDO, "FIND_ALL", -2);
        return result;
    }

    public TaxRate getActiveTaxRate(int _siteId, int _countryId, Date currentDate) throws FinderException {
        TaxRate result = null;
        List taxRateList = this.findTaxRates(_siteId, _countryId);
        if (taxRateList.size() == 0) {
            return null;
        } else {
            GregorianCalendar gc = new GregorianCalendar();
            gc.setTime(currentDate);
            gc.add(5, -180);
            Date dateSixMonthsAgo = gc.getTime();
            Iterator taxRatesIterator = taxRateList.iterator();

            while (taxRatesIterator.hasNext()) {
                TaxRate curTaxRate = (TaxRate)taxRatesIterator.next();
                Date effectiveDate = curTaxRate.getEffectiveDate();
                if (effectiveDate.after(dateSixMonthsAgo) && curTaxRate.isEffective(currentDate)) {
                    result = curTaxRate;
                    break;
                }
            }

            return result;
        }
    }
}
