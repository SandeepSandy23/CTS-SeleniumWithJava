package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.cos.type.v3.base.CurrencyCodeEnum;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.OrderTotal;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.globalenv.SiteEnum;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.EntityTotal;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.CurrencyCodeType;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;
import java.util.Optional;

/**
 * Util class for amount type
 */
public final class AmountTypeUtil {

    private AmountTypeUtil() {
        // sonar - Class should define a constructor.
    }

    /**
     * @param currency currency
     * @param value    vale
     * @return AmountType
     */
    public static AmountType getAmountType(String currency, Double value) {
        return getAmountType(CurrencyCodeType.fromValue(currency), value);
    }

    public static AmountType getAmountType(String currency, String value) {
        return getAmountType(currency, Double.parseDouble(value));
    }

    public static AmountType getAmountType(CurrencyCodeType currencyCodeType, double value) {
        AmountType amountType = new AmountType();
        amountType.setValue(value);
        amountType.setCurrencyID(currencyCodeType);
        return amountType;
    }

    public static AmountType getAmountType(@Nonnull Amount amount) {
        AmountType at = new AmountType();
        at.setValue(amount.getValue());
        if (amount.getCurrency() != null) {
            at.setCurrencyID(CurrencyCodeType.fromValue(amount.getCurrency().name()));
        }
        return at;
    }

    public static AmountType getAmountType(@Nonnull com.ebay.cos.type.v3.base.Amount amount) {
        AmountType at = new AmountType();
        if(amount.getValue() != null) at.setValue(amount.getValue());
        if (amount.getCurrency() != null) {
            at.setCurrencyID(CurrencyCodeType.fromValue(amount.getCurrency().name()));
        }
        return at;
    }

    public static AmountType getAmountType(@Nonnull EntityTotal entityTotal) {
        AmountType res = null;
        if (entityTotal.getAmount() != null) {
            res = new AmountType();
            res.setValue(entityTotal.getAmount().getValue());
            res.setCurrencyID(CurrencyCodeType.fromValue(entityTotal.getAmount().getCurrency().name()));
        }

        return res;
    }

    public static AmountType getDefaultZeroAmountType(@Nonnull OrderCSXType order) {
        return getDefaultZeroAmountType(order.getOrderTotalSummary());
    }

    public static AmountType getDefaultZeroAmountType(@Nonnull ProformaOrderXType proformaOrder) {
        return getDefaultZeroAmountType(proformaOrder.getOrderTotalSummary());
    }

    public static AmountType getDefaultZeroAmountType(OrderTotal orderTotalSummary) {
        return PaymentUtil.getOrderTotal(orderTotalSummary).map(Amount::getCurrency)
                .map(codeEnum -> getAmountType(codeEnum.name(), ApiSellingExtSvcConstants.ZERO_AMOUNT))
                .orElseGet(() -> AmountTypeUtil.getAmountType(CurrencyCodeEnum.USD.name(), ApiSellingExtSvcConstants.ZERO_AMOUNT));
    }

    public static AmountType negate(@Nonnull AmountType amount) {
        return getAmountType(amount.getCurrencyID().name(), BigDecimal.valueOf(amount.getValue()).negate().doubleValue());
    }

    public static AmountType getZeroAmountType(@Nonnull String currency) {
        return getAmountType(currency, ApiSellingExtSvcConstants.ZERO_AMOUNT);
    }

    public static AmountType getAmountTypeAndConvertedCurrency(@Nonnull Amount amount) {
        if (amount.getConvertedFromValue() != null && amount.getConvertedFromCurrency() != null) {
            return getAmountType(amount.getConvertedFromCurrency().name(), amount.getConvertedFromValue());
        }
        return getAmountType(amount);
    }

    /**
     * null safe method for add two amount with same currency
     *
     * @param augend
     * @param addend
     * @return
     */
    public static AmountType sum(AmountType augend, AmountType addend) {
        //null safe
        if (augend == null && addend == null) {
            return null;
        }
        if (augend == null) {
            return addend;
        }
        if (addend == null) {
            return augend;
        }
        // pre assert
        assert augend.getCurrencyID() == addend.getCurrencyID();

        double value = new BigDecimal(String.valueOf(augend.getValue()))
                .add(new BigDecimal(String.valueOf(addend.getValue())))
                .setScale(ApiSellingExtSvcConstants.SCALE_OF_DECIMAL, RoundingMode.HALF_UP)
                .doubleValue();
        return getAmountType(augend.getCurrencyID().name(), value);
    }


    /**
     * get currency from EntityTotal
     * @param entityTotal
     * @return
     */
    public static String getCurrency(EntityTotal entityTotal) {
        return Optional.ofNullable(entityTotal)
                .map(EntityTotal::getAmount)
                .map(Amount::getCurrency)
                .map(CurrencyCodeEnum::name)
                .orElse(null);
    }

    public static AmountType getAmountType(Integer siteId, Double value) {
        SiteEnum site = SiteEnum.get(siteId);
        return getAmountType(Currency.getInstance(site.getLocale()).getCurrencyCode(), value);
    }
}