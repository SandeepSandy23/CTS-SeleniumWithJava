package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.order.common.v1.PaymentMethodTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.BuyerPaymentMethodCodeType;
import org.apache.commons.lang3.tuple.Pair;

public class PaymentMethodMapper {

    // todo proforma order mapping
    // checkout trans payment method
    private static final ImmutableMap<String, Pair<BuyerPaymentMethodCodeType, Integer>> mapName
            = new ImmutableMap.Builder<String, Pair<BuyerPaymentMethodCodeType, Integer>>()
            .put(PaymentMethodTypeEnum.COD.name(), Pair.of(BuyerPaymentMethodCodeType.COD, 0))
            .put(PaymentMethodTypeEnum.GENERIC_CREDIT_CARD.name(), Pair.of(BuyerPaymentMethodCodeType.CC_ACCEPTED, 0))
            .put(PaymentMethodTypeEnum.CASH_ON_PICKUP.name(), Pair.of(BuyerPaymentMethodCodeType.CASH_ON_PICKUP, 0))
            .put("CHECK", Pair.of(BuyerPaymentMethodCodeType.PERSONAL_CHECK, 0))
            .put(PaymentMethodTypeEnum.EMS_ESCROW.name(), Pair.of(BuyerPaymentMethodCodeType.ESCROW, 0)) // 02-00022-19840
            .put(PaymentMethodTypeEnum.PAYPAL.name(), Pair.of(BuyerPaymentMethodCodeType.PAY_PAL, 0))
            .put(PaymentMethodTypeEnum.OTHER.name(), Pair.of(BuyerPaymentMethodCodeType.OTHER, 0))
            .put(PaymentMethodTypeEnum.CIP.name(),
                    Pair.of(BuyerPaymentMethodCodeType.MONEY_XFER_ACCEPTED_IN_CHECKOUT, 0)) // chekcout trans payment method = 13
            .put("MO_CASHIERS", Pair.of(BuyerPaymentMethodCodeType.MOCC, 0)) // chekcout trans payment method = 3
            .put(PaymentMethodTypeEnum.MONEY_TRANSFER.name(),
                    Pair.of(BuyerPaymentMethodCodeType.MONEY_XFER_ACCEPTED, 0)) // chekcout trans payment method = 8
            .build();

    private PaymentMethodMapper() {
    }

    public static BuyerPaymentMethodCodeType map(String key, int trxVersion) {
        Pair<BuyerPaymentMethodCodeType, Integer> pair = mapName.get(key);
        if (pair != null && trxVersion >= pair.getRight()) {
            return pair.getLeft();
        }

        //when trxversion >= 849, use credit card as default value else custom code
        if (trxVersion >= VersionConstant.VERSION_PROGESSIVE_XO) {
            return BuyerPaymentMethodCodeType.CREDIT_CARD;
        } else {
            return BuyerPaymentMethodCodeType.CUSTOM_CODE;
        }
    }


}
