package com.ebay.app.apisellingextsvc.service.client.model.StoreEditEntityClient;

import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Component
public class StoreEditEntityServiceClient extends BaseGingerClient<String, StoreEditEntityResponse> {
    private static final Logger logger = LoggerFactory.getLogger(StoreEditEntityServiceClient.class);
    private static final String STORE_ENTITY_CLIENT = "storeedit.entitysvc";
    private static final String PATH = "/sell/get_store_details?fieldGroups=COMPACT";

    public StoreEditEntityServiceClient() {
        super(StoreEditEntityResponse.class);
    }

    @Override
    public GingerClientResponse<StoreEditEntityResponse> getGingerResponse(GingerClientRequest<String> gingerClientRequest) {
        return processGetStoreRequest(PATH, gingerClientRequest.getHeaders());
    }

    @Override
    public String getTargetBase() {
        return STORE_ENTITY_CLIENT;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
