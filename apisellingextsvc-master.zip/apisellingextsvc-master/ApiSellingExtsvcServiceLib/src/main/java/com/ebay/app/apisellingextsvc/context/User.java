package com.ebay.app.apisellingextsvc.context;


import lombok.Getter;

@Getter
public class User {

    public String userId;
    public String userName;

    public User(String userName, String userId) {
        this.userId = userId;
        this.userName = userName;
    }

    public static User createUser(String userName, String userId) {
        return new User(userName, userId);
    }

}
