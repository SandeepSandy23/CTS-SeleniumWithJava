package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.mappers.ShippingTypeCodeTypeMapper;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.app.apisellingextsvc.utils.PriceLineAmountUtil;
import com.ebay.app.apisellingextsvc.utils.ProgramUtil;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cos.type.v3.base.Amount;
import com.ebay.cos.type.v3.core.listing.Listing;
import com.ebay.cos.type.v3.core.listing.termsAndPolicies.LogisticsTerms;
import com.ebay.cos.type.v3.core.listing.termsAndPolicies.TermsAndPolicies;
import com.ebay.cos.type.v3.core.logistics.LogisticsPlan;
import com.ebay.cos.type.v3.core.logistics.LogisticsStep;
import com.ebay.cos.type.v3.core.logistics.ShippingCostPlan;
import com.ebay.cos.type.v3.core.logistics.ShippingOption;
import com.ebay.cos.type.v3.core.logistics.ShippingStepExtension;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.ShippingDetailsType;
import ebay.apis.eblbasecomponents.ShippingServiceOptionsType;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.ebay.app.apisellingextsvc.tasks.GMES.ListingActivitiesUtil.getAmountTypes;

public class ItemShippingDetailsBuilder extends BaseFacetBuilder<ShippingDetailsType> {

    private final ListingActivitiesDetail listingActivitiesDetail;
    private final ContractResponseType contractResponseType;

    public ItemShippingDetailsBuilder(Task<?> task, ListingActivitiesDetail listingActivitiesDetail, ContractResponseType contractResponseType) {
        super(task);
        this.listingActivitiesDetail = listingActivitiesDetail;
        this.contractResponseType = contractResponseType;
    }

    @Override
    public ShippingDetailsType doBuild() {
        Optional<LogisticsTerms> logisticsTerms = Optional.ofNullable(listingActivitiesDetail)
                .map(ListingActivitiesDetail::getListing).map(Listing::getTermsAndPolicies)
                .map(TermsAndPolicies::getLogisticsTerms);
        ShippingDetailsType shippingDetailsType = new ShippingDetailsType();
        Boolean isGlobalShipping = logisticsTerms.map(LogisticsTerms::getGSPLogisticsPlanSupported).orElse(Boolean.FALSE);
        if (isGlobalShipping) {
            shippingDetailsType.setGlobalShipping(isGlobalShipping);
        }
        Optional<ShippingCostPlan> shippingCostPlan = getShippingCostPlan(logisticsTerms);

        // This field is refereed for Active Listings
        shippingDetailsType.setShippingType(Optional.ofNullable(listingActivitiesDetail)
                .map(ListingActivitiesDetail::getSellerSelectedShippingCostPlanType)
                .map(ShippingTypeCodeTypeMapper::map).orElse(null));
        if (shippingDetailsType.getShippingType() == null) {
            if (ContractResponseUtil.isOrder(contractResponseType) || ContractResponseUtil.isProformaOrder(contractResponseType)) {
                shippingDetailsType.setShippingType(shippingCostPlan.map(ShippingCostPlan::getCostPlanType)
                        .map(ShippingTypeCodeTypeMapper::map).orElse(null));
            }
        }
        ShippingServiceOptionsType shippingServiceOptionsType = new ShippingServiceOptionsType();
        Boolean isLocalPickup = logisticsTerms.map(LogisticsTerms::getLocalPickupLogisticsPlanSupported).orElse(Boolean.FALSE);
        if (isLocalPickup) {
            shippingServiceOptionsType.setLocalPickup(isLocalPickup);
        }
        AmountType shippingServiceCost;
        if (ContractResponseUtil.isOrder(contractResponseType)) {
            shippingServiceCost = getLineItemShippingCost(CommonUtil.getLineItemIdForFilter(contractResponseType), contractResponseType.getOrder());
            if (shippingServiceCost != null) { // set cost even if 0
                shippingServiceOptionsType.setShippingServiceCost(shippingServiceCost);
            }
        } else if (ContractResponseUtil.isProformaOrder(contractResponseType)) {
            shippingServiceCost = getLineItemShippingCost(CommonUtil.getProformaLineItemIdForFilter(contractResponseType), contractResponseType.getProformaOrder());
            if (shippingServiceCost != null) {
                shippingServiceOptionsType.setShippingServiceCost(shippingServiceCost);
            }
        } else {
            shippingServiceCost = getShippingServiceCost(shippingCostPlan);
            if (shippingServiceCost != null) {
                shippingServiceOptionsType.setShippingServiceCost(shippingServiceCost);
            }
        }
        List<ShippingServiceOptionsType> shippingServiceOptions = new ArrayList<>();
        shippingServiceOptions.add(shippingServiceOptionsType);
        shippingDetailsType.getShippingServiceOptions().addAll(shippingServiceOptions);
        return shippingDetailsType;
    }

    private static AmountType getLineItemShippingCost(String lineItemId, OrderCSXType order) {
        if (ProgramUtil.isPSAOrder(order.getPrograms())) {
            return AmountTypeUtil.getDefaultZeroAmountType(order);
        }
        if (lineItemId == null) {
            AmountType domesticLegCost = PriceLineAmountUtil.getLineItemTotalPriceLineAmountTotal(PricelineTypeEnum.DOMESTIC_LEG_COST, order);
            if (domesticLegCost.getValue() != 0) {
                return domesticLegCost;
            }
            return order.getLineItemTypes().stream().map(lineItemXType -> lineItemXType.getLineItemTotalSummary())
                    .map(totalSummary -> totalSummary.getShippingCost()).findFirst()
                    .map(AmountTypeUtil::getAmountType).orElse(null);
        }
        return order.getLineItemTypes().stream().filter(lineItemXType -> lineItemXType.getLineItemId().equals(lineItemId))
                .map(lineItemXType -> lineItemXType.getLineItemTotalSummary())
                .map(totalSummary -> totalSummary.getShippingCost()).findFirst()
                .map(AmountTypeUtil::getAmountType).orElse(null);
    }

    private static AmountType getLineItemShippingCost(Long lineItemId, ProformaOrderXType order) {
        if (ProgramUtil.isPSAOrder(order.getPrograms())) {
            return AmountTypeUtil.getDefaultZeroAmountType(order);
        }
        if (lineItemId == null) {
            AmountType domesticLegCost = PriceLineAmountUtil.getLineItemTotalPriceLineAmountTotal(PricelineTypeEnum.DOMESTIC_LEG_COST, order);
            if (domesticLegCost.getValue() != 0) {
                return domesticLegCost;
            }
            return PriceLineAmountUtil.getPriceLineAmount(PricelineTypeEnum.SHIPPING_COST, order);
        }

        return order.getLineItemTypes().stream().filter(lineItemXType -> lineItemXType.getLineItemId() == lineItemId)
                .map(lineItemXType -> lineItemXType.getLineItemTotalSummary())
                .map(totalSummary -> totalSummary.getShippingCost()).findFirst()
                .map(AmountTypeUtil::getAmountType).orElse(null);
    }

    private static Optional<ShippingCostPlan> getShippingCostPlan(Optional<LogisticsTerms> logisticsTerms) {
        return logisticsTerms.map(LogisticsTerms::getLogisticsPlan)
                .flatMap(logisticsPlans -> logisticsPlans.stream().findFirst())
                .map(LogisticsPlan::getSteps).flatMap(logisticsSteps -> logisticsSteps.stream().findFirst())
                .map(LogisticsStep::getStepExtension)
                .map(logisticsStepExtension -> (ShippingStepExtension) logisticsStepExtension)
                .map(ShippingStepExtension::getShippingOption)
                .flatMap(shippingOptions -> shippingOptions.stream().findFirst())
                .map(ShippingOption::getShippingCostPlan);
    }

    private AmountType getShippingServiceCost(Optional<ShippingCostPlan> shippingCostPlan) {
        Amount amount = shippingCostPlan.map(ShippingCostPlan::getShippingCost).orElse(null);
        return getAmountTypes(amount, null).getKey();
    }
}
