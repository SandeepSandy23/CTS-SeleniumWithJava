package com.ebay.app.apisellingextsvc.common.helper;

import java.io.File;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;

public class FileHelper {

    public FileHelper() {
    }

    public static File readResourceFile(String path) throws URISyntaxException {
        URL resource = FileHelper.class.getClassLoader().getResource(path);
        return new File(resource.toURI());
    }

    public static InputStream readResourceFileAsStream(String path) {
        return FileHelper.class.getClassLoader().getResourceAsStream(path);
    }
}
