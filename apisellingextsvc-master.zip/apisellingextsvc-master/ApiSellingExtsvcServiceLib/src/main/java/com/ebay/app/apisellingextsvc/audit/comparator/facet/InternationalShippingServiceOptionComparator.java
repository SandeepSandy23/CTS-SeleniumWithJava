package com.ebay.app.apisellingextsvc.audit.comparator.facet;


import com.ebay.app.apisellingextsvc.audit.comparator.CustomExtComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.IJsonNodeComparator;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.Objects;

public class  InternationalShippingServiceOptionComparator implements IJsonNodeComparator {

    private CustomExtComparator comparator;

    public InternationalShippingServiceOptionComparator(CustomExtComparator comparator) {
        this.comparator = comparator;
    }

    @Override
    public boolean customCompareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        // disable auditing for checkout order, but enable it for proforma order
        if (comparator.isCheckoutOrder() || Objects.equals(org, tar)) {
            return true;
        }
        return comparator.defaultCompareNode(org, tar, pattern, path, key, report);
    }
}
