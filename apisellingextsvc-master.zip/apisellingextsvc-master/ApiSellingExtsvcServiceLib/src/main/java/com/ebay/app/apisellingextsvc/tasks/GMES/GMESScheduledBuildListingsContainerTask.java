package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.builders.ItemShippingDetailsBuilder;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.service.invokers.model.BulkUserInfoModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.ItemProfilesModel;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;
import ebay.apis.eblbasecomponents.ItemType;
import ebay.apis.eblbasecomponents.PaginationType;

import java.util.List;

public class GMESScheduledBuildListingsContainerTask extends GMESBuildListingsContainerTask {
    public GMESScheduledBuildListingsContainerTask(Task<?> task, PaginationType paginationType,
                                                   ContentResource contentResource, List<ErrorType> errorList,
                                                   boolean includeNotes, boolean isHideVariations) {
        super(task, paginationType, contentResource, errorList, includeNotes, isHideVariations);
    }

    @Override
    protected void populateItemType(ItemType itemType, ListingActivitiesDetail listingActivity, BulkUserInfoModel bulkUserInfoModel, ItemProfilesModel bpItemProfilesModel) {
        super.populateItemType(itemType, listingActivity, bulkUserInfoModel, bpItemProfilesModel);
        itemType.setShippingDetails(removeZeroShippingCostOptions(new ItemShippingDetailsBuilder(null, listingActivity, null).doBuild(), listingActivity));
        itemType.setListingDuration(ListingActivitiesUtil.getListingDuration(listingActivity));
        //Default to 0.0 with site currency
        itemType.setClassifiedAdPayPerLeadFee(ListingActivitiesUtil.getClassifiedAdPayPerLeadFee(listingActivity));
        Integer newLeadCount = ListingActivitiesUtil.getNewLeadCount(listingActivity);
        if (newLeadCount > 0) {
            itemType.setQuestionCount(newLeadCount.longValue());
            itemType.setNewLeadCount(newLeadCount);
        }
    }

}
