package com.ebay.app.apisellingextsvc.mappers;

import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.ItemSortTypeCodeType;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

public class ItemSortTypeCodeTypeMapper {
    public enum Service {
        LAS,
        COSMOS
    }

    private static final ImmutableMap<ItemSortTypeCodeType, ItemSortTypeCodeType> negationMap = ImmutableMap.<ItemSortTypeCodeType, ItemSortTypeCodeType>builder()
            .put(ItemSortTypeCodeType.BEST_OFFER_COUNT_DESCENDING, ItemSortTypeCodeType.BEST_OFFER_COUNT)
            .put(ItemSortTypeCodeType.BID_COUNT_DESCENDING, ItemSortTypeCodeType.BID_COUNT)
            .put(ItemSortTypeCodeType.BIDDER_COUNT_DESCENDING, ItemSortTypeCodeType.BIDDER_COUNT)
            .put(ItemSortTypeCodeType.BUYER_EMAIL_DESCENDING, ItemSortTypeCodeType.BUYER_EMAIL)
            .put(ItemSortTypeCodeType.BUYER_POSTAL_CODE_DESCENDING, ItemSortTypeCodeType.BUYER_POSTAL_CODE)
            .put(ItemSortTypeCodeType.BUYER_USER_ID_DESCENDING, ItemSortTypeCodeType.BUYER_USER_ID)
            .put(ItemSortTypeCodeType.CURRENT_PRICE_DESCENDING, ItemSortTypeCodeType.CURRENT_PRICE)
            .put(ItemSortTypeCodeType.END_TIME_DESCENDING, ItemSortTypeCodeType.END_TIME)
            .put(ItemSortTypeCodeType.FEEDBACK_LEFT_DESCENDING, ItemSortTypeCodeType.FEEDBACK_LEFT)
            .put(ItemSortTypeCodeType.FEEDBACK_RECEIVED_DESCENDING, ItemSortTypeCodeType.FEEDBACK_RECEIVED)
            .put(ItemSortTypeCodeType.HIGH_BIDDER_USER_ID_DESCENDING, ItemSortTypeCodeType.HIGH_BIDDER_USER_ID)
            .put(ItemSortTypeCodeType.ITEM_ID_DESCENDING, ItemSortTypeCodeType.ITEM_ID)
            .put(ItemSortTypeCodeType.LEAD_COUNT_DESCENDING, ItemSortTypeCodeType.LEAD_COUNT)
            .put(ItemSortTypeCodeType.LISTING_DURATION_DESCENDING, ItemSortTypeCodeType.LISTING_DURATION)
            .put(ItemSortTypeCodeType.LISTING_TYPE_DESCENDING, ItemSortTypeCodeType.LISTING_TYPE)
            .put(ItemSortTypeCodeType.NEW_LEAD_COUNT_DESCENDING, ItemSortTypeCodeType.NEW_LEAD_COUNT)
            .put(ItemSortTypeCodeType.QUANTITY_DESCENDING, ItemSortTypeCodeType.QUANTITY)
            .put(ItemSortTypeCodeType.QUANTITY_AVAILABLE_DESCENDING, ItemSortTypeCodeType.QUANTITY_AVAILABLE)
            .put(ItemSortTypeCodeType.QUANTITY_PURCHASED_DESCENDING, ItemSortTypeCodeType.QUANTITY_PURCHASED)
            .put(ItemSortTypeCodeType.QUANTITY_SOLD_DESCENDING, ItemSortTypeCodeType.QUANTITY_SOLD)
            .put(ItemSortTypeCodeType.QUESTION_COUNT_DESCENDING, ItemSortTypeCodeType.QUESTION_COUNT)
            .put(ItemSortTypeCodeType.RESERVE_PRICE_DESCENDING, ItemSortTypeCodeType.RESERVE_PRICE)
            .put(ItemSortTypeCodeType.SHIPPING_SERVICE_COST_DESCENDING, ItemSortTypeCodeType.SHIPPING_SERVICE_COST)
            .put(ItemSortTypeCodeType.START_PRICE_DESCENDING, ItemSortTypeCodeType.START_PRICE)
            .put(ItemSortTypeCodeType.START_TIME_DESCENDING, ItemSortTypeCodeType.START_TIME)
            .put(ItemSortTypeCodeType.TIME_LEFT_DESCENDING, ItemSortTypeCodeType.TIME_LEFT)
            .put(ItemSortTypeCodeType.TITLE_DESCENDING, ItemSortTypeCodeType.TITLE)
            .put(ItemSortTypeCodeType.TOTAL_PRICE_DESCENDING, ItemSortTypeCodeType.TOTAL_PRICE)
            .put(ItemSortTypeCodeType.WATCH_COUNT_DESCENDING, ItemSortTypeCodeType.WATCH_COUNT)
            .build();

    private static final ImmutableMap<ItemSortTypeCodeType, String> lasMap = ImmutableMap.<ItemSortTypeCodeType, String>builder()
            .put(ItemSortTypeCodeType.BEST_OFFER_COUNT, "pendingOfferCount")
            .put(ItemSortTypeCodeType.BID_COUNT, upperCamelCase(ItemSortTypeCodeType.BID_COUNT))
            .put(ItemSortTypeCodeType.BIDDER_COUNT, "uniqueBidderCount")
            .put(ItemSortTypeCodeType.CURRENT_PRICE, "price")
            .put(ItemSortTypeCodeType.END_TIME, "actualEndDate")
            .put(ItemSortTypeCodeType.HIGH_BIDDER_USER_ID, "highBidderUsername")
            .put(ItemSortTypeCodeType.ITEM_ID, "listingId")
            .put(ItemSortTypeCodeType.LISTING_DURATION, upperCamelCase(ItemSortTypeCodeType.LISTING_DURATION))
            .put(ItemSortTypeCodeType.LISTING_TYPE, "format")
            .put(ItemSortTypeCodeType.NEW_LEAD_COUNT, "questionCount")
            .put(ItemSortTypeCodeType.QUANTITY, "listedQuantity")
            .put(ItemSortTypeCodeType.QUANTITY_AVAILABLE, "availableQuantity")
            .put(ItemSortTypeCodeType.QUESTION_COUNT, "unansweredQuestionCount")
            .put(ItemSortTypeCodeType.RESERVE_PRICE, "auctionReservePrice")
            .put(ItemSortTypeCodeType.SHIPPING_SERVICE_COST, "shippingCost")
            .put(ItemSortTypeCodeType.START_PRICE, "startingBidPrice")
            .put(ItemSortTypeCodeType.START_TIME, "scheduledStartDate")
            .put(ItemSortTypeCodeType.TIME_LEFT, "timeRemaining")
            .put(ItemSortTypeCodeType.TITLE, upperCamelCase(ItemSortTypeCodeType.TITLE))
            .put(ItemSortTypeCodeType.WATCH_COUNT, upperCamelCase(ItemSortTypeCodeType.WATCH_COUNT))
            .build();

    private static final ImmutableMap<ItemSortTypeCodeType, String> cosmosMap = ImmutableMap.<ItemSortTypeCodeType, String>builder()
            .put(ItemSortTypeCodeType.BUYER_EMAIL, ItemSortTypeCodeType.BUYER_EMAIL.value().toLowerCase())
            .put(ItemSortTypeCodeType.BUYER_POSTAL_CODE, "buyerzip")
            .put(ItemSortTypeCodeType.BUYER_USER_ID, "userid")
            .put(ItemSortTypeCodeType.END_TIME, "creationdate")
            .put(ItemSortTypeCodeType.FEEDBACK_LEFT, ItemSortTypeCodeType.FEEDBACK_LEFT.value().toLowerCase())
            .put(ItemSortTypeCodeType.FEEDBACK_RECEIVED, ItemSortTypeCodeType.FEEDBACK_RECEIVED.value().toLowerCase())
            .put(ItemSortTypeCodeType.LISTING_TYPE, "format")
            .put(ItemSortTypeCodeType.RESERVE_PRICE, ItemSortTypeCodeType.RESERVE_PRICE.value().toLowerCase())
            .put(ItemSortTypeCodeType.START_PRICE, ItemSortTypeCodeType.START_PRICE.value().toLowerCase())
            .put(ItemSortTypeCodeType.TOTAL_PRICE, ItemSortTypeCodeType.TOTAL_PRICE.value().toLowerCase())
            .build();

    private static final ImmutableMap<Service, Map<ItemSortTypeCodeType, String>> serviceMap = ImmutableMap.of(
            Service.COSMOS, cosmosMap,
            Service.LAS, lasMap
    );

    private static String negate(String sort) {
        return "-" + sort;
    }

    private static String upperCamelCase(ItemSortTypeCodeType sort) {
        String value = sort.value();
        if (value.length() > 0) {
            value = Character.toLowerCase(value.charAt(0)) + value.substring(1);
        }
        return value;
    }

    public static String map(ItemSortTypeCodeType sort, Service service, String defaultSort) {
        if (sort == null) {
            return StringUtils.EMPTY;
        }

        Map<ItemSortTypeCodeType, String> paramMapping = serviceMap.get(service);
        if (negationMap.containsKey(sort)) {
            String sortString = paramMapping.get(negationMap.get(sort));
            if (sortString == null) {
                return defaultSort;
            }
            return negate(sortString);
        }
        return paramMapping.getOrDefault(sort, defaultSort);
    }
}
