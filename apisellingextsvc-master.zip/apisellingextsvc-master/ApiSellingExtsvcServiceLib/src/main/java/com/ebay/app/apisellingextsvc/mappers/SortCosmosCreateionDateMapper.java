package com.ebay.app.apisellingextsvc.mappers;

import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.SortOrderCodeType;

public class SortCosmosCreateionDateMapper {

    private static final ImmutableMap<SortOrderCodeType, String> mapName
            = new ImmutableMap.Builder<SortOrderCodeType, String>()
            .put(SortOrderCodeType.ASCENDING, "creationdate")
            .put(SortOrderCodeType.DESCENDING, "-creationdate")
            .build();

    private SortCosmosCreateionDateMapper() {

    }

    // default is ASCENDING
    public static String map(SortOrderCodeType input) {
        return mapName.getOrDefault(input, "creationdate");
    }
}
