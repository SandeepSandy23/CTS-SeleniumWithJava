package com.ebay.app.apisellingextsvc.service.bof.saleaggregator;


import java.util.ArrayList;
import java.util.List;

public class SaleAggregatorDataListMock {
    private List<SaleAggregatorDataMock> saleAggregatorList = new ArrayList<>();

    public List<SaleAggregatorDataMock> getSaleAggregatorDatas() {
        return saleAggregatorList;
    }

    public void setSaleAggregatorList(List<SaleAggregatorDataMock> saleAggregatorList) {
        this.saleAggregatorList = saleAggregatorList;
    }
}
