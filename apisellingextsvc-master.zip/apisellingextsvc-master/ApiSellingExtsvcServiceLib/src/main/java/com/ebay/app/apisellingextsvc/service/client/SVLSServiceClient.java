package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.app.apisellingextsvc.service.client.model.svls.SvlsRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ebay.selling.svls.item.Item;

public class SVLSServiceClient extends BaseGingerClient<SvlsRequest, Item> {

    private static final Logger logger = LoggerFactory.getLogger(SVLSServiceClient.class);
    private static final String CLIENT_ID = "svls.item";

    private static final String PATH = "/selling/v1/item/%s/%s?field_group_type=FULL_NO_DESC";

    public SVLSServiceClient() {
        super(Item.class);
    }

    @Override
    public GingerClientResponse<Item> getGingerResponse(GingerClientRequest<SvlsRequest> gingerRequest) {
        return processGetSVLSRequest(getPath(gingerRequest.getRequest()), gingerRequest.getHeaders());
    }

    private String getPath(SvlsRequest svlsRequest) {
        //e.g. http://svls.qa.ebay.com/core/selling/v1/item/350032049955/65521774011?field_group_type=FULL_NO_DESC
        //e.g. http://svls.qa.ebay.com/core/selling/v1/item/{itemid}-{variationid}/65521774011?field_group_type=FULL_NO_DESC
        String url = null;
		if (StringUtils.isNotBlank(svlsRequest.getItemId()) && StringUtils.isNotBlank(svlsRequest.getItemVersionId())) {
			String itemid = null;
			try {
				itemid = (StringUtils.isNotBlank(svlsRequest.getVariationId()) && (Long.parseLong(svlsRequest.getVariationId().trim()) != 0)) ? svlsRequest.getItemId() + "-" + svlsRequest.getVariationId() : svlsRequest.getItemId();
				url = String.format(PATH, itemid, svlsRequest.getItemVersionId());
			} catch (NumberFormatException e) {
				logger.warn("Failed to parse variationId: " + svlsRequest.getVariationId(), e);
				// Ignores invalid variationId & proceeds with itemId
				url = String.format(PATH, itemid, svlsRequest.getItemVersionId());
			}

		}
       return url;
   }
    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
