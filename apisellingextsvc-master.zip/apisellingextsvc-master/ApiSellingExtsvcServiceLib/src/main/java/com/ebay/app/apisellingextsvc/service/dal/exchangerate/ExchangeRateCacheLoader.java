package com.ebay.app.apisellingextsvc.service.dal.exchangerate;

import com.ebay.integ.dal.cache2.CacheLoader;
import com.ebay.integ.dal.cache2.CacheLoaderException;
import com.ebay.integ.dal.cache2.ExternalCacheEntryLoader;
import com.ebay.integ.dal.cache2.FullCacheException;
import com.ebay.integ.dal.cache2.MessageId;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.kernel.context.AppBuildConfig;
import com.ebay.kernel.message.Message;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateUtils;

import java.util.Date;
import java.util.List;

public class ExchangeRateCacheLoader implements CacheLoader {
    private static final long serialVersionUID = -2245388360095602987L;

    public ExchangeRateCacheLoader() {
    }

    public void startup(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        this.load(externalCacheEntryLoader);
    }

    public void refresh(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        this.load(externalCacheEntryLoader);
    }

    private void load(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        try {
            ExchangeRateDAO dao = ExchangeRateDAO.getInstance();
            Date date;
            if (AppBuildConfig.getInstance().isDev() || AppBuildConfig.getInstance().isXStage() || AppBuildConfig.getInstance().isQATE()) {
                 date = DateUtils.addDays(new Date(), -60);
            } else {
                 date = DateUtils.addDays(new Date(), -2);
            }
            Date latestDate = dao.findRateByDay(date).stream().map(ExchangeRate::getDayOfRate).max(Date::compareTo).orElse(new Date());
            List<ExchangeRate> rateByDay = dao.findRateByDay(latestDate);
            if (CollectionUtils.isNotEmpty(rateByDay)) {
                externalCacheEntryLoader.flushCache();
                externalCacheEntryLoader.putInCacheFromList(rateByDay);
            }
        } catch (FinderException | FullCacheException ex) {
            String[] params = new String[] {this.getClass().getName(), ex.getMessage()};
            Message complaint = new Message(MessageId.CACHE_LOADER_FAILURE, params);
            throw new CacheLoaderException(complaint, ex);
        }
    }
}
