package com.ebay.app.apisellingextsvc.tasks.filter;

public interface IFilter {
    void doFilter();
}
