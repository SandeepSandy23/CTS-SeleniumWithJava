package com.ebay.app.apisellingextsvc.audit.comparator;


import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.fasterxml.jackson.databind.JsonNode;


import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;

public abstract class CustomExtComparator extends ExtensiveComparator {
    public static final String TRANSACTION_START_PATH = "root.TransactionArray.Transaction[*]";
    public static final String TRANSACTION_TYPE_IDENTIFICATION_FIELD = "MonetaryDetails";
    private Boolean  isProformaOrder = null;
    private final boolean disablePatternFile;
    private final Map<String, IJsonNodeComparator> jsonNodeComparatorMap = new HashMap<>();

    protected CustomExtComparator(String filePath, String excludeFile, boolean disablePatternFile) {
        super(filePath, excludeFile);
        this.disablePatternFile = disablePatternFile;
    }

    protected CustomExtComparator(String filePath, List<String> excludeFieldList, boolean disablePatternFile) {
        super(filePath, excludeFieldList);
        this.disablePatternFile = disablePatternFile;
    }

    /**
     * add customized Json node comparator. It only supports leaf nodes
     *
     * @param path               json path
     * @param jsonNodeComparator comparator
     */
    protected void addCustomJsonNodeComparator(String path, IJsonNodeComparator jsonNodeComparator) {
        jsonNodeComparatorMap.put(path, jsonNodeComparator);
    }

    @Override
    public boolean compare(JsonNode org, JsonNode tar, IReport report) {
        if (disablePatternFile) {
            return this.compareNode(org, tar, org != null ? org : tar, "root", "N/A", report);
        } else {
            return super.compare(org, tar, report);
        }
    }

    @Override
    public void printDiff(String key, String path, String org, String tar, boolean success, IReport report) {
        super.printDiff(key, path, org, tar, success, report);
    }

    @Override
    protected boolean compareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        String normalizedPath = getNormalizedPath(path);
        if (shouldExcludePath(normalizedPath)) {
            return true;
        }
        if (TRANSACTION_START_PATH.equals(normalizedPath)) {
            extractOrderType(tar == null ? org : tar);
        }
        if (jsonNodeComparatorMap.containsKey(normalizedPath)) {
            try {
                return jsonNodeComparatorMap.get(normalizedPath).customCompareNode(org, tar, pattern, path, key, report);
            } catch (Exception e) {
                CalLogger.warn("CustomExtComparator.compareNode", "path:" + path + ", key:" + key);
                return defaultCompareNode(org, tar, pattern, path, key, report);
            }
        } else {
            return defaultCompareNode(org, tar, pattern, path, key, report);
        }
    }

    public boolean defaultCompareNode(JsonNode org, JsonNode tar, @Nullable JsonNode pattern, String path, String key, IReport report) {
        return super.compareNode(org, tar, pattern, path, key, report);
    }

    @Override
    protected Boolean compareObject(@Nonnull JsonNode org, @Nonnull JsonNode tar, @Nonnull JsonNode pattern,
                                    String path, String key, IReport report) {
        boolean res;
        if (!disablePatternFile) {
            return super.compareObject(org, tar, pattern, path, key, report);
        }
        Boolean childResult = super.compareObject(org, tar, pattern, path, key, report);
        if (childResult != null) {
            return childResult;
        } else {
            res = shouldExcludePath(path);
            if (!res) {
                /*
                 * merge all the field names in org and tar
                 */
                Set<String> mergedFieldNames = new HashSet<>();
                Iterator<String> orgIter = org.fieldNames();
                Iterator<String> tarIter = tar.fieldNames();
                while (orgIter.hasNext()) {
                    mergedFieldNames.add(orgIter.next());
                }
                while (tarIter.hasNext()) {
                    mergedFieldNames.add(tarIter.next());
                }
                Iterator<String> facetNameIter = mergedFieldNames.iterator();

                boolean childRes;
                boolean child;
                for (childRes = true; facetNameIter.hasNext(); childRes = childRes && child) {
                    String name = facetNameIter.next();
                    // make sure that patternNode is not null
                    JsonNode patternNode = org.get(name);
                    if (patternNode == null) {
                        patternNode = tar.get(name);
                    }
                    child = this.compareNode(org.get(name), tar.get(name), patternNode, path + "." + name, key, report);
                }

                res = childRes;
            }

            return res;
        }
    }

    public boolean isProformaOrder() {
        return isProformaOrder != null && isProformaOrder;
    }

    public boolean isCheckoutOrder() {
        return isProformaOrder != null && !isProformaOrder;
    }

    protected String getNormalizedPath(String path) {
        return path.replaceAll("\\[\\d+]", "[*]");
    }

    protected boolean shouldExcludePath(String path) {
        return this.excludes.contains(path);
    }

    /**
     * check whether it is a proforma order
     *
     * @param tar json node of new tradingApi
     */
    protected void extractOrderType(@Nonnull JsonNode tar) {
        this.isProformaOrder = tar.get(TRANSACTION_TYPE_IDENTIFICATION_FIELD) == null;
    }
}