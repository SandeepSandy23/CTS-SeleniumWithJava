package com.ebay.app.apisellingextsvc.audit.comparator;

import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.ebay.app.apisellingextsvc.common.logger.ILogger;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ExtensiveComparator extends JsonTemplateComparator {
    private List<IFacetComparator> facetComparators = new ArrayList();

    public ExtensiveComparator(String filePath, String excludeFile) {
        super(filePath, excludeFile);
    }

    public ExtensiveComparator(String filePath, List<String> excludeFieldList) {
        super(filePath, excludeFieldList);
    }

    public ExtensiveComparator(ILogger logger, String filePath, String excludeFile) {
        super(logger, filePath, excludeFile);
    }

    public ExtensiveComparator(ILogger logger, String filePath, List<String> excludeFieldList) {
        super(logger, filePath, excludeFieldList);
    }

    public final void addFacetComparators(IFacetComparator facetComparator) {
        this.facetComparators.add(facetComparator);
    }

    protected Boolean compareArray(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        return this.compareUsingFacetComparators(org, tar, pattern, path, key, report);
    }

    protected Boolean compareObject(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        return this.compareUsingFacetComparators(org, tar, pattern, path, key, report);
    }

    private Boolean compareUsingFacetComparators(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        if (this.excludes.contains(path)) {
            return true;
        } else {
            Iterator var7 = this.facetComparators.iterator();

            IFacetComparator facetComparator;
            do {
                if (!var7.hasNext()) {
                    return null;
                }

                facetComparator = (IFacetComparator)var7.next();
            } while(!facetComparator.qualified(org, tar, path));

            return facetComparator.compare(org, tar, path, pattern, key, report);
        }
    }
}

