package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.mappers.PaymentHoldReasonMapper;
import com.ebay.app.apisellingextsvc.mappers.PaymentHoldReleaseActionMapper;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.AttributeGroup;
import com.ebay.order.common.v1.DistributionType;
import com.ebay.order.common.v1.PaymentHoldDetailsType;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.PaymentHoldDetailType;
import ebay.apis.eblbasecomponents.RequiredSellerActionArrayType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import java.util.Optional;


public class PaymentHoldDetailsBuilder extends BaseFacetBuilder<PaymentHoldDetailType> {

    private static final String DECISION_REASON = "DecisionReason";
    private static final String TRANSACTION_RISK_HOLD_DECISION = "TransactionRiskHoldDecision";
    private final OrderCSXType order;

    public PaymentHoldDetailsBuilder(Task<?> task, OrderCSXType order) {
        super(task);
        this.order = order;
    }

    @Override
    protected PaymentHoldDetailType doBuild() {
        PaymentHoldDetailType res = null;
        //folow the logic in COMSPaymentHoldDetailsBuilder -> buildPaymentHoldDetails
        PaymentHoldDetailsType paymentHoldDetails =
                PaymentUtil.getPaymentDistribution(order.getPayments(), ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_SELLER)
                        .map(DistributionType::getPaymentHoldDetails).orElse(null);
        if (paymentHoldDetails != null) {
            res = new PaymentHoldDetailType();
            if (paymentHoldDetails.getReleaseDate() != null) {
                res.setExpectedReleaseDate(DateUtil.convertToXMLGregorianCalendar(paymentHoldDetails.getReleaseDate()));
            }

            //Populate Seller Action To Release
            if (StringUtils.isNotEmpty(paymentHoldDetails.getSellerActionToRelease())) {
                String releaseAction = paymentHoldDetails.getSellerActionToRelease();
                RequiredSellerActionArrayType requredSellerActionArrary = new RequiredSellerActionArrayType();
                requredSellerActionArrary.getRequiredSellerAction().add(PaymentHoldReleaseActionMapper.map(releaseAction));
                res.setRequiredSellerActionArray(requredSellerActionArrary);
            }

            //Populate Payment Hold Reason
            String holdReason = getHoldReason(paymentHoldDetails);
            if (StringUtils.isNotEmpty(holdReason)) {
                res.setPaymentHoldReason(PaymentHoldReasonMapper.map(holdReason));
            }
        }
        return res;
    }

    private String getHoldReason(PaymentHoldDetailsType paymentHoldDetails) {

        return Optional.of(paymentHoldDetails)
                .map(PaymentHoldDetailsType::getAttributeGroups)
                .flatMap(ag -> ag.stream().filter(it -> TRANSACTION_RISK_HOLD_DECISION.equalsIgnoreCase(it.getType())).findFirst()
                        .map(AttributeGroup::getAttribute))
                .filter(CollectionUtils::isNotEmpty)
                .map(attr -> AttributeUtil.findAttributes(attr, DECISION_REASON))
                .map(Attribute::getValue)
                .orElse(null);
    }
}
