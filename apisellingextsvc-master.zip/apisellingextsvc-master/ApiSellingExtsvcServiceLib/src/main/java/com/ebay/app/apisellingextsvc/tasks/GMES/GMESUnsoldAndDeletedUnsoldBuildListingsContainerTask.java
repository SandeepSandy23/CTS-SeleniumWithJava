package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.builders.ItemShippingDetailsBuilder;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.service.invokers.model.BulkUserInfoModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.ItemProfilesModel;
import com.ebay.app.apisellingextsvc.utils.ListingCodeTypeUtil;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.ErrorType;
import ebay.apis.eblbasecomponents.ItemPolicyViolationType;
import ebay.apis.eblbasecomponents.ItemType;
import ebay.apis.eblbasecomponents.ListingTypeCodeType;
import ebay.apis.eblbasecomponents.PaginationType;
import ebay.apis.eblbasecomponents.SellingStatusType;
import org.apache.commons.lang3.tuple.Pair;

import java.util.List;
import java.util.Optional;

import static com.ebay.app.apisellingextsvc.tasks.GMES.ListingActivitiesUtil.getActualEndTime;

public class GMESUnsoldAndDeletedUnsoldBuildListingsContainerTask extends GMESBuildListingsContainerTask {
    private final ContentResource contentResource;

    public GMESUnsoldAndDeletedUnsoldBuildListingsContainerTask(Task<?> task, PaginationType paginationType,
                                                                ContentResource contentResource,
                                                                List<ErrorType> errorList, boolean includeNotes,
                                                                boolean isHideVariations) {
        super(task, paginationType, contentResource, errorList, includeNotes, isHideVariations);
        this.contentResource = contentResource;
    }

    @Override
    protected void populateItemType(ItemType itemType, ListingActivitiesDetail listingActivity, BulkUserInfoModel bulkUserInfoModel, ItemProfilesModel bpItemProfilesModel) {
        super.populateItemType(itemType, listingActivity, bulkUserInfoModel, bpItemProfilesModel);
        itemType.setShippingDetails(removeZeroShippingCostOptions(new ItemShippingDetailsBuilder(null, listingActivity, null).doBuild(), listingActivity));
        Optional.of(itemType).map(ItemType::getListingDetails).ifPresent(listingDetails -> listingDetails.setEndTime(getActualEndTime(listingActivity)));
        Boolean isRelistedAlready = ListingActivitiesUtil.getRelistedAlready(listingActivity);
        if (isRelistedAlready) {
            itemType.setRelisted(true);
        }
        ItemPolicyViolationType itemPolicyViolation = ListingActivitiesUtil.getPolicyViolationNotes(listingActivity, contentResource.contentHelper);
        itemType.setItemPolicyViolation(itemPolicyViolation);
        ListingTypeCodeType listingType = ListingActivitiesUtil.getListingCodeType(listingActivity);
        if (itemType.getSellingStatus() != null) { //redundant safety check (sellingStatus is nonnull in superclass)
            SellingStatusType sellingStatus = itemType.getSellingStatus();
            sellingStatus.setReserveMet(null);
            sellingStatus.setQuantitySold(null);
            if (itemPolicyViolation != null) {
                sellingStatus.setAdminEnded(true);
            }
            if (ListingCodeTypeUtil.isClassifiedAdType(listingType)) {
                Pair<AmountType, AmountType> currentPrices = ListingActivitiesUtil.getLowestFixedPrices(listingActivity);
                sellingStatus.setCurrentPrice(currentPrices.getKey());
                sellingStatus.setConvertedCurrentPrice(currentPrices.getValue());
            }
        }
    }
}
