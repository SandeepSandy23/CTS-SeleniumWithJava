package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.LogisticUtil;
import com.ebay.app.apisellingextsvc.utils.PriceLineAmountUtil;
import com.ebay.app.apisellingextsvc.utils.ProgramUtil;
import com.ebay.app.apisellingextsvc.utils.ShippingServiceUtil;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.ShippingServiceOptionsType;
import org.apache.commons.lang3.StringUtils;


public class OrderShippingServiceSelectedBuilder extends ShippingBuilder {
    private static final String NOT_SELECTED = "NotSelected";
    private final OrderCSXType order;
    private final String lineItemId;
    private final int trxVersion;

    public OrderShippingServiceSelectedBuilder(Task<?> task, OrderCSXType order, String lineItemId, int trxVersion) {
        super(task);
        this.order = order;
        this.lineItemId = lineItemId;
        this.trxVersion = trxVersion;
    }

    @Override
    protected ShippingServiceOptionsType doBuild() {
        ShippingServiceOptionsType shippingServiceOptionsType = new ShippingServiceOptionsType();
        String shippingMethodCode = getShippingMethodCode();
        if (StringUtils.isNotEmpty(shippingMethodCode)) {
            shippingServiceOptionsType.setShippingService(shippingMethodCode);
            AmountType shippingServiceCost = ShippingServiceUtil.getShippingServiceCost(lineItemId, order);
            shippingServiceOptionsType.setShippingServiceCost(shippingServiceCost);
        } else {
            shippingServiceOptionsType.setShippingService(NOT_SELECTED);
        }
        shippingServiceOptionsType.setImportCharge(PriceLineAmountUtil.getPriceLineAmount(PricelineTypeEnum.IMPORT_CHARGES, order));
        shippingServiceOptionsType.getShippingPackageInfo().addAll(getShippingPackageInfo(order, lineItemId, trxVersion));
        
        return shippingServiceOptionsType;
    }

    private String getShippingMethodCode() {
        return LogisticUtil.getDigitalDeliveryPlan(order.getLogistics()).map(e -> ApiSellingExtSvcConstants.SHIPPING_METHOD_CODE_OVERNIGHT)
                .orElseGet(() -> {
                    if (ProgramUtil.containsProgram(order, ProgramEnumType.PSA)) {
                        return LogisticUtil.getShippingMethodByIsIntermediated(order.getLogistics(), true);
                    } else {
                        return LogisticUtil.getShippingMethodByIsIntermediated(order.getLogistics(), false);
                    }
                });
    }
}
