package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.*;
import com.ebay.kernel.collection.LongKeyHashMap;

import java.util.*;

public class ItemHostToupleProvider extends ToupleProvider {
    private static Map s_staticMap = new HashMap();
    private static FindItemComparator s_findItemComparator = new FindItemComparator();
    protected final String m_itemIdHintName;
    protected final String m_userIdHintName;
    protected final String m_itemHostIdHintName;
    protected final String m_catyGroupIdHintName;
    protected final String m_physicalTableName;
    protected final String m_customerReferenceHintName;
    private LongKeyHashMap m_primaryTouplesByHostIdMap;
    private LongKeyHashMap m_readOnlyTouplesByHostIdMap;
    private boolean m_itemIdHintRequired;
    private boolean m_forSequence;
    private RangeBasedToupleHolder[] m_toupleHolderArray;


    public ItemHostToupleProvider(String physicalTableName, String itemIdHintName,
                                  String itemHostIdHintName, boolean itemIdHintRequired) throws DDRMisconfiguredException {
        this(DdrInfoFactory.getInstance(), physicalTableName, itemIdHintName, null, itemHostIdHintName,
                "m_catyGroupId", "m_genericHint", itemIdHintRequired, false);
    }

    public ItemHostToupleProvider(DdrInfo ddrInfo, String physicalTableName, String itemIdHintName, String userIdHintName, String itemHostIdHintName,
                                  String catyGroupIdHintName, String customerReferenceHintName, boolean itemIdHintRequired, boolean forSequence) {
        if (physicalTableName == null) {
            DDRExceptionHelper.throwDDRMisconfiguredException(this, (Map) null,
                    "Physical Table Name passed to the Touple Provider Constructor is null.  You have to provide a valid non-null value.");
        }

        if (ddrInfo == null) {
            DDRExceptionHelper.throwDDRMisconfiguredException(this, (Map) null,
                    "DDRInfo instance passed to the Touple Provider Constructor is null.  You have to provide a valid non-null value.");
        }

        if (itemIdHintName == null && itemIdHintRequired) {
            DDRExceptionHelper.throwDDRMisconfiguredException(this, (Map) null,
                    "Item ID hint name passed to the Touple Provider Constructor is null.  You have to provide a valid non-null value.");
        }

        this.m_physicalTableName = physicalTableName;
        this.m_itemIdHintName = itemIdHintName;
        this.m_itemHostIdHintName = itemHostIdHintName;
        this.m_itemIdHintRequired = itemIdHintRequired;
        this.m_forSequence = forSequence;
        this.m_userIdHintName = userIdHintName;
        this.m_catyGroupIdHintName = catyGroupIdHintName;
        this.m_customerReferenceHintName = customerReferenceHintName;
        synchronized (s_staticMap) {
            ItemHostInfoHolder itemHostInfoHolder = (ItemHostInfoHolder) s_staticMap.get(ddrInfo);
            if (itemHostInfoHolder == null) {
                try {
                    List itemHostInfoList = ItemHostInfoDAO.getInstance().findAllDirect2DB();
                    ItemHostInfo[] rangeSortedArray = new ItemHostInfo[itemHostInfoList.size()];

                    for (int i = 0; i < itemHostInfoList.size(); ++i) {
                        rangeSortedArray[i] = (ItemHostInfo) itemHostInfoList.get(i);
                    }

                    Arrays.sort(rangeSortedArray, new ItemHostInfoByRangeStartComparator());
                    itemHostInfoHolder = new ItemHostInfoHolder(rangeSortedArray);
                } catch (FinderException var16) {
                    DDRExceptionHelper.throwDDRMisconfiguredException(this, (Map) null, var16.getMessage());
                }

                s_staticMap.put(ddrInfo, itemHostInfoHolder);
            }

            this.initLists(ddrInfo, itemHostInfoHolder.m_rangeSortedArray);
        }

    }

    @Override
    public List getTouples(Map hints) throws DDRException {
        boolean hasReadOnlyHint = this.hasReadOnlyItemHostHint((Map) hints);
        boolean hasReadFailOverOnMarkDownHint = this.hasReadFailOverOnMarkDownHint((Map) hints);
        Number itemId = (Number) ((Map) hints).get(this.m_itemIdHintName);
        Number hostId = (Number) ((Map) hints).get(this.m_itemHostIdHintName);
        Number userId = (Number) ((Map) hints).get(this.m_userIdHintName);
        Number catyGroupId = (Number) ((Map) hints).get(this.m_catyGroupIdHintName);
        List retVal = new ArrayList();
        DetailedTableTouple touple = null;
        if (itemId == null && this.m_itemIdHintRequired) {
            DDRExceptionHelper.throwDDRMisconfiguredException(this, (Map) hints, "The required item id hint was not passed in the hint map.");
        }
        if (itemId != null && hostId != null) {
            DDRExceptionHelper.throwDDRMisconfiguredException(this, (Map) hints, "Both hints " + this.getItemIdHintName() +
                    " and " + this.getItemHostIdHintName() + " were passed to the Query Engine, but only one is allowed.");
        }

        if (catyGroupId != null && userId == null) {
            DDRExceptionHelper.throwDDRMisconfiguredException(this, (Map) hints, "Insufficient hints passed to the Query Engine. " +
                    "Need catyGroupId AND userId.");
        }

        if (itemId != null) {
            int foundIndex = Arrays.binarySearch(this.m_toupleHolderArray, itemId, s_findItemComparator);
            if (foundIndex > -1) {
                if (hasReadFailOverOnMarkDownHint) {
                    retVal.add(this.m_toupleHolderArray[foundIndex].getPrimaryTouple().clone());
                    DetailedTableTouple readOnlyTouple = this.m_toupleHolderArray[foundIndex].getReadOnlyTouple();
                    DetailedTableTouple failOverTouple = new DetailedTableTouple(readOnlyTouple.getPhysicalTable(),
                            null, readOnlyTouple.getLogicalHost(), DdrToupleType.FAILOVER);
                    retVal.add(failOverTouple);
                } else {
                    touple = this.m_toupleHolderArray[foundIndex].getTouple(hasReadOnlyHint);
                    retVal.add(touple);
                }

                return retVal;
            }
        }
        return retVal;
    }

    @Override
    public List getAllPossibleTouples(Map hints) throws DDRException {
        return getAllPossibleTouples();
    }

    @Override
    public List getAllPossibleTouples() throws DDRException {
        List result = new ArrayList();
        result.addAll(this.m_primaryTouplesByHostIdMap.values());
        result.addAll(this.m_readOnlyTouplesByHostIdMap.values());
        return result;
    }

    @Override
    public ToupleProvider getRefreshInstance(DdrInfo ddrInfo) throws DDRMisconfiguredException {
        return new ItemHostToupleProvider(ddrInfo, this.m_physicalTableName, this.m_itemIdHintName,
                this.m_userIdHintName, this.m_itemHostIdHintName, this.m_catyGroupIdHintName, this.m_customerReferenceHintName,
                this.m_itemIdHintRequired, this.m_forSequence);
    }

    private String getItemHostIdHintName() {
        return m_itemHostIdHintName;
    }

    private void initLists(DdrInfo ddrInfo, ItemHostInfo[] itemHostInfoArray) {
        this.m_primaryTouplesByHostIdMap = new LongKeyHashMap();
        this.m_readOnlyTouplesByHostIdMap = new LongKeyHashMap();
        this.m_toupleHolderArray = new RangeBasedToupleHolder[itemHostInfoArray.length];
        long lastRangeEnd = -1L;

        for (int i = 0; i < itemHostInfoArray.length; ++i) {
            ItemHostInfo doObj = itemHostInfoArray[i];
            DetailedTableTouple primaryTouple = new DetailedTableTouple(this.m_physicalTableName,
                    ddrInfo, doObj.getPrimaryHostName().toLowerCase());
            this.m_primaryTouplesByHostIdMap.put(doObj.getHostId(), primaryTouple);
            DetailedTableTouple readOnlyTouple = new DetailedTableTouple(this.m_physicalTableName,
                    ddrInfo, doObj.getReadOnlyHostName().toLowerCase());
            this.m_readOnlyTouplesByHostIdMap.put(doObj.getHostId(), readOnlyTouple);
            this.m_toupleHolderArray[i] = new RangeBasedToupleHolder(doObj.getRangeStart(), doObj.getRangeEnd(), primaryTouple, readOnlyTouple);
            if (doObj.getRangeStart() <= lastRangeEnd) {
                DDRExceptionHelper.throwDDRMisconfiguredException(this, (Map) null,
                        "Category Item ID Range Overlap in ITEM_HOST_ITEM_ID_RANGE. Host ID: " + doObj.getHostId() +
                                "; Range Start: " + doObj.getRangeStart() + "; Previous Range End: " + lastRangeEnd);
            }

            lastRangeEnd = doObj.getRangeEnd();
        }

    }

    private boolean hasReadOnlyItemHostHint(Map hints) {
        Boolean ret = (Boolean) hints.get("m_useReadOnlyItemHosts");
        return ret != null && ret;
    }

    private boolean hasReadFailOverOnMarkDownHint(Map hints) {
        return hints.containsKey("readFailoverOnMarkdown");
    }

    public String getItemIdHintName() {
        return this.m_itemIdHintName;
    }

}
