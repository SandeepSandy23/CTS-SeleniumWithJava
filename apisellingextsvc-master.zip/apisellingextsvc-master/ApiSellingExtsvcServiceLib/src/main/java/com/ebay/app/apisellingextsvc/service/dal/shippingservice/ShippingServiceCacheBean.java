package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.integ.dal.cache2.BaseIntegCacheBean;
import com.ebay.integ.dal.cache2.CacheBeanInitializationException;
import com.ebay.kernel.bean.configuration.ConfigCategoryCreateException;

public class ShippingServiceCacheBean extends BaseIntegCacheBean {
    public static final String CATEGORY_ID = "ebay.dal.CacheObject.ShippingService";
    private static ShippingServiceCacheBean m_Instance = null;

    private ShippingServiceCacheBean() throws ConfigCategoryCreateException {
        super(createBeanConfigCategoryInfo(CATEGORY_ID,
                "com.ebay.domain.core.integ.CacheObject.ShippingService",
                "com.ebay.integ.CacheObject"),
                true,
                "ShippingService",
                new ShippingServiceCacheLoader(),
                ShippingServiceKeyManager.getInstance(),
                86400,
                "1:00",
                180,
                true,
                true,
                -1,
                2000,
                true);
    }

    public static ShippingServiceCacheBean getInstance() {
        if (m_Instance == null) {
            try {
                m_Instance = new ShippingServiceCacheBean();
            } catch (ConfigCategoryCreateException var1) {
                throw new CacheBeanInitializationException(var1, "ShippingServiceCacheBean");
            }
        }

        return m_Instance;
    }
}
