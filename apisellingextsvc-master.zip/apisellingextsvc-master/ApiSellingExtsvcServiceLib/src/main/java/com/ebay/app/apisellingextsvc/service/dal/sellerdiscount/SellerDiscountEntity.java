package com.ebay.app.apisellingextsvc.service.dal.sellerdiscount;


import com.ebay.integ.dal.DalDOI;
import com.ebay.persistence.HiddenLocal;
import com.ebay.persistence.HiddenLocals;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "SELLER_DISCOUNT_ENTITY_%")
@com.ebay.persistence.Table(alias = "S")
@HiddenLocals({@HiddenLocal(attrName = "entityIdColumnSwitcher", defaultType = 3)})
public interface SellerDiscountEntity extends DalDOI {
    @Id
    @Column(name = "SELLER_DISCOUNT_ENTITY_ID")
    long getSellerDiscountEntityId();

    void setSellerDiscountEntityId(long var1);

    @Id
    @Column(name = "PARTITION_KEY")
    int getPartitionKey();

    void setPartitionKey(int var1);

    @Column(name = "BUYER_ID")
    long getBuyerId();

    void setBuyerId(long var1);

    @Column(name = "SELLER_ID")
    long getSellerId();

    void setSellerId(long var1);

    @Column(name = "CHECKOUT_CART_ID")
    long getCheckoutCartId();

    void setCheckoutCartId(long var1);

    @Column(name = "ITEM_ID")
    long getItemId();

    void setItemId(long var1);

    @Column(name = "TRANSACTION_ID")
    long getTransactionId();

    void setTransactionId(long var1);

    @Column(name = "ORDER_ID")
    long getOrderId();

    void setOrderId(long var1);

    @Column(name = "TRANSACTION_QUANTITY")
    long getTransactionQuantity();

    void setTransactionQuantity(long var1);

    @Column(name = "ORIGINAL_ITEM_PRICE")
    double getOriginalItemPrice();

    void setOriginalItemPrice(double var1);

    @Column(name = "ITEM_PRICE")
    double getItemPrice();

    void setItemPrice(double var1);

    @Column(name = "SHIPPING_FEE")
    double getShippingFee();

    void setShippingFee(double var1);

    @Column(name = "SHIPPING_DISCOUNT_AMOUNT")
    double getShippingDiscountAmount();

    void setShippingDiscountAmount(double var1);

    @Column(name = "CURRENCY_ID")
    int getCurrencyId();

    void setCurrencyId(int var1);

    @Column(name = "ORIGINAL_SHIPPING_SERVICE")
    int getOriginalShippingService();

    void setOriginalShippingService(int var1);

    @Column(name = "PROMO_SHIPPING_SERVICE")
    int getPromoShippingService();

    void setPromoShippingService(int var1);

    @Column(name = "DISCOUNT_STATUS")
    int getDiscountStatus();

    void setDiscountStatus(int var1);

    @Column(name = "SELLER_CAMPAIGN_ID")
    long getSellerCampaignId();

    void setSellerCampaignId(long var1);

    @Column(name = "RULE_INSTANCE_ID")
    long getRuleInstanceId();

    void setRuleInstanceId(long var1);

    @Column(name = "PRIMARY_ITEM_ID")
    long getPrimaryItemId();

    void setPrimaryItemId(long var1);

    @Column(name = "CREATION_DATE")
    Date getCreationDate();

    void setCreationDate(Date var1);

    @Column(name = "LAST_MODIFIED_DATE")
    Date getLastModifiedDate();

    void setLastModifiedDate(Date var1);

    @Column(name = "SELLER_PRODUCT_BUNDLE_ID")
    long getSellerProductBundleId();

    void setSellerProductBundleId(long var1);

    @Column(name = "DEBUG_INFO")
    String getDebugInfo();

    void setDebugInfo(String var1);

    @Column(name = "TITLE")
    String getTitle();

    void setTitle(String var1);

    @Column(name = "TRANSACTION_DATE")
    Date getTransactionDate();

    void setTransactionDate(Date var1);

    @Column(name = "FLAGS01")
    long getFlags01();

    void setFlags01(long var1);

    @Column(name = "SELLER_PRODUCT")
    String getSellerProduct();

    void setSellerProduct(String var1);

    @Column(name = "PROCESSED_FLAG")
    int getProcessedFlag();

    void setProcessedFlag(int var1);

    @Column(name = "OFFERCHECKSUMID")
    long getOfferchecksumid();

    void setOfferchecksumid(long var1);

    @Column(name = "OFFER_TIER")
    String getOfferTier();

    void setOfferTier(String var1);

    @Column(name = "OFFER_RANK")
    int getOfferRank();

    void setOfferRank(int var1);

    @Column(name = "OFFER_TYPE")
    int getOfferType();

    void setOfferType(int var1);

    @Column(name = "OFFER_SUB_TYPE")
    int getOfferSubType();

    void setOfferSubType(int var1);

    @Column(name = "SHIPPING_DISCOUNT_STATUS")
    int getShippingDiscountStatus();

    void setShippingDiscountStatus(int var1);

    @Column(name = "OFFER_MESSAGE")
    String getOfferMessage();

    void setOfferMessage(String var1);

    @Column(name = "OFFER_CONDITIONAL_MESSAGE")
    String getOfferConditionalMessage();

    void setOfferConditionalMessage(String var1);
}
