package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.PickupStatusEnumType;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.PickupStatusCodeType;

public class PickupStatusMapper {
    private static final ImmutableMap<PickupStatusEnumType, PickupStatusCodeType> mapName
            = new ImmutableMap.Builder<PickupStatusEnumType, PickupStatusCodeType>()
            .put(PickupStatusEnumType.INVALID, PickupStatusCodeType.INVALID)
            .put(PickupStatusEnumType.NOT_APPLICABLE, PickupStatusCodeType.NOT_APPLICABLE)
            .put(PickupStatusEnumType.PENDING_MERCHANT_CONFIRMATION, PickupStatusCodeType.PENDING_MERCHANT_CONFIRMATION)
            .put(PickupStatusEnumType.READY_FOR_PICKUP, PickupStatusCodeType.READY_TO_PICKUP)
            .put(PickupStatusEnumType.PICKED_UP, PickupStatusCodeType.PICKEDUP)
            .put(PickupStatusEnumType.PICKUP_CANCELLED_OUT_OF_STOCK, PickupStatusCodeType.PICKUP_CANCELLED_OUT_OF_STOCK)
            .put(PickupStatusEnumType.PICKUP_CANCELLED_BUYER_REJECTED, PickupStatusCodeType.PICKUP_CANCELLED_BUYER_REJECTED)
            .put(PickupStatusEnumType.PICKUP_CANCELLED_BUYER_NO_SHOW, PickupStatusCodeType.PICKUP_CANCELLED_BUYER_NO_SHOW)
            .put(PickupStatusEnumType.READY_FOR_VALET_PICKUP, PickupStatusCodeType.NOT_APPLICABLE)                       //ng extra field
            .put(PickupStatusEnumType.VALET_ASSIGNED, PickupStatusCodeType.NOT_APPLICABLE)                               //ng extra field
            .put(PickupStatusEnumType.VALET_PICKEDUP_ORDER, PickupStatusCodeType.NOT_APPLICABLE)                         //ng extra field
            .put(PickupStatusEnumType.PICKUP_PENDING_MERCHANT_CONFIRMATION, PickupStatusCodeType.NOT_APPLICABLE)         //ng extra field
            .put(PickupStatusEnumType.DEFAULT, PickupStatusCodeType.NOT_APPLICABLE)                                      //ng extra field
            .build();


    private PickupStatusMapper() {
    }

    public static PickupStatusCodeType map(PickupStatusEnumType pickupStatus) {
        return mapName.getOrDefault(pickupStatus, PickupStatusCodeType.NOT_APPLICABLE);
    }

}
