package com.ebay.app.apisellingextsvc.framework.outputselector;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;
import java.util.Map.Entry;

public class GraphMap implements Serializable {

    /**
     * <pre>
     * Graph map serve two purpose
     * 1. Store overall field hierarchy for response class. In this case Map key = current field name,
     * value = a set of customNode for this field name.
     * We need to map field name to a list of node because field can have different path from top to bottom.
     *
     * 2. Store relationship between field and parent field (used in serialization). In this case Map key = current field name,
     * value = a set of parent customNode for this field.
     * We need this relationship to make sure current path is match our intention.
     *
     * </pre>
     */
    private final Map<String, List<com.ebay.app.apisellingextsvc.framework.outputselector.CustomNode>> mp = new HashMap<>();

    public void put(com.ebay.app.apisellingextsvc.framework.outputselector.CustomNode node) {
        mp.computeIfAbsent(node.getClazz().getSimpleName().toLowerCase(Locale.US), k -> new ArrayList<>()).add(node);
    }

    public void put(String key, com.ebay.app.apisellingextsvc.framework.outputselector.CustomNode val) {
        mp.computeIfAbsent(key, k -> new ArrayList<>()).add(val);
    }

    public List<com.ebay.app.apisellingextsvc.framework.outputselector.CustomNode> get(String key) {
        return mp.get(key);
    }

    public Map<String, List<com.ebay.app.apisellingextsvc.framework.outputselector.CustomNode>> getMap() {
        return this.mp;
    }

    public boolean contain(String key) {
        return mp.containsKey(key);
    }

    public boolean containField(String key, String parentFieldName) {
        if (mp.containsKey(key)) {
            return mp.get(key).stream()
                    .anyMatch(it -> parentFieldName.equals(it.getFieldName())
                            || parentFieldName.equalsIgnoreCase(it.getClazz().getSimpleName()));
        }
        return false;
    }

    public void combine(GraphMap other) {
        if (other != null) {
            for (Entry<String, List<com.ebay.app.apisellingextsvc.framework.outputselector.CustomNode>> en : other.getMap().entrySet()) {
                mp.computeIfAbsent(en.getKey(), k -> new ArrayList<>()).addAll(en.getValue());
            }
        }
    }

    /**
     * Always treat de-serialization as a full-blown constructor, by validating the final state of the de-serialized object.
     */
    private void readObject(
            ObjectInputStream inputStream
    ) throws ClassNotFoundException, IOException {
        //always perform the default de-serialization first
        inputStream.defaultReadObject();

    }

    /**
     * This is the default implementation of writeObject. Customise if necessary.
     */
    private void writeObject(
            ObjectOutputStream outputStream
    ) throws IOException {
        //perform the default serialization for all non-transient, non-static fields
        outputStream.defaultWriteObject();
    }
}
