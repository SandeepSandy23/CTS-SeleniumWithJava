package com.ebay.app.apisellingextsvc.service.bof.saleaggregator;

import com.ebay.af.common.flag.FlagMask;
import com.ebay.app.apisellingextsvc.service.dal.saleaggregator.SaleAggregator;

public class SaleAggregatorDataMock implements SaleAggregator {
    private String sellerProId;

    private long itemId;

    private long sellerId;

    @Override
    public String getSellerProId() {
        return sellerProId;
    }

    @Override
    public void setSellerProId(String sellerProdId) {
        this.sellerProId = sellerProdId;
    }

    @Override
    public long getItemId() {
        return itemId;
    }

    @Override
    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    @Override
    public long getSellerId() {
        return sellerId;
    }

    @Override
    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }
    

    @Override
    public boolean equalsData(Object o) {
        return false;
    }

    @Override
    public boolean hasFlag(FlagMask flagMask) {
        return false;
    }

    @Override
    public void setFlag(FlagMask flagMask, boolean b) {

    }
}
