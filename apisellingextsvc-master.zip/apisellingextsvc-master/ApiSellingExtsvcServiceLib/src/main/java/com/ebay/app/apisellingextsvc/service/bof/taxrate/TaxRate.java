package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import java.util.Date;

public interface TaxRate extends TaxRateCodeGen {
    boolean isEffective(Date var1);
}
