package com.ebay.app.apisellingextsvc.service.dal.useraddress;

import com.ebay.af.common.flag.BaseMaskBackingFlag;
import com.ebay.af.common.flag.FlagMask;

public class UserAddressFlags extends BaseMaskBackingFlag {

    private static final int BUYERS_CONSENT_TO_SHOW_PHONE_NUMBER_MASK = 8192;

    public static final FlagMask BUYERS_CONSENT_TO_SHOW_PHONE_NUMBER =
            FlagMask.createFlagMask("BuyersConsentToShowPhonenumber", 1,
                    BUYERS_CONSENT_TO_SHOW_PHONE_NUMBER_MASK);

    protected UserAddressFlags(int id, String name) {
        super(id, name);
    }
}
