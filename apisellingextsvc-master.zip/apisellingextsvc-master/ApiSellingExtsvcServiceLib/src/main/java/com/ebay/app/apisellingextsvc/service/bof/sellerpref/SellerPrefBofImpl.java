package com.ebay.app.apisellingextsvc.service.bof.sellerpref;

import com.ebay.integ.dal.dao.FinderException;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPref;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPrefDAO;

public class SellerPrefBofImpl implements ISellerPrefBof {

    @Override
    public SellerPref findBySellerId(long sellerId) {
        try {
            return SellerPrefDAO.getInstance().findByPrimaryKey(sellerId);
        } catch (FinderException e) {
            CalLogger.warn("failed to load seller pref with sellerId",
                    "sellerId = " + sellerId + " - " + e.getMessage());
        }

        return null;
    }
}
