package com.ebay.app.apisellingextsvc.service.dal.userlookup;

import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.DDRException;
import com.ebay.integ.dal.ddr.DDRExceptionHelper;
import com.ebay.integ.dal.ddr.DDRMisconfiguredException;
import com.ebay.integ.dal.ddr.DdrInfo;
import com.ebay.integ.dal.ddr.DetailedTableTouple;
import com.ebay.integ.dal.ddr.ToupleProvider;
import com.ebay.integ.dal.ddr.rt.DDRMain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UserLookupTupleProvider extends ToupleProvider {

    private final String physicalTableName;
    private final String logicalHostNameTemp;
    private final int minHost;
    private final int maxHost;
    private final String shardingField;

    private final List<DetailedTableTouple> touples = new ArrayList<>();

    public UserLookupTupleProvider(String physicalTableName, String logicalHostNameTemp, int minHost, int maxHost, String shardingField) {

        this.physicalTableName = physicalTableName;
        this.logicalHostNameTemp = logicalHostNameTemp;
        this.minHost = minHost;
        this.maxHost = maxHost;
        this.shardingField = shardingField;

        DDRMain ddrInfo = DDRMain.getInstance();
        for (int i = minHost; i <= maxHost; i ++) {
            String logicalHostName = logicalHostNameTemp.replace("%", String.valueOf(i));
            touples.add(new DetailedTableTouple(physicalTableName, ddrInfo, logicalHostName));
        }
    }

    @Override
    public List getTouples(Map hints) {

        if (!hints.containsKey(shardingField)) {
            DDRExceptionHelper.throwDDRMisconfiguredException(
                    this, hints, "Required " + shardingField + " hint was not passed to the Query Engine"
            );
        }

        Object val = hints.get(shardingField);

        long id = 0;
        if (val instanceof Long) {
            id = (Long) val;
        } else if (val instanceof Integer) {
            id = ((Integer)val).longValue();
        } else {
            String details = shardingField + " hint must be either Long or Integer.  Value passed: "
                    + val + " was of type " + val.getClass().getName();
            DDRExceptionHelper.throwDDROutOfRangeException(this, hints, details);
        }

        if (id < 0) {
            String details = shardingField + " hint must be a non-negative number.  Value passed: " + val;
            DDRExceptionHelper.throwDDROutOfRangeException(this, hints, details);
        }

        List<DetailedTableTouple> result = new ArrayList<>();

        try {
            UserLookup userLookup = UserLookupDAO.getInstance().findByUserId(id);
            if (userLookup.getHostId01() < minHost || userLookup.getHostId01() > maxHost) {
                String details = "target host " + userLookup.getHostId01() + "is not from " + minHost + " to " + maxHost;
                DDRExceptionHelper.throwDDROutOfRangeException(this, hints,details);
            }
            result.add(touples.get(userLookup.getHostId01() - minHost));
        } catch (FinderException e) {
            DDRExceptionHelper.throwDDROutOfRangeException(this, hints, "failed load sharding host with " + id);
        }

        return result;
    }

    @Override
    public List getAllPossibleTouples(Map hints) throws DDRException {
        return touples;
    }

    @Override
    public List getAllPossibleTouples() throws DDRException {
        return getAllPossibleTouples((Map) null);
    }

    @Override
    public ToupleProvider getRefreshInstance(DdrInfo ddrInfo) throws DDRMisconfiguredException {
        return new UserLookupTupleProvider(this.physicalTableName, this.logicalHostNameTemp,this.minHost, this.maxHost, this.shardingField);
    }
}
