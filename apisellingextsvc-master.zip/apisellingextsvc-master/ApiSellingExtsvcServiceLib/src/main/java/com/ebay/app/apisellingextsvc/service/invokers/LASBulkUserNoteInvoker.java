package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.LASBulkUserNoteClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.cos.las.type.BulkUserNoteRequest;
import com.ebay.cos.las.type.BulkUserNoteResponse;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class LASBulkUserNoteInvoker extends BaseServiceInvoker<BulkUserNoteRequest, BulkUserNoteResponse, BulkUserNoteRequest> {

    // use for mock
    public static final String NAME = "LASBulkUserNoteServiceInvoker";

    public LASBulkUserNoteInvoker(TracerContext tracerContext) {
        super(NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<BulkUserNoteRequest, BulkUserNoteResponse> getGingerClient(
            BulkUserNoteRequest BulkUserNoteRequest) {
        return new LASBulkUserNoteClient();
    }

    @Override
    protected GingerClientRequest<BulkUserNoteRequest> getGingerRequest(BulkUserNoteRequest bulkUserNoteRequest, HttpHeaders httpHeaders) {
        GingerClientRequest<BulkUserNoteRequest> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(bulkUserNoteRequest);
        return gingerClientRequest;
    }

}
