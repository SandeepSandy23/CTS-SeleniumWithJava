package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Map;
import java.util.Optional;

import com.ebay.app.apisellingextsvc.service.bof.shippingcarrier.IShippingCarrierBof;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.util.ResourceUtils;
import org.yaml.snakeyaml.Yaml;

/**
 * convert carrier_enum_id to carrier_name
 * try use java data first, if not found try use data from globalconfig.
 * <p>
 * carrier enum mapping file, data come from <a href="https://github.corp.ebay.com/RaptorServer/RaptorDAL/blob/23324921e58f7209780ce50139d883aa6bb9653b/DALParent/DALItem/src/main/java/com/ebay/integ/item/common/ShippingCarrierEnum.java">DaL Item</a>
 * <p>
 * config data come from `lookuputf8host`, use sql `select CARRIER_ENUM_ID, SHIPPING_CARRIER_NAME from SHIPPING_CARRIER  where rownum < 1000`
 */
public class ShippingCarrierMapper {
    private static final Map<Integer, String> CARRIER_MAP;

    static {
        try {
            URL url = ResourceUtils.getURL("classpath:carrier_mapping.yaml");
            try (InputStream inputStream = url.openStream()) {
                CARRIER_MAP = new Yaml().load(inputStream);
            }
        } catch (IOException e) {
            throw new Error(e);
        }
    }


    public static String convertToCarrierName(IShippingCarrierBof shippingCarrierBof, String carrier, ApiSellingExtSvcConfigValues configValues) {
        //check
        if (StringUtils.isBlank(carrier)) {
            return null;
        }
        carrier = carrier.trim();
        if (!NumberUtils.isParsable(carrier)) {
            return null;
        }

        int carrierId = Integer.parseInt(carrier);

        String carrierDisplayName = Optional.ofNullable(CARRIER_MAP.get(carrierId)).orElseGet(() ->
                Optional.ofNullable(shippingCarrierBof).map(shippingCarrierBo -> shippingCarrierBo.findCarrierNameByCarrierId(carrierId))
                        .orElse(null));
        if (configValues != null) {
            for (String remoteConfig : configValues.shippingCarrierMapping) {
                if (remoteConfig.startsWith(carrier + ApiSellingExtSvcConstants.SEP)) {
                    carrierDisplayName = remoteConfig.substring(carrier.length() + ApiSellingExtSvcConstants.SEP.length());
                }
            }
        }

        if (carrierDisplayName == null) {
            //if no mapping in java and config, log warn, and response raw enum id
            CalLogger.warn("CARRIER_NO_MAPPING", String.format("carrier used %s no mapping", carrier));
            carrierDisplayName = carrier;
        }
        return carrierDisplayName;
    }

}
