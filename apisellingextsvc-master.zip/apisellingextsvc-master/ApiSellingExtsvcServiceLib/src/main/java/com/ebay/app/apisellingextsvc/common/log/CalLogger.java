package com.ebay.app.apisellingextsvc.common.log;

import com.ebay.raptor.opentracing.SpanEvent;
import com.ebay.raptor.opentracing.SpanEventHelper;

public class CalLogger {

    private static final String TYPE_INFO = "Info";
    private static final String TYPE_DEBUG = "debug";
    // private static final String TYPE_WARN = "WARN";
    private static final String TYPE_ERROR = "Error";

    private static final String STATUS_SUCCESS = "0";
    private static final String STATUS_ERROR = "1";

    public static void info(String name, String message) {
        logEvent(TYPE_INFO, name, STATUS_SUCCESS, message);
    }

    public static void debug(String name, String message) {
        logEvent(TYPE_DEBUG, name, STATUS_SUCCESS, message);
    }

    public static void warn(String name, String message) {
        SpanEventHelper.writeWarning(name, null, message);
    }

    public static void error(String name, String message) {
        logEvent(TYPE_ERROR, name, STATUS_ERROR, message);
    }

    private static void logEvent(String type, String name, String status, String message) {
        SpanEvent.builder().type(type).name(name).status(status).data(message).build();
    }

}
