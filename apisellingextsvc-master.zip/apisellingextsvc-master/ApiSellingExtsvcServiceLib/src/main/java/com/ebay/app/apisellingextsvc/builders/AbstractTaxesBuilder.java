package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.TaxStateConstants;
import com.ebay.app.apisellingextsvc.common.constant.TaxSubTypeConstants;
import com.ebay.app.apisellingextsvc.common.constant.TaxSubTypeFormatMapper;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.PatternUtil;
import com.ebay.app.apisellingextsvc.utils.TaxUtil;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.UserCS;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.EntityTotal;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.order.common.v1.Tax;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.common.collect.ImmutableSet;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.CollectionMethodCodeType;
import ebay.apis.eblbasecomponents.EBayTaxReferenceValue;
import ebay.apis.eblbasecomponents.TaxDescriptionCodeType;
import ebay.apis.eblbasecomponents.TaxDetailsType;
import ebay.apis.eblbasecomponents.TaxTypeCodeType;
import ebay.apis.eblbasecomponents.TaxesType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 *
 */
public abstract class AbstractTaxesBuilder extends BaseFacetBuilder<TaxesType> {

    private static final ImmutableSet<String> taxStateWithSeparatedTaxNumberSet =
            ImmutableSet.of(TaxStateConstants.EuropeanUnion,
                    TaxStateConstants.UnitedKingdom, TaxStateConstants.France,
                    TaxStateConstants.Kazakhstan, TaxStateConstants.Jersey, TaxStateConstants.Belarus, TaxStateConstants.Malaysia);

    protected final int trxVersion;

    private final OrderCSXType order;
    private final LineItemXType lineItem;
    private final Tax lineitemTax;
    protected final UserCS buyer;
    private final String defaultCurrency;
    private final ApiSellingExtSvcConfigValues configValues;
    protected final List<Attribute> orderAttributes;

    public AbstractTaxesBuilder(Task<?> task,
                                OrderCSXType order,
                                LineItemXType lineItem,
                                int trxVersion,
                                Tax lineitemTax,
                                UserCS buyer,
                                String defaultCurrency,
            ApiSellingExtSvcConfigValues configValues,
            List<Attribute> orderAttributes) {
        super(task);
        this.order = order;
        this.lineItem = lineItem;
        this.trxVersion = trxVersion;
        this.lineitemTax = lineitemTax;
        this.buyer = buyer;
        this.defaultCurrency = defaultCurrency;
        this.configValues = configValues;
        this.orderAttributes = orderAttributes;
    }

    @Override
    protected abstract TaxesType doBuild();

    protected TaxesType buildTaxTypeDetails(TaxesType taxesType, String taxType) {
        //build total tax amount. return 0 if null
        taxesType.setTotalTaxAmount(buildTotalTaxAmount());
        //build tax detail
        taxesType.getTaxDetails().add(buildTaxDetail(taxType));
        //build tax fee detail
        TaxDetailsType taxFee = buildTaxFeeDetail();
        if (taxFee != null) {
            taxesType.getTaxDetails().add(taxFee);
        }
        //build EBayReference, value is VAT ID for eBay
        taxesType.setEBayReference(buildEBayReference(taxType));
        return taxesType;
    }

    @Nonnull
    private TaxDetailsType buildTaxDetail(@Nonnull String taxType) {
        TaxDetailsType taxDetailsType = new TaxDetailsType();
        taxDetailsType.setImposition(buildImposition(taxType));
        taxDetailsType.setTaxDescription(buildDescription(taxDetailsType.getImposition()));
        taxDetailsType.setTaxAmount(buildTaxAmount());

        if (ApiSellingExtSvcConstants.TAX_TYPE_SALES_TAX.equals(taxType)) {
            List<PriceLine> priceLineList = Optional.ofNullable(lineitemTax)
                                                    .map(Tax::getTotalTaxAmount)
                                                    .map(EntityTotal::getPriceLines)
                                                    .orElse(Collections.emptyList());
            taxDetailsType.setTaxOnSubtotalAmount(buildTaxAmountFromPriceLine(PricelineTypeEnum.ITEM_TAX, priceLineList));
            taxDetailsType.setTaxOnShippingAmount(buildTaxAmountFromPriceLine(PricelineTypeEnum.SHIPPING_TAX, priceLineList));
            taxDetailsType.setTaxOnHandlingAmount(buildTaxAmountFromPriceLine(PricelineTypeEnum.HANDLING_TAX, priceLineList));
        }
        taxDetailsType.setCollectionMethod(buildCollectionMethod());
        taxDetailsType.setTaxCode(buildTaxCode());
        return taxDetailsType;
    }

    @Nullable
    private TaxDetailsType buildTaxFeeDetail() {
        PriceLine taxFeePriceLine = getTaxFeePriceLine();
        if (taxFeePriceLine == null) {
            return null;
        }
        BigDecimal taxFeeValue = getTaxFeeValue(taxFeePriceLine);
        if (taxFeeValue.compareTo(BigDecimal.ZERO) <= 0) {
            return null;
        }
        TaxDetailsType taxDetailsType = new TaxDetailsType();
        PricelineTypeEnum pricelineTypeEnum = Optional.ofNullable(taxFeePriceLine.getPriceLineExt())
                                                      .flatMap(item -> item.stream()
                                                                           .map(PriceLine::getType)
                                                                           .findFirst())
                                                      .orElse(null);
        taxDetailsType.setImposition(buildImposition(pricelineTypeEnum));
        taxDetailsType.setTaxDescription(buildDescription(pricelineTypeEnum));
        taxDetailsType.setTaxAmount(buildTaxFee(taxFeePriceLine));
        taxDetailsType.setCollectionMethod(buildCollectionMethod());
        return taxDetailsType;
    }

    private TaxDescriptionCodeType buildDescription(TaxTypeCodeType taxTypeCodeType) {
        /**
         * GST: indicates that a Goods and Services import tax was charged to the buyer against the order line item.
         * SalesTax:  indicates that standard sales tax was charged to the buyer against the order line item.
         */
        // migrated from legacy trading api, not sure about this logic
        if (TaxTypeCodeType.IMPORT_VAT == taxTypeCodeType
                || TaxTypeCodeType.VAT == taxTypeCodeType
                || TaxTypeCodeType.CUSTOM_CODE == taxTypeCodeType) {
            return TaxDescriptionCodeType.CUSTOM_CODE;
        } else if (TaxTypeCodeType.GST == taxTypeCodeType && trxVersion >= VersionConstant.VERSION_AU_GST) {
            return TaxDescriptionCodeType.GST;
        }
        return TaxDescriptionCodeType.SALES_TAX;
    }

    private TaxDescriptionCodeType buildDescription(PricelineTypeEnum pricelineType) {
        /**
         * ElectronicWasteRecyclingFee: indicates that an electronic waste recycling fee was charged to the buyer against the order line item.
         * TireRecyclingFee: indicates that a tire recycling fee was charged to the buyer against the order line item.
         */
        if (PricelineTypeEnum.ECO_RECYCLE_FEE == pricelineType) {
            return TaxDescriptionCodeType.ELECTRONIC_WASTE_RECYCLING_FEE;
        } else if (PricelineTypeEnum.TYRE_RECYCLE_FEE == pricelineType) {
            return TaxDescriptionCodeType.TIRE_RECYCLING_FEE;
        }
        return TaxDescriptionCodeType.CUSTOM_CODE;
    }

    private TaxTypeCodeType buildImposition(String taxType) {
        /**
         * GST： only applicable for items being sold by Australian or New Zealand sellers.
         * VAT： applies to VAT tax on the UK marketplace, the Norway marketplace, and other EU marketplaces (except for France).
         * ImportVAT： only applicable for items sold on the eBay France marketplaces.
         * SalesTax：standard sales tax was charged to the buyer against the order line item.
         * CustomCode： Reserved for internal or future use.
         */
        if (trxVersion >= VersionConstant.VERSION_FR_VAT && ApiSellingExtSvcConstants.TAX_TYPE_IMPORT_VAT.equals(taxType)) {
            return TaxTypeCodeType.IMPORT_VAT;
        } else if (trxVersion >= VersionConstant.VERSION_FR_VAT && ApiSellingExtSvcConstants.TAX_TYPE_VAT.equals(taxType)) {
            return TaxTypeCodeType.VAT;
        } else if (ApiSellingExtSvcConstants.GST.equals(taxType)) {
            if (trxVersion >= VersionConstant.VERSION_AU_GST) {
                return TaxTypeCodeType.GST;
            } else {
                return TaxTypeCodeType.CUSTOM_CODE;
            }
        }
        return TaxTypeCodeType.SALES_TAX;
    }

    private TaxTypeCodeType buildImposition(@Nullable PricelineTypeEnum pricelineType) {
        /**
         * WasteRecyclingFee： indicates that an electronic waste recycling fee was charged to the buyer against the order line item.
         */
        if (PricelineTypeEnum.ECO_RECYCLE_FEE == pricelineType || PricelineTypeEnum.TYRE_RECYCLE_FEE == pricelineType) {
            return TaxTypeCodeType.WASTE_RECYCLING_FEE;
        }
        return TaxTypeCodeType.CUSTOM_CODE;
    }

    private String buildTaxCode() {
        /**
         * This value is the actual tax ID for the buyer.
         * This field will generally only be returned if a seller on the Italy or Spain sites
         * required that the buyer supply a tax ID during the checkout process.
         * If the Order.BuyerTaxIdentifier container is returned, the type of tax ID can be found in the BuyerTaxIdentifier.Type field.
         */
        if (trxVersion >= VersionConstant.VERSION_ESTIMATED_DELIVERY) {
            return Optional.ofNullable(buyer)
                           .map(UserCS::getTaxIdentifiers)
                           .filter(CollectionUtils::isNotEmpty)
                           .flatMap(item -> item.stream().filter(tax -> tax != null
                                   && org.apache.commons.lang3.StringUtils.isNoneBlank(tax.getType())).findFirst())
                           .map(item -> item.getType())
                           .orElse(null);
        }
        return null;
    }

    private PriceLine getTaxFeePriceLine() {
        return Optional.ofNullable(lineitemTax)
                       .map(Tax::getTotalTaxAmount)
                       .map(EntityTotal::getPriceLines)
                       .filter(CollectionUtils::isNotEmpty)
                       .flatMap(item -> item.stream()
                                            .filter(pl -> pl != null && PricelineTypeEnum.TAX_FEE == pl.getType())
                                            .findFirst())
                       .orElse(null);
    }

    private BigDecimal getTaxFeeValue(PriceLine taxFeePriceLine) {
        return Optional.ofNullable(taxFeePriceLine)
                       .map(PriceLine::getAmount)
                       .map(Amount::getValue)
                       .map(BigDecimal::valueOf)
                       .orElse(BigDecimal.ZERO);
    }

    private AmountType buildTaxAmountFromPriceLine(PricelineTypeEnum pricelineType, List<PriceLine> priceLineList) {
        return buildTaxAmount(priceLineList
                                      .stream()
                                      .filter(item -> pricelineType.equals(item.getType()))
                                      .findFirst()
                                      .map(PriceLine::getAmount)
                                      .orElse(null), true);
    }

    protected AmountType buildTotalTaxAmount() {
        return buildTaxAmount(Optional.ofNullable(lineitemTax)
                                      .map(Tax::getTotalTaxAmount)
                                      .map(EntityTotal::getAmount)
                                      .orElse(null), false);
    }

    private AmountType buildTaxAmount() {
        // this may move to shared trans data for getOrders and getOrderTrans
        AmountType totalTaxAmount = buildTotalTaxAmount();
        if (totalTaxAmount == null
                || BigDecimal.valueOf(totalTaxAmount.getValue()).compareTo(BigDecimal.ZERO) <= 0) {
            return totalTaxAmount;
        }
        //get tax fee
        BigDecimal taxFeeValue = getTaxFeeValue(getTaxFeePriceLine());
        //tax amount: total tax amount - tax fee
        totalTaxAmount.setValue(BigDecimal.valueOf(totalTaxAmount.getValue()).subtract(taxFeeValue).doubleValue());
        return totalTaxAmount;
    }

    private AmountType buildTaxAmount(Amount amount, boolean defaultZero) {
        if (amount != null) {
            return AmountTypeUtil.getAmountType(amount);
        }
        if (defaultZero && StringUtils.isNoneBlank(defaultCurrency)) {
            return AmountTypeUtil.getZeroAmountType(defaultCurrency);
        }
        return null;
    }

    private AmountType buildTaxFee(PriceLine taxFeePriceLine) {
        return AmountTypeUtil.getAmountType(taxFeePriceLine.getAmount());
    }


    private EBayTaxReferenceValue buildEBayReference(String taxType) {
        /**
         * The value returned in this field is the VAT ID for eBay, if VAT tax is applicable for the order.
         * This value is returned with a version number of 1211 (or newer)
         * For French VAT ID/VATIN values to be returned with a version number of 1225 (or newer)
         * Sample Order: 275481055784-2587086029017, 07-08516-63546
         */
        if (configValues.enableEbayReference
                && (trxVersion >= VersionConstant.VERSION_EU_VAT &&
                (isTaxTypeGST(taxType) || isTaxTypeMYSalesTax(taxType, getTaxState()))
                || trxVersion >= VersionConstant.VERSION_FR_VAT && isTaxTypeImportVat(taxType))) {

            String taxNumber = TaxUtil.getTaxNumber(orderAttributes);
            String subtype = TaxUtil.getTaxSubtype(orderAttributes);
            String taxState = getTaxState();
            if(taxState.equals(TaxStateConstants.Kazakhstan) && StringUtils.isBlank(taxNumber)){
                taxNumber = "-";
            }

            String taxReferenceName = getTaxReferenceName(taxState, subtype, taxNumber, taxType);
            if (org.apache.commons.lang3.StringUtils.isBlank(taxReferenceName)) {
                return null;
            }
            String taxReferenceValue = getTaxReferenceValue(taxState, taxNumber, taxReferenceName);
            if (org.apache.commons.lang3.StringUtils.isBlank(taxReferenceValue)) {
                return null;
            }
            EBayTaxReferenceValue referenceValue = new EBayTaxReferenceValue();
            referenceValue.setName(taxReferenceName);
            referenceValue.setValue(taxReferenceValue);
            return referenceValue;
        }
        return null;
    }

    protected CollectionMethodCodeType buildCollectionMethod() {
        return null;
    }

    protected String getTaxType() {
        return null;
    }

    protected String getTaxState() {
        return TaxUtil.getTaxState(orderAttributes);
    }

    protected String getEbayCollectAndRemitTax() {
        return TaxUtil.getTaxType(lineItem.getAttribute());
    }

    protected boolean isInvoiceToSeller() {
        String taxType = TaxUtil.getTaxType(orderAttributes);
        return ApiSellingExtSvcConstants.INVOICE_TO_SELLER.equalsIgnoreCase(taxType);
    }

    protected boolean isTaxIncludeInSellerDistribution() {
        return TaxUtil.isTaxIncludeInSellerDistribution(orderAttributes);
    }

    protected boolean isTaxTypeGST(String taxType) {
        return ApiSellingExtSvcConstants.GST.equals(taxType) || ApiSellingExtSvcConstants.TAX_TYPE_VAT.equals(taxType);
    }

    protected boolean isTaxTypeMYSalesTax(String taxType, String taxState) {
        return ApiSellingExtSvcConstants.TAX_TYPE_SALES_TAX.equals(taxType) && TaxStateConstants.Malaysia.equals(taxState);
    }

    protected boolean isTaxTypeImportVat(String taxType) {
        return ApiSellingExtSvcConstants.TAX_TYPE_IMPORT_VAT.equals(taxType);
    }

    protected String getTaxTypeWithTaxState(String taxState) {
        if (TaxStateConstants.France.equals(taxState)) {
            return ApiSellingExtSvcConstants.TAX_TYPE_IMPORT_VAT;
        } else if (isVATTaxState(taxState)) {
            return ApiSellingExtSvcConstants.TAX_TYPE_VAT;
        }
        return ApiSellingExtSvcConstants.GST;
    }

    protected Boolean isVATTaxState(String taxState) {
        return TaxStateConstants.UnitedKingdom.equals(taxState)
                || TaxStateConstants.EuropeanUnion.equals(taxState)
                || TaxStateConstants.Norway.equals(taxState)
                || TaxStateConstants.Kazakhstan.equals(taxState)
                || TaxStateConstants.Belarus.equals(taxState);
    }
    @Nullable
    private String getTaxReferenceName(String taxState, String taxSubType, @Nonnull String taxNumber, String taxType) {
        String res = null;
        if (isTaxStateEmitTaxSubTypeOrTaxTypeAsEbayRefName(taxState)) {
            if (TaxStateConstants.France.equals(taxState)) {
                if (trxVersion >= VersionConstant.VERSION_FR_VAT) {
                    res = TaxSubTypeConstants.VAT_ID;
                } else if (trxVersion >= VersionConstant.VERSION_AU_GST && trxVersion < VersionConstant.VERSION_EU_VAT) {
                    res = taxSubType;
                }
            } else if (TaxStateConstants.Norway.equals(taxState)) {
                return TaxSubTypeConstants.VOEC;
            } else if (StringUtils.isNoneBlank(taxNumber)) {
                String format = PatternUtil.getPatternOfTaxNumber(taxNumber);
                return TaxSubTypeFormatMapper.mapNameWithFormat(format);
            }
        } else {
            res = taxSubType;
            if(StringUtils.isNotEmpty(taxType) && StringUtils.isBlank(res)){
                res = taxType;
            }
        }
        return res;
    }

    protected Boolean isTaxStateEmitTaxSubTypeOrTaxTypeAsEbayRefName(String taxState) {
        return !TaxStateConstants.EuropeanUnion.equals(taxState) && !TaxStateConstants.UnitedKingdom.equals(taxState)
                && !TaxStateConstants.Kazakhstan.equals(taxState) && !TaxStateConstants.Jersey.equals(taxState)
                && !TaxStateConstants.Belarus.equals(taxState) && !TaxStateConstants.Malaysia.equals(taxState);
    }
    /**
     * ABN: if this string is returned, the ID in the field is an eBay Australia tax number IOSS: if this string is returned, the ID in the field is
     * an eBay EU or UK IOSS number IRD: if this string is returned, the ID in the field is an eBay New Zealand tax number OSS: if this string is
     * returned, the ID in the field is an eBay Germany VAT ID VOEC: if this string is returned, the ID in the field is an eBay Norway tax number
     */
    @Nullable
    private String getTaxReferenceValue(String taxState, String taxNumber, String taxReferenceName) {
        if (TaxStateConstants.EuropeanUnion.equals(taxState) && TaxSubTypeConstants.OSS.equals(taxReferenceName)) {
            return configValues.euvatEbayVatId;
        } else if (!taxStateWithSeparatedTaxNumberSet.contains(taxState) && StringUtils.isNoneBlank(taxNumber)) {
            // SOAPI-1085: Null check added
            return taxNumber.replace(TaxSubTypeFormatMapper.map(taxReferenceName), ApiSellingExtSvcConstants.EMPTY_STRING);
        } else {
            return taxNumber;
        }
    }
}
