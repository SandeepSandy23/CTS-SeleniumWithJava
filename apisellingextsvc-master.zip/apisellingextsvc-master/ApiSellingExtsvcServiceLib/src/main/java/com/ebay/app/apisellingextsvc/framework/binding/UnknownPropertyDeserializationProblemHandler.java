package com.ebay.app.apisellingextsvc.framework.binding;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;

/**
 * maintain a list of filed that would cause UnrecognizedPropertyException
 */
public class UnknownPropertyDeserializationProblemHandler extends DeserializationProblemHandler {
    private final HashSet<String> KNOWN_UNKNOWN_FIELDS = new HashSet<>(Arrays.asList(
            "InsuranceOption", //ShippingDetailsType
            "InsuranceFee", //ShippingDetailsType
            "CustomLabel", //SellingManagerProductDetailsType
            "ExpressWallet",  //sellerType
            "ExpressEligible", //SellerType
            "ExpressListing",
            "LiveAuctionAuthorized",
            "PackageDepth",
            "PackageLength",
            "PackageWidth",
            "ShippingPackage",
            "WeightMajor",
            "WeightMinor"
    ));

    public boolean handleUnknownProperty(DeserializationContext ctxt, JsonParser p,
                                         JsonDeserializer<?> deserializer, Object beanOrClass, String propertyName) {
        String message = "UnknownProperty "+propertyName + " for " + beanOrClass.getClass().getName();
        boolean known = KNOWN_UNKNOWN_FIELDS.contains(propertyName);
        if (known) {
            CalLogger.info("UnknownXmlProperty", message);
            try {
                p.skipChildren();
            } catch (IOException e) {
                return false;
            }
        } else {
            CalLogger.warn("UnknownXmlProperty", message);
        }
        return known;
    }
}
