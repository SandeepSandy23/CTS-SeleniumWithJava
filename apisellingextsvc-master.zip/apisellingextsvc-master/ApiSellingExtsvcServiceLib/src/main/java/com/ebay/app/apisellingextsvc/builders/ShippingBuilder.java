package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.v1.DateTime;
import com.ebay.order.common.v1.LineItemFulfillmentInfo;
import com.ebay.order.common.v1.LogisticsPlan;
import com.ebay.order.common.v1.LogisticsStep;
import com.ebay.order.common.v1.LogisticsStepTypeEnumType;
import com.ebay.order.common.v1.PackageType;
import com.ebay.order.common.v1.ShippingOption;
import com.ebay.order.common.v1.ShippingStepExtension;
import com.ebay.order.common.v1.ShippingTypeEnum;
import com.ebay.order.common.v1.TimeEstimate;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ShippingPackageInfoType;
import ebay.apis.eblbasecomponents.ShippingServiceOptionsType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.ebay.app.apisellingextsvc.utils.OrderBuilderUtil.isLineItemInPackage;
import static com.ebay.order.common.v1.LogisticsStepTypeEnumType.SHIPPING;

public abstract class ShippingBuilder extends BaseFacetBuilder<ShippingServiceOptionsType> {

    public ShippingBuilder(Task<?> task) {
        super(task);
    }

    static String getShippingMethodCodeValue(String res, LogisticsStep logisticsStep) {
        if (logisticsStep != null && LogisticsStepTypeEnumType.SHIPPING.equals(logisticsStep.getStepType())
                && logisticsStep.getStepExtension() != null
                && logisticsStep.getStepExtension().getShippingStep() != null
                && CollectionUtils.isNotEmpty(logisticsStep.getStepExtension().getShippingStep()
                .getShippingOptions())) {
            for (ShippingOption shippingOption : logisticsStep.getStepExtension().getShippingStep()
                    .getShippingOptions()) {
                if (shippingOption != null && shippingOption.getShipppingMethod() != null
                        && shippingOption.getShipppingMethod().getShippingMethodCode() != null
                        && StringUtils.isNotEmpty(shippingOption.getShipppingMethod().getShippingMethodCode()
                        .getValue())) {
                    res = shippingOption.getShipppingMethod().getShippingMethodCode().getValue();
                }
            }
        }
        return res;
    }

    public static ShippingStepExtension getShippingSteps(List<LogisticsPlan> logistics) {
        /**
         * Apixoio returns domestic shipping steps for both seller and buyer view,
         * code: OrderShippingServiceDataRetriever.retrieve
         *
         * This logic is consistent with GetOrders doc, referred to the description of
         * OrderArray.Order.MultiLegShippingDetails.SellerShipmentToLogisticsProvider:
         *  Contains information about the domestic leg of a international order being shipped through
         *  the Global Shipping Program or eBay International Shipping, including the selected shipping service,
         *  the domestic shipping cost, the domestic address of the international shipping provider,
         *  and the estimated shipping time range.
         *
         *  Currently we act same as apixoio which returns domestic shipping steps.
         */

        if (CollectionUtils.isNotEmpty(logistics)) {
            return logistics.stream().filter(Objects::nonNull)
                    .map(LogisticsPlan::getSteps)
                    .filter(CollectionUtils::isNotEmpty)
                    .flatMap(Collection::stream)
                    .filter(item -> SHIPPING == item.getStepType())
                    .map(LogisticsStep::getStepExtension)
                    .filter(Objects::nonNull)
                    .map(LogisticsStep.StepExtension::getShippingStep)
                    .filter(Objects::nonNull)
                    .filter(item -> ShippingTypeEnum.DOMESTIC_SHIPPING == item.getShippingStepType())
                    .findFirst()
                    .orElse(null);
        }
        return null;
    }

    public static DateTime getActualDeliveryDate(OrderCSXType order, String lineItemId) {

        List<DateTime> dateTimes = new ArrayList<>();

        if (order != null && CollectionUtils.isNotEmpty(order.getLogistics())) {
            for (LogisticsPlan logisticsPlan : order.getLogistics()) {
                if (logisticsPlan != null && CollectionUtils.isNotEmpty(logisticsPlan.getSteps())) {
                    for (LogisticsStep logisticsStep : logisticsPlan.getSteps()) {
                        if (logisticsStep != null && LogisticsStepTypeEnumType.SHIPPING.equals(logisticsStep.getStepType())
                                && logisticsStep.getStepExtension() != null
                                && logisticsStep.getStepExtension().getShippingStep() != null
                                && CollectionUtils.isNotEmpty(logisticsStep.getStepExtension().getShippingStep().getPackage())) {

                            for (PackageType packageType : logisticsStep.getStepExtension().getShippingStep().getPackage()) {
                                if (packageType != null && packageType.getActualDeliveryDate() != null
                                        && isLineItemInPackage(packageType, lineItemId)) {
                                    dateTimes.add(packageType.getActualDeliveryDate());
                                }
                            }
                        }
                    }
                }
            }
        }

        return dateTimes.stream().max(Comparator.comparing(DateTime::getValue)).orElse(null);
    }

    protected List<ShippingPackageInfoType> getShippingPackageInfo(OrderCSXType order, String lineItemId, int trxVersion) {
        List<ShippingPackageInfoType> res = new ArrayList<>();
        if (order != null && CollectionUtils.isNotEmpty(order.getLogistics())) {
            for (LogisticsPlan logisticsPlan : order.getLogistics()) {
                if (logisticsPlan != null && CollectionUtils.isNotEmpty(logisticsPlan.getSteps())) {
                    //check SHIPPING step num, if we have to `SHIPPING` step use the last one, aka max sequence.
                    Integer shippingStepFilterSequence = logisticsPlan.getSteps().stream()
                            .filter(ShippingBuilder::isShippingStep)
                            .map(LogisticsStep::getSequence)
                            .max(Comparator.naturalOrder()).orElse(null);

                    for (LogisticsStep logisticsStep : logisticsPlan.getSteps()) {
                        if (ShippingBuilder.isShippingStep(logisticsStep) && logisticsStep.getSequence() == shippingStepFilterSequence) {
                            if (CollectionUtils.isNotEmpty(logisticsStep.getLineItemFufillmentInfo())) {
                                for (LineItemFulfillmentInfo lineItemFulfillmentInfo : logisticsStep.getLineItemFufillmentInfo()) {
                                    populatePackage(res, order, lineItemFulfillmentInfo, lineItemId, trxVersion);
                                }
                            } else if (logisticsStep.getStepExtension() != null
                                    && logisticsStep.getStepExtension().getShippingStep() != null
                                    && CollectionUtils.isNotEmpty(logisticsStep.getStepExtension()
                                    .getShippingStep().getShippingOptions())) {
                                for (ShippingOption shippingOption : logisticsStep.getStepExtension()
                                        .getShippingStep().getShippingOptions()) {
                                    if (shippingOption != null && shippingOption.getDeliveryEstimate() != null
                                            && shippingOption.getDeliveryEstimate().getTimeEstimate() != null) {
                                        ShippingPackageInfoType shippingPackageInfo = new ShippingPackageInfoType();
                                        TimeEstimate timeEstimate = shippingOption.getDeliveryEstimate().getTimeEstimate();
                                        shippingPackageInfo.setEstimatedDeliveryTimeMin(DateUtil
                                                .convertToXMLGregorianCalendar(timeEstimate.getMinDate()));
                                        shippingPackageInfo.setEstimatedDeliveryTimeMax(DateUtil
                                                .convertToXMLGregorianCalendar(timeEstimate.getMaxDate()));
                                        res.add(shippingPackageInfo);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return res;
    }

    public void populatePackage(List<ShippingPackageInfoType> res, OrderCSXType order, LineItemFulfillmentInfo lineItemFulfillmentInfo,
                                       String lineItemId, int trxVersion) {

        if (lineItemFulfillmentInfo == null || !Objects.equals(lineItemId, lineItemFulfillmentInfo.getLineItemId())) {
            return;
        }

        ShippingPackageInfoType shippingPackageInfo = new ShippingPackageInfoType();
        Optional.ofNullable(lineItemFulfillmentInfo.getMaxEstimateDate()).map(DateUtil::convertToXMLGregorianCalendar)
                .ifPresent(shippingPackageInfo::setEstimatedDeliveryTimeMax);
        Optional.ofNullable(lineItemFulfillmentInfo.getMinEstimateDate()).map(DateUtil::convertToXMLGregorianCalendar)
                .ifPresent(shippingPackageInfo::setEstimatedDeliveryTimeMin);
        Optional.ofNullable(lineItemFulfillmentInfo.getMaxOriginalEstimateDate()).map(DateUtil::convertToXMLGregorianCalendar)
                .ifPresent(shippingPackageInfo::setEstimatedDeliveryTimeMax);
        Optional.ofNullable(lineItemFulfillmentInfo.getMinOriginalEstimateDate()).map(DateUtil::convertToXMLGregorianCalendar)
                .ifPresent(shippingPackageInfo::setEstimatedDeliveryTimeMin);
        Optional.ofNullable(getActualDeliveryDate(order, lineItemId)).map(DateUtil::convertToXMLGregorianCalendar)
                .ifPresent(shippingPackageInfo::setActualDeliveryTime);

        if (trxVersion >= VersionConstant.VERSION_HANDLEBY_DATE) {
            Optional.ofNullable(lineItemFulfillmentInfo.getHandleByDate()).map(DateUtil::convertToXMLGregorianCalendar)
                    .ifPresent(shippingPackageInfo::setHandleByTime);
            Optional.ofNullable(lineItemFulfillmentInfo.getMaxNativeEstimateDate()).map(DateUtil::convertToXMLGregorianCalendar)
                    .ifPresent(shippingPackageInfo::setMaxNativeEstimatedDeliveryTime);
            Optional.ofNullable(lineItemFulfillmentInfo.getMinNativeEstimateDate()).map(DateUtil::convertToXMLGregorianCalendar)
                    .ifPresent(shippingPackageInfo::setMinNativeEstimatedDeliveryTime);
        }

        if (isEmptyPackage(shippingPackageInfo)) {
            return;
        }
        res.add(shippingPackageInfo);
    }

    public static boolean isShippingStep(LogisticsStep logisticsStep) {
        return logisticsStep != null && LogisticsStepTypeEnumType.SHIPPING.equals(logisticsStep.getStepType());
    }

    public boolean isEmptyPackage(ShippingPackageInfoType shippingPackageInfo) {
        return shippingPackageInfo.getEstimatedDeliveryTimeMax() == null && shippingPackageInfo.getEstimatedDeliveryTimeMin() == null
                && shippingPackageInfo.getMaxNativeEstimatedDeliveryTime() == null && shippingPackageInfo.getMinNativeEstimatedDeliveryTime() == null
                && shippingPackageInfo.getHandleByTime() == null && shippingPackageInfo.getActualDeliveryTime() == null;
    }
}
