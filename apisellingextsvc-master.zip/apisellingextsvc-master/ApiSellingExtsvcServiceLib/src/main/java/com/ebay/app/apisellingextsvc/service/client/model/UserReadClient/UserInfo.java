package com.ebay.app.apisellingextsvc.service.client.model.UserReadClient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserInfo {
    @JsonProperty("legacyUserId")
    private String internalId;

    @JsonProperty("userAccountName")
    private String username;

    @JsonProperty("userAccountType")
    private String userAccountType;

    @JsonProperty("registrationSiteId")
    private String registrationSiteId;

    @JsonProperty("countryOfResidence")
    private String countryOfResidence;

    @JsonProperty("registrationMarketPlaceId")
    private String registrationMarketPlaceId;

    @JsonProperty("userAccountStatus")
    private String userAccountStatus;

    @JsonProperty("userAccountCreationDate")
    private String creationDate;

    @JsonProperty("individualIdentityProfile")
    private IndividualIdentityProfile individualIdentityProfile;

    @JsonProperty("businessIdentityProfile")
    private BusinessIdentityProfile businessIdentityProfile;

    @JsonProperty("extensions")
    private List<Extensions> extensions;

}
