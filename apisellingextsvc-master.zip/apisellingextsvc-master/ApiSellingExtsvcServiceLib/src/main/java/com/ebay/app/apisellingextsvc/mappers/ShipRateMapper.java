package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.ShipRateTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.ShippingTypeCodeType;

public class ShipRateMapper {
    private static final ImmutableMap<ShipRateTypeEnum, ShippingTypeCodeType> mapName
            = new ImmutableMap.Builder<ShipRateTypeEnum, ShippingTypeCodeType>()
            .put(ShipRateTypeEnum.FLAT, ShippingTypeCodeType.FLAT)
            .put(ShipRateTypeEnum.CALCULATED, ShippingTypeCodeType.CALCULATED)
            .put(ShipRateTypeEnum.FREIGHT, ShippingTypeCodeType.FREIGHT)
            .put(ShipRateTypeEnum.FREE, ShippingTypeCodeType.FREE)
            .put(ShipRateTypeEnum.NOT_SPECIFIED, ShippingTypeCodeType.NOT_SPECIFIED)
            .put(ShipRateTypeEnum.FLAT_DOMESTIC_CALCULATED_INTERNATIONAL, ShippingTypeCodeType.FLAT_DOMESTIC_CALCULATED_INTERNATIONAL)
            .put(ShipRateTypeEnum.CALCULATE_DDOMESTIC_FLAT_INTERNATIONAL, ShippingTypeCodeType.CALCULATED_DOMESTIC_FLAT_INTERNATIONAL)
            .put(ShipRateTypeEnum.SEE_DESC, ShippingTypeCodeType.CUSTOM_CODE)
            .build();

    private ShipRateMapper() {
    }

    public static ShippingTypeCodeType map(ShipRateTypeEnum key) {
        return mapName.getOrDefault(key, ShippingTypeCodeType.CUSTOM_CODE);
    }
}