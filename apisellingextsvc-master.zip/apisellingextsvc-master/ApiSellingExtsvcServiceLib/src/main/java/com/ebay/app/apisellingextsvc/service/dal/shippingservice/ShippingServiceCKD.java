package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.integ.dal.cache2.GeneralCollectionObjectKeyDefinition;
import com.ebay.integ.dal.cache2.keydef.PersistableKeyType;

public class ShippingServiceCKD extends GeneralCollectionObjectKeyDefinition implements PersistableKeyType {
    private static final long serialVersionUID = 2904442893010280701L;

    public ShippingServiceCKD(int id, Class targetClass) {
        super(id, targetClass);
    }

    public Object createKey(Object obj) {
        ShippingServiceDoImpl objImpl = (ShippingServiceDoImpl)obj;
        return createKey(objImpl.m_shippingServiceId);
    }

    public static Object createKey(int shippingServiceId) {
        return new ShippingServiceCK(shippingServiceId);
    }
}
