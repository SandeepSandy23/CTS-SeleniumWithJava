package com.ebay.app.apisellingextsvc.test;

import java.util.List;

public class TestMock {
    private String name;
    private Object mockData;
    private List<MultiValuedParam> validations;

    public TestMock() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getMockData() {
        return this.mockData;
    }

    public void setMockData(Object mockData) {
        this.mockData = mockData;
    }

    public List<MultiValuedParam> getValidations() {
        return this.validations;
    }

    public void setValidations(List<MultiValuedParam> validations) {
        this.validations = validations;
    }
}

