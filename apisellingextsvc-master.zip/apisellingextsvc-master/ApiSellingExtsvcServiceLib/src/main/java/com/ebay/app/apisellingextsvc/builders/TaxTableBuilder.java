package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.ProgramUtil;
import com.ebay.app.apisellingextsvc.utils.TaxUtil;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.LineItem;
import com.ebay.order.common.v1.Tax;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.TaxJurisdictionType;
import ebay.apis.eblbasecomponents.TaxTableType;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class TaxTableBuilder extends BaseFacetBuilder<TaxTableType> {

    private ProformaOrderXType proformaOrder;
    private OrderCSXType order;
    private LineItemXType lineItem;
    private final List<Attribute> attributes;

    public TaxTableBuilder(Task<?> task, OrderCSXType order, LineItemXType lineItem) {
        super(task);
        this.order = order;
        this.lineItem = lineItem;
        this.attributes = order.getAttributes();
    }

    public TaxTableBuilder(Task<?> task, ProformaOrderXType proformaOrder) {
        super(task);
        this.proformaOrder = proformaOrder;
        this.attributes = proformaOrder.getAttributes();
    }

    @Override
    protected TaxTableType doBuild() {
        TaxTableType taxTable = new TaxTableType();

        if (showTaxTable(attributes)) {
            if (ProgramUtil.isExportsOrder(order.getPrograms())) {
                return taxTable;
            }
            TaxJurisdictionType taxJurisdictionType = new TaxJurisdictionType();
            Optional.ofNullable(lineItem)
                    .map(LineItem::getTax)
                    .map(Tax::getSalesTaxPercentage)
                    .ifPresent(taxPercentage -> taxJurisdictionType.setSalesTaxPercent(taxPercentage.floatValue()));
            Optional.ofNullable(lineItem)
                    .map(LineItem::getTax)
                    .map(Tax::getSalesTaxState)
                    .ifPresent(taxJurisdictionType::setJurisdictionID);

            Optional.ofNullable(lineItem).ifPresent(itemXType -> taxJurisdictionType.setShippingIncludedInTax(TaxUtil.isShippingIncludedInTax(lineItem.getTax())));
            taxTable.getTaxJurisdiction().add(taxJurisdictionType);
        }

        return taxTable;
    }

    private boolean showTaxTable(List<Attribute> attributes) {
        // boolean hasTaxPartner = PaymentUtil.hasTaxPartnerDistribution(order);
        return AttributeUtil.findAttribute(attributes, ApiSellingExtSvcConstants.ATTR_TAX_ENGINE_USED)
                .map(Attribute::getValue)
                .map(ApiSellingExtSvcConstants.EBAY_TAX_ENGINE::equals)
                .orElse(false);

        // if (hasTaxPartner && isEbayTaxEngine) {
        //     return true;
        // }
        //
        // return !hasTaxPartner;
    }


}
