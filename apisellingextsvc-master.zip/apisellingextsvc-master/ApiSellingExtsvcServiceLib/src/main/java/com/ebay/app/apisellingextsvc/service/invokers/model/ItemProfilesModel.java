package com.ebay.app.apisellingextsvc.service.invokers.model;

import ebay.apis.eblbasecomponents.SellerProfilesType;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * wrapper class to differentiate data in orchestrator dependency since Map<?,?> response of invoker is
 * generic
 *
 */
@AllArgsConstructor
@Getter
public class ItemProfilesModel {
    private Map<Long, SellerProfilesType> itemProfiles;
}
