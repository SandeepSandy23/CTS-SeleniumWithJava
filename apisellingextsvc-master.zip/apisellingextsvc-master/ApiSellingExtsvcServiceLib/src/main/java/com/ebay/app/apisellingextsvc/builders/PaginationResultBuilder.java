package com.ebay.app.apisellingextsvc.builders;


import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import com.ebay.app.apisellingextsvc.handlers.ExceptionHandler;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.cos.las.type.ListingActivitiesResponse;
import com.ebay.cosmos.ContractResponse;
import ebay.apis.eblbasecomponents.ErrorType;
import ebay.apis.eblbasecomponents.PaginationResultType;
import ebay.apis.eblbasecomponents.PaginationType;

import java.util.List;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.MAX_TOTAL_ENTRIES;

public class PaginationResultBuilder {

    public PaginationResultType buildCosmosPagination(ContractResponse cosmosResponse, PaginationType paginationType) {
        PaginationResultType paginationResultType = new PaginationResultType();
        Integer totalEntry = 0;
        if (cosmosResponse != null && cosmosResponse.getSummary() != null) {
            totalEntry = ContractResponseUtil.getTotalCountSummary(cosmosResponse);
            paginationResultType.setTotalNumberOfEntries(totalEntry);
        }
        int totalNumberOfPages = (int) Math.ceil((double) totalEntry / paginationType.getEntriesPerPage());
        paginationResultType.setTotalNumberOfPages(totalNumberOfPages);
        return paginationResultType;
    }

    public PaginationResultType buildListingsPagination(ListingActivitiesResponse listingActivitiesResponse, PaginationType paginationType, ContentResource contentResource, List<ErrorType> errorList) {
        PaginationResultType paginationResultType = new PaginationResultType();
        int totalEntry = 0;
        if (listingActivitiesResponse != null) {
            totalEntry = listingActivitiesResponse.getTotal();
            if(totalEntry >= MAX_TOTAL_ENTRIES) {
                totalEntry = MAX_TOTAL_ENTRIES;
                ExceptionHandler.logException(errorList, ApplicationError.DATA_TRUNCATED, contentResource.contentHelper.getErrorContentManager());
            }
            paginationResultType.setTotalNumberOfEntries(totalEntry);
        }
        int totalNumberOfPages = (int) Math.ceil((double) totalEntry / paginationType.getEntriesPerPage());
        paginationResultType.setTotalNumberOfPages(totalNumberOfPages);
        return paginationResultType;
    }

}
