package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import com.ebay.integ.dal.cache2.BaseIntegCacheBean;
import com.ebay.integ.dal.cache2.CacheBeanInitializationException;
import com.ebay.kernel.bean.configuration.ConfigCategoryCreateException;

public class TaxRateCacheBean extends BaseIntegCacheBean {
    public static final String CATEGORY_ID = "ebay.dal.CacheObject.TaxRate";
    private static TaxRateCacheBean m_Instance = null;

    private TaxRateCacheBean() throws ConfigCategoryCreateException {
        super(createBeanConfigCategoryInfo("ebay.dal.CacheObject.TaxRate",
                "com.ebay.domain.sharedbilling.integ.CacheObject.TaxRate",
                "com.ebay.integ.CacheObject"),
                true,
                "TaxRate",
                new TaxRateCacheLoader(),
                TaxRateKeyManager.getInstance(),
                3600,
                "12:00",
                300,
                true,
                true,
                -1,
                100,
                true);
    }

    public static TaxRateCacheBean getInstance() {
        if (m_Instance == null) {
            try {
                m_Instance = new TaxRateCacheBean();
            } catch (ConfigCategoryCreateException var1) {
                throw new CacheBeanInitializationException(var1, "TaxRateCacheBean");
            }
        }

        return m_Instance;
    }
}
