package com.ebay.app.apisellingextsvc.audit.comparator.facet;


import com.ebay.app.apisellingextsvc.audit.comparator.CustomExtComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.IJsonNodeComparator;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;
import com.ebay.app.apisellingextsvc.audit.comparator.api.GetSellerTransactionsComparator;

import java.util.Objects;
import java.util.function.Predicate;

public class TrimEmptyToNullComparator implements IJsonNodeComparator {

    private final CustomExtComparator comparator;
    private final Predicate<JsonNode> predicator;

    public TrimEmptyToNullComparator(GetSellerTransactionsComparator comparator, Predicate<JsonNode> shouldTrim) {
        this.comparator = comparator;
        this.predicator = shouldTrim;
    }

    @Override
    public boolean customCompareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        assert pattern.isTextual();

        if (predicator.test(tar)) {
            tar = null;
        }
        if (predicator.test(org)) {
            org = null;
        }
        if (Objects.equals(org, tar)) {
            return true;
        }

        return comparator.defaultCompareNode(org, tar, pattern, path, key, report);
    }

}
