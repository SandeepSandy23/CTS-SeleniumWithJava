package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.mappers.ProgramAddressMapper;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPref;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPrefDAO;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPrefFlags;
import com.ebay.app.apisellingextsvc.service.dal.useraddress.UserAddress;
import com.ebay.app.apisellingextsvc.service.dal.useraddress.UserAddressDAO;
import com.ebay.app.apisellingextsvc.utils.AddressHelper;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.SitePolicyUtil;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.globalenv.policy.SitePolicy;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.OrderAddressType;
import com.ebay.order.common.v1.ProgramEnumType;
import com.ebay.order.common.v1.ProgramType;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AddressType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.ATTR_REFERENCE_ID;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.EBAY_MANAGED_SHIPPING;
import static com.ebay.app.apisellingextsvc.service.dal.useraddress.UserAddressFlags.BUYERS_CONSENT_TO_SHOW_PHONE_NUMBER;
import static com.ebay.order.common.v1.AddressType.BUYER_SHIPPING_ADDRESS;


public class OrderShippingAddressBuilder extends BaseFacetBuilder<AddressType> {
    private final OrderCSXType order;
    private final List<String> shippingProgramName;
    private final SiteContext siteContext;
    private final IContentHelper contentHelper;

    public OrderShippingAddressBuilder(Task<?> task,
                                       @Nonnull OrderCSXType order,
                                       SiteContext siteContext,
                                       IContentHelper contentHelper) {
        super(task);
        this.order = order;
        this.contentHelper = contentHelper;

        shippingProgramName = order.getPrograms().stream()
                .map(ProgramType::getName)
                .filter(ProgramAddressMapper::containShippingProgram)
                .collect(Collectors.toList());

        this.siteContext = siteContext;
    }

    @Override
    protected AddressType doBuild() {

        OrderAddressType buyerShippingAddress = AddressHelper.getOrderAddressType(order,BUYER_SHIPPING_ADDRESS);

        if (shippingProgramName.contains(ProgramEnumType.PICK_UP_DROP_OFF.value())) {
            return handlePudoProgramShippingAddress();
        } else if (shippingProgramName.contains(ProgramEnumType.VAULT.value()) && isWareHouseShippingAddressForVault()) {
            return handleVaultProgramShippingAddress();
        } else if (shippingProgramName.contains(EBAY_MANAGED_SHIPPING)) {
            return handleEMSAddress();
        } else if (shippingProgramName.contains(ProgramEnumType.PSA.value())) {
            return handlePSAProgramShippingAddress();
        } else if (shippingProgramName.contains(ProgramEnumType.EXPORTS.name())) {
            return handleExportShippingAddressCase();
        } else if (shippingProgramName.contains(ProgramEnumType.GLOBAL_SHIPPING_PROGRAM.value())) {
            return handleGSPAddress(order, buyerShippingAddress);
        } else if (isRegisterAddress(buyerShippingAddress)) {
            return handleRegisterAddressAsShippingAddressCase(buyerShippingAddress);
        } else {
            return handleDefaultProgramShippingAddress(buyerShippingAddress);
        }
    }

    private AddressType handleGSPAddress(OrderCSXType order, OrderAddressType buyerShippingAddress) {
        com.ebay.order.common.v1.AddressType addressTypeParams =
                ProgramAddressMapper.mapAddress(ProgramEnumType.GLOBAL_SHIPPING_PROGRAM);
        OrderAddressType orderAddressType = AddressHelper.getOrderAddressType(order, addressTypeParams);
        //For GSP order the name should be taken from BUYER_SHIPPING_ADDRESS
        String name = Optional.ofNullable(buyerShippingAddress).map(OrderAddressType::getName).map(Text::getContent).orElse(null);
        AddressType gspAddressType = AddressHelper.getAddressType(order, orderAddressType, addressTypeParams, this.contentHelper);
        gspAddressType.setName(name);
        //For GSP order the referenceID should be taken from the warehouse address. GSP order doesn't have EVTN.
        gspAddressType.setReferenceID(AttributeUtil.findAttributeValue(orderAddressType.getAttributes(), ATTR_REFERENCE_ID));
        return gspAddressType;
    }

    private AddressType handleEMSAddress() {
        com.ebay.order.common.v1.AddressType addressTypeParams = com.ebay.order.common.v1.AddressType.WAREHOUSE_ADDRESS;
        OrderAddressType orderAddressType = AddressHelper.getOrderAddressType(order, addressTypeParams);
        return AddressHelper.getAddressType(order,orderAddressType, addressTypeParams, this.contentHelper);
    }

    private AddressType handlePudoProgramShippingAddress() {
        com.ebay.order.common.v1.AddressType addressTypeParams =
                ProgramAddressMapper.mapAddress(ProgramEnumType.PICK_UP_DROP_OFF);
        OrderAddressType orderAddressType = AddressHelper.getOrderAddressType(order, addressTypeParams);
        AddressType pudoAddressType = AddressHelper.getAddressType(order, orderAddressType, addressTypeParams,
                this.contentHelper);
        pudoAddressType.setReferenceID(AttributeUtil.findAttributeValue(orderAddressType.getAttributes(), ATTR_REFERENCE_ID));
        return pudoAddressType;
    }

    private AddressType handleVaultProgramShippingAddress() {
        com.ebay.order.common.v1.AddressType addressTypeParams = com.ebay.order.common.v1.AddressType.WAREHOUSE_ADDRESS;
        OrderAddressType orderAddressType = AddressHelper.getOrderAddressType(order, addressTypeParams);
        return AddressHelper.getAddressType(order, orderAddressType, addressTypeParams, this.contentHelper);
    }

    private AddressType handlePSAProgramShippingAddress() {

        com.ebay.order.common.v1.AddressType addressTypeParams =
                ProgramAddressMapper.mapAddress(ProgramEnumType.PSA);

        OrderAddressType orderAddressType = AddressHelper.getOrderAddressType(order, addressTypeParams);

        return AddressHelper.getAddressType(order, orderAddressType, addressTypeParams, this.contentHelper);
    }

    private AddressType handleRegisterAddressAsShippingAddressCase(OrderAddressType orderAddressType) {
        // todo handle export program override street case.
        return AddressHelper.getAddressType(order, orderAddressType, BUYER_SHIPPING_ADDRESS, this.contentHelper);
    }

    private AddressType handleExportShippingAddressCase() {
        com.ebay.order.common.v1.AddressType addressTypeParams =
                ProgramAddressMapper.mapAddress(ProgramEnumType.EXPORTS);
        OrderAddressType orderAddressType = AddressHelper.getOrderAddressType(order, addressTypeParams);
        // todo handle export program override street case.
        return AddressHelper.getAddressType(order, orderAddressType, addressTypeParams, this.contentHelper);
    }

    private AddressType handleDefaultProgramShippingAddress(OrderAddressType from) {
        AddressType shipAddress = AddressHelper.getAddressType(order, from, BUYER_SHIPPING_ADDRESS, this.contentHelper);
        if (from != null && isMarkPhoneAsInvalidRequest(from)) {
            shipAddress.setPhone(ApiSellingExtSvcConstants.INVALID_REQUEST);
        }
        return shipAddress;
    }

    private boolean isMarkPhoneAsInvalidRequest(OrderAddressType from) {
        try {
            //todo isSellerRequirePhoneNumber should be call only one time
            //todo buyer setting should bulk fetch from database

            //https://jirap.corp.ebay.com/browse/TRXAPI-2124
            return !isPrivateContactInfoShow(siteContext.viewingSiteId, getBuyerRegisterSiteId())
                    && (!isSellerRequirePhoneNumber() || !isBuyerAllowShowPhoneNumber(from));
        } catch (Exception e) {
            CalLogger.warn(OrderShippingAddressBuilder.class.getSimpleName(), e.getMessage());
        }
        return false;
    }

    private Integer getBuyerRegisterSiteId() {

        //this attribute is added in this ticket, https://jirap.corp.ebay.com/browse/COSMOS-7627
        //it merged to master in 2022/11/09, so it may produce mismatch if order create date is before time.
        //pr, https://github.corp.ebay.com/cosmos/cosmosng/pull/857
        return Optional.of(order.getBuyer().getAttributes())
                .flatMap(x -> x.stream()
                        .filter(y -> y.getName().equals(ApiSellingExtSvcConstants.BUYER_REGISTRATION_SITE_ID))
                        .map(Attribute::getValue)
                        .map(Integer::parseInt).findFirst())
                .orElse(0);
    }

    private boolean isBuyerAllowShowPhoneNumber(OrderAddressType from) throws FinderException {
        long addressId = Long.parseLong(from.getAddressId().getBaseIdentifier());
        long userId = Long.parseLong(order.getBuyer().getUserIdentifier().getUserId());
        UserAddress userAddress = UserAddressDAO.getInstance().findByPrimaryKey(addressId, userId);
        return userAddress != null && userAddress.hasFlag(BUYERS_CONSENT_TO_SHOW_PHONE_NUMBER);
    }

    private boolean isSellerRequirePhoneNumber() throws FinderException {
        long sellerId = Long.parseLong(order.getSeller().getUserIdentifier().getUserId());
        SellerPref sellerPref = SellerPrefDAO.getInstance().findByPrimaryKey(sellerId);
        return sellerPref != null && sellerPref.hasFlag(SellerPrefFlags.REQUIRE_PHONE_FOR_SHIPPING_MASK);
    }

    public boolean isPrivateContactInfoShow(int siteId, int registerSiteId) {
        SitePolicy sitePolicy = SitePolicyUtil.getSitePolicy(siteId);
        SitePolicy regSitePolicy = SitePolicyUtil.getSitePolicy(registerSiteId);
        return !regSitePolicy.antiSpamEnabled() && !sitePolicy.antiSpamEnabled();
    }

    private boolean isRegisterAddress(OrderAddressType orderAddressType) {
        if (orderAddressType == null || CollectionUtils.isEmpty(orderAddressType.getAttributes())) {
            return false;
        }

        Optional<Attribute> isRegistrationAddress = orderAddressType.getAttributes().stream()
                .filter(x -> x.getName().equals(ApiSellingExtSvcConstants.IS_REGISTRATION_ADDRESS))
                .findFirst();

        return isRegistrationAddress.isPresent() && isRegistrationAddress.get().getValue().equalsIgnoreCase(Boolean.TRUE.toString());
    }

    private boolean isWareHouseShippingAddressForVault() {
        String vasSubTypeValue  = order.getPrograms().stream()
                .filter(x -> ProgramEnumType.VAULT.name().equals(x.getName()))
                .flatMap(y -> y.getSpecifics().stream().filter(z -> z.getName()
                        .equals(ApiSellingExtSvcConstants.VAS_SUB_TYPE_NAME)))
                .findFirst().map(Attribute::getValue).orElse(null);

        if (StringUtils.isNotEmpty(vasSubTypeValue)) {
            return ApiSellingExtSvcConstants.SHIP_TO_VAULT.equals(vasSubTypeValue);
        }
        return false;
    }
}
