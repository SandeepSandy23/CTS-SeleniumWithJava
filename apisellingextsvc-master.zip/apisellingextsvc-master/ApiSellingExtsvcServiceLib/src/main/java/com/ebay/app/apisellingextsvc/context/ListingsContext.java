package com.ebay.app.apisellingextsvc.context;

import org.apache.commons.lang3.tuple.Pair;

import javax.ws.rs.core.HttpHeaders;
import java.util.List;

public class ListingsContext {

    private final List<Pair<String, Object>> queryParams;
    private final HttpHeaders headers;

    public ListingsContext(List<Pair<String, Object>> queryParams,
                           HttpHeaders headers) {
        this.queryParams = queryParams;
        this.headers = headers;
    }

    public static ListingsContext createGetRequestContext(List<Pair<String, Object>> queryParams, HttpHeaders headers) {
        return new ListingsContext(queryParams, headers);
    }

    public List<Pair<String, Object>> getQueryParams() {
        return queryParams;
    }

    public HttpHeaders getHeaders() {
        return headers;
    }

}
