package com.ebay.app.apisellingextsvc.tasks.models;

import java.util.HashMap;
import java.util.Map;

public class SellerProdDataModel {
    private Map<Long, String> sellerProdId;

    public Map<Long, String> getSellerProdId() {
        if (sellerProdId == null) {
            return new HashMap<>();
        }
        return sellerProdId;
    }

    public void setSellerProdId(Map<Long, String> sellerProdId) {
        this.sellerProdId = sellerProdId;
    }
}
