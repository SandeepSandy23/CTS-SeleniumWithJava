package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import com.ebay.af.common.types.RawString;
import com.ebay.integ.dal.BaseDo2;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;

import java.lang.reflect.Field;
import java.util.Date;

public class ItemHostInfoCodeGenDoImpl extends BaseDo2 implements ItemHostInfo {
    public static final int HOSTID = 0;
    public static final int PRIMARYHOSTNAME = 1;
    public static final int READONLYHOSTNAME = 2;
    public static final int DESCRIPTION = 3;
    public static final int RANGESTART = 4;
    public static final int RANGEEND = 5;
    public static final int CREATIONDATE = 6;
    public static final int LASTMODIFIEDDATE = 7;
    public static final int _HOSTID = 8;
    public static final int _CREATIONDATE = 9;
    public static final int _LASTMODIFIEDDATE = 10;
    public static final int ITEMID = 11;
    public static final int NUM_FIELDS = 12;
    public static final int NUM_SUBOBJECT_FIELDS = 0;
    public long m_hostId;
    public String m_primaryHostName;
    public String m_readOnlyHostName;
    public String m_description;
    public long m_rangeStart;
    public long m_rangeEnd;
    public Date m_creationDate;
    public Date m_lastModifiedDate;
    public long m__hostId;
    public Date m__creationDate;
    public Date m__lastModifiedDate;
    public long m_itemId;

    public ItemHostInfoCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public int getNumFields() {
        return 12;
    }

    public int getNumSubObjects() {
        return 0;
    }

    public long getHostId() {
        this.loadValue(HOSTID);
        return this.m_hostId;
    }

    public void setHostId(long hostId) {
        this.m_hostId = hostId;
        this.setDirty(HOSTID);
    }

    public String getPrimaryHostName() {
        this.loadValue(PRIMARYHOSTNAME);
        return this.m_primaryHostName;
    }

    public void setPrimaryHostName(String primaryHostName) {
        this.m_primaryHostName = primaryHostName;
        this.setDirty(PRIMARYHOSTNAME);
    }

    public String getReadOnlyHostName() {
        this.loadValue(READONLYHOSTNAME);
        return this.m_readOnlyHostName;
    }

    public void setReadOnlyHostName(String readOnlyHostName) {
        this.m_readOnlyHostName = readOnlyHostName;
        this.setDirty(READONLYHOSTNAME);
    }

    public String getDescription() {
        this.loadValue(DESCRIPTION);
        return this.m_description;
    }

    public void setDescription(String description) {
        this.m_description = description;
        this.setDirty(DESCRIPTION);
    }

    public long getRangeStart() {
        this.loadValue(RANGESTART);
        return this.m_rangeStart;
    }

    public void setRangeStart(long rangeStart) {
        this.m_rangeStart = rangeStart;
        this.setDirty(RANGESTART);
    }

    public long getRangeEnd() {
        this.loadValue(RANGEEND);
        return this.m_rangeEnd;
    }

    public void setRangeEnd(long rangeEnd) {
        this.m_rangeEnd = rangeEnd;
        this.setDirty(RANGEEND);
    }

    public Date getCreationDate() {
        this.loadValue(CREATIONDATE);
        return this.m_creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.m_creationDate = creationDate;
        this.setDirty(CREATIONDATE);
    }

    public Date getLastModifiedDate() {
        this.loadValue(LASTMODIFIEDDATE);
        return this.m_lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.m_lastModifiedDate = lastModifiedDate;
        this.setDirty(LASTMODIFIEDDATE);
    }

    public long get_hostId() {
        this.loadValue(_HOSTID);
        return this.m__hostId;
    }

    public void set_hostId(long _hostId) {
        this.m__hostId = _hostId;
        this.setDirty(_HOSTID);
    }

    public Date get_creationDate() {
        this.loadValue(_CREATIONDATE);
        return this.m__creationDate;
    }

    public void set_creationDate(Date _creationDate) {
        this.m__creationDate = _creationDate;
        this.setDirty(_CREATIONDATE);
    }

    public Date get_lastModifiedDate() {
        this.loadValue(_LASTMODIFIEDDATE);
        return this.m__lastModifiedDate;
    }

    public void set_lastModifiedDate(Date _lastModifiedDate) {
        this.m__lastModifiedDate = _lastModifiedDate;
        this.setDirty(_LASTMODIFIEDDATE);
    }

    public long getItemId() {
        return this.m_itemId;
    }

    public void setItemId(long itemId) {
        this.m_itemId = itemId;
        this.setDirty(11);
    }

    public Object getSubObject(int subObjConst) {
        Object theObj = null;
        switch (subObjConst) {
            default:
                theObj = super.getSubObject(subObjConst);
                return theObj;
        }
    }

    public Object loadSubObject(int subObjConst, int readSet) {
        Object theObj = null;
        switch (subObjConst) {
            default:
                theObj = super.loadSubObject(subObjConst, readSet);
                return theObj;
        }
    }

    public boolean equalsData(BaseDo2 other) {
        if (other == null) {
            return false;
        } else if (!(other instanceof ItemHostInfoCodeGenDoImpl)) {
            return false;
        } else if (!super.equalsData(other)) {
            return false;
        } else {
            ItemHostInfoCodeGenDoImpl cmpDo = (ItemHostInfoCodeGenDoImpl) other;
            String className = this.getClass().getName();
            String packageName = className.substring(0, className.lastIndexOf("."));
            String myClassName = packageName + ".ItemHostInfoCodeGenDoImpl";
            Class myClass = null;

            try {
                myClass = Class.forName(myClassName);
            } catch (ClassNotFoundException var15) {
                return false;
            }

            Field[] fields = myClass.getDeclaredFields();

            for (int i = 0; i < fields.length; ++i) {
                Field f = fields[i];
                if (f.getModifiers() == 1 && f.getModifiers() != 8) {
                    String fieldType = f.getType().getName();

                    try {
                        boolean isEqual = true;
                        if (fieldType.equals("int")) {
                            isEqual = safeEquals(f.getInt(this), f.getInt(cmpDo));
                        } else if (fieldType.equals("long")) {
                            isEqual = safeEquals(f.getLong(this), f.getLong(cmpDo));
                        } else if (fieldType.equals("float")) {
                            isEqual = safeEquals(f.getFloat(this), f.getFloat(cmpDo));
                        } else if (fieldType.equals("double")) {
                            isEqual = safeEquals(f.getDouble(this), f.getDouble(cmpDo));
                        } else if (fieldType.equals("boolean")) {
                            isEqual = safeEquals(f.getBoolean(this), f.getBoolean(cmpDo));
                        } else if (fieldType.endsWith("RawString")) {
                            RawString a = (RawString) f.get(this);
                            RawString b = (RawString) f.get(cmpDo);
                            isEqual = safeEquals(a, b);
                        } else if (fieldType.endsWith("java.util.Date")) {
                            Date a = (Date) f.get(this);
                            Date b = (Date) f.get(cmpDo);
                            isEqual = safeEquals(a, b);
                        } else {
                            isEqual = safeEquals(f.get(this), f.get(cmpDo));
                        }

                        if (!isEqual) {
                            return false;
                        }
                    } catch (IllegalAccessException var14) {
                        return false;
                    }
                }
            }

            return true;
        }
    }

    private void copyFieldsFrom_Batch0(ItemHostInfoCodeGenDoImpl from) {
        if (!this.isLoaded(0) && from.isLoaded(0)) {
            this.m_hostId = from.m_hostId;
            this.copyFieldState(from, 0);
        }

        if (!this.isLoaded(1) && from.isLoaded(1)) {
            this.m_primaryHostName = from.m_primaryHostName;
            this.copyFieldState(from, 1);
        }

        if (!this.isLoaded(2) && from.isLoaded(2)) {
            this.m_readOnlyHostName = from.m_readOnlyHostName;
            this.copyFieldState(from, 2);
        }

        if (!this.isLoaded(3) && from.isLoaded(3)) {
            this.m_description = from.m_description;
            this.copyFieldState(from, 3);
        }

        if (!this.isLoaded(4) && from.isLoaded(4)) {
            this.m_rangeStart = from.m_rangeStart;
            this.copyFieldState(from, 4);
        }

        if (!this.isLoaded(5) && from.isLoaded(5)) {
            this.m_rangeEnd = from.m_rangeEnd;
            this.copyFieldState(from, 5);
        }

        if (!this.isLoaded(6) && from.isLoaded(6)) {
            this.m_creationDate = copyDate(from.m_creationDate);
            this.copyFieldState(from, 6);
        }

        if (!this.isLoaded(7) && from.isLoaded(7)) {
            this.m_lastModifiedDate = copyDate(from.m_lastModifiedDate);
            this.copyFieldState(from, 7);
        }

        if (!this.isLoaded(8) && from.isLoaded(8)) {
            this.m__hostId = from.m__hostId;
            this.copyFieldState(from, 8);
        }

        if (!this.isLoaded(9) && from.isLoaded(9)) {
            this.m__creationDate = copyDate(from.m__creationDate);
            this.copyFieldState(from, 9);
        }

        if (!this.isLoaded(10) && from.isLoaded(10)) {
            this.m__lastModifiedDate = copyDate(from.m__lastModifiedDate);
            this.copyFieldState(from, 10);
        }

        if (!this.isLoaded(11) && from.isLoaded(11)) {
            this.m_itemId = from.m_itemId;
            this.copyFieldState(from, 11);
        }

    }

    public void copyFieldsFrom(BaseDo2 copyFromObj) {
        super.copyFieldsFrom(copyFromObj);
        if (copyFromObj != null && copyFromObj instanceof ItemHostInfoCodeGenDoImpl) {
            ItemHostInfoCodeGenDoImpl from = (ItemHostInfoCodeGenDoImpl) copyFromObj;
            this.copyFieldsFrom_Batch0(from);
        }

        this.makeFieldsNullAndLoaded();
    }

    private void makeFieldsNullAndLoaded() {
        if (!this.isLoaded(0)) {
            this.setLoadedField(0);
            this.setNull(0);
        }

        if (!this.isLoaded(1)) {
            this.setLoadedField(1);
            this.setNull(1);
        }

        if (!this.isLoaded(2)) {
            this.setLoadedField(2);
            this.setNull(2);
        }

        if (!this.isLoaded(3)) {
            this.setLoadedField(3);
            this.setNull(3);
        }

        if (!this.isLoaded(4)) {
            this.setLoadedField(4);
            this.setNull(4);
        }

        if (!this.isLoaded(5)) {
            this.setLoadedField(5);
            this.setNull(5);
        }

        if (!this.isLoaded(6)) {
            this.setLoadedField(6);
            this.setNull(6);
        }

        if (!this.isLoaded(7)) {
            this.setLoadedField(7);
            this.setNull(7);
        }

        if (!this.isLoaded(8)) {
            this.setLoadedField(8);
            this.setNull(8);
        }

        if (!this.isLoaded(9)) {
            this.setLoadedField(9);
            this.setNull(9);
        }

        if (!this.isLoaded(10)) {
            this.setLoadedField(10);
            this.setNull(10);
        }

        if (!this.isLoaded(11)) {
            this.setLoadedField(11);
            this.setNull(11);
        }

    }
}
