package com.ebay.app.apisellingextsvc.service.dal.userlookup;

import com.ebay.integ.dal.DalDOI;
import com.ebay.persistence.Column;
import com.ebay.persistence.Table;

import javax.persistence.Entity;

@Entity
@Table(name = "USER_HOST_ID_LOOKUP")
public interface UserLookup extends DalDOI {

    @Column(name = "USER_ID")
    long getUserId();

    void setUserId(long userId);

    @Column(name = "HOST_ID01")
    int getHostId01();

    void setHostId01(int hostId);

}
