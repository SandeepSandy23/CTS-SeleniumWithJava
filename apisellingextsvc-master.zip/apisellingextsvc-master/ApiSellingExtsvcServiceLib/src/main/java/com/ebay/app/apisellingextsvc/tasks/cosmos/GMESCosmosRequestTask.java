package com.ebay.app.apisellingextsvc.tasks.cosmos;

import com.ebay.app.apisellingextsvc.builders.CosmosRequestBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.enums.FundingEnum;
import com.ebay.app.apisellingextsvc.enums.ShipmentEnum;
import com.ebay.app.apisellingextsvc.init.GetMyeBaySellerRequestContext;
import com.ebay.app.apisellingextsvc.mappers.ItemSortTypeCodeTypeMapper;
import com.ebay.app.apisellingextsvc.service.client.model.CosmosRequest;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.SummaryUtil;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.GetMyeBaySellingRequestType;
import ebay.apis.eblbasecomponents.ItemListCustomizationType;
import ebay.apis.eblbasecomponents.ItemSortTypeCodeType;
import ebay.apis.eblbasecomponents.OrderStatusFilterCodeType;
import org.apache.commons.collections.CollectionUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.Calendar;
import java.util.TimeZone;

public class GMESCosmosRequestTask implements Task<CosmosRequest>, ITaskResultInjectable {

    private GetMyeBaySellerRequestContext requestContext;
    private final GetMyeBaySellingRequestType request;
    private final HttpHeaders httpHeaders;
    private final User user;
    private final ApiSellingExtSvcConfigValues configValues;
    private final String type;

    public GMESCosmosRequestTask(
            GetMyeBaySellingRequestType request,
            HttpHeaders httpHeaders,
            User user,
            ApiSellingExtSvcConfigValues configValues,
            String type) {
        this.request = request;
        this.httpHeaders = httpHeaders;
        this.user = user;
        this.configValues = configValues;
        this.type = type;
    }

    @Override
    public CosmosRequest call() {
        CosmosRequestBuilder builder = new CosmosRequestBuilder();
        builder.requestHeader(httpHeaders);
        if (CollectionUtils.isNotEmpty(request.getDetailLevel())) {
            builder.detailLevel(request.getDetailLevel().get(0).value());
        }
        builder.hasPaginationMode(false);
        builder.userType("seller");
        builder.userId(this.user.getUserId());
        builder.userName(this.user.getUserName());
        builder.omsVersion(configValues.omsVersion);

        if (type.equals(ApiSellingExtSvcConstants.SOLD_LIST)) {
            builder.visibilityValue(CosmosRequestBuilder.VisibilityValue.ACTIVE);
            validateRequest(request.getSoldList(), builder);
        }

        if (type.equals(ApiSellingExtSvcConstants.SUMMARY) || type.equals(ApiSellingExtSvcConstants.SELLING_SUMMARY)) {
            builder.visibilityValue(CosmosRequestBuilder.VisibilityValue.ACTIVE);
            validateSummaryRequest(request.getSoldList(), builder);
            return builder.buildSummary();
        }

        if (type.equals(ApiSellingExtSvcConstants.DELETED_FROM_SOLD_LIST)) {
            builder.visibilityValue(CosmosRequestBuilder.VisibilityValue.HIDDEN);
            validateRequest(request.getDeletedFromSoldList(), builder);
        }

        return builder.build();
    }

    private void validateRequest(ItemListCustomizationType itemListCustomizationType, CosmosRequestBuilder builder) {
        if (itemListCustomizationType != null) {
            buildOrderStatusFilterCodeType(itemListCustomizationType, builder);
            buildDuration(itemListCustomizationType, builder);
            buildPagination(itemListCustomizationType, builder);
            buildSort(itemListCustomizationType, builder);
        }
    }

    private void validateSummaryRequest(ItemListCustomizationType itemListCustomizationType, CosmosRequestBuilder builder) {
        int duration = SummaryUtil.getSoldDurationInDays(itemListCustomizationType, configValues);
        buildCreationDateFilter(duration, builder);
    }

    public void buildPagination(ItemListCustomizationType itemListCustomizationType, CosmosRequestBuilder builder) {
        if (itemListCustomizationType.getPagination() != null) {
            builder.entryPerPage(itemListCustomizationType.getPagination().getEntriesPerPage());
            builder.pageNumber(itemListCustomizationType.getPagination().getPageNumber());
        }
    }

    public void buildOrderStatusFilterCodeType(ItemListCustomizationType itemListCustomizationType, CosmosRequestBuilder builder) {
        if (itemListCustomizationType.getOrderStatusFilter() != null) {
            orderStatusFilterMapper(itemListCustomizationType.getOrderStatusFilter(), builder);
        }
    }

    public void buildSort(ItemListCustomizationType itemListCustomizationType, CosmosRequestBuilder builder) {
        if (itemListCustomizationType.getSort() != null) {
            builder.sortOrder(ItemSortTypeCodeTypeMapper.map(itemListCustomizationType.getSort(), ItemSortTypeCodeTypeMapper.Service.COSMOS, "-creationdate"));
        }
    }

    public void buildDuration(ItemListCustomizationType itemListCustomizationType, CosmosRequestBuilder builder) {
        if (itemListCustomizationType.getDurationInDays() == null) {
            itemListCustomizationType.setDurationInDays(configValues.gmesSoldDefaultDays);
        }
        buildCreationDateFilter(itemListCustomizationType.getDurationInDays(), builder);
    }

    public void buildCreationDateFilter(int duration, CosmosRequestBuilder builder) {
        TimeZone timezone = TimeZone.getDefault();
        Calendar dateNow = DateUtil.getCalendarNow(timezone);
        Calendar dateFrom = DateUtil.getDateWithOffset(duration, timezone);
        builder.createDateFrom(dateFrom);
        builder.createDateTo(dateNow);
    }

    private void orderStatusFilterMapper(OrderStatusFilterCodeType orderStatusFilter, CosmosRequestBuilder builder) {
        if (orderStatusFilter.equals(OrderStatusFilterCodeType.AWAITING_PAYMENT)) {
            builder.fundingStatus(FundingEnum.unpaid.toString());
        } else if (orderStatusFilter.equals(OrderStatusFilterCodeType.AWAITING_SHIPMENT)) {
            builder.fundingStatus(FundingEnum.paid.toString());
            builder.shipmentStatus(ShipmentEnum.notshipped.toString() + "|" + ShipmentEnum.partiallyshipped.toString() );
        } else if (orderStatusFilter.equals(OrderStatusFilterCodeType.PAID_AND_SHIPPED)) {
            builder.fundingStatus(FundingEnum.paid.toString());
            builder.shipmentStatus(ShipmentEnum.shipped.toString() + "|" + ShipmentEnum.partiallyshipped.toString() );
        }
    }

    @Override
    public void addResult(Object result) {
        this.requestContext = (GetMyeBaySellerRequestContext) result;
    }
}
