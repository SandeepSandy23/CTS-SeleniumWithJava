package com.ebay.app.apisellingextsvc.service.bof.exchangerate;

import com.ebay.app.apisellingextsvc.service.dal.exchangerate.ExchangeRate;
import com.ebay.app.apisellingextsvc.test.TestMock;
import com.ebay.app.apisellingextsvc.test.TestMockHolder;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;


public class ExchangeRateBofMock implements IExchangeRateBof {

    public static final String EXCHANGE_RATE_MOCK_NAME_PREFIX = "IExchangeRateBof";

    private final Map<Integer, ExchangeRate> map;

    public ExchangeRateBofMock(TestMock mock) {
        map = TestMockHolder.getMock(mock, ExchangeRateListMock.class).getExchangeRates().stream()
              .collect(Collectors.toMap(ExchangeRate::getFromCurrency,
                    Function.identity()));
    }

    public ExchangeRateBofMock(ExchangeRateListMock mock) {
        map = mock.getExchangeRates().stream()
              .collect(Collectors.toMap(ExchangeRate::getFromCurrency,
                    Function.identity()));
    }

    @Override
    public Double findExchangeRateByCurrencyId(int currencyId) {
        return map.get(currencyId).getRate();
    }
}
