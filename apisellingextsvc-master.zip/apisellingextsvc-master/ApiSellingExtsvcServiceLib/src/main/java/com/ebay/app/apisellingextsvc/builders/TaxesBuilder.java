package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.app.apisellingextsvc.utils.TaxUtil;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.UserCS;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.TaxesType;

public class TaxesBuilder extends AbstractTaxesBuilder {

    public TaxesBuilder(Task<?> task,
                        OrderCSXType order,
                        LineItemXType lineItem,
                        int trxVersion,
                        UserCS buyer,
                        ApiSellingExtSvcConfigValues configValues) {
        super(task, order, lineItem, trxVersion, lineItem.getTax(), buyer, AmountTypeUtil.getCurrency(order.getOrderTotal()), configValues, order.getAttributes());
    }

    @Override
    protected TaxesType doBuild() {
        return buildTax();
    }

    protected TaxesType buildTax() {
        TaxesType taxesType = new TaxesType();
        //get tax type first, return directly if cannot find any valid tax type
        String taxType = getTaxType();
        if (buildTotalTaxAmount() == null) {
            return null;
        }
        if(taxType == null){
            return taxesType;
        }
        return buildTaxTypeDetails(taxesType, taxType);
    }


    @Override
    protected String getTaxType() {
        String taxType = getEbayCollectAndRemitTax();
        if (!PaymentUtil.hasEbayCollectedTax(orderAttributes) && !isInvoiceToSeller()) {
            return getTaxTypeCollectedBySeller(taxType);
        } else if ((isInvoiceToSeller() || isTaxIncludeInSellerDistribution())) {
            return getTaxTypeCollectedBySeller(taxType);
        } else if (trxVersion < VersionConstant.VERSION_AU_GST) {
            /**
             * Legacy trading api:
             * transactionBo.getTaxCalculator() != 5 && !OmsDetailsUtil.isGSTInfoInOmsDetails(transactionBo)
             * field TaxCalculator map to taxEngineUsed attribute, value 5 map to AU_GST_ENGINE, this message get from wiki below:
             * https://wiki.corp.ebay.com/display/OMS/CreatePO+AUTax
             * https://wiki.corp.ebay.com/display/OMS/AU+Tax
             * https://wiki.corp.ebay.com/display/Trustengineering/%5BDeprecated%5D+COPS+and+WATAX+Metrics+and+Alerts+for+Resolutions
             */
            if (!isTaxEngineGst() && !isTaxTypeGST(taxType)) {
                return ApiSellingExtSvcConstants.TAX_TYPE_SALES_TAX;
            }
            return ApiSellingExtSvcConstants.GST;
        } else if(PaymentUtil.hasEbayCollectedTax(orderAttributes) && isTaxTypeMYSalesTax(taxType, getTaxState())) {
            return ApiSellingExtSvcConstants.TAX_TYPE_SALES_TAX;
        }
        return null;
    }

    private String getTaxTypeCollectedBySeller(String taxType) {
        if (isTaxTypeGST(taxType)) {
            return ApiSellingExtSvcConstants.GST;
        }
        return ApiSellingExtSvcConstants.TAX_TYPE_SALES_TAX;
    }

    private boolean isTaxEngineGst() {
        String taxEngineUsed = TaxUtil.getTaxEngineUsed(orderAttributes);
        return ApiSellingExtSvcConstants.AU_GST_ENGINE.equalsIgnoreCase(taxEngineUsed);
    }
}
