package com.ebay.app.apisellingextsvc.service.client;


import com.ebay.jaxrs.client.config.ConfigurationBuilder;

import java.util.HashMap;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Configuration;

import org.apache.commons.lang3.StringUtils;

public class GingerClientFactory {

    private static final GingerClientFactory instance = new GingerClientFactory();

    private static final Object mutex = new Object();

    private HashMap<String, Client> clients = null;

    private GingerClientFactory() {
        clients = new HashMap<>();
    }

    public static GingerClientFactory getInstance() {
        return instance;
    }

    public Client getClientById(String clientId) {
        if (StringUtils.isNoneBlank(clientId) && !clients.containsKey(clientId)) {
            synchronized (mutex) {
                Configuration config = ConfigurationBuilder.newConfig(clientId);
                Client client = ClientBuilder.newClient(config);
                clients.put(clientId, client);
            }
        }
        return clients.get(clientId);
    }

}
