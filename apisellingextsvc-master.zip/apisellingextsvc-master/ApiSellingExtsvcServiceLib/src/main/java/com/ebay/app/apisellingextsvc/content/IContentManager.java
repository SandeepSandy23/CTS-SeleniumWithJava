package com.ebay.app.apisellingextsvc.content;

import com.ebay.content.runtime.api.IContentMap;
import com.ebay.content.runtime.api.IContentStructure;
import com.ebay.app.apisellingextsvc.context.ErrorMessage;
import com.ebay.app.apisellingextsvc.enums.ContentBundleEnum;

import java.util.Map;

public interface IContentManager {

    IContentStructure getContentStructure(ContentBundleEnum bundle, String key);

    IContentMap getContentMap(ContentBundleEnum bundle, String key);

    String getContentMapValue(ContentBundleEnum bundle, String key, String mapKey);

    ErrorMessage getErrorMessage(String key, Map<String, String> replaceMap);

    String getText(ContentBundleEnum bundle, String key);
}
