package com.ebay.app.apisellingextsvc.builders;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cos.type.v3.core.listing.ItemVariation;
import com.ebay.cos.type.v3.core.listing.Listing;
import com.ebay.raptor.orchestrationv2.task.Task;

import ebay.apis.eblbasecomponents.SellingStatusType;
import ebay.apis.eblbasecomponents.VariationType;
import ebay.apis.eblbasecomponents.VariationsType;

/**
 * Builds variation for SoldList
 */
public class SoldItemVariationsBuilder extends ItemVariationsBuilder {

    private final String sourceVariationId;

	public SoldItemVariationsBuilder(Task<?> task, ListingActivitiesDetail listingActivity, SellingStatusType sellingStatus, String sourceVariationId) {
		super(task, listingActivity, sellingStatus);
		this.sourceVariationId = sourceVariationId; // Sold variation Id from COSMOS
	}
	
	/**
	 * Builds the variationType for the sold variation 
	 */
	@Override
    public VariationsType doBuild() {
        VariationsType variationsType = null;
        List<VariationType> variationTypeList = new ArrayList<>();
        Optional<List<ItemVariation>> variationList = Optional.ofNullable(getListingActivity())
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getItemVariations)
                .filter(CollectionUtils::isNotEmpty);
        
        if (variationList.isPresent()) {
            for (ItemVariation itemVariation : variationList.get()) {
            	// Filters out sold variation from the available variations
            	if (sourceVariationId != null && itemVariation.getVariationId() != null && sourceVariationId.equals(String.valueOf(itemVariation.getVariationId()))) {
            		setVariationType(itemVariation, variationTypeList, false);
            	}
            }
            if (CollectionUtils.isNotEmpty(variationTypeList)) {
                variationsType = new VariationsType();
                variationsType.getVariation().addAll(variationTypeList);
            }
        }
        return variationsType;
    }

}
