package com.ebay.app.apisellingextsvc.tasks.filter;

import com.ebay.app.apisellingextsvc.application.common.request.BaseApplicationRequest;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.content.IContentManager;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import com.ebay.app.apisellingextsvc.handlers.ExceptionHandler;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;

import com.ebay.app.apisellingextsvc.utils.NumberUtil;

import javax.ws.rs.core.HttpHeaders;
import java.util.Arrays;

import static org.apache.axis2.transport.http.HTTPConstants.HEADER_SOAP_ACTION;

public class BasicRequestValidatorFilter implements IFilter {

    private final BaseApplicationRequest baseRequest;
    private final ContentResource contentResource;
    private final String errorLanguage;
    private final HttpHeaders headers;
    private final ApiSellingExtSvcConfigValues configValues;

    public BasicRequestValidatorFilter(BaseApplicationRequest baseRequest,
                                       ContentResource contentResource,
                                       String errorLanguage,
                                       ApiSellingExtSvcConfigValues configValues) {
        this.baseRequest = baseRequest;
        this.contentResource = contentResource;
        this.errorLanguage = errorLanguage;
        this.headers = baseRequest.getHeaders();
        this.configValues = configValues;

    }

    @Override
    public void doFilter() {
        IContentManager errorContentManager = contentResource.contentHelper.getErrorContentManager();
        if (headers.getRequestHeaders().containsKey(HEADER_SOAP_ACTION.toUpperCase())) {
            doSOAPVersionValidation(errorContentManager);
        } else {
            doXMLVersionValidation(errorContentManager);
        }
    }

    private void doSOAPVersionValidation(IContentManager errorContentManager) {
        Integer version = NumberUtil.safeStringToInt(baseRequest.getRequestType().getVersion());
        if (version == null || version < configValues.minimumSchemaVersion) {
            String versionString = version != null ? version.toString() : "null";
            CalLogger.error("Request Filter Error", "Client SOAP Body Schema Version incompatible.");
            ExceptionHandler.throwException(ApplicationError.INCOMPATIBLE_SCHEMA_VERSION, errorContentManager, Arrays.asList(versionString, configValues.minimumSchemaVersion.toString()));
        }
        baseRequest.trxVersion = version;
    }

    private void doXMLVersionValidation(IContentManager errorContentManager) {
        Integer headerVersion = NumberUtil.safeStringToInt(HeaderUtil.getCompatibilityLevel(headers));
        if (headerVersion == null) {
            CalLogger.error("Request Filter Error", "Client XML Header Schema Version invalid.");
            ExceptionHandler.throwException(ApplicationError.INVALID_HEADER, errorContentManager, Arrays.asList("X-EBAY-API-COMPATIBILITY-LEVEL", "(null)"));
        } else if (headerVersion < configValues.minimumSchemaVersion) {
            CalLogger.error("Request Filter Error", "Client XML Header Schema Version too low.");
            ExceptionHandler.throwException(ApplicationError.UNSUPPORTED_COMPATABILITY, errorContentManager);
        }
        Integer requestBodyVersion = NumberUtil.safeStringToInt(baseRequest.getRequestType().getVersion());
        if (requestBodyVersion != null && !headerVersion.equals(requestBodyVersion)) {
            ExceptionHandler.logException(baseRequest.getErrorList(), ApplicationError.COMPATIBILITY_HEADER_MISMATCH, errorContentManager, Arrays.asList(headerVersion.toString(), requestBodyVersion.toString()));
        }

        baseRequest.trxVersion = headerVersion;
    }
}
