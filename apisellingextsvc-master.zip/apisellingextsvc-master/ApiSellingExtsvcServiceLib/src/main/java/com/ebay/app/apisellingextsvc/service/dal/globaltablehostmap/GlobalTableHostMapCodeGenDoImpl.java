package com.ebay.app.apisellingextsvc.service.dal.globaltablehostmap;

import com.ebay.integ.dal.BaseDo2;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;

public class GlobalTableHostMapCodeGenDoImpl extends BaseDo2 implements GlobalTableHostMap {
    public static final int PHYSICALTABLENAME = 1;
    public static final int LOGICALHOSTID = 2;
    public static final int LOGICALHOSTNAME = 3;
    public static final int MINHOSTNUM = 4;
    public static final int MAXHOSTNUM = 5;

    public static final int NUM_FIELDS = 7;
    public String m_physicalTableName;
    public int m_logicalHostId;
    public String m_logicalHostName;
    public short m_minHostNum;
    public short m_maxHostNum;

    public GlobalTableHostMapCodeGenDoImpl() {
        super(GlobalTableHostMapDAO.getInstance(), GenericMap.getInitializedMap(GlobalTableHostMap.class));
    }

    public GlobalTableHostMapCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public int getNumFields() {
        return NUM_FIELDS;
    }

    public String getPhysicalTableName() {
        this.loadValue(PHYSICALTABLENAME);
        return this.m_physicalTableName;
    }

    public void setPhysicalTableName(String physicalTableName) {
        this.m_physicalTableName = physicalTableName;
        this.setDirty(PHYSICALTABLENAME);
    }

    public int getLogicalHostId() {
        this.loadValue(LOGICALHOSTID);
        return this.m_logicalHostId;
    }

    public void setLogicalHostId(int logicalHostId) {
        this.m_logicalHostId = logicalHostId;
        this.setDirty(LOGICALHOSTID);
    }

    public String getLogicalHostName() {
        this.loadValue(LOGICALHOSTNAME);
        return this.m_logicalHostName;
    }

    public void setLogicalHostName(String logicalHostName) {
        this.m_logicalHostName = logicalHostName;
        this.setDirty(LOGICALHOSTNAME);
    }

    public short getMinHostNum() {
        this.loadValue(MINHOSTNUM);
        return this.m_minHostNum;
    }

    public void setMinHostNum(short minHostNum) {
        this.m_minHostNum = minHostNum;
        this.setDirty(MINHOSTNUM);
    }

    public short getMaxHostNum() {
        this.loadValue(MAXHOSTNUM);
        return this.m_maxHostNum;
    }

    public void setMaxHostNum(short maxHostNum) {
        this.m_maxHostNum = maxHostNum;
        this.setDirty(MAXHOSTNUM);
    }
}
