package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.ListingsContext;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.model.ListingActivitiesByIdsModel;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsResponse;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.common.collect.ImmutableList;
import ebay.apis.eblbasecomponents.ErrorType;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.util.CollectionUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.EQUALS;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.LISTING_ID;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_FIELDS;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_Q_FIELD;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_Q_OPERATOR;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_Q_VALUE;

/**
 * <pre>
 * <a href="https://github.corp.ebay.com/Selling/lasng/blob/master/lasngService/src/main/resources/api/openapi.yaml">Selling lasng</a>
 * GET https://lasng.vip.qa.ebay.com/lasngsvc/v1/listing_activity
 * Sample request: https://lasng.vip.ebay.com/lasngsvc/v1/listing_activity?
 * fields=price,quantity,format,duration,shipping,lifecycle,bid_count,best_offer_terms,
 * category,is_managed_by_sku&q_field=listing_id&q_operator=equals&q_value=173460309834|173460331230|173461965736|173461971756
 * Headers
 * 1. Authorization
 * 2. X-EBAY-C-ENDUSERCTX
 *
 * if user ctx is buyer, return 400
 * </pre>
 */
public class GSTLasngServiceTask implements Task<ListingActivitiesByIdsModel>, ITaskResultInjectable {

    private Map<String, Object> resultMap = new HashMap<>();
    private final User user;
    private final IServiceInvoker<ListingsContext, GetListingActivitiesByIdsResponse> lasngServiceInvoker;
    private final List<ErrorType> errorList;
    private final HttpHeaders headers;
    final String OUTPUT_FIELD_SELECTOR = "price,quantity,format,duration,shipping,lifecycle,bid_count,best_offer_terms,category,is_managed_by_sku,variations";

    public GSTLasngServiceTask(
            IServiceInvoker<ListingsContext, GetListingActivitiesByIdsResponse> lasngServiceInvoker,
            List<ErrorType> errorList,
            HttpHeaders headers,
            User user) {
        this.lasngServiceInvoker = lasngServiceInvoker;
        this.errorList = errorList;
        this.user = user;
        this.headers = headers;
    }

    @Override
    public ListingActivitiesByIdsModel call() {
        headers.getRequestHeaders().putSingle(ApiSellingExtSvcConstants.X_EBAY_C_ENDUSERCTX, HeaderUtil.getEndUserCtx(user.getUserName(), user.getUserId()));
        ContractResponse contractResponse = (ContractResponse) resultMap.get(ContractResponse.class.getName());
        List<ContractResponseType> contractResponseTypeList = Optional.ofNullable(contractResponse)
                .map(ContractResponse::getMembers)
                .orElse(Collections.emptyList());
        if (CollectionUtils.isEmpty(contractResponseTypeList)) {
            return new ListingActivitiesByIdsModel(Collections.emptyMap());
        }
        ImmutableList<Pair<String, Object>> queryParams = ImmutableList.of(
                ImmutablePair.of(QUERY_PARAM_FIELDS, OUTPUT_FIELD_SELECTOR),
                ImmutablePair.of(QUERY_PARAM_Q_FIELD, LISTING_ID),
                ImmutablePair.of(QUERY_PARAM_Q_OPERATOR, EQUALS),
                ImmutablePair.of(QUERY_PARAM_Q_VALUE, ItemIdsParam(contractResponse)));
        ListingsContext listingsContext = new ListingsContext(queryParams,headers);
        GetListingActivitiesByIdsResponse getListingActivitiesByIdsResponse = this.lasngServiceInvoker.getResponse(listingsContext, headers);
        HashMap<Long, ListingActivity> itemIdListingActivityMap = new HashMap<>();
        if (getListingActivitiesByIdsResponse != null) {
            for (ListingActivity listingActivity : getListingActivitiesByIdsResponse.getMembers()) {
                itemIdListingActivityMap.put(listingActivity.getListingId(), listingActivity);
            }
        }
        return new ListingActivitiesByIdsModel(itemIdListingActivityMap);
    }

    private String ItemIdsParam(ContractResponse contractResponse) {
        List<String> itemList = LasngServiceTask.getItemsList(contractResponse);
        StringBuilder strItemIdBuilder = new StringBuilder();
        for (String itemId: itemList) {
            strItemIdBuilder.append(itemId).append("|");
        }
        return strItemIdBuilder.toString();
    }


    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result))  resultMap.put(result.getClass().getName(), result);
    }
}
