package com.ebay.app.apisellingextsvc.service.client.model.StoreEditEntityClient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class StoreEditEntityResponse {

    @JsonProperty("storeUrlIdentifier")
    private String storeUrlIdentifier;

}
