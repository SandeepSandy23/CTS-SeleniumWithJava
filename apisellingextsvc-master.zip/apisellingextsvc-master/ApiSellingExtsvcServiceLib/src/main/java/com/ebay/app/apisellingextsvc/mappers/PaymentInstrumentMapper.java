package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.BuyerPaymentInstrumentCodeType;

import java.util.Locale;

public class PaymentInstrumentMapper {

    // todo proforma order mapping
    // checkout trans payment method
    // 290027169334-0 no payment instrument
    private static final ImmutableMap<String, BuyerPaymentInstrumentCodeType> mapName
            = new ImmutableMap.Builder<String, BuyerPaymentInstrumentCodeType>()
            .put(ApiSellingExtSvcConstants.CREDIT_CARD, BuyerPaymentInstrumentCodeType.CREDIT_CARD) // checkout trans payment instrument type 1
            .put(ApiSellingExtSvcConstants.SOFORT, BuyerPaymentInstrumentCodeType.BANK_DIRECT_DEBIT) // checkout trans payment instrument type 2
            .put(ApiSellingExtSvcConstants.PAYPAL_FULL, BuyerPaymentInstrumentCodeType.PAY_PAL) // checkout trans payment instrument type 3
            .put(ApiSellingExtSvcConstants.PAYPAL_ACCOUNT, BuyerPaymentInstrumentCodeType.PAY_PAL) // checkout trans payment instrument type 3
            .put(ApiSellingExtSvcConstants.PAYPAL_CREDIT, BuyerPaymentInstrumentCodeType.BML) // checkout trans payment instrument type 16
            .build();

    private PaymentInstrumentMapper() {
    }

    public static BuyerPaymentInstrumentCodeType map(String key) {
        return mapName.getOrDefault(key.toUpperCase(Locale.US), BuyerPaymentInstrumentCodeType.CUSTOM_CODE);
    }

}
