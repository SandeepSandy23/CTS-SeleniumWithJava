package com.ebay.app.apisellingextsvc.framework.outputselector;

import com.ebay.app.apisellingextsvc.application.common.response.GetMyeBaySellingResponse;
import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.google.common.collect.ImmutableSet;
import ebay.apis.eblbasecomponents.AbstractResponseType;
import ebay.apis.eblbasecomponents.GetMyeBaySellingResponseType;
import ebay.apis.eblbasecomponents.GetSellerTransactionsResponseType;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class OutputSelectorGraphImpl {

    public static final int s_MAX_LEVEL = 10;
    private static final List<String> ACCESSOR = Arrays.asList("get", "set");
    private static final Map<Class<?>, GraphMap> allGraphMap = new HashMap<>();
    private static final Set<String> SKIP_FIELD = ImmutableSet.of(
            "containingorder" // this field will break logic due to it contain order
    );

    static {
        allGraphMap.put(GetSellerTransactionsResponseType.class, buildGraph(GetSellerTransactionsResponseType.class));
        allGraphMap.put(GetMyeBaySellingResponseType.class, buildGraph(GetMyeBaySellingResponseType.class));
    }


    public static GraphMap getGetSellerTransactionsResponseTypeGraphMap() {
        return allGraphMap.get(GetSellerTransactionsResponseType.class);
    }
    
    public static GraphMap getMyEbaySellingResponseTypeGraphMap() {
        return allGraphMap.get(GetMyeBaySellingResponseType.class);
    }

    public static GraphMap getGetSellerTransactionsResponseGraphMap() {
        return buildGraph(GetSellerTransactionsResponse.class, true);
    }

    public static GraphMap getGetMyEbaySellingResponseGraphMap() {
        return buildGraph(GetMyeBaySellingResponse.class, true);
    }

    public static GraphMap getAbstractResponseGraphMap() {
        return buildGraph(AbstractResponseType.class);
    }

    private static GraphMap buildGraph(Class<?> clazz) {
        return buildGraph(clazz, false);
    }

    private static GraphMap buildGraph(Class<?> clazz, boolean isCustomType) {
        GraphMap graphMap = new GraphMap();
        CustomNode node = new CustomNode(clazz);
        graphMap.put(node);
        buildGraph(node, 0, graphMap, isCustomType);
        return graphMap;
    }

    /**
     * @param isCustomType for profiler and diagnostics
     */
    private static void buildGraph(CustomNode parentNode, int level, GraphMap graphMap, boolean isCustomType) {
        Field[] fields = parentNode.getClazz().getDeclaredFields();
        for (Field field : fields) {
            String fieldName = field.getName();
            Class<?> fieldTypeClass = field.getType();
            boolean isArray = false;
            if (isSchemaField(fieldName)) {
                fieldName = fieldName.toLowerCase(Locale.US);
                if (Collection.class.isAssignableFrom(fieldTypeClass)) {
                    isArray = true;
                    ParameterizedType integerListType = (ParameterizedType) field.getGenericType();
                    fieldTypeClass = (Class<?>) integerListType.getActualTypeArguments()[0];
                }
                CustomNode currentNode = new CustomNode(fieldName, getXmlName(field), fieldTypeClass, parentNode);
                parentNode.addChild(currentNode);
                graphMap.put(fieldName, currentNode);
                if (isCustomType) {
                    addGetterAndSetterNode(parentNode, graphMap, field, fieldName, fieldTypeClass);

                }
                if (level < s_MAX_LEVEL - 1 && goNextLevel(fieldTypeClass, isArray) && !SKIP_FIELD.contains(parentNode.getFieldName())) {
                    buildGraph(currentNode, level + 1, graphMap, isCustomType);
                }
            }
        }
    }

    private static void addGetterAndSetterNode(CustomNode parentNode,
                                               GraphMap graphMap,
                                               Field field,
                                               String fieldName,
                                               Class<?> fieldTypeClass) {
        for (String accessor : ACCESSOR) {
            String acFieldName = accessor + fieldName;
            CustomNode acNode = new CustomNode(acFieldName, getXmlName(field), fieldTypeClass, parentNode);
            graphMap.put(acFieldName, acNode);
        }
    }

    private static boolean isSchemaField(String name) {
        return !name.startsWith("_") && !name.equals("typeDesc") && !name.equals("any");
    }

    private static boolean goNextLevel(Class<?> c, boolean isArray) {
        if (c.getName().startsWith("java.lang")
                || c.getName().startsWith("java.math")
                || c.getName().startsWith("java.util")
                || c.getName().contains("org.apache.axis")) {
            return false;
        }
        if (c.isEnum() && isArray) {
            return false;
        }
        return !c.isEnum() || isArray;
    }

    private static String getXmlName(Field field) {
        XmlElement xmlElement = field.getAnnotation(XmlElement.class);
        if (xmlElement != null && xmlElement.name() != null && !xmlElement.name().startsWith("##")) {
            return xmlElement.name();
        }
        XmlAttribute xmlAttribute = field.getAnnotation(XmlAttribute.class);
        if (xmlAttribute != null && xmlAttribute.name() != null) {
            return xmlAttribute.name();
        }
        // no xml annotation or XmlValue
        return field.getName();
    }
}
