package com.ebay.app.apisellingextsvc.service.dal.exchangerate;

import com.ebay.integ.dal.cache2.BaseIntegCacheBean;
import com.ebay.integ.dal.cache2.CacheBeanInitializationException;
import com.ebay.kernel.bean.configuration.ConfigCategoryCreateException;

public class ExchangeRateCacheBean extends BaseIntegCacheBean {

    public static final String CATEGORY_ID = "ebay.dal.CacheObject.ExchangeRate";
    private static final long serialVersionUID = -3732771815319534098L;
    private static volatile ExchangeRateCacheBean m_instance = null;

    private ExchangeRateCacheBean() throws ConfigCategoryCreateException {
        super(createBeanConfigCategoryInfo(
                    CATEGORY_ID,
                    "com.ebay.integ.CacheObject.ExchangeRate",
                    "com.ebay.integ.CacheObject"),
              true,
              "ExchangeRate",
              new ExchangeRateCacheLoader(),
              ExchangeRateKeyManager.getInstance(),
              86400,
              "22:00",
              600,
              true,
              true,
              -1,
              0,
              true,
              true);
    }

    public static ExchangeRateCacheBean getInstance() {
        if (m_instance == null) {
            try {
                m_instance = new ExchangeRateCacheBean();
            } catch (ConfigCategoryCreateException var1) {
                throw new CacheBeanInitializationException(var1, "ExchangeRateCacheBean");
            }
        }

        return m_instance;
    }

}
