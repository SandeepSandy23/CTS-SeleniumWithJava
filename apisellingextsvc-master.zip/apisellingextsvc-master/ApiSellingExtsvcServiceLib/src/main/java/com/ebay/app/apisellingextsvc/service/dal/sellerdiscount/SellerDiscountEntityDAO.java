package com.ebay.app.apisellingextsvc.service.dal.sellerdiscount;


import com.ebay.integ.dal.DalRuntimeException;
import com.ebay.integ.dal.cache2.KeyDefinition;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.ModulusToupleProvider;
import com.ebay.integ.dal.ddr.ToupleProvider;
import com.ebay.integ.dal.map.*;
import com.ebay.persistence.DALVersion;
import com.ebay.app.apisellingextsvc.service.dal.common.ReadSets;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@DALVersion("3.0")
public class SellerDiscountEntityDAO extends BaseDao2 {
    public static final String FINDALLBYSELLERIDTRANSIDIN = "FINDALLBYSELLERIDTRANSIDIN";
    public static final String FINDALLBYBUYERIDTRANSIDIN = "FINDALLBYSBUYERIDTRANSIDIN";
    private static MappingIncludesAttribute[] m_ourDDRHints = new MappingIncludesAttribute[0];
    private static MappingIncludesAttribute[] m_discountEntityHints = new MappingIncludesAttribute[0];
    private static boolean m_mapInitialized = false;
    private static final String REGULAR_TABLE = "SELLER_DISCOUNT_ENTITY_%";
    private static volatile SellerDiscountEntityDAO s_instance;
    private static SellerDiscountEntityDAOHelper m_helper = SellerDiscountEntityDAOHelper.getInstance();
    private static final String PRIMARY_LOGICAL_HOST_TEMPLATE = "incentive%host";
    private static final String ID_HINT_NAME2 = "m_sellerId";
    private static SellerDiscountEntityCodeGenDoImpl s_noFetchProtoDO;
    private static GenericMap<SellerDiscountEntity> s_map;

    protected SellerDiscountEntityDAO() {
        if (!m_mapInitialized) {
            initMap();
        }
    }

    public static SellerDiscountEntityDAO getInstance() {
        if (s_instance == null) {
            synchronized (SellerDiscountEntityDAO.class) {
                if (s_instance == null) {
                    s_instance = new SellerDiscountEntityDAO();
                }
            }
        }

        return s_instance;
    }

    public static void initMap() {
        if (!m_mapInitialized) {
            GenericMap<SellerDiscountEntity> map = GenericMap.getMap(SellerDiscountEntity.class);
            if (map == null) {
                map = new GenericMap(SellerDiscountEntity.class);
            }

            map.setDalVersion("3.0");
            m_mapInitialized = true;
            s_map = map;
            s_noFetchProtoDO = new SellerDiscountEntityCodeGenDoImpl((BaseDao2)null, map);
            s_noFetchProtoDO.setSellerId(0L);

            try {
                map.registerToupleProvider(getToupleProvider());
            } catch (NullPointerException var2) {
                throw new DalRuntimeException("DAL not properly initialized.");
            }

            map.setTableJoins(getTableJoins());
            map.setQueries(getRawQueries());
            map.setReadSets(getReadSets(map));
            initHintGroups(map);
            map.init();
        }
    }

    protected static void initHintGroups(GenericMap<SellerDiscountEntity> map) {
        m_ourDDRHints = new MappingIncludesAttribute[]{map.getLocalFieldMapping(2)};
        m_discountEntityHints = new MappingIncludesAttribute[]{map.getLocalFieldMapping(3)};
    }

    protected static ToupleProvider getToupleProvider() {
        return new ModulusToupleProvider(REGULAR_TABLE, PRIMARY_LOGICAL_HOST_TEMPLATE, ID_HINT_NAME2);
    }

    public List<SellerDiscountEntity> findAllByBuyerIdTransIdIn(long sellerId, long buyerId, List<Long> transIds) throws FinderException {

        List<SellerDiscountEntity> protoDos = new ArrayList(transIds.size());
        Iterator var6 = transIds.iterator();

        while (var6.hasNext()) {
            long transId = (Long)var6.next();
            SellerDiscountEntityCodeGenDoImpl protoDo = new SellerDiscountEntityCodeGenDoImpl();
            protoDo.setLocalOnly(true);
            protoDo.setSellerId(sellerId);
            protoDo.setBuyerId(buyerId);
            protoDo.setTransactionId(transId);
            m_helper.setHint(protoDo);
            protoDos.add(protoDo);
        }

        QueryEngine qe = new QueryEngine();
        List<SellerDiscountEntity> result = new ArrayList();
        qe.readMultiple(result, s_map, protoDos, FINDALLBYBUYERIDTRANSIDIN, ReadSets.FULL.getValue(), null, m_discountEntityHints);
        return result;
    }

    public List<SellerDiscountEntity> findAllBySellerIdTransIdIn(long sellerId, List<Long> transIds) throws FinderException {
        List<SellerDiscountEntity> protoDos = new ArrayList(transIds.size());
        Iterator var6 = transIds.iterator();

        while (var6.hasNext()) {
            long transId = (Long)var6.next();
            SellerDiscountEntityCodeGenDoImpl protoDo = new SellerDiscountEntityCodeGenDoImpl();
            protoDo.setLocalOnly(true);
            protoDo.setSellerId(sellerId);
            protoDo.setTransactionId(transId);
            m_helper.setHint(protoDo);
            protoDos.add(protoDo);
        }

        QueryEngine qe = new QueryEngine();
        List<SellerDiscountEntity> result = new ArrayList();
        qe.readMultiple(result, s_map, protoDos, FINDALLBYSELLERIDTRANSIDIN, ReadSets.FULL.getValue(), (KeyDefinition)null, m_discountEntityHints);
        return result;
    }

    protected static Query[] getRawQueries() {
        Query[] queries = new Query[]{
                new SelectQuery(FINDALLBYSELLERIDTRANSIDIN, m_ourDDRHints,
                        new SelectStatement[]{new SelectStatement(ReadSets.MATCHANY.getValue(),
                                "SELECT /*<CALCOMMENT/>*/ /*+ index(S, S(TRANSACTION_ID,SELLER_ID) ) */ <SELECTFIELDS/> FROM <TABLES/> " +
                                        "WHERE S.SELLER_ID = :m_sellerId AND S.TRANSACTION_ID IN <IN>:m_transactionId</IN> AND (<JOIN/>)")}, -1,
                        new SelectSetParms(200, 100, 500, s_noFetchProtoDO)),
                new SelectQuery(FINDALLBYBUYERIDTRANSIDIN, m_ourDDRHints,
                        new SelectStatement[]{new SelectStatement(ReadSets.MATCHANY.getValue(),
                                "SELECT /*<CALCOMMENT/>*/ /*+ index(S, S(TRANSACTION_ID,SELLER_ID) ) */ <SELECTFIELDS/> FROM <TABLES/> " +
                                        "WHERE S.BUYER_ID = :m_buyerId AND S.TRANSACTION_ID IN <IN>:m_transactionId</IN> AND (<JOIN/>)")}, -1,
                        new SelectSetParms(200, 100, 500, s_noFetchProtoDO))
        };
        return queries;
    }

    protected static TableJoin[] getTableJoins() {
        TableJoin[] tableJoins = new TableJoin[0];
        return tableJoins;
    }

    protected static ReadSet[] getReadSets(GenericMap<SellerDiscountEntity> map) {
        ReadableMapping lastModifiedDateFm = (ReadableMapping)map.getLocalFieldMapping(21);
        ReadSet[] readSets = new ReadSet[]{new ReadSet(ReadSets.FULL.getValue(), null),
                new ReadSet(ReadSets.LAST_MODIFIED_DATE.getValue(), new ReadableMapping[]{lastModifiedDateFm})};
        return readSets;
    }

}