package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.service.bof.taxrate.ITaxRateBof;
import com.ebay.cosmos.ContractIdentifier;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.order.common.v1.LineItemSource;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Optional;

public abstract class BaseTransactionArrayTypeBuilder extends BaseFacetBuilder<List<TransactionType>> {
    private final String requestLookupKey;
    private final String publicContractId;

    public BaseTransactionArrayTypeBuilder(Task<?> task,
                                           @Nonnull ContractResponseType contractResponseType) {
        super(task);
        this.requestLookupKey = Optional.of(contractResponseType).map(ContractResponseType::getIdentifier)
                .map(ContractIdentifier::getLookupKey)
                .orElse(null);
        this.publicContractId = Optional.of(contractResponseType).map(ContractResponseType::getIdentifier)
                .map(ContractIdentifier::getPublicContractId)
                .orElse(null);
    }


    protected boolean isFullTransaction(int lineItemListSize) {
        return lineItemListSize == 1 || StringUtils.equals(this.requestLookupKey, this.publicContractId);
    }

    protected boolean isRequestTransaction(String lineItemLookupKey) {
        return StringUtils.equals(this.requestLookupKey, lineItemLookupKey);
    }

    protected boolean shouldBuildTransaction(int lineItemListSize, LineItemSource lineItemSource) {
        if (lineItemSource != null) {
            String lineItemLookupKey =
                    Optional.of(lineItemSource).map(LineItemSource::getLookupKey).orElse(null);
            return isFullTransaction(lineItemListSize) || isRequestTransaction(lineItemLookupKey);
        }
        return false;
    }
}

