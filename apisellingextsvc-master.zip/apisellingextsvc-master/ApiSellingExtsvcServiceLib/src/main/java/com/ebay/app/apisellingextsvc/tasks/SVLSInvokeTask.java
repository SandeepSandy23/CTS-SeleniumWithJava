package com.ebay.app.apisellingextsvc.tasks;


import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.service.client.model.svls.SvlsRequest;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.model.SVLSItemInfoModel;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.order.common.v1.LineItemSource;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import com.fasterxml.jackson.databind.ObjectMapper;
import ebay.apis.eblbasecomponents.ErrorType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Function;
import java.util.stream.Collectors;


public class SVLSInvokeTask implements Task<SVLSItemInfoModel>, ITaskResultInjectable {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private final IServiceInvoker<SvlsRequest,Item>  svlsServiceInvoker;
    private final HttpHeaders headers;
    private final ApiSellingExtSvcConfigValues configValues;
    private final Executor executor;

    private Map<String, Object> resultMap = new HashMap<>();

    public SVLSInvokeTask(IServiceInvoker<SvlsRequest,Item> svlsServiceInvoker,
                          List<ErrorType> errorList, HttpHeaders headers, ApiSellingExtSvcConfigValues configValues,
                          Executor executor) {

        this.svlsServiceInvoker = svlsServiceInvoker;
        this.headers = headers;
        this.configValues = configValues;
        this.executor = executor;
    }

    @Override
    public SVLSItemInfoModel call() {

        List<ContractResponseType> contractResponseTypeList = Optional.ofNullable((ContractResponse)resultMap.get(ContractResponse.class.getName()))
                .map(ContractResponse::getMembers)
                .orElse(Collections.emptyList());

        if (CollectionUtils.isEmpty(contractResponseTypeList)) {
            return new SVLSItemInfoModel(Collections.emptyMap());
        }

        List<SvlsRequest> svlsRequestList  = buildSvlsRequest(contractResponseTypeList);
        Map<String,Item> svlsresponseMap =  new HashMap<>();
        if (!configValues.isSVLSNewParallelCallOn) {
            Map<String, Item> finalSvlsresponseMap = svlsresponseMap;
            svlsRequestList.parallelStream().forEach((request) -> {
                Item item = svlsServiceInvoker.getResponse(request, headers);
                if(item!=null) {
                    finalSvlsresponseMap.put(request.getItemId(), item);
                }
            });
        } else {
             svlsresponseMap = Optional.of(svlsRequestList)
                    .orElse(new ArrayList<>())
                    .stream()
                    .map(t -> CompletableFuture.supplyAsync(() -> this.svlsServiceInvoker.getResponse(t, headers), executor))
                    .collect(Collectors.toList()).stream()
                    .map(CompletableFuture::join)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList())
                    .stream()
                    .collect(Collectors.toMap(Item::getItemId, Function.identity()));
        }
        return new SVLSItemInfoModel(svlsresponseMap);
    }

    private List<SvlsRequest> buildSvlsRequest(List<ContractResponseType> contractResponseTypeList) {
      Set<SvlsRequest> svlsRequestSet = new HashSet<>();
        for (ContractResponseType member :contractResponseTypeList) {
            if (ContractResponseUtil.isOrder(member))
                for (LineItemXType lineItem : member.getOrder().getLineItemTypes()) {
                        SvlsRequest svlsRequest = SvlsRequest.builder().build();
                        Optional.ofNullable(lineItem.getSourceId())
                                .map(LineItemSource::getItemId)
                                .ifPresent(svlsRequest::setItemId);

                        Optional.ofNullable(lineItem.getSourceId())
                                .map(LineItemSource::getVersion)
                                .ifPresent(svlsRequest::setItemVersionId);

                        Optional.ofNullable(lineItem.getSourceId())
                                .map(LineItemSource::getVariationId)
                                .ifPresent(svlsRequest::setVariationId);

                        if (StringUtils.isNotBlank(svlsRequest.getItemId()) && StringUtils.isNotBlank(svlsRequest.getItemVersionId())) {
                            svlsRequestSet.add(svlsRequest);
                        }
                }
            if (ContractResponseUtil.isProformaOrder(member))
                for (ProformaOrderLineItemXType proformalineItem : member.getProformaOrder().getLineItemTypes()) {
                    SvlsRequest svlsRequest = SvlsRequest.builder().build();
                    Optional.ofNullable(proformalineItem.getSourceId())
                            .map(LineItemSource::getItemId)
                            .ifPresent(svlsRequest::setItemId);

                    Optional.ofNullable(proformalineItem.getSourceId())
                            .map(LineItemSource::getVersion)
                            .ifPresent(svlsRequest::setItemVersionId);

                    Optional.ofNullable(proformalineItem.getSourceId())
                            .map(LineItemSource::getVariationId)
                            .ifPresent(svlsRequest::setVariationId);

                    if(StringUtils.isNotBlank(svlsRequest.getItemId()) && StringUtils.isNotBlank(svlsRequest.getItemVersionId()))  {
                        svlsRequestSet.add(svlsRequest);
                    }
                }
        }

        return new ArrayList<>(svlsRequestSet);
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}