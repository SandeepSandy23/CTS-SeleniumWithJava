package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

public interface ShippingService extends ShippingServiceCodeGen {
}
