package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.invokers.BulkUserReadServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.CosmosServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.LASBulkUserNoteInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.LasngServiceInvoker;
import com.ebay.app.apisellingextsvc.tasks.BulkUserReadServiceInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.LASBulkUserNoteTask;
import com.ebay.app.apisellingextsvc.tasks.LasngServiceTask;
import com.ebay.app.apisellingextsvc.tasks.cosmos.CosmosInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.cosmos.GMESCosmosRequestTask;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.TaskOrchestrationUtil;
import com.ebay.app.apisellingextsvc.utils.TracerUtil;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsRequest;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.raptor.orchestrationv2.task.TaskConfiguration;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.PaginatedOrderTransactionArrayType;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.context.Scope;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public class GMESSoldContainerTask implements Task<PaginatedOrderTransactionArrayType>, ITaskResultInjectable {

    private final Map<String, Object> resultMap = new HashMap<>();
    private final GetMyeBaySellingRequest request;
    private final Executor executor;
    private final List<DetailLevelCodeType> detailLevels;

    public GMESSoldContainerTask(GetMyeBaySellingRequest request,
                                 Executor executor,
                                 List<DetailLevelCodeType> detailLevels) {

        this.request = request;
        this.executor = executor;
        this.detailLevels = detailLevels;
    }

    @Override
    public PaginatedOrderTransactionArrayType call() {
        if (!CommonUtil.isRequiredContainer(request.getRequestType().getSoldList(), detailLevels)) return null;

        Span openTeleChildSpan = TracerUtil.getOpenTeleChildSpan(this.getClass().getSimpleName(), this.request.getTracerContext());
        io.opentracing.Span openTracerChildSpan = TracerUtil.getOpenTracerChildSpan(this.getClass().getSimpleName(), this.request.getTracerContext());

        TracerContext updatedParentTracerContext = new TracerContext(this.request.getTracerContext().getOpenTeleTracer(),
                openTeleChildSpan,
                this.request.getTracerContext().getOpenTracingTracer(),
                openTracerChildSpan);

        try (Scope scope = TracerUtil.startOpenTeleChildSpan(openTeleChildSpan, this.request.getTracerContext()); io.opentracing.Scope tracerScope =
                TracerUtil.startOpenTracerChildSpan(openTracerChildSpan, this.request.getTracerContext())) {

            GetListingActivitiesByIdsRequest getListingActivitiesByIdsRequest = new GetListingActivitiesByIdsRequest();
            GMESCosmosRequestTask cosmosRequestTask = new GMESCosmosRequestTask(request.requestType, request.getHeaders(), this.request.getUser(), this.request.getConfigValues(), ApiSellingExtSvcConstants.SOLD_LIST);
            CosmosInvokeTask cosmosInvokeTask = new CosmosInvokeTask(new CosmosServiceInvoker(updatedParentTracerContext), request.getErrorList());
            LasngServiceTask lasngServiceTask = new LasngServiceTask(new LasngServiceInvoker(updatedParentTracerContext),
                    request.getErrorList(), this.request.getHeaders(),
                    getListingActivitiesByIdsRequest, this.request.getUser());
            LASBulkUserNoteTask lasBulkUserNoteTask = new LASBulkUserNoteTask(new LASBulkUserNoteInvoker(updatedParentTracerContext), request.getErrorList(), request.getHeaders(), this.request.getUser(), this.request.requestType.getSoldList().isIncludeNotes());

            GMESBuildOrderTransactionTask soldContainerTask = new GMESBuildOrderTransactionTask(request, request.getRequestType().getSoldList().getPagination(), request.contentResource);

            TaskConfiguration cosmosInvokeConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosRequestTask);
            TaskConfiguration lasngConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask);
            TaskConfiguration lasBulkUserNotesConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask);
            TaskConfiguration soldContainerConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask, lasngServiceTask, lasBulkUserNoteTask);

            request.orchestrator.execute(cosmosRequestTask);
            request.orchestrator.execute(cosmosInvokeTask, cosmosInvokeConfig);
            request.orchestrator.execute(lasngServiceTask, lasngConfig);
            request.orchestrator.execute(lasBulkUserNoteTask, lasBulkUserNotesConfig);

            CompletableFuture<PaginatedOrderTransactionArrayType> getSoldListContainerCompletableFuture = request.orchestrator.execute(soldContainerTask, soldContainerConfig);
            PaginatedOrderTransactionArrayType soldItems = (PaginatedOrderTransactionArrayType) TaskOrchestrationUtil.safeGet(getSoldListContainerCompletableFuture);
            return soldItems;
        } finally {
            openTeleChildSpan.end();
            openTracerChildSpan.finish();
        }
    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
