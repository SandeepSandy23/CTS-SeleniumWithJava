package com.ebay.app.apisellingextsvc.service.invokers;



import com.ebay.app.apisellingextsvc.audit.es.ESResponse;
import com.ebay.app.apisellingextsvc.audit.es.Report;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;

import javax.inject.Inject;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import com.ebay.app.apisellingextsvc.service.client.ESAuditClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import org.springframework.stereotype.Component;

public class ESServiceInvoker extends BaseServiceInvoker<Report, ESResponse, Report> {

    public static final String NAME = "ESServiceInvoker";
    private static final String AUTHORIZATION = "Authorization";
    private static final String staging_auth ="MjA2OGE1OTJhOWEwNDYzOThjN2NiNmMyNmJmMGY1ZGM6NnZ3WkZma3dSWEpsajRKME5KYmFDRzMyU2dZb1owWkZxdmkwTUFLVVdBZ1JoUGQ3NzdablhuRFRtejlZcFpGUw==";
    private  ApiSellingExtSvcConfigValues config;

    public ESServiceInvoker(TracerContext tracerContext,ApiSellingExtSvcConfigValues config ) {
        super(NAME, tracerContext);
        this.config=config;
    }
    private String getAuth() {
        //TODO Change to Fidelius client
        String auth = staging_auth;
        if (config != null) {
            auth = "Basic " +config.esauthSecret;
        }
        return auth;
    }

    @Override
    protected BaseGingerClient<Report, ESResponse> getGingerClient(Report report) {
        MultivaluedMap<String, Object> headerMap = new MultivaluedHashMap<>(1);
        headerMap.putSingle(AUTHORIZATION, getAuth());
        return new ESAuditClient(report.getRequest().getEsIndexName(), headerMap);
    }

    @Override
    protected GingerClientRequest<Report> getGingerRequest(Report report, HttpHeaders httpHeaders) {
        GingerClientRequest<Report> gingerClientRequest = new GingerClientRequest<>();
        gingerClientRequest.setRequest(report);
        return gingerClientRequest;
    }


}
