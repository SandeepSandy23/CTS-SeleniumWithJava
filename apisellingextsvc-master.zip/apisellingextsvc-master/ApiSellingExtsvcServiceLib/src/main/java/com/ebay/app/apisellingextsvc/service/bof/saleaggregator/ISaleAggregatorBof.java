package com.ebay.app.apisellingextsvc.service.bof.saleaggregator;

import java.util.List;
import java.util.Map;

public interface ISaleAggregatorBof {
    String getSellerProdId(long itemId, long sellerId);

    Map<Long, String> getSellerProdIdByItems(List<Long> itemIds, long sellerId);
}
