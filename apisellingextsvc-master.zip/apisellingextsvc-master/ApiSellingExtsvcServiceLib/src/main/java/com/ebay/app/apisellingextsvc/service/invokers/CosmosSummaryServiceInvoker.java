package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.FindContractV2RequestContext;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.CosmosSummaryClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.cosmos.SummaryResponse;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class CosmosSummaryServiceInvoker extends BaseServiceInvoker<FindContractV2RequestContext, SummaryResponse, FindContractV2RequestContext> {

    // use for mock
    public static final String NAME = "CosmosSummaryServiceInvoker";

    public CosmosSummaryServiceInvoker(TracerContext tracerContext) {
        super(NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<FindContractV2RequestContext, SummaryResponse> getGingerClient(
            FindContractV2RequestContext findContractV2RequestContext) {
        return new CosmosSummaryClient();
    }

    @Override
    protected GingerClientRequest<FindContractV2RequestContext> getGingerRequest(FindContractV2RequestContext findContractV2RequestContext,
                                                                                 HttpHeaders httpHeaders) {
        GingerClientRequest<FindContractV2RequestContext> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(findContractV2RequestContext);
        return gingerClientRequest;
    }

}