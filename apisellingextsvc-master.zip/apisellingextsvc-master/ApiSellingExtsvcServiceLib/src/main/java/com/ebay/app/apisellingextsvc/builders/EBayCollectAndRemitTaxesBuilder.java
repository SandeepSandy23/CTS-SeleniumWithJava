package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.UserCS;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.CollectionMethodCodeType;
import ebay.apis.eblbasecomponents.TaxesType;

public class EBayCollectAndRemitTaxesBuilder extends AbstractTaxesBuilder {

    public EBayCollectAndRemitTaxesBuilder(Task<?> task,
                                    OrderCSXType order,
                                    LineItemXType lineItem,
                                    int trxVersion,
                                    UserCS buyer,
                                    ApiSellingExtSvcConfigValues configValues) {
        super(task, order, lineItem, trxVersion, lineItem.getTax(), buyer, AmountTypeUtil.getCurrency(order.getOrderTotal()), configValues,
              order.getAttributes());
    }

    @Override
    protected TaxesType doBuild() {
        return buildTax();
    }

    protected TaxesType buildTax() {
        TaxesType taxesType = new TaxesType();
        //get tax type first, return directly if cannot find any valid tax type
        String taxType = getTaxType();
        if (buildTotalTaxAmount() == null || taxType == null) {
            return null;
        }
        return buildTaxTypeDetails(taxesType, taxType);
    }

    @Override
    protected String getTaxType() {
        String taxType = getEbayCollectAndRemitTax();
        if ((PaymentUtil.hasEbayCollectedTax(orderAttributes) || isInvoiceToSeller())
                && trxVersion >= VersionConstant.VERSION_AU_GST) {
            String taxState = getTaxState();
            if (!isTaxTypeGST(taxType)) {
                return ApiSellingExtSvcConstants.TAX_TYPE_SALES_TAX;
            } else if (trxVersion >= VersionConstant.VERSION_FR_VAT && taxState != null) {
                return getTaxTypeWithTaxState(taxState);
            }
            return ApiSellingExtSvcConstants.GST;

        }
        return null;
    }

    @Override
    protected CollectionMethodCodeType buildCollectionMethod() {
        if (isInvoiceToSeller()) {
            return CollectionMethodCodeType.INVOICE;
        } else if (PaymentUtil.hasEbayCollectedTax(orderAttributes)) {
            return CollectionMethodCodeType.NET;
        }
        return null;
    }
}
