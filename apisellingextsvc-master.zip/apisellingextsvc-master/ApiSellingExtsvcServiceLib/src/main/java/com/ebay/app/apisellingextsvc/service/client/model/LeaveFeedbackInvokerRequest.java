package com.ebay.app.apisellingextsvc.service.client.model;

//import com.ebay.feedback.type.v1.request.leavefeedback.LeaveFeedbackRequest;

public class LeaveFeedbackInvokerRequest {

//    public final LeaveFeedbackRequest leaveFeedbackRequest;
//    public final String userName;
//    public final String userId;
//
//    public LeaveFeedbackInvokerRequest(LeaveFeedbackRequest leaveFeedbackRequest, String userName, String userId) {
//        this.leaveFeedbackRequest = leaveFeedbackRequest;
//        this.userName = userName;
//        this.userId = userId;
//    }

}
