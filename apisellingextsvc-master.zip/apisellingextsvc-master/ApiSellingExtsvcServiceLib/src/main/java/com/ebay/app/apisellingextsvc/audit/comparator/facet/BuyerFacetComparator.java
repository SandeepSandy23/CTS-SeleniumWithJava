package com.ebay.app.apisellingextsvc.audit.comparator.facet;
import com.ebay.app.apisellingextsvc.audit.comparator.BaseFacetComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.Iterator;

public class BuyerFacetComparator extends BaseFacetComparator {

    private static final String BUYER = "Buyer";
    private static final String EMAIL = "Email";

    public BuyerFacetComparator(ExtensiveComparator comparator) {
        super(comparator);
    }


    @Override
    public boolean qualified(JsonNode org, JsonNode tar, String path) {
        return org.isObject() && tar.isObject()
                && path.endsWith(BUYER);
    }

    @Override
    public boolean compare(JsonNode org, JsonNode tar, String path, JsonNode pattern, String key, IReport report) {
        boolean res = true;

        Iterator<String> childName = pattern.fieldNames();
        while (childName.hasNext()) {
            String name = childName.next();
            JsonNode patternChild = pattern.get(name);
            JsonNode orgChild = org.get(name);
            JsonNode tarChild = tar.get(name);

            if (EMAIL.equalsIgnoreCase(name) && buyerEmailVariation(orgChild, tarChild)) {
                continue;
            }
            res = compareNode(orgChild, tarChild, patternChild, path + "." + name, key, report) && res;
        }

        return res;
    }

    private boolean buyerEmailVariation(JsonNode orgChild, JsonNode tarChild) {
        boolean result = false;
        if (orgChild != null && tarChild != null && orgChild.isTextual() && tarChild.isTextual()) {
            result = getValue(orgChild).contains("@") && getValue(tarChild).contains("@");
        }
        return result;
    }
}
