package com.ebay.app.apisellingextsvc.service.dal.exchangerate;

import com.ebay.integ.dal.cache2.KeyDefinition;
import com.ebay.integ.dal.cache2.KeyManager;
import com.ebay.integ.dal.cache2.SimpleCollectionKeyDefinition;
import com.ebay.kernel.util.JdkUtil;

public class ExchangeRateKeyManager implements KeyManager {
    public static final int FROM_CURRENCY = 0;

    private static volatile ExchangeRateKeyManager m_instance;

    private KeyDefinition[] m_keyDefinitionList;

    public ExchangeRateKeyManager() {
        init();
    }

    public static ExchangeRateKeyManager getInstance() {
        if (m_instance == null) {
            synchronized (ExchangeRateKeyManager.class) {
                if (m_instance == null) {
                    m_instance = new ExchangeRateKeyManager();
                }
            }
        }
        return m_instance;
    }


    private void init() {
        String[] keyFieldNameList2 = new String[] {"m_fromCurrency"};
        this.m_keyDefinitionList =
              new KeyDefinition[] {
                    new SimpleCollectionKeyDefinition(FROM_CURRENCY, keyFieldNameList2, JdkUtil.forceInit(ExchangeRateCodeGenDoImpl.class))};

    }

    @Override
    public KeyDefinition getKeyDefinition(int id) {
        return this.m_keyDefinitionList[id];
    }

    @Override
    public KeyDefinition[] getKeyDefinitionList() {
        return this.m_keyDefinitionList;
    }
}
