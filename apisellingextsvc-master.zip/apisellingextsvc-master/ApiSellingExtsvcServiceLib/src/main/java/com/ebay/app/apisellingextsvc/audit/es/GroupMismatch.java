package com.ebay.app.apisellingextsvc.audit.es;

import java.util.ArrayList;
import java.util.List;

public class GroupMismatch {

    private String name;
    private List<Mismatch> mismatches;

    public GroupMismatch(String name) {
        this.name = name;
        this.mismatches = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Mismatch> getMismatches() {
        return mismatches;
    }

    public void setMismatches(List<Mismatch> mismatches) {
        this.mismatches = mismatches;
    }
}
