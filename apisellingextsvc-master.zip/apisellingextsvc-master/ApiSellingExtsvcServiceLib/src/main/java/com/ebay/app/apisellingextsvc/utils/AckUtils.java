package com.ebay.app.apisellingextsvc.utils;

import ebay.apis.eblbasecomponents.AbstractResponseType;
import ebay.apis.eblbasecomponents.AckCodeType;
import ebay.apis.eblbasecomponents.ErrorType;
import org.apache.commons.collections.CollectionUtils;

import java.util.List;

public class AckUtils {

    public static void populateAckAndErrors(List<ErrorType> errorList, AbstractResponseType response) {
        if (CollectionUtils.isNotEmpty(errorList)) {
            response.setAck(AckCodeType.WARNING);
            response.getErrors().addAll(errorList);
        } else {
            response.setAck(AckCodeType.SUCCESS);
        }
    }
}
