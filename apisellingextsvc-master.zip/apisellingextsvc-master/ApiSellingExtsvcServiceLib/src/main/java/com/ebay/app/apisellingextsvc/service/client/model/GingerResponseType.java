package com.ebay.app.apisellingextsvc.service.client.model;

public enum GingerResponseType {

    SUCCESS, FAILURE, TIMEOUT, CONFLICT

}
