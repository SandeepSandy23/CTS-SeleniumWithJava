package com.ebay.app.apisellingextsvc.service.invokers.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;
import com.ebay.selling.svls.item.Item;

/**
 * wrapper class to differentiate data in orchestrator dependency since Map<?,?> response of invoker is
 * generic
 *
 */
@AllArgsConstructor
@Getter
public class SVLSItemInfoModel {
    private Map<String, Item> itemMap;
}
