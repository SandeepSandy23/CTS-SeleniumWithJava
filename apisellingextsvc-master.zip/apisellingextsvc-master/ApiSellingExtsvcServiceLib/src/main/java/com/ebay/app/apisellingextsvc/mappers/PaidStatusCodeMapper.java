package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.OrderStateTypeCS;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.FulfillmentStatusType;
import com.ebay.order.common.v1.FundingHeldStatusType;
import com.ebay.order.common.v1.FundingStatusTypeEnum;
import com.ebay.order.common.v1.OrderStateType;
import com.ebay.order.common.v1.RefundStatusEnum;
import ebay.apis.eblbasecomponents.PaidStatusCodeType;

import java.util.Optional;

public class PaidStatusCodeMapper {

    public static PaidStatusCodeType map(OrderCSXType order) {
        return getFundingStatus(order.getOrderStates());
    }

    public static PaidStatusCodeType map(ProformaOrderXType proformaOrder) {
        PaidStatusCodeType paidStatusCodeType = getFundingStatus(proformaOrder.getOrderStates());
        if (paidStatusCodeType.equals(PaidStatusCodeType.BUYER_HAS_NOT_COMPLETED_CHECKOUT)) {
            return PaidStatusCodeType.NOT_PAID;
        }
        return paidStatusCodeType;
    }

    private static PaidStatusCodeType getFundingStatus(OrderStateTypeCS orderStates) {
        if (isFullyRefunded(orderStates) || isPartiallyRefunded(orderStates)) {
            return PaidStatusCodeType.REFUNDED;
        }

        FundingStatusTypeEnum fundingStatus = orderStates.getFundingStatus();
        switch (fundingStatus) {
            case NOT_FUNDED:
                if (fundingStatusNotHeld(orderStates) && !isCancelled(orderStates) && !fullfillmentStatusCompleted(orderStates)) {
                    return PaidStatusCodeType.BUYER_HAS_NOT_COMPLETED_CHECKOUT;
                }
                return PaidStatusCodeType.NOT_PAID;
            case FUNDED:
                return PaidStatusCodeType.MARKED_AS_PAID;
            case PENDING:
                return PaidStatusCodeType.PAYMENT_PENDING;
            default:
                return PaidStatusCodeType.NOT_PAID;
        }
    }

    private static boolean isFullyRefunded(OrderStateTypeCS orderStates) {
        return Optional.ofNullable(orderStates)
                .map(OrderStateTypeCS::getRefundStatus)
                .map(RefundStatusEnum.REFUNDED::equals)
                .orElse(false);
    }

    private static boolean isPartiallyRefunded(OrderStateTypeCS orderStates) {
        return Optional.ofNullable(orderStates)
                .map(OrderStateTypeCS::getRefundStatus)
                .map(RefundStatusEnum.PARTIAL_REFUNDED::equals)
                .orElse(false);
    }

    private static boolean isCancelled(OrderStateTypeCS orderStates) {
        OrderStateType orderState = orderStates.getOrderStatus();
        return OrderStateType.CANCELLED.equals(orderState);
    }

    private static boolean fundingStatusNotHeld(OrderStateTypeCS orderStates) {
        FundingHeldStatusType fundingHeldStatus = orderStates.getPaymentHoldStatus();
        return FundingHeldStatusType.NOT_HELD.equals(fundingHeldStatus);
    }

    private static boolean fullfillmentStatusCompleted(OrderStateTypeCS orderStates) {
        FulfillmentStatusType fulfillmentStatus = orderStates.getFulfillmentStatus();
        return FulfillmentStatusType.COMPLETED.equals(fulfillmentStatus);
    }
}
