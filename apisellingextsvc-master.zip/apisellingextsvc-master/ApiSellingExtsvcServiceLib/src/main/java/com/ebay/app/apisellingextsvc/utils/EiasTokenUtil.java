package com.ebay.app.apisellingextsvc.utils;

import com.ebay.kernel.util.Base64;

import java.nio.charset.StandardCharsets;

public class EiasTokenUtil {

    public static String encode(String userId) {
        //we are using 1 for type because in v3 we are reading EiasUserIdEncoder.FILL_CHAR_EQUAL which has value 1
        return encode(userId, 1);
    }

    public static String encode(String id, int type) {
        byte[] bs = id.getBytes(StandardCharsets.UTF_8);
        byte[] bytes = new byte[40];
        System.arraycopy(bs, 0, bytes, 40 - bs.length, bs.length);

        for (int i = 0; i < 40 - bs.length; ++i) {
            bytes[i] = 61;
        }

        byte[] buffer = new byte[8];
        System.arraycopy(bytes, 0, buffer, 0, 8);
        System.arraycopy(bytes, 8, bytes, 0, 32);
        System.arraycopy(buffer, 0, bytes, 32, 8);
        byte[] xor = new byte[]{-96, -78, -111, 32};
        int cnt = 0;

        for (int i = 0; i < 10; ++i) {
            for (int j = 0; j < 4; ++j) {
                bytes[cnt] ^= xor[j];
                ++cnt;
            }

            xor[3] = (byte) (xor[3] + 4);
        }

        boolean fillWithEqual = type == 1;

        return Base64.encode(bytes, fillWithEqual);
    }
}
