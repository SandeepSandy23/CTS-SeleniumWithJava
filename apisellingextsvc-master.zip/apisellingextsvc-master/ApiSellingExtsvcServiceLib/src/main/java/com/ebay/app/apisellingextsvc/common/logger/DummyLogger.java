package com.ebay.app.apisellingextsvc.common.logger;


public class DummyLogger implements ILogger {

    private static final DummyLogger instance = new DummyLogger();

    private DummyLogger() {
    }

    public static DummyLogger getInstance() {
        return instance;
    }

    public void warn(String message) {
        System.out.println("WARN:" + message);
    }

    public void error(String message) {
        System.out.println("ERROR:" + message);
    }

    public void error(String message, Throwable t) {
        System.out.println("ERROR:" + message + " e:" + t.getMessage());
    }
}
