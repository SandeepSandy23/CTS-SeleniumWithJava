package com.ebay.app.apisellingextsvc.service.client;


import com.ebay.app.apisellingextsvc.audit.es.ESResponse;
import com.ebay.app.apisellingextsvc.audit.es.Report;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.MultivaluedMap;

public class ESAuditClient extends BaseGingerClient<Report, ESResponse> {

    private static final Logger logger = LoggerFactory.getLogger(ESAuditClient.class);

    private static final String CLIENT_ID = "apisellingextsvc.elasticsearch";

    private final MultivaluedMap<String, Object> headers;

    private final String path;

    public ESAuditClient(String path, MultivaluedMap<String, Object> headers) {
        super(ESResponse.class);
        this.path = path;
        this.headers = headers;
    }

    @Override
    public GingerClientResponse<ESResponse> getGingerResponse(GingerClientRequest<Report> gingerRequest) {
        return processPostESRequest(path, headers, gingerRequest);
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
