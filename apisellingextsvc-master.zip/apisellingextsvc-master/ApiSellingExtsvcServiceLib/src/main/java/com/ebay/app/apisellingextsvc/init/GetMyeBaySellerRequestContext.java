package com.ebay.app.apisellingextsvc.init;

import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;
import ebay.apis.eblbasecomponents.GetMyeBaySellingRequestType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;

@Getter
@Setter
@AllArgsConstructor
@Builder
public class GetMyeBaySellerRequestContext {
    private String userName;
    private String userId;
    private int siteId;
    private GetMyeBaySellingRequestType request;
    private User user;
    private HttpHeaders headers;
    private Task tasks;
    public final ArrayList<ErrorType> errorList;
}