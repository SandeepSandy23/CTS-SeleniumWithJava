package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.application.common.request.GetSellerTransactionsRequest;
import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.invokers.ESServiceInvoker;
import com.ebay.app.apisellingextsvc.tasks.audit.GetSellerTransactionsAuditTask;
import com.ebay.app.apisellingextsvc.utils.AuditUtil;
import com.ebay.app.apisellingextsvc.utils.TaskOrchestrationUtil;
import com.ebay.app.apisellingextsvc.utils.XmlUtil;
import com.ebay.app.apisellingextsvc.enums.APITypeEnum;

public final class GetSellerTransactionsAuditHandler extends ApiSellingExtAuditHandler<GetSellerTransactionsResponse> {

    private final GetSellerTransactionsRequest request;

    public GetSellerTransactionsAuditHandler(GetSellerTransactionsRequest request) {
        super(request);
        this.request = request;
        this.httpHeaders = createRequestHeader(request.headers);
        this.configValue = this.request.configValues;
    }

    @Override
    public void doAudit(GetSellerTransactionsResponse response) {
        // skip output selector audit, because it's done during serialization.
        if (apisellingioResponseFuture != null && response!=null && !AuditUtil.hasOutputSelector(request.requestType)) {

            String apisellingioXmlResponseString= (String) TaskOrchestrationUtil.safeGet(apisellingioResponseFuture);
            CalLogger.info("old response string : ", apisellingioXmlResponseString);

            String apisellingextsvcXmlResponseString= (String) XmlUtil.writeAsString(response);
            CalLogger.info("new response string: ", apisellingextsvcXmlResponseString);

            GetSellerTransactionsResponse apisellingioXmlResponse = XmlUtil.readResponseString(apisellingioXmlResponseString, GetSellerTransactionsResponse.class);

            if (apisellingioXmlResponse ==null || apisellingextsvcXmlResponseString==null ||AuditUtil.shouldSkipAudit(apisellingioXmlResponse, response)) {
                CalLogger.info("Audit skipped","---------");
                return;
            }
            //TODO revist the sort order.
           //AuditUtil.sort(apisellingioXmlResponse);
            AuditUtil.sort(response);

            GetSellerTransactionsAuditTask auditTask = new GetSellerTransactionsAuditTask(response, apisellingioXmlResponse, request.requestType,
                    new ESServiceInvoker(this.request.getTracerContext(),this.configValue), this.httpHeaders, configValue);

            request.orchestrator.execute(auditTask);
        }
    }



    @Override
    protected String createRequestBody() {
        return XmlUtil.writeRequestAsString(request.requestType, APITypeEnum.GetSellerTransactions);
    }

}
