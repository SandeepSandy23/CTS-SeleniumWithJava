package com.ebay.app.apisellingextsvc.framework.outputselector;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import ebay.apis.eblbasecomponents.GetMyeBaySellingResponseType;
import ebay.apis.eblbasecomponents.GetSellerTransactionsResponseType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;

public class OutputSelectorGenerator {

    private static final GraphMap ABSTRACT_RESPONSE_SELECTOR_REF = createDefaultSelector(OutputSelectorGraphImpl.getAbstractResponseGraphMap());
    private static final GraphMap GET_SELLER_TRANSACTIONS_RESPONSE_SELECTOR_REF = createDefaultSelector(OutputSelectorGraphImpl.getGetSellerTransactionsResponseGraphMap());
    private static final GraphMap GET_MYEBAY_SELLING_RESPONSE_SELECTOR_REF = createDefaultSelector(OutputSelectorGraphImpl.getGetMyEbaySellingResponseGraphMap());

    private static GraphMap getGraphMap(@Nonnull Class<?> clazz) {
        if (GetSellerTransactionsResponseType.class.isAssignableFrom(clazz)) {
            return OutputSelectorGraphImpl.getGetSellerTransactionsResponseTypeGraphMap();
        } else if (GetMyeBaySellingResponseType.class.isAssignableFrom(clazz)) {
            return OutputSelectorGraphImpl.getMyEbaySellingResponseTypeGraphMap();
        }
        return OutputSelectorGraphImpl.getGetSellerTransactionsResponseTypeGraphMap();
    }

    public static GraphMap getGraphMap(List<String> requestSelector,
                                       @Nonnull Class<?> clazz) {
        if (CollectionUtils.isEmpty(requestSelector)) {
            return null;
        }
        return getGraphMap(clazz);
    }

    /**
     * if output selector is "ContainingOrder" it won't work due to ContainingOrder is order type, and it will self reference
     */
    public static GraphMap createOutputSelector(List<String> requestSelector, @Nonnull Class<?> clazz) {
        if (CollectionUtils.isEmpty(requestSelector)) {
            return null;
        }
        GraphMap graphMap = getGraphMap(clazz);
        GraphMap outputSelectorRef = new GraphMap();
        for (String path : preProcessOutputSelector(requestSelector)) {
            if (path.contains(".")) {
                // case 1 - user give full path
                formFullPathSelectorRef(path, graphMap, outputSelectorRef);
            } else {
                List<CustomNode> customNodes = graphMap.get(path.toLowerCase(Locale.US));
                if (customNodes!=null && !customNodes.isEmpty()) {
                    for (CustomNode node : customNodes) {
                        walkToParent(node, outputSelectorRef);
                        walkToChildren(node, outputSelectorRef);
                    }
                }
            }
        }
        // combine abstract response
        outputSelectorRef.combine(OutputSelectorGenerator.ABSTRACT_RESPONSE_SELECTOR_REF);
        // combine xmlns
        outputSelectorRef.combine(getAdditionalResponseMap(clazz));
        return outputSelectorRef;
    }

    private static List<String> preProcessOutputSelector(@Nonnull List<String> rawOutputSelector) {
        List<String> outputSelector = new ArrayList<>();
        for (String s : rawOutputSelector) {
            outputSelector.addAll(Arrays.asList(s.split(ApiSellingExtSvcConstants.QUERY_PARAM_COMMA)));
        }
        return outputSelector;
    }

    private static void formFullPathSelectorRef(String path, GraphMap graphMap, GraphMap outputSelectorRef) {
        String[] splitPath = path.split(ApiSellingExtSvcConstants.REG_DOT);
        String firstKey = splitPath[0].toLowerCase(Locale.US);
        if (graphMap.contain(firstKey)) {
            // for getOrderResponseType or GetItemTransactionType ...
            outputSelectorRef.put(firstKey, graphMap.get(firstKey).get(0).getParent());
        }

        for (int i = 1; i < splitPath.length; i++) {
            // split path should always larger than 1 since it has "."
            if (StringUtils.isNotBlank(splitPath[i])) {
                String key = splitPath[i].toLowerCase(Locale.US);
                String parentKey = splitPath[i - 1].toLowerCase(Locale.US);
                if (graphMap.contain(key)) {
                    List<CustomNode> customNodes = graphMap.get(key);
                    for (CustomNode customNode : customNodes) {
                        String fieldName = customNode.getFieldName();
                        CustomNode parent = customNode.getParent();
                        if (parentKey.equals(parent.getFieldName())) {
                            outputSelectorRef.put(fieldName, parent);
                            break;
                        }
                    }
                }
            }
        }
        // walk to children if last pathSplit has children
        String lastPathKey = splitPath[splitPath.length - 1].toLowerCase(Locale.US);
        if (graphMap.contain(lastPathKey)) {
            for (CustomNode customNode : graphMap.get(lastPathKey)) {
                walkToChildren(customNode, outputSelectorRef);
            }
        }
    }

    private static GraphMap getAdditionalResponseMap(@Nonnull Class<?> clazz) {
        if (clazz.equals(GetSellerTransactionsResponseType.class)) {
            return GET_SELLER_TRANSACTIONS_RESPONSE_SELECTOR_REF;
        } else if (clazz.equals(GetMyeBaySellingResponseType.class)) {
            return GET_MYEBAY_SELLING_RESPONSE_SELECTOR_REF;
        }
        return null;
    }

    private static void walkToParent(CustomNode customNodes, GraphMap outputSelectorRef) {
        if (customNodes.getParent() != null) {
            outputSelectorRef.put(customNodes.getFieldName(), customNodes.getParent());
            walkToParent(customNodes.getParent(), outputSelectorRef);
        }
    }

    private static void walkToChildren(CustomNode currentNode, GraphMap outputSelectorRef) {
        if (currentNode != null && !currentNode.getChildren().isEmpty()) {
            for (CustomNode childNode : currentNode.getChildren()) {
                outputSelectorRef.put(childNode.getFieldName(), currentNode);
                walkToChildren(childNode, outputSelectorRef);
            }
        }
    }

    private static GraphMap createDefaultSelector(GraphMap responseGraphMap) {
        GraphMap defaultSelectorRef = new GraphMap();
        for (Entry<String, List<CustomNode>> en : responseGraphMap.getMap().entrySet()) {
            for (CustomNode node : en.getValue()) {
                walkToParent(node, defaultSelectorRef);
            }
        }
        return defaultSelectorRef;
    }
}
