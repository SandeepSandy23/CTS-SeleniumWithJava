package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.cos.las.type.BulkUserNoteRequest;
import com.ebay.cos.las.type.BulkUserNoteResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LASBulkUserNoteClient extends BaseGingerClient<BulkUserNoteRequest, BulkUserNoteResponse> {

    private static final Logger logger = LoggerFactory.getLogger(LasngClient.class);

    private static final String CLIENT_ID = "las.bulkusernotes";

    private static final String PATH = "/bulkusernote";

    public LASBulkUserNoteClient() {
        super(BulkUserNoteResponse.class);
    }

    @Override
    public GingerClientResponse<BulkUserNoteResponse> getGingerResponse(GingerClientRequest<BulkUserNoteRequest> gingerRequest) {
        return processPostRequest(PATH, gingerRequest);
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
