package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.InquiryStatusTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.InquiryStatusCodeType;

// for transaction.status.inquiry status
public class InquiryStatusMapper {

    private static final ImmutableMap<InquiryStatusTypeEnum, InquiryStatusCodeType> mapName
            = new ImmutableMap.Builder<InquiryStatusTypeEnum, InquiryStatusCodeType>()
            .put(InquiryStatusTypeEnum.INVALID, InquiryStatusCodeType.INVALID)
            .put(InquiryStatusTypeEnum.DEFAULT, InquiryStatusCodeType.NOT_APPLICABLE)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_PENDING_BUYER_RESPONSE, InquiryStatusCodeType.TRACK_INQUIRY_PENDING_BUYER_RESPONSE)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_PENDING_SELLER_RESPONSE, InquiryStatusCodeType.TRACK_INQUIRY_PENDING_SELLER_RESPONSE)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_CLOSED_WITH_REFUND, InquiryStatusCodeType.TRACK_INQUIRY_CLOSED_WITH_REFUND)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_CLOSED_NO_REFUND, InquiryStatusCodeType.TRACK_INQUIRY_CLOSED_NO_REFUND)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_ESCALATED_PENDING_BUYER, InquiryStatusCodeType.TRACK_INQUIRY_ESCALATED_PENDING_BUYER)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_ESCALATED_PENDING_SELLER, InquiryStatusCodeType.TRACK_INQUIRY_ESCALATED_PENDING_SELLER)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_ESCALATED_PENDING_CS, InquiryStatusCodeType.TRACK_INQUIRY_ESCALATED_PENDING_CS)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_ESCALATED_CLOSED_WITH_REFUND, InquiryStatusCodeType.TRACK_INQUIRY_ESCALATED_CLOSED_WITH_REFUND)
            .put(InquiryStatusTypeEnum.TRACK_INQUIRY_ESCALATED_CLOSED_NO_REFUND, InquiryStatusCodeType.TRACK_INQUIRY_ESCALATED_CLOSED_NO_REFUND)
            .put(InquiryStatusTypeEnum.NOT_APPLICABLE, InquiryStatusCodeType.NOT_APPLICABLE)
            .build();

    private InquiryStatusMapper() {
    }

    public static InquiryStatusCodeType map(InquiryStatusTypeEnum key) {
        if (key == null) {
            return null;
        }
        return mapName.getOrDefault(key, InquiryStatusCodeType.NOT_APPLICABLE);
    }

}
