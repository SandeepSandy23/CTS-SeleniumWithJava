package com.ebay.app.apisellingextsvc.test;


import java.util.List;

public class MocksTestModel {
    private List<TestMockModel> mocks;

    public MocksTestModel() {
    }

    public List<TestMockModel> getMocks() {
        return this.mocks;
    }

    public void setMocks(List<TestMockModel> mocks) {
        this.mocks = mocks;
    }
}
