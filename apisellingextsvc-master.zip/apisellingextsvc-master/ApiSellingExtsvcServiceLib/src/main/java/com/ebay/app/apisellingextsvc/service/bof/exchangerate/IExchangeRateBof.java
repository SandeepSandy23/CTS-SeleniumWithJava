package com.ebay.app.apisellingextsvc.service.bof.exchangerate;

import com.ebay.integ.dal.dao.ObjectNotFoundException;

public interface IExchangeRateBof {

    Double findExchangeRateByCurrencyId(int currencyId) throws ObjectNotFoundException;
}
