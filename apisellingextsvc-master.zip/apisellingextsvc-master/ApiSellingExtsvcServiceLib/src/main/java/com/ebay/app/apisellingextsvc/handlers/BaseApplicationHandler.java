package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.utils.Headers;

public interface BaseApplicationHandler<T> {

    T handle();

    void setResponseHeaders(Headers responseHeaders);
}
