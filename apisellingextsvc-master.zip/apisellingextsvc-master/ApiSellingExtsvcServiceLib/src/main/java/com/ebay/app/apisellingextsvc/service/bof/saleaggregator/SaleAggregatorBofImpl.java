package com.ebay.app.apisellingextsvc.service.bof.saleaggregator;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.integ.dal.dao.FinderException;
import com.google.gson.Gson;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.dal.saleaggregator.SaleAggregator;
import com.ebay.app.apisellingextsvc.service.dal.saleaggregator.SaleAggregatorDAO;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SaleAggregatorBofImpl implements ISaleAggregatorBof {
    @Override
    public String getSellerProdId(long itemId, long sellerId) {
        try {
            return SaleAggregatorDAO.getInstance().findByPrimaryKey(itemId, sellerId).getSellerProId();
        } catch (FinderException e) {
            CalLogger.error("failed to load ebay items with itemId",
                    "itemId = " + itemId + " - " + e.getMessage());
        }

        return null;
    }

    @Override
    public Map<Long, String> getSellerProdIdByItems(List<Long> itemIds, long sellerId) {
        try {
            List<SaleAggregator> aggregators = SaleAggregatorDAO.getInstance().findBySellerAndItemIds(itemIds, sellerId);
            Map<Long, String> result = new HashMap<>(aggregators.size());
            if (!CollectionUtils.isEmpty(aggregators)) {
                result = aggregators.stream().filter(saleAggregator -> saleAggregator.getItemId() > 0
                        && !StringUtils.isEmpty(saleAggregator.getSellerProId())).collect(Collectors.toMap(SaleAggregator::getItemId,
                        SaleAggregator::getSellerProId));
            }
            return result;
        } catch (Exception e) {
            CalLogger.error("failed to load ebay items with itemId",
                    "itemId = " + new Gson().toJson(itemIds) + " - " + e.getMessage());
        }
        return new HashMap<>();
    }
}
