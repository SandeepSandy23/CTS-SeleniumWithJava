package com.ebay.app.apisellingextsvc.service.invokers.model;

import ebay.apis.eblbasecomponents.PaginatedItemArrayType;
import lombok.Getter;


/**
 * wrapper class to differentiate data in orchestrator dependency
 *
 */
@Getter
public class ActiveModel extends ResponseModel{

    public ActiveModel(PaginatedItemArrayType activeList) {
        super(activeList);
    }
}
