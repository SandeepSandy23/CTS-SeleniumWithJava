package com.ebay.app.apisellingextsvc.tasks.cosmos;


import com.ebay.app.apisellingextsvc.builders.CosmosRequestBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.init.GetSellerTransactionsRequestContext;
import com.ebay.app.apisellingextsvc.service.client.model.CosmosRequest;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.GetSellerTransactionsRequestType;
import org.apache.commons.collections.CollectionUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.Calendar;

public class CosmosRequestTask implements Task<CosmosRequest>, ITaskResultInjectable {

    private GetSellerTransactionsRequestContext requestContext;
    private final GetSellerTransactionsRequestType request;
    private final HttpHeaders httpHeaders;
    private final User user;
    private final ApiSellingExtSvcConfigValues configValues;

    public CosmosRequestTask(
            GetSellerTransactionsRequestType request,
            HttpHeaders httpHeaders,
            User user,
            ApiSellingExtSvcConfigValues configValues) {
        this.request = request;
        this.httpHeaders = httpHeaders;
        this.user = user;
        this.configValues = configValues;
    }

    @Override
    public CosmosRequest call() {
        CosmosRequestBuilder builder = new CosmosRequestBuilder();
        builder.requestHeader(httpHeaders);
        if (doesNotHaveDateRangeInRequest()) {
            request.setNumberOfDays(ApiSellingExtSvcConstants.MAX_NUMBER_OF_DAYS);
        }
        buildFilter(builder);

        if (CollectionUtils.isNotEmpty(request.getDetailLevel())) {
            builder.detailLevel(request.getDetailLevel().get(0).value());
        }
        if (request.getPagination() != null) {
            builder.entryPerPage(request.getPagination().getEntriesPerPage());
            builder.pageNumber(request.getPagination().getPageNumber());
        }
        builder.hasPaginationMode(true);
        builder.userType("seller");
        builder.userId(this.user.getUserId());
        builder.userName(this.user.getUserName());
        builder.omsVersion(configValues.omsVersion);
        return builder.build();
    }

    private boolean doesNotHaveDateRangeInRequest() {
        return request.getModTimeTo() == null && request.getModTimeFrom() == null && request.getNumberOfDays() == null;
    }


    void buildFilter(CosmosRequestBuilder builder) {
        Calendar dateNow = DateUtil.getCalendarNow();
        if (request.getNumberOfDays() != null) {
            builder.modDateFrom(DateUtil.addDays(dateNow.getTime(), -request.getNumberOfDays()));
            builder.modDateTo(dateNow);
        } else {
            Calendar modTimeFrom = DateUtil.convertToCalendar(request.getModTimeFrom());
            Calendar modTimeTo = DateUtil.convertToCalendar(request.getModTimeTo());
            if (modTimeFrom == null) {
                modTimeFrom = DateUtil.addDays(modTimeTo.getTime(), -ApiSellingExtSvcConstants.MAX_MODIFIED_DURATION_DAYS);
            } else if (modTimeTo == null) {
                modTimeTo = DateUtil.addDays(modTimeFrom.getTime(), ApiSellingExtSvcConstants.MAX_MODIFIED_DURATION_DAYS);
            }
            Calendar MINIMUM = DateUtil.addDays(dateNow.getTime(), -configValues.modifiedDateMaxDaysBack);
            builder.modDateFrom(clampCalendar(modTimeFrom, MINIMUM, dateNow));
            builder.modDateTo(clampCalendar(modTimeTo, MINIMUM, dateNow));
        }
        builder.sortOrder("lastmodifieddate");
    }

    private Calendar clampCalendar(Calendar calendar, Calendar min, Calendar max) {
        if (calendar.compareTo(min) < 0) {
            calendar = min;
        }
        if (calendar.compareTo(max) > 0) {
            calendar = max;
        }
        return calendar;
    }

    @Override
    public void addResult(Object result) {
        this.requestContext = (GetSellerTransactionsRequestContext) result;
    }

}
