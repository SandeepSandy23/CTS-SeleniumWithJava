package com.ebay.app.apisellingextsvc.utils;

import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.OrderTotal;
import com.ebay.order.common.v1.PricelineTypeEnum;
import ebay.apis.eblbasecomponents.AmountType;

import java.util.Optional;

public class GMESCosmosFieldUtil {
    public static AmountType getOrderTotal(OrderCSXType order) {
        Optional<AmountType> optionalRunningTotal = Optional.of(order)
                .map(OrderCSXType::getOrderTotalSummary)
                .map(OrderTotal::getRunningTotal)
                .map(AmountTypeUtil::getAmountType);

        if (optionalRunningTotal.isPresent()) {
            AmountType runningTotal = optionalRunningTotal.get();
            if (runningTotal.getValue() > 0.0d && (ProgramUtil.isGSPOrder(order.getPrograms()) || ProgramUtil.isExportsOrder(order.getPrograms()))) {
                // running total - international leg cost + import charges
                AmountType intlLegCost = PriceLineAmountUtil.getLineItemTotalPriceLineAmountTotal(PricelineTypeEnum.INTERNATIONAL_LEG_COST, order);
                AmountType importCharges = PriceLineAmountUtil.getLineItemTotalPriceLineAmountTotal(PricelineTypeEnum.IMPORT_CHARGES, order);
                return AmountTypeUtil.sum(runningTotal, AmountTypeUtil.negate(AmountTypeUtil.sum(intlLegCost, importCharges)));
            }
            return runningTotal;
        }
        return null;
    }
}
