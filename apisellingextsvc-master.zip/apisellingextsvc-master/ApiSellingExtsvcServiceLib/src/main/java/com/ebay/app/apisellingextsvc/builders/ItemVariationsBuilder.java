package com.ebay.app.apisellingextsvc.builders;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.tuple.Pair;
import com.ebay.app.apisellingextsvc.tasks.GMES.ListingActivitiesUtil;
import com.ebay.app.apisellingextsvc.utils.NameValueListTypeUtil;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cos.las.type.Note;
import com.ebay.cos.las.type.NoteType;
import com.ebay.cos.las.type.VariationActivitiesDetail;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.ItemVariation;
import com.ebay.cos.type.v3.core.listing.Listing;
import com.ebay.cos.type.v3.core.listing.PriceSettings;
import com.ebay.cos.type.v3.core.listing.QuantityAndAvailability;
import com.ebay.cos.type.v3.core.listing.QuantityAndAvailabilityByLogisticsPlans;
import com.ebay.cos.type.v3.core.listing.classification.RankedSellerAspect;
import com.ebay.cos.type.v3.core.listing.tradingSummary.ItemVariationTradingSummary;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.NameValueListArrayType;
import ebay.apis.eblbasecomponents.NameValueListType;
import ebay.apis.eblbasecomponents.SellingStatusType;
import ebay.apis.eblbasecomponents.VariationType;
import ebay.apis.eblbasecomponents.VariationsType;
import lombok.Getter;

public class ItemVariationsBuilder extends BaseFacetBuilder<VariationsType> {

	@Getter
    private final ListingActivitiesDetail listingActivity;
    private final SellingStatusType sellingStatus;

    public ItemVariationsBuilder(Task<?> task, ListingActivitiesDetail listingActivity, SellingStatusType sellingStatus) {
        super(task);
        this.listingActivity = listingActivity;
        this.sellingStatus = sellingStatus;
    }

    @Override
    public VariationsType doBuild() {
        VariationsType variationsType = null;
        List<VariationType> variationTypeList = new ArrayList<>();
        Optional<List<ItemVariation>> variationList = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getItemVariations)
                .filter(CollectionUtils::isNotEmpty);
        if (variationList.isPresent()) {
            for (ItemVariation itemVariation : variationList.get()) {
            	// Workaround to skip emitting variations even for non-variation listings. This constraint could be removed once it got fixed on LASNG mappers
                if (itemVariation.getVariationId() != null) {
                    setVariationType(itemVariation, variationTypeList, true);
                }
            }
            if (CollectionUtils.isNotEmpty(variationTypeList)) {
                variationsType = new VariationsType();
                variationsType.getVariation().addAll(variationTypeList);
            }
        }
        return variationsType;
    }

    protected void setVariationType(ItemVariation itemVariation, List<VariationType> variationTypeList,
            boolean setSellingStatus) {
        VariationType variationType = new VariationType();
        variationType.setPrivateNotes(getPrivateNotes(itemVariation));
        variationType.setQuantity(getQuantity(itemVariation));
        if(setSellingStatus) {
            variationType.setSellingStatus(buildSellingStatus(itemVariation));
        }
        variationType.setStartPrice(Optional.ofNullable(getStartPrices(itemVariation)).map(Pair::getKey).orElse(null));
        String variationSKU = getSKU(itemVariation);
        if (null != variationSKU) {
            variationType.setSKU(variationSKU);
        }
        variationType.setVariationSpecifics(getVariationSpecifics(itemVariation));
        variationType.setVariationTitle(getVariationTitle(itemVariation));
        Long watchCount = getWatchCount(itemVariation);
        if (null != watchCount && watchCount > 0L) {
            variationType.setWatchCount(watchCount);
        }
        variationTypeList.add(variationType);
    }

    private SellingStatusType buildSellingStatus(ItemVariation itemVariation) {
        SellingStatusType sellingStatus = new SellingStatusType();
        sellingStatus.setQuantitySold(Optional.ofNullable(itemVariation).map(ItemVariation::getQuantityAndAvailabilityByLogisticsPlans).orElse(new ArrayList<>()).stream().findFirst().map(QuantityAndAvailabilityByLogisticsPlans::getQuantityAndAvailability).map(QuantityAndAvailability::getSoldQuantity).orElse(0));
        return sellingStatus;
    }

    private Pair<AmountType, AmountType> getStartPrices(ItemVariation itemVariation) {
        return Optional.of(itemVariation).map(ItemVariation::getPriceSettings)
                .map(PriceSettings::getLowestFixedPrice)
                .map(value -> ListingActivitiesUtil.getAmountTypes(value, null))
                .orElse(null);
    }

    private Long getWatchCount(ItemVariation itemVariation) {
        return Optional.ofNullable(itemVariation)
                .map(ItemVariation::getItemVariationTradingSummary)
                .map(ItemVariationTradingSummary::getWatchCount)
                .map(Long::valueOf).orElse(null);
    }

    private String getVariationTitle(ItemVariation itemVariation) {
        return Optional.ofNullable(itemVariation)
                .map(ItemVariation::getVariationTitle)
                .map(Text::getContent).orElse(null);
    }

    private Integer getQuantity(ItemVariation itemVariation) {
        return Optional.ofNullable(itemVariation)
                .map(ItemVariation::getQuantityAndAvailabilityByLogisticsPlans)
                .flatMap(quantityAndAvailabilityByLogisticsPlans -> quantityAndAvailabilityByLogisticsPlans.stream().findFirst())
                .map(QuantityAndAvailabilityByLogisticsPlans::getQuantityAndAvailability)
                .map(QuantityAndAvailability::getListedQuantity).orElse(null);
    }


    private NameValueListArrayType getVariationSpecifics(ItemVariation itemVariation) {
        List<NameValueListType> list = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(itemVariation.getAspects())) {
            for (RankedSellerAspect rankedSellerAspect : itemVariation.getAspects()) {
                List<String> aspectValues = new ArrayList<>();
                rankedSellerAspect.getAspectValues().forEach(rankedSellerAspectValue -> aspectValues.add(rankedSellerAspectValue.getValue().getContent()));
                list.add(NameValueListTypeUtil.getNameValueListType(rankedSellerAspect.getName().getContent(), aspectValues));
            }
        }
        NameValueListArrayType nameValueListArrayType = new NameValueListArrayType();
        nameValueListArrayType.getNameValueList().addAll(list);
        return nameValueListArrayType;
    }

    private String getSKU(ItemVariation itemVariation) {
        return Optional.ofNullable(itemVariation)
                .map(ItemVariation::getVariationSKU)
                .orElse(null);
    }

    private String getPrivateNotes(ItemVariation itemVariation) {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getVariationActivitiesDetails)
                .flatMap(variationActivitiesDetails -> Arrays.stream(variationActivitiesDetails)
                        .filter(variationActivitiesDetail -> variationActivitiesDetail.getVariationId().equals(itemVariation.getVariationId())).findFirst())
                .map(VariationActivitiesDetail::getNotes)
                .flatMap(notes -> Arrays.stream(notes)
                        .filter(note -> NoteType.USER.equals(note.getType())).findFirst())
                .map(Note::getMessage).orElse(null);
    }
}