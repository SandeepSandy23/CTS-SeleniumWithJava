package com.ebay.app.apisellingextsvc.service.bof.taxrate;


import com.ebay.af.common.types.RawString;
import com.ebay.integ.dal.BaseDo2;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;

import java.lang.reflect.Field;
import java.util.Date;


public abstract class TaxRateCodeGenDoImpl extends BaseDo2 implements TaxRateCodeGen {
    public static final int SITEID = 0;
    public static final int COUNTRYID = 1;
    public static final int TAXPERCENTAGE = 2;
    public static final int EFFECTIVEDATE = 3;
    public static final int TERMINATIONDATE = 4;
    public static final int USERSTATE = 5;
    public static final int NUM_FIELDS = 6;
    public static final int NUM_SUBOBJECT_FIELDS = 0;
    public int m_siteId;
    public int m_countryId;
    public double m_taxPercentage;
    public Date m_effectiveDate;
    public Date m_terminationDate;
    public String m_userState;

    public TaxRateCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public int getNumFields() {
        return 6;
    }

    public int getSiteId() {
        this.loadValue(0);
        return this.m_siteId;
    }

    public void setSiteId(int siteId) {
        this.m_siteId = siteId;
        this.setDirty(0);
    }

    public int getCountryId() {
        this.loadValue(1);
        return this.m_countryId;
    }

    public void setCountryId(int countryId) {
        this.m_countryId = countryId;
        this.setDirty(1);
    }

    public double getTaxPercentage() {
        this.loadValue(2);
        return this.m_taxPercentage;
    }

    public void setTaxPercentage(double taxPercentage) {
        this.m_taxPercentage = taxPercentage;
        this.setDirty(2);
    }

    public Date getEffectiveDate() {
        this.loadValue(3);
        return this.m_effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.m_effectiveDate = effectiveDate;
        this.setDirty(3);
    }

    public Date getTerminationDate() {
        this.loadValue(4);
        return this.m_terminationDate;
    }

    public void setTerminationDate(Date terminationDate) {
        this.m_terminationDate = terminationDate;
        this.setDirty(4);
    }

    public String getUserState() {
        this.loadValue(5);
        return this.m_userState;
    }

    public void setUserState(String userState) {
        this.m_userState = userState;
        this.setDirty(5);
    }

    @Override
    public Object getSubObject(int subObjConst) {
        Object theObj = null;
        switch (subObjConst) {
            default:
                theObj = super.getSubObject(subObjConst);
                return theObj;
        }
    }

    @Override
    public Object loadSubObject(int subObjConst, int readSet) {
        Object theObj = null;
        switch (subObjConst) {
            default:
                theObj = super.loadSubObject(subObjConst, readSet);
                return theObj;
        }
    }

    @Override
    public boolean equalsData(BaseDo2 other) {
        if (other == null) {
            return false;
        } else if (other == this) {
            return true;
        } else if (!(other instanceof TaxRateCodeGenDoImpl)) {
            return false;
        } else if (!super.equalsData(other)) {
            return false;
        } else {
            TaxRateCodeGenDoImpl cmpDo = (TaxRateCodeGenDoImpl)other;
            String className = this.getClass().getName();
            String packageName = className.substring(0, className.lastIndexOf("."));
            String myClassName = packageName + ".TaxRateCodeGenDoImpl";
            Class myClass = null;

            try {
                myClass = Class.forName(myClassName);
            } catch (ClassNotFoundException var15) {
                return false;
            }

            Field[] fields = myClass.getDeclaredFields();

            for (int i = 0; i < fields.length; ++i) {
                Field f = fields[i];
                if (f.getModifiers() == 1 && f.getModifiers() != 8) {
                    String fieldType = f.getType().getName();

                    try {
                        boolean isEqual = true;
                        if (fieldType.equals("int")) {
                            isEqual = safeEquals(f.getInt(this), f.getInt(cmpDo));
                        } else if (fieldType.equals("long")) {
                            isEqual = safeEquals(f.getLong(this), f.getLong(cmpDo));
                        } else if (fieldType.equals("float")) {
                            isEqual = safeEquals(f.getFloat(this), f.getFloat(cmpDo));
                        } else if (fieldType.equals("double")) {
                            isEqual = safeEquals(f.getDouble(this), f.getDouble(cmpDo));
                        } else if (fieldType.equals("boolean")) {
                            isEqual = safeEquals(f.getBoolean(this), f.getBoolean(cmpDo));
                        } else if (fieldType.endsWith("RawString")) {
                            RawString a = (RawString)f.get(this);
                            RawString b = (RawString)f.get(cmpDo);
                            isEqual = safeEquals(a, b);
                        } else if (fieldType.endsWith("java.util.Date")) {
                            Date a = (Date)f.get(this);
                            Date b = (Date)f.get(cmpDo);
                            isEqual = safeEquals(a, b);
                        } else {
                            isEqual = safeEquals(f.get(this), f.get(cmpDo));
                        }

                        if (!isEqual) {
                            return false;
                        }
                    } catch (IllegalAccessException var14) {
                        return false;
                    }
                }
            }

            return true;
        }
    }

    private void copyFieldsFrom_Batch0(TaxRateCodeGenDoImpl from) {
        if (!this.isLoaded(0) && from.isLoaded(0)) {
            this.m_siteId = from.m_siteId;
            this.copyFieldState(from, 0);
        }

        if (!this.isLoaded(1) && from.isLoaded(1)) {
            this.m_countryId = from.m_countryId;
            this.copyFieldState(from, 1);
        }

        if (!this.isLoaded(2) && from.isLoaded(2)) {
            this.m_taxPercentage = from.m_taxPercentage;
            this.copyFieldState(from, 2);
        }

        if (!this.isLoaded(3) && from.isLoaded(3)) {
            this.m_effectiveDate = copyDate(from.m_effectiveDate);
            this.copyFieldState(from, 3);
        }

        if (!this.isLoaded(4) && from.isLoaded(4)) {
            this.m_terminationDate = copyDate(from.m_terminationDate);
            this.copyFieldState(from, 4);
        }

        if (!this.isLoaded(5) && from.isLoaded(5)) {
            this.m_userState = from.m_userState;
            this.copyFieldState(from, 5);
        }

    }

    @Override
    public void copyFieldsFrom(BaseDo2 copyFromObj) {
        super.copyFieldsFrom(copyFromObj);
        if (copyFromObj != null && copyFromObj instanceof TaxRateCodeGenDoImpl) {
            TaxRateCodeGenDoImpl from = (TaxRateCodeGenDoImpl)copyFromObj;
            this.copyFieldsFrom_Batch0(from);
        }

        this.makeFieldsNullAndLoaded();
    }

    private void makeFieldsNullAndLoaded_Batch0() {
        if (!this.isLoaded(0)) {
            this.setLoadedField(0);
            this.setNull(0);
        }

        if (!this.isLoaded(1)) {
            this.setLoadedField(1);
            this.setNull(1);
        }

        if (!this.isLoaded(2)) {
            this.setLoadedField(2);
            this.setNull(2);
        }

        if (!this.isLoaded(3)) {
            this.setLoadedField(3);
            this.setNull(3);
        }

        if (!this.isLoaded(4)) {
            this.setLoadedField(4);
            this.setNull(4);
        }

        if (!this.isLoaded(5)) {
            this.setLoadedField(5);
            this.setNull(5);
        }

    }

    private void makeFieldsNullAndLoaded() {
        this.makeFieldsNullAndLoaded_Batch0();
    }
}
