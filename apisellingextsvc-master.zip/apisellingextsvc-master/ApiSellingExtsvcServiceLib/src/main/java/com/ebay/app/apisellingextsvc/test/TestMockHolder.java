package com.ebay.app.apisellingextsvc.test;

import com.ebay.app.apisellingextsvc.utils.JsonUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestMockHolder {
    private static final Map<String, Object> MOCKS = new HashMap();
    private static boolean CACHE_MOCKS = false;
    public static final String NULL_OBJECT = "NULL_OBJECT";

    public TestMockHolder() {
    }

    public static void enableCacheMocks() {
        CACHE_MOCKS = true;
    }

    public static <T> T getMock(TestMock mock, Class<T> clazz) {
        Object rval = MOCKS.get(mock.getName());
        if (null == rval) {
            boolean nullObject = false;
            List<MultiValuedParam> validations = mock.getValidations();
            if (validations != null && validations.size() == 1) {
                MultiValuedParam param = (MultiValuedParam)validations.get(0);
                if ("NULL_OBJECT".equals(param.getName())) {
                    nullObject = true;
                }
            }

            if (!nullObject) {
                rval = JsonUtil.getMapper().convertValue(mock.getMockData(), clazz);
            } else {
                rval = "NULL_OBJECT";
            }

            if (CACHE_MOCKS) {
                MOCKS.put(mock.getName(), rval);
            }
        }

        return "NULL_OBJECT".equals(rval) ? null : (T) rval;
    }
}
