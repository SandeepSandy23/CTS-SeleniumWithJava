package com.ebay.app.apisellingextsvc.builders;


import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.mappers.PaymentStatusMapper;
import com.ebay.app.apisellingextsvc.utils.*;
import com.ebay.cosmos.AdjustmentTypeCS;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;

public class MonetaryDetailsBuilder extends BaseFacetBuilder<PaymentsInformationType> {

    private static final Set<String> invalidFMMOrderTransTypes = new HashSet<>(Arrays.asList(ApiSellingExtSvcConstants.ORDER_TRANSACTION_TYPE_INCENTIVE,
            ApiSellingExtSvcConstants.ORDER_TRANSACTION_TYPE_GIFTCARD));

    private static final HashSet<String> PAYMENT_TYPES = new HashSet<>(Arrays.asList(ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_SELLER, ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_EBAY_SELLER_FEE, ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_SHIPPING_PARTNER));
    private static final HashSet<String> EMS_COST_TYPES = new HashSet<>(Arrays.asList(ApiSellingExtSvcConstants.INTL_LEG_COST, ApiSellingExtSvcConstants.IMPORT_CHARGES));
    private static final List<List<String>> PRIMARY_REFUND_TYPE_GROUPS = Arrays.asList(Collections.singletonList(ApiSellingExtSvcConstants.COLLECTION_TYPE_SELLER), Collections.singletonList(ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_SHIPPING_PARTNER));
    private static final List<List<String>> EMS_REFUND_TYPE_GROUPS = Arrays.asList(Arrays.asList(ApiSellingExtSvcConstants.COLLECTION_TYPE_SELLER, ApiSellingExtSvcConstants.EBAY, ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_SHIPPING_PARTNER));

    private static final HashMap<String, Integer> PRIMARY_REFUND_TYPE_MAP = groupsToMapping(PRIMARY_REFUND_TYPE_GROUPS);
    private static final HashMap<String, Integer> EMS_REFUND_TYPE_MAP = groupsToMapping(EMS_REFUND_TYPE_GROUPS);


    private final OrderCSXType order;
    private final List<DetailLevelCodeType> detailLevels;

    public MonetaryDetailsBuilder(Task<?> task,
                                  @Nonnull OrderCSXType order,
                                  @Nullable List<DetailLevelCodeType> detailLevels) {
        super(task);
        this.order = order;
        this.detailLevels = detailLevels;
    }


    @Override
    protected PaymentsInformationType doBuild() {
        PaymentsInformationType monetaryDetails = null;
        if (CommonUtil.shouldExposeOnlyForReturnAll(detailLevels)
                && CollectionUtils.isNotEmpty(order.getPayments().getDistribution())) {
            monetaryDetails = new PaymentsInformationType();
            Optional<PaymentInformationType> payments = buildPayments();
            if (payments.isPresent()) {
                monetaryDetails.setPayments(payments.get());
            }
            Optional<RefundInformationType> refunds = buildRefunds();
            if (refunds.isPresent()) {
                monetaryDetails.setRefunds(refunds.get());
            }
        }
        return monetaryDetails;
    }

    private Optional<PaymentInformationType> buildPayments() {
        Optional<PaymentInformationType> optionalPayments = Optional.empty();
        PaymentInformationType payment = new PaymentInformationType();
        payment.getPayment().addAll(getPaymentTransactionTypes());
        optionalPayments = Optional.of(payment);
        return optionalPayments;
    }

    private Optional<RefundInformationType> buildRefunds() {
        Optional<RefundInformationType> optionalRefundType = Optional.empty();
        List<RefundTransactionInfoType> refundList;
        if (ProgramUtil.isGSPOrder(order.getPrograms()) || ProgramUtil.isExportsOrder(order.getPrograms())) {
            refundList = getRefundTransactionsInfoTypes(EMS_REFUND_TYPE_MAP);
        } else {
            refundList = getRefundTransactionsInfoTypes(PRIMARY_REFUND_TYPE_MAP);
        }

        if (CollectionUtils.isNotEmpty(refundList)) {
            RefundInformationType refundType = new RefundInformationType();
            refundType.getRefund().addAll(refundList);
            optionalRefundType = Optional.of(refundType);
        }
        return optionalRefundType;
    }

    private List<PaymentTransactionType> getPaymentTransactionTypes() {
        UserIdentityType buyer = UserIdentityTypeUtil.getUserIdentityType(UserIdentityCodeType.E_BAY_USER, getBuyerUsername());
        UserIdentityType seller = UserIdentityTypeUtil.getUserIdentityType(UserIdentityCodeType.E_BAY_USER, getSellerUsername());
        List<PaymentTransactionType> sellerTransactions = new ArrayList<>();
        PaymentTransactionType sellerPaymentTransaction = new PaymentTransactionType();
        sellerPaymentTransaction.setPaymentStatus(getPaymentStatus());
        sellerPaymentTransaction.setPayee(seller);
        sellerPaymentTransaction.setPayer(buyer);
        sellerPaymentTransaction.setReferenceID(getFMMReferenceId());
        sellerPaymentTransaction.setFeeOrCreditAmount(PaymentUtil.getFeeOrCreditAmount(order));
        populateSellerPaymentAmountsAndTimes(sellerPaymentTransaction);
        sellerTransactions.add(sellerPaymentTransaction);
        if (ProgramUtil.isGSPOrder(order.getPrograms()) || ProgramUtil.isExportsOrder(order.getPrograms())) {
            PaymentTransactionType partnerPaymentTransaction = new PaymentTransactionType();
            UserIdentityType shippingPartner = UserIdentityTypeUtil.getUserIdentityType(UserIdentityCodeType.E_BAY_USER, getShippingPartner());
            partnerPaymentTransaction.setPayee(shippingPartner);
            partnerPaymentTransaction.setPayer(buyer);
            partnerPaymentTransaction.setPaymentStatus(getPaymentStatus());
            populatePartnerPaymentAmountAndTimes(partnerPaymentTransaction);

            partnerPaymentTransaction.setPaymentTime(sellerPaymentTransaction.getPaymentTime());
            if (partnerPaymentTransaction.getPaymentAmount() != null) { //Subtract (IMPORT_CHARGES + INTL Shipping Cost) for EMS orders
                double originalValue = sellerPaymentTransaction.getPaymentAmount().getValue();
                double newValue = originalValue - partnerPaymentTransaction.getPaymentAmount().getValue();
                sellerPaymentTransaction.getPaymentAmount().setValue(newValue);
            }

            if (PaymentUtil.hasEbayCollectedTax(order.getAttributes())) {
                sellerTransactions.add(partnerPaymentTransaction);
            }
        }

        for (PaymentTransactionType paymentTransactionType : sellerTransactions) {
            if (paymentTransactionType.getPaymentTime() == null) {
                paymentTransactionType.setPaymentTime(PaymentUtil.getLastPaymentClearedDate(order));
            }
            if (paymentTransactionType.getPaymentTime() == null) {
                paymentTransactionType.setPaymentTime(PaymentUtil.getCreationDate(order));
            }
            //Truncate milliseconds from paymentTimes
            if (paymentTransactionType.getPaymentTime() != null) {
                paymentTransactionType.getPaymentTime().setMillisecond(0);
            }
            //Truncate amount values to the nearest cent due to floating-point math errors
            if (paymentTransactionType.getPaymentAmount() != null) {
                paymentTransactionType.getPaymentAmount().setValue(NumberUtil.roundToCent(paymentTransactionType.getPaymentAmount().getValue()));
            }
        }
        return sellerTransactions;
    }

    private void populateSellerPaymentAmountsAndTimes(PaymentTransactionType paymentTransaction) {
        Optional<CurrencyCodeType> currencyCodeType = Optional.empty();
        double value = 0;
        Optional<DateTime> paymentTime = Optional.empty();
        for (DistributionType distribution : order.getPayments().getDistribution()) {
            if (PAYMENT_TYPES.contains(distribution.getType())) {
                ImmutablePair<CurrencyCodeType, Double> pair = getConvertedCurrencyFromAmount(distribution.getTotalAmount().getAmount());
                currencyCodeType = Optional.of(pair.getKey());
                value += pair.getValue();
                paymentTime = Optional.ofNullable(distribution.getDisbursementClearedDate());
            }
        }

        if (currencyCodeType.isPresent()) {
            AmountType amount = new AmountType();
            amount.setCurrencyID(currencyCodeType.get());
            amount.setValue(value);
            paymentTransaction.setPaymentAmount(amount);
            paymentTime.ifPresent(dateTime -> paymentTransaction.setPaymentTime(DateUtil.convertToXMLGregorianCalendar(dateTime)));
        }
    }

    private void populatePartnerPaymentAmountAndTimes(PaymentTransactionType paymentTransaction) {
        Optional<CurrencyCodeType> currencyCodeType = Optional.empty();
        double value = 0;
        if (order.getLineItemTypes().size() > 0) {
            PriceLine[] priceLines = order.getLineItemTypes().get(0).getLineItemTotal().getPriceLines().stream()
                    .filter(priceLine -> EMS_COST_TYPES.contains(priceLine.getType().value())).toArray(PriceLine[]::new);

            for (PriceLine priceLine : priceLines) {
                ImmutablePair<CurrencyCodeType, Double> pair = getConvertedCurrencyFromAmount(priceLine.getAmount());
                currencyCodeType = Optional.of(pair.getKey());
                value += pair.getValue();
            }
        }

        if (currencyCodeType.isPresent()) {
            AmountType amount = new AmountType();
            amount.setCurrencyID(currencyCodeType.get());
            amount.setValue(value);
            paymentTransaction.setPaymentAmount(amount);
        }
    }

    private List<RefundTransactionInfoType> getRefundTransactionsInfoTypes(HashMap<String, Integer> typeMap) {
        RefundTransactionInfoType[] refundTransactionInfoTypes = new RefundTransactionInfoType[typeMap.size()];

        for (AdjustmentTypeCS adjustment : order.getAdjustmentsCS()) {
            List<CollectionType> collections = Optional.of(adjustment)
                    .filter(this::isValidAdjustment)
                    .map(AdjustmentTypeCS::getTypeExtension)
                    .map(AdjustmentType.TypeExtension::getPaymentAdjustment)
                    .map(PaymentAdjustmentType::getCollection).orElse(Collections.emptyList());

            for (CollectionType collection : collections) {
                if (StringUtils.isNotEmpty(collection.getType()) && typeMap.containsKey(collection.getType())) {
                    if (collection.getTotalAmount() != null && collection.getTotalAmount().getAmount() != null) {
                        Amount amount = collection.getTotalAmount().getAmount();
                        int index = typeMap.get(collection.getType());
                        if (refundTransactionInfoTypes[index] == null) {
                            RefundTransactionInfoType refund = new RefundTransactionInfoType();
                            refund.setRefundTime(DateUtil.convertToXMLGregorianCalendar(adjustment.getAdjustmentDate()));
                            refund.getRefundTime().setMillisecond(0);
                            ImmutablePair<CurrencyCodeType, Double> pair = getConvertedCurrencyFromAmount(amount);
                            refund.setRefundAmount(AmountTypeUtil.negate(AmountTypeUtil.getAmountType(pair.getKey(), pair.getValue())));
                            refund.setRefundStatus(PaymentTransactionStatusCodeType.SUCCEEDED);
                            refund.setRefundType(RefundSourceTypeCodeType.PAYMENT_REFUND);
                            refund.setRefundTo(UserIdentityTypeUtil.getUserIdentityType(UserIdentityCodeType.E_BAY_USER, getBuyerUsername()));
                            refundTransactionInfoTypes[index] = refund;
                            refund.setReferenceID(getRMMReferenceId(adjustment));
                        } else {
                            RefundTransactionInfoType refund = refundTransactionInfoTypes[index];
                            ImmutablePair<CurrencyCodeType, Double> pair = getConvertedCurrencyFromAmount(amount);
                            double refundValue = refund.getRefundAmount().getValue();
                            refund.getRefundAmount().setValue(refundValue - pair.getValue());
                        }
                    }
                }
            }
        }

        List<RefundTransactionInfoType> refundTransactionInfoTypeList = new ArrayList<>();
        for (RefundTransactionInfoType refundTransactionInfoType : refundTransactionInfoTypes) {
            if (refundTransactionInfoType != null) {
                refundTransactionInfoTypeList.add(refundTransactionInfoType);
            }
        }
        return refundTransactionInfoTypeList;
    }

    private ImmutablePair<CurrencyCodeType, Double> getConvertedCurrencyFromAmount(Amount amount) {
        CurrencyCodeType currencyCodeType;
        double value;
        if (isFxConversionRequired(amount)) {
            currencyCodeType = CurrencyCodeType.fromValue(amount.getConvertedFromCurrency().name());
            value = amount.getConvertedFromValue();
        } else {
            currencyCodeType = CurrencyCodeType.fromValue(amount.getCurrency().name());
            value = amount.getValue();
        }
        return new ImmutablePair<>(currencyCodeType, value);
    }

    private boolean isRMMOrder() {
        return PaymentUtil.hasRefund(order);
    }

    private boolean isValidAdjustment(AdjustmentTypeCS adj) {
        if (AdjustmentTypeEnumType.REFUND.equals(adj.getAdjustmentType())
                || AdjustmentTypeEnumType.PAYOUT.equals(adj.getAdjustmentType())) {
            return AdjustmentStatusType.SUCCESS.equals(adj.getStatus());
        }
        return false;
    }

    /**
     * is buyerFx
     * buyer collection
     *
     * @param amount
     * @return
     */
    private boolean isFxConversionRequired(Amount amount) {
        return amount.getConvertedFromCurrency() != null && amount.getConvertedFromValue() != null;
    }

    private String getBuyerUsername() {
        return Optional.of(order).map(OrderCSXType::getBuyer).map(UserUtil::getUserName).orElse(null);
    }

    private String getSellerUsername() {
        return Optional.of(order).map(OrderCSXType::getSeller).map(UserUtil::getUserName).orElse(null);
    }

    private String getShippingPartner() {
        return ApiSellingExtSvcConstants.EBAY_PAYEE;
    }

    private PaymentTransactionStatusCodeType getPaymentStatus() {
        return Optional.of(order).map(Order::getPayments).map(PaymentsType::getFundingStatus).map(PaymentStatusMapper::map)
                .orElse(PaymentTransactionStatusCodeType.CUSTOM_CODE);
    }

    private TransactionReferenceType getFMMReferenceId() {
        if (order.getPayments() != null && order.getPayments().getPaymentOrderTransactions() != null) {
            String paymentProviderTransactionId = order.getPayments().getPaymentOrderTransactions().stream()
                    .filter(paymentOrderTransaction -> !invalidFMMOrderTransTypes.contains(paymentOrderTransaction.getPaymentMethod()))
                    .map(PaymentOrderTransaction::getPaymentProviderTransactionId).findFirst().orElse(null);
            TransactionReferenceType refId = new TransactionReferenceType();
            refId.setType(TransactionReferenceCodeType.EXTERNAL_TRANSACTION_ID);
            refId.setValue(paymentProviderTransactionId);
            return refId;
        } else {
            return null;
        }
    }

    private TransactionReferenceType getRMMReferenceId(AdjustmentTypeCS adjustmentType) {
        return Optional.ofNullable(adjustmentType)
                .map(AdjustmentType::getExternalReferenceId)
                .map(Identifier::getExtendedIdentifier1)
                .map(identifier -> {
                    TransactionReferenceType refId = new TransactionReferenceType();
                    refId.setType(TransactionReferenceCodeType.EXTERNAL_TRANSACTION_ID);
                    refId.setValue(identifier);
                    return refId;
                }).orElse(null);
    }

    private static HashMap<String, Integer> groupsToMapping(List<List<String>> groups) {
        HashMap<String, Integer> map = new HashMap<>();
        for (int index = 0; index < groups.size(); index += 1) {
            for (String string : groups.get(index)) {
                map.put(string, index);
            }
        }
        return map;
    }
}