package com.ebay.app.apisellingextsvc.service.client.model;


import javax.ws.rs.core.HttpHeaders;

public class CosmosRequest {

    private final String queryStr;
    private final HttpHeaders headers;

    private final Integer pageNumber;

    private final Integer entryPerPage;

    public CosmosRequest(String queryStr, HttpHeaders headers, Integer pageNumber, Integer entryPerPage) {
        this.queryStr = queryStr;
        this.headers = headers;
        this.pageNumber = pageNumber;
        this.entryPerPage = entryPerPage;
    }

    public String getQueryStr() {
        return queryStr;
    }

    public HttpHeaders getHeaders() {
        return headers;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public Integer getEntryPerPage() {
        return entryPerPage;
    }
}
