package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.order.common.v1.Attribute;
import com.ebay.raptor.orchestrationv2.task.Task;

import java.util.List;

public class EbayCollectAndRemitTaxBuilder extends BaseFacetBuilder<Boolean> {

    private final List<Attribute> attributes;
    private final int trxVersion;

    public EbayCollectAndRemitTaxBuilder(Task<?> task, List<Attribute> attributes, int trxVersion) {
        super(task);
        this.attributes = attributes;
        this.trxVersion = trxVersion;
    }

    @Override
    protected Boolean doBuild() {
        Boolean res = null;
        if (VersionConstant.isGreaterEqualThan(this.trxVersion, VersionConstant.VERSION_AU_GST)) {
            return PaymentUtil.hasEbayCollectedTax(attributes) || isInvoiceToSeller();
        }
        return res;
    }

    private boolean isInvoiceToSeller() {
        String taxType = AttributeUtil.findAttribute(attributes, ApiSellingExtSvcConstants.ATTR_TAX_TYPE)
                .map(Attribute::getValue)
                .orElse(null);
        return ApiSellingExtSvcConstants.INVOICE_TO_SELLER.equalsIgnoreCase(taxType);
    }
}
