package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.service.bof.sellerdiscount.ISellerDiscountBof;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscount.SellerDiscountEntity;
import com.ebay.app.apisellingextsvc.service.invokers.model.SellerDiscountEntityModel;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.app.apisellingextsvc.utils.TypeCastUtil;
import com.ebay.app.apisellingextsvc.utils.UserUtil;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import org.apache.commons.collections.CollectionUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class LoadSellerDiscountsTask implements Task, ITaskResultInjectable {

    private Map<String, Object> resultMap = new HashMap<>();
    private static final int DEFAULT_SHARDING_NUM = 10;
    private final Long requestUserId;
    private final ISellerDiscountBof sellerDiscountBof;

    public LoadSellerDiscountsTask(ISellerDiscountBof sellerDiscountBof,
                                   String requestUserId) {
        this.sellerDiscountBof = sellerDiscountBof;
        this.requestUserId = TypeCastUtil.parseLong(requestUserId);
    }

    @Override
    public SellerDiscountEntityModel call() {
        Map<Long, List<Long>> sellerTransMap = getDiscountMap((ContractResponse)resultMap.get(ContractResponse.class.getName()));
        if (sellerTransMap == null || sellerTransMap.isEmpty()) {
            return new SellerDiscountEntityModel(new HashMap<>());
        }
        List<SellerDiscountEntity> finalResult = sellerDiscountBof.findAllMetTransBySellerIdTransIds(requestUserId, sellerTransMap.get(requestUserId));
        return new SellerDiscountEntityModel(getResultMap(finalResult));
    }

    private Map<Long, List<Long>> getDiscountMap(ContractResponse contractResponse) {
        Map<Long, List<Long>> sellerTransList = Optional.ofNullable(contractResponse)
                .map(ContractResponse::getMembers)
                .orElse(Collections.emptyList())
                .stream()
                .filter(item -> item != null && ContractResponseUtil.isOrder(item))
                .map(ContractResponseType::getOrder)
                .filter(item -> item != null
                        && item.getLineItemTypes().stream().filter(line -> CollectionUtils.isNotEmpty(line.getPromotionsCS())).findAny().isPresent())
                .collect(Collectors.toMap(
                    item -> TypeCastUtil.parseLong(UserUtil.getUserId(item.getSeller())),
                    item -> item.getLineItemTypes().stream()
                            .filter(line -> CollectionUtils.isNotEmpty(line.getPromotionsCS()))
                            .map(line -> TypeCastUtil.parseLong(line.getSourceId().getTransactionId()))
                .collect(Collectors.toList()),
                    (List<Long> v1, List<Long> v2) -> {
                        v1.addAll(v2);
                        return v1;
                    }
                ));
        return sellerTransList;
    }

    private Map<String, SellerDiscountEntity> getResultMap(List<SellerDiscountEntity> result) {
        if (CollectionUtils.isEmpty(result)) {
            return new HashMap<>();
        }
        return result.stream()
                .collect(Collectors.toMap(item -> item.getItemId() + "-" + item.getTransactionId(),
                    Function.identity(),
                    (v1, v2) -> {
                        return v1;
                    }
                ));
    }

    @Override
    public void addResult(Object result) {
       if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result) ;

    }
}
