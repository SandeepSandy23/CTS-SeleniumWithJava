package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import com.ebay.persistence.Column;
import com.ebay.persistence.SecondaryTable;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

@Entity
@SecondaryTable(name = "ITEM_HOST_ITEM_ID_RANGE", alias = "ir")
@Table(name = "ITEM_HOST")
public interface ItemHostInfo {
    @Column(name = "HOST_ID")
    long getHostId();

    void setHostId(long var1);

    @Column(name = "PRIMARY_HOST_NAME")
    String getPrimaryHostName();

    void setPrimaryHostName(String var1);

    @Column(name = "READ_ONLY_HOST_NAME")
    String getReadOnlyHostName();

    void setReadOnlyHostName(String var1);

    @Column(name = "DESCRIPTION")
    String getDescription();

    void setDescription(String var1);

    @Column(name = "RANGE_START", table = "ITEM_HOST_ITEM_ID_RANGE")
    long getRangeStart();
    
    @Column(name = "RANGE_END", table = "ITEM_HOST_ITEM_ID_RANGE")
    long getRangeEnd();

    void setRangeStart(long var1);

    void setRangeEnd(long var1);

    @Column(name = "CREATION_DATE")
    Date getCreationDate();

    @Column(name = "LAST_MODIFIED_DATE")
    Date getLastModifiedDate();

}
