package com.ebay.app.apisellingextsvc.service.bof.sellerdiscount;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscount.SellerDiscountEntity;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscount.SellerDiscountEntityDAO;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.List;

public class SellerDiscountBofImpl implements ISellerDiscountBof {

    @Override
    public List<SellerDiscountEntity> findAllMetTransBySellerIdTransIds(long sellerId, List<Long> transIds) {
        try {
            List<SellerDiscountEntity> sellerDiscountEntities = SellerDiscountEntityDAO.getInstance()
                    .findAllBySellerIdTransIdIn(sellerId, transIds);
            return sellerDiscountEntities;
        } catch (Exception e) {
            CalLogger.error("Seller Discounts get error: ",
                    "cannot get Seller Discounts with sellerId:" + sellerId
                            + " transIds:" + StringUtils.join(transIds, ApiSellingExtSvcConstants.QUERY_PARAM_COMMA));
        }

        return Collections.emptyList();
    }

    @Override
    public List<SellerDiscountEntity> findAllMetTransByBuyerIdTransIds(long sellerId, long buyerId, List<Long> transIds) {
        try {
            List<SellerDiscountEntity> sellerDiscountEntities = SellerDiscountEntityDAO.getInstance()
                    .findAllByBuyerIdTransIdIn(sellerId, buyerId, transIds);
            return sellerDiscountEntities;
        } catch (Exception e) {
            CalLogger.error("Seller Discounts get error: ",
                    "cannot get Seller Discounts with sellerId:" + sellerId
                            + " buyerId:" + buyerId
                            + " transIds:" + StringUtils.join(transIds, ApiSellingExtSvcConstants.QUERY_PARAM_COMMA));
        }

        return Collections.emptyList();
    }

}