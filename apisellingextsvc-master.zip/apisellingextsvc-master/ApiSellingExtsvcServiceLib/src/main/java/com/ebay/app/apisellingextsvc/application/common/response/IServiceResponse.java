package com.ebay.app.apisellingextsvc.application.common.response;


import com.ebay.marketplace.services.ErrorData;

import java.util.List;

public interface IServiceResponse {

    void setWarnings(List<ErrorData> warnings);

    List<ErrorData> getWarnings();

}
