package com.ebay.app.apisellingextsvc.service.dal.sellerpref;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.service.dal.userlookup.UserLookupTupleProvider;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.ToupleProviderRegistry;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.integ.dal.map.MappingIncludesAttribute;
import com.ebay.integ.dal.map.Query;
import com.ebay.integ.dal.map.QueryEngine;
import com.ebay.integ.dal.map.ReadSet;
import com.ebay.integ.dal.map.SelectQuery;
import com.ebay.integ.dal.map.SelectStatement;
import com.ebay.persistence.DALVersion;

import java.util.Optional;

@DALVersion("3.0")
@SuppressWarnings({"PMD", "FindBugs"})
public class SellerPrefDAO extends BaseDao2 {

    private static final String FIND_BY_PK = BaseMap2.PRIMARYKEYLOOKUP;
    private static MappingIncludesAttribute[] ourDDRHints;
    private static volatile SellerPrefDAO instance;

    public static SellerPrefDAO getInstance() {

        if (instance == null) {
            synchronized (SellerPrefDAO.class) {
                if (instance == null) {
                    instance = new SellerPrefDAO();
                }
            }
        }
        return instance;
    }

    public SellerPref findByPrimaryKey(long sellerId) throws FinderException {
        SellerPrefCodeGenDoImpl protoDO = new SellerPrefCodeGenDoImpl();
        protoDO.setSellerId(sellerId);
        QueryEngine qe = new QueryEngine();
        protoDO.setLocalOnly(true);
        return (SellerPref)qe.readSingle(protoDO.getMap(), protoDO, FIND_BY_PK, ReadSets.FULL.value);
    }

    public void initMap() {

        GenericMap<SellerPref> map = GenericMap.getMap(SellerPref.class);
        map = Optional.ofNullable(map).orElse(new GenericMap<>(SellerPref.class));
        map.setDalVersion("3.0");

        //todo need to load minHost and maxHost from global_table_host_map, and cache it in local,
        //https://jirap.corp.ebay.com/browse/TRXAPI-2122

        //todo add failover host to handle exception case
        //https://jirap.corp.ebay.com/browse/TRXAPI-2123

        UserLookupTupleProvider userLookupTupleProvider =
                new UserLookupTupleProvider("EBAY_SELLER_PREF",
                        "userread%host", ApiSellingExtSvcConstants.MIN_HOST,
                        ApiSellingExtSvcConstants.MAX_HOST, "m_sellerId");
        ToupleProviderRegistry.getInstance().registerToupleProvider("EBAY_SELLER_PREF", userLookupTupleProvider);

        initHintGroups(map);
        map.setQueries(getRawQueries(map));
        map.setReadSets(getReadSets(map));
        map.init();
    }

    public static void initHintGroups(@SuppressWarnings("unused") GenericMap<SellerPref> map) {
        ourDDRHints = new MappingIncludesAttribute[] { map.getLocalFieldMapping(SellerPrefCodeGenDoImpl.SELLERID) };
    }

    public static Query[] getRawQueries(GenericMap<SellerPref> map) {

        return new Query[]{
                new SelectQuery(
                        FIND_BY_PK,
                        ourDDRHints,
                        new SelectStatement[] { new SelectStatement(
                                ReadSets.FULL.value,
                                "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE SELLER_ID = :m_sellerId") })
        };
    }

    public static ReadSet[] getReadSets(@SuppressWarnings("unused") GenericMap<SellerPref> map) {
        return new ReadSet[]{ new ReadSet(ReadSets.FULL.value, null) };
    }

    public enum ReadSets {

        MATCHANY(-1), FULL(-2);
        private final int value;

        ReadSets(int v) {
            value = v;
        }
    }
}
