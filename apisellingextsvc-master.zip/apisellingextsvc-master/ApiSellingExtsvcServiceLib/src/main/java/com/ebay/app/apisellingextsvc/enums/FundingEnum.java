package com.ebay.app.apisellingextsvc.enums;

public enum FundingEnum {
    paid("paid"),
    unpaid("unpaid"),
    pending("pending");

    private String name;
    private FundingEnum(String s) {
        name = s;
    }

    public boolean equalsName(String otherName){
        return (otherName == null)? false:name.equals(otherName);
    }

    public String toString() {
        return name;
    }
}
