package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.LasngClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsRequest;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsResponse;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class LasngServiceInvoker extends BaseServiceInvoker<GetListingActivitiesByIdsRequest, GetListingActivitiesByIdsResponse, GetListingActivitiesByIdsRequest> {

    // use for mock
    public static final String NAME = "LasngServiceInvoker";

    public LasngServiceInvoker(TracerContext tracerContext) {
        super( NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<GetListingActivitiesByIdsRequest, GetListingActivitiesByIdsResponse> getGingerClient(
            GetListingActivitiesByIdsRequest getListingActivitiesByIdsRequest) {
        return new LasngClient();
    }

    @Override
    protected GingerClientRequest<GetListingActivitiesByIdsRequest> getGingerRequest(GetListingActivitiesByIdsRequest getListingActivitiesByIdsRequest,
                                                                                     HttpHeaders httpHeaders) {
        GingerClientRequest<GetListingActivitiesByIdsRequest> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(getListingActivitiesByIdsRequest);
        return gingerClientRequest;
    }

}
