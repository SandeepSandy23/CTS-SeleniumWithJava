package com.ebay.app.apisellingextsvc.framework.binding;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;
import com.ebay.app.apisellingextsvc.framework.outputselector.GraphMap;
import com.ebay.app.apisellingextsvc.utils.XmlUtil;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;

import javax.xml.stream.XMLOutputFactory;
import java.io.IOException;
import java.util.Locale;

public class XmlSerializerFactory {

    public static XmlMapper getXmlMapper(final GraphMap outputSelectorRef) {
        XmlMapper XML_MAPPER = XmlMapper.xmlBuilder().defaultUseWrapper(false)
                        .addHandler(new UnknownPropertyDeserializationProblemHandler())
                        .addModule(new JaxbAnnotationModule()).build();
        XML_MAPPER.setDateFormat(XmlUtil.getZuluDateFormat());
        // This ignores empty elements (Trading API fails when empty elements are present in request)
        XML_MAPPER.setSerializationInclusion(Include.NON_EMPTY);

        XML_MAPPER.getFactory().getXMLOutputFactory().setProperty(XMLOutputFactory.IS_REPAIRING_NAMESPACES, true);
        if(outputSelectorRef != null) {

            XML_MAPPER.setAnnotationIntrospector(new JaxbAnnotationIntrospector(TypeFactory.defaultInstance()) {
                @Override
                public boolean hasIgnoreMarker(final AnnotatedMember m) {
                    String currentFieldName = m.getName().toLowerCase(Locale.US);
                    String parentFieldName = m.getDeclaringClass().getSimpleName().toLowerCase(Locale.US);
                    return !outputSelectorRef.containField(currentFieldName, parentFieldName)
                            || super.hasIgnoreMarker(m);
                }
            });
        }
        return XML_MAPPER;
    }

    public static XmlMapper getXmlMapperWithIgnoreUnknownProperties() {

        XmlMapper XML_MAPPER = XmlMapper.xmlBuilder().defaultUseWrapper(false)
                .addHandler(new DeserializationProblemHandler() {
                    @Override
                    public boolean handleUnknownProperty(DeserializationContext ctxt, JsonParser p,
                                                         JsonDeserializer<?> deserializer,
                                                         Object beanOrClass, String propertyName) throws IOException {
                        CalLogger.warn("XmlSerializerFactory", "unknown propertyName=" + propertyName);
                        return true;
                    }
                })
                .addModule(new JaxbAnnotationModule()).build();

        XML_MAPPER.setDateFormat(XmlUtil.getZuluDateFormat());
        // This ignores empty elements (Trading API fails when empty elements are present in request)
        XML_MAPPER.setSerializationInclusion(Include.NON_EMPTY);

        XML_MAPPER.getFactory().getXMLOutputFactory().setProperty(XMLOutputFactory.IS_REPAIRING_NAMESPACES, true);

        return XML_MAPPER;
    }
}
