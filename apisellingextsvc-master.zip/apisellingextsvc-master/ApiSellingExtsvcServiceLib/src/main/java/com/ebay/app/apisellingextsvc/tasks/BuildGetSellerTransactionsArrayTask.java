package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.builders.gst.GSTOrderTransactionArrayBuilder;
import com.ebay.app.apisellingextsvc.builders.gst.proforma.GSTProformaOrderTransactionArrayBuilder;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.service.bof.saleaggregator.ISaleAggregatorBof;
import com.ebay.app.apisellingextsvc.service.bof.taxrate.ITaxRateBof;
import com.ebay.app.apisellingextsvc.service.invokers.model.BulkUserInfoModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.FeedBackPercentageModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.ListingActivitiesByIdsModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.SVLSItemInfoModel;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.TransactionArrayType;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Transaction array task
 */
public class BuildGetSellerTransactionsArrayTask implements Task, ITaskResultInjectable {

    private final Map<String, Object> resultMap = new HashMap<>();
    private final int trxVersion;
    private final ApiSellingExtSvcConfigValues configValues;
    private final List<DetailLevelCodeType> detailLevels;
    private final SiteContext siteContext;
    private final ISaleAggregatorBof saleAggregatorBof;
    private final boolean includeFinalValueFee;
    private final  ContentResource contentResource;
    private final boolean includeContainingOrder;

    public BuildGetSellerTransactionsArrayTask(int trxVersion,
                                               ApiSellingExtSvcConfigValues configValues,
                                               List<DetailLevelCodeType> detailLevels,
                                               ITaxRateBof taxRateBof, SiteContext siteContext,
                                               ContentResource contentResource,
                                               ISaleAggregatorBof saleAggregatorBof, boolean includeFinalValueFee,
                                               boolean includeContainingOrder) {

        this.trxVersion = trxVersion;
        this.configValues = configValues;
        this.siteContext = siteContext;
        this.contentResource = contentResource;
        this.detailLevels = detailLevels;
        this.saleAggregatorBof = saleAggregatorBof;
        this.includeFinalValueFee = includeFinalValueFee;
        this.includeContainingOrder = includeContainingOrder;
    }

    @Override
    public TransactionArrayType call() {
        ContractResponse cosmosResponse = (ContractResponse) resultMap.get(ContractResponse.class.getName());
        SellerProfileDataContext dataContext =
                (SellerProfileDataContext) resultMap.get(SellerProfileDataContext.class.getName());
        BulkUserInfoModel bulkUserInfoModel = (BulkUserInfoModel) resultMap.get(BulkUserInfoModel.class.getName());
        ListingActivitiesByIdsModel listingActivitiesByIdsModel = (ListingActivitiesByIdsModel) resultMap.get(ListingActivitiesByIdsModel.class.getName());
        SVLSItemInfoModel svlsItemInfoModel = (SVLSItemInfoModel) resultMap.get(SVLSItemInfoModel.class.getName());
        FeedBackPercentageModel feedBackPercentageModel = (FeedBackPercentageModel) resultMap.get(FeedBackPercentageModel.class.getName());

        if(cosmosResponse == null || (CollectionUtils.isNotEmpty(cosmosResponse.getMembers()) &&
                                         (bulkUserInfoModel.getUserInfoData().isEmpty() || listingActivitiesByIdsModel.getItemIdListingActivityMap().isEmpty()))){
            return null;
        }
        Map<String, Item> itemMap = (svlsItemInfoModel !=null && MapUtils.isNotEmpty(svlsItemInfoModel.getItemMap()))? svlsItemInfoModel.getItemMap(): null;
        List<TransactionType> transactionTypeList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(cosmosResponse.getMembers())) {
            for (ContractResponseType member : cosmosResponse.getMembers()) {
                if (ContractResponseUtil.isOrder(member)) {
                    transactionTypeList.addAll(new GSTOrderTransactionArrayBuilder(this, member, trxVersion, siteContext, contentResource.contentHelper,
                            detailLevels, configValues, bulkUserInfoModel.getUserInfoData(), dataContext, includeFinalValueFee, includeContainingOrder,
                            saleAggregatorBof, listingActivitiesByIdsModel.getItemIdListingActivityMap(), feedBackPercentageModel.getFeedBackPercentageMap(),
                            itemMap).build());
                } else if (ContractResponseUtil.isProformaOrder(member)) {
                    transactionTypeList.addAll(new GSTProformaOrderTransactionArrayBuilder(this, member, trxVersion, siteContext, contentResource.contentHelper,
                            detailLevels, configValues, dataContext, saleAggregatorBof, includeContainingOrder,
                            listingActivitiesByIdsModel.getItemIdListingActivityMap(), itemMap).build());
                }
            }
        }

        TransactionArrayType transactionArrayType = new TransactionArrayType();
        transactionArrayType.getTransaction().addAll(transactionTypeList);
        return transactionArrayType;
    }
    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
