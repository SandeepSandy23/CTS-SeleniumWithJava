package com.ebay.app.apisellingextsvc.service.client.FeedBackSvcClient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class OverallRatingSummaryDistribution {
    private Double positiveFeedbackReceivedPercentNonRepeatedNeutralExcluded;
}
