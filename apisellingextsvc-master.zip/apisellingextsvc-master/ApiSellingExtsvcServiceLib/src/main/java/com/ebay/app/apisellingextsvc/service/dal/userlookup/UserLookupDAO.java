package com.ebay.app.apisellingextsvc.service.dal.userlookup;

import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.SimpleTableTouple;
import com.ebay.integ.dal.ddr.SimpleToupleProvider;
import com.ebay.integ.dal.ddr.ToupleProviderRegistry;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.integ.dal.map.MappingIncludesAttribute;
import com.ebay.integ.dal.map.Query;
import com.ebay.integ.dal.map.QueryEngine;
import com.ebay.integ.dal.map.ReadSet;
import com.ebay.integ.dal.map.SelectQuery;
import com.ebay.integ.dal.map.SelectStatement;
import com.ebay.persistence.DALVersion;

import java.util.Optional;

@DALVersion("3.0")
@SuppressWarnings({"PMD", "FindBugs"})
public class UserLookupDAO extends BaseDao2 {

    public static final String FIND_BY_USERID = "FIND_BY_USERID";
    private static final MappingIncludesAttribute[] ourDDRHints = new MappingIncludesAttribute[0];
    private static volatile UserLookupDAO instance;

    public static UserLookupDAO getInstance() {

        if (instance == null) {
            synchronized (UserLookupDAO.class) {
                if (instance == null) {
                    instance = new UserLookupDAO();
                }
            }
        }

        return instance;
    }

    /**
    * this method is used to find database host by userId.
    * */
    public UserLookup findByUserId(long userId) throws FinderException {
        UserLookupCodeGenDoImpl protoDO = new UserLookupCodeGenDoImpl();
        protoDO.setUserId(userId);
        QueryEngine qe = new QueryEngine();
        protoDO.setLocalOnly(true);
        protoDO.setReadOnlyHint(true);
        return (UserLookup) qe.readSingle(protoDO.getMap(), protoDO, FIND_BY_USERID, ReadSets.FULL.value);
    }

    public void initMap() {
        GenericMap<UserLookup> map = GenericMap.getMap(UserLookup.class);
        map = Optional.ofNullable(map).orElse(new GenericMap<>(UserLookup.class));
        map.setDalVersion("3.0");

        ToupleProviderRegistry.getInstance().registerToupleProvider("USER_HOST_ID_LOOKUP",
                new SimpleToupleProvider(
                        new SimpleTableTouple("USER_HOST_ID_LOOKUP", "userlookupwritehost"),
                        new SimpleTableTouple("USER_HOST_ID_LOOKUP", "userlookupreadhost")));

        map.setQueries(getRawQueries());
        map.setReadSets(getReadSets());
        map.init();
    }

    public static Query[] getRawQueries() {
        return new Query[]{new SelectQuery(FIND_BY_USERID,
                ourDDRHints,
                new SelectStatement[]{
                        new SelectStatement(-1, "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE USER_ID = :m_userId")
                })
        };
    }

    public static ReadSet[] getReadSets() {
        return new ReadSet[]{ new ReadSet(ReadSets.FULL.value, null) };
    }

    public enum ReadSets {

        MATCHANY(-1), FULL(-2);
        private final int value;

        ReadSets(int v) {
            value = v;
        }
    }
}
