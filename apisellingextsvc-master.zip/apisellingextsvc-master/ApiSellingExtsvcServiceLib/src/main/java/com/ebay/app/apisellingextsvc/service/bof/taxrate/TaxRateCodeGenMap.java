package com.ebay.app.apisellingextsvc.service.bof.taxrate;


import com.ebay.integ.dal.map.*;


public abstract class TaxRateCodeGenMap extends BaseMap2 {
    public static final String FIND_ALL = "FIND_ALL";
    public static final TableDef m_tax_rateTable = new TableDef("tax_rate", "tr");
    public FullFieldMapping m_siteIdFm;
    public FullFieldMapping m_countryIdFm;
    public FullFieldMapping m_taxPercentageFm;
    public FullFieldMapping m_effectiveDateFm;
    public FullFieldMapping m_terminationDateFm;
    public FullFieldMapping m_userStateFm;
    protected final MappingIncludesAttribute[] m_ourDDRHints;
    private FieldMapping[] m_builtFieldMappings;
    private FieldMapping[] m_ourFieldMappings;
    private ReadSet[] m_builtReadSets;

    protected TaxRateCodeGenMap() {
        this.m_siteIdFm = new FullFieldMapping("m_siteId", 0, m_tax_rateTable, "LISTING_SITE_ID");
        this.m_countryIdFm = new FullFieldMapping("m_countryId", 1, m_tax_rateTable, "USER_COUNTRY_ID");
        this.m_taxPercentageFm = new FullFieldMapping("m_taxPercentage", 2, m_tax_rateTable, "TAX_PERCENTAGE");
        this.m_effectiveDateFm = new FullFieldMapping("m_effectiveDate", 3, m_tax_rateTable, "EFFECTIVE_DATE");
        this.m_terminationDateFm = new FullFieldMapping("m_terminationDate", 4, m_tax_rateTable, "TERMINATION_DATE");
        this.m_userStateFm = new FullFieldMapping("m_userState", 5, m_tax_rateTable, "USER_STATE");
        this.m_ourDDRHints = new MappingIncludesAttribute[0];
        this.m_builtFieldMappings = null;
        this.m_ourFieldMappings = null;
        this.m_builtReadSets = null;
    }

    protected Class getDOClassToMap() {
        return TaxRateDoImpl.class;
    }

    public MappingIncludesAttribute[] getOurDDRHints() {
        return this.m_ourDDRHints;
    }

    protected TableDef[] getTableDefs() {
        TableDef[] tableDefs = new TableDef[]{m_tax_rateTable};
        return tableDefs;
    }

    protected TableJoin[] getTableJoins() {
        TableJoin[] tableJoins = new TableJoin[0];
        return tableJoins;
    }

    protected void initFieldMappings() {
        super.initFieldMappings();
    }

    protected FieldMapping[] getFieldMappings() {
        if (this.m_builtFieldMappings == null) {
            this.m_ourFieldMappings = new FieldMapping[]{this.m_siteIdFm, this.m_countryIdFm,
                    this.m_taxPercentageFm, this.m_effectiveDateFm, this.m_terminationDateFm, this.m_userStateFm};
            this.m_builtFieldMappings = this.appendMappings(super.getFieldMappings(), this.m_ourFieldMappings);
        }

        return this.m_builtFieldMappings;
    }

    protected ReadSet[] getReadSets() {
        if (this.m_builtReadSets == null) {
            ReadSet[] readSets = new ReadSet[]{new ReadSet(-2, null)};
            this.m_builtReadSets = this.appendReadSets(super.getReadSets(), super.getFieldMappings(), readSets, this.m_ourFieldMappings);
        }

        return this.m_builtReadSets;
    }

    protected Query[] getRawQueries() {
        Query[] queries = new Query[]{new SelectQuery("FIND_ALL", this.m_ourDDRHints,
                new SelectStatement[]{new SelectStatement(-1,
                        "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/>  ")})};
        queries = this.mergeQuerySets(super.getRawQueries(), queries);
        return queries;
    }
}

