package com.ebay.app.apisellingextsvc.service.bof.shippingcarrier;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.dal.shippingcarrier.ShippingCarrier;
import com.ebay.app.apisellingextsvc.service.dal.shippingcarrier.ShippingCarrierDAO;

import java.util.Optional;

public class ShippingCarrierBofImpl implements IShippingCarrierBof {

    public String findCarrierNameByCarrierId(int carrierId) {

        try {
            ShippingCarrier carrier = ShippingCarrierDAO.getInstance().findCarrierNameByEnumId(carrierId);
            return Optional.ofNullable(carrier).map(ShippingCarrier::getShippingCarrierName).orElse(null);
        } catch (Throwable e) {
            CalLogger.error("Shipping Carrier get error: ",
                  "cannot get Shipping Carrier with carrierId:" + carrierId);
            return null;
        }
    }
}
