package com.ebay.app.apisellingextsvc.audit.comparator;

import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

public interface IFacetComparator {
    boolean qualified(JsonNode var1, JsonNode var2, String var3);

    boolean compare(JsonNode var1, JsonNode var2, String var3, JsonNode var4, String var5, IReport var6);
}