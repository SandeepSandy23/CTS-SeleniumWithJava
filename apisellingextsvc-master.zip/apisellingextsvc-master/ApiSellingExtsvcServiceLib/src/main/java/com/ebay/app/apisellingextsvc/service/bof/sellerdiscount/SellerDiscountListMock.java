package com.ebay.app.apisellingextsvc.service.bof.sellerdiscount;

import com.ebay.app.apisellingextsvc.service.dal.sellerdiscount.SellerDiscountEntityMock;

import java.util.List;

public class SellerDiscountListMock {

    private List<SellerDiscountEntityMock> sellerDiscountEntityMockList;

    public List<SellerDiscountEntityMock> getSellerDiscountEntityMockList() {
        return sellerDiscountEntityMockList;
    }

    public void setSellerDiscountEntityMockList(List<SellerDiscountEntityMock> sellerDiscountEntityMockList) {
        this.sellerDiscountEntityMockList = sellerDiscountEntityMockList;
    }
}
