package com.ebay.app.apisellingextsvc.audit.comparator.api;

import com.ebay.app.apisellingextsvc.audit.comparator.CustomExtComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.IJsonNodeComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.facet.*;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class GetSellerTransactionsComparator extends CustomExtComparator {

    public static final String PATTERN_FILE = "audit/response/get_seller_transactions.json";
    public final List<String> excludeFieldList;

    public GetSellerTransactionsComparator(List<String> excludeFieldList) {
        this(false, false, excludeFieldList);
    }

    public GetSellerTransactionsComparator(boolean disablePatternFile, boolean disableExclusionFile, List<String> excludeFieldList) {
        super(PATTERN_FILE, disableExclusionFile ? Collections.emptyList() : excludeFieldList, disablePatternFile);
        this.excludeFieldList = excludeFieldList;
        registerExtendedComparators();
    }


    private void registerExtendedComparators() {
        addFacetComparators(new GetSellerTransactionsFacetComparator(this));
        addFacetComparators(new TransactionArrayFacetComparator(this));
        addFacetComparators(new BuyerFacetComparator(this));

        DateTimeComparator timeComparator = new DateTimeComparator(this);
        //addCustomJsonNodeComparator("root.OrderArray.Order[*].CreatedTime", timeComparator);
        // addCustomJsonNodeComparator("root.OrderArray.Order[*].CheckoutStatus.LastModifiedTime", timeComparator);
        addCustomJsonNodeComparator("root.TransactionArray.Transaction[*].CreatedDate", timeComparator);

        // handle ShippingAddress.StateOrProvince mismatch remove "." compare in lower case
        IJsonNodeComparator stateOrProvinceComparator = new StateOrProvinceComparator(this);
        addCustomJsonNodeComparator("root.TransactionArray.Transaction[*].ShippingAddress.StateOrProvince", stateOrProvinceComparator);

        //ignored for GST only when it is a purchase order
        addCustomJsonNodeComparator("root.TransactionArray.Transaction[*].ShippingDetails.ShippingServiceOptions",
                new ShippingServiceOptionsComparator(this));
        //ignored for GST only when it is a purchase order
        addCustomJsonNodeComparator("root.TransactionArray.Transaction[*].ShippingDetails.InternationalShippingServiceOption",
                new InternationalShippingServiceOptionComparator(this));

        //handle BuyerCheckoutMessage mismatch ignore the message end with '\n'
        IJsonNodeComparator buyerCheckoutMessageComparator = new BuyerCheckoutMessageComparator(this);
        addCustomJsonNodeComparator("root.TransactionArray.Transaction[*].BuyerCheckoutMessage", buyerCheckoutMessageComparator);

        // trim empty string to null and then compare, only apply to textual field.
        addCustomJsonNodeComparator("root.TransactionArray.Transaction[*].ShippingDetails.SalesTax.SalesTaxState",
                new TrimEmptyToNullComparator(this, jsonNode -> Objects.nonNull(jsonNode)
                        && StringUtils.isEmpty(jsonNode.textValue())));
    }
}
