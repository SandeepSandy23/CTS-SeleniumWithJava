package com.ebay.app.apisellingextsvc.service.bof.sellerdiscountcampaign;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign.SellerDiscountCampaign;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign.SellerDiscountCampaignDAO;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.List;

public class SellerDiscountCampaignBofImpl implements ISellerDiscountCampaignBof {
    @Override
    public List<SellerDiscountCampaign> findCampaignsByIds(List<Long> campaignIds) {
        try {
            List<SellerDiscountCampaign> sellerDiscountCampaigns = SellerDiscountCampaignDAO.getInstance().findCampaignsByIds(campaignIds);
            return sellerDiscountCampaigns;
        } catch (Exception e) {
            CalLogger.error("Seller Campaigns get error: ",
                    "cannot get Seller Campaigns with campaignIds:" +
                            StringUtils.join(campaignIds, ApiSellingExtSvcConstants.QUERY_PARAM_COMMA));
        }

        return Collections.emptyList();
    }
}
