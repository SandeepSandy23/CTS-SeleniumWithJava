package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.LimitStatusClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.rm.limit.enforcement.types.CheckSellingLimitStatusResponse;

import javax.ws.rs.core.HttpHeaders;

public class LimitStatusServiceInvoker extends BaseServiceInvoker<String, CheckSellingLimitStatusResponse, String> {

    public static final String NAME = "LimitStatusServiceInvoker";

    public LimitStatusServiceInvoker(TracerContext tracerContext) {
        super(NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<String, CheckSellingLimitStatusResponse> getGingerClient(String request) {
        return new LimitStatusClient();
    }

    @Override
    protected GingerClientRequest<String> getGingerRequest(String request, HttpHeaders httpHeaders) {
        GingerClientRequest<String> gingerClientRequest = new GingerClientRequest<>();
        gingerClientRequest.setRequest(request);
        return gingerClientRequest;
    }
}
