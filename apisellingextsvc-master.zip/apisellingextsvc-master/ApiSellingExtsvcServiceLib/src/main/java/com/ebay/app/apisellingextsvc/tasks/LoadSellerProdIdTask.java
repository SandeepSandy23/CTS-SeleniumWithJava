package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.tasks.models.SellerProdDataModel;
import com.ebay.app.apisellingextsvc.utils.TypeCastUtil;
import com.ebay.app.apisellingextsvc.utils.UserUtil;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.app.apisellingextsvc.service.bof.saleaggregator.ISaleAggregatorBof;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

public class LoadSellerProdIdTask implements Task, ITaskResultInjectable {

    private Map<String, Object> resultMap = new HashMap<>();
    public static final String TASK_NAME = "LoadSellerProdIdTask";
    private final ISaleAggregatorBof saleAggregatorBof;

    public LoadSellerProdIdTask(ISaleAggregatorBof saleAggregatorBof) {
        this.saleAggregatorBof = saleAggregatorBof;
    }

    @Override
    public SellerProdDataModel call() {
        SellerProdDataModel response = new SellerProdDataModel();
        Map<Long, List<Long>> sellerItemsMap = getItemIdsMap();
        if (CollectionUtils.isEmpty(sellerItemsMap)) {
            return response;
        }
        Map<Long, String> result = new HashMap<>();
        if (!CollectionUtils.isEmpty(sellerItemsMap)) {
            for (Map.Entry<Long, List<Long>> entry : sellerItemsMap.entrySet()) {
                List<Long> itemIds = entry.getValue().stream().distinct().collect(Collectors.toList());
                Map<Long, String> items = saleAggregatorBof.getSellerProdIdByItems(itemIds, entry.getKey());
                result.putAll(items);
            }
        }
        response.setSellerProdId(result);
        return response;
    }


    private Map<Long, List<Long>> getItemIdsMap() {
        Map<Long, List<Long>> sellerTransList =
                Optional.ofNullable((ContractResponse) resultMap.get(ContractResponse.class.getName()))
                .map(ContractResponse::getMembers)
                .orElse(Collections.emptyList())
                .stream()
                .filter(Objects::nonNull)
                .map(ContractResponseType::getOrder)
                .filter(item -> item != null
                        && item.getLineItemTypes().stream().anyMatch(line -> line.getSourceId() != null
                        && StringUtils.isNotEmpty(line.getSourceId().getItemId())))
                .collect(Collectors.toMap(
                    item -> TypeCastUtil.parseLong(UserUtil.getUserId(item.getSeller())),
                    item -> item.getLineItemTypes().stream()
                            .filter(line -> line.getSourceId() != null && line.getSourceId().getItemId() != null)
                            .map(line -> TypeCastUtil.parseLong(line.getSourceId().getItemId()))
                .collect(Collectors.toList()),
                    (List<Long> v1, List<Long> v2) -> {
                        v1.addAll(v2);
                        return v1;
                    }
                ));
        return sellerTransList;
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
