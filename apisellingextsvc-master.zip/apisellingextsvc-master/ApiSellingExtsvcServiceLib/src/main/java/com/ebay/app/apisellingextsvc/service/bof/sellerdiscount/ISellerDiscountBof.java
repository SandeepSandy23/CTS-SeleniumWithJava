package com.ebay.app.apisellingextsvc.service.bof.sellerdiscount;

import com.ebay.app.apisellingextsvc.service.dal.sellerdiscount.SellerDiscountEntity;

import java.util.List;

public interface ISellerDiscountBof {
    List<SellerDiscountEntity> findAllMetTransBySellerIdTransIds(long sellerId, List<Long> transIds);

    List<SellerDiscountEntity> findAllMetTransByBuyerIdTransIds(long sellerId, long buyerId, List<Long> transIds);

}
