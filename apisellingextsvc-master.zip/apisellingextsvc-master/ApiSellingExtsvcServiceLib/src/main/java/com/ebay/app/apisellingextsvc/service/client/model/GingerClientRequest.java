package com.ebay.app.apisellingextsvc.service.client.model;

import javax.ws.rs.core.MultivaluedMap;

public class GingerClientRequest<REQUEST> {

    private REQUEST request;

    private boolean requestDataAvailable = false;

    private MultivaluedMap<String, Object> headers;

    public REQUEST getRequest() {
        return request;
    }

    public void setRequest(REQUEST request) {
        if (request != null) {
            requestDataAvailable = true;
            this.request = request;
        }
    }

    public MultivaluedMap<String, Object> getHeaders() {
        return headers;
    }

    public void setHeaders(MultivaluedMap<String, Object> headers) {
        this.headers = headers;
    }

    public boolean isRequestDataAvailable() {
        return requestDataAvailable;
    }

    public void setRequestDataAvailable(boolean requestDataAvailable) {
        this.requestDataAvailable = requestDataAvailable;
    }


}
