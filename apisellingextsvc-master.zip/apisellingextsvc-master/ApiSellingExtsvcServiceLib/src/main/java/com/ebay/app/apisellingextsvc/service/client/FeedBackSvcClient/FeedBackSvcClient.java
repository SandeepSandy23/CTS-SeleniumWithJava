package com.ebay.app.apisellingextsvc.service.client.FeedBackSvcClient;

import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Component
public class FeedBackSvcClient extends BaseGingerClient<String, String> {

    private static Logger logger = LoggerFactory.getLogger(FeedBackSvcClient.class);

    private static final String FDBKSVC_CLIENT = "feedback.fdbksvc";
    private static final String PATH = "dgs/graphql";

    public FeedBackSvcClient() {
        super(String.class);
    }

    @Override
    public GingerClientResponse<String> getGingerResponse(GingerClientRequest<String> gingerClientRequest) {
        return processPostRequest(PATH, gingerClientRequest.getHeaders(), gingerClientRequest,true);
    }

    @Override
    public String getTargetBase() {
        return FDBKSVC_CLIENT;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
