package com.ebay.app.apisellingextsvc.tasks.audit;

import com.ebay.app.apisellingextsvc.application.common.request.BaseApplicationRequest;
import com.ebay.app.apisellingextsvc.application.common.response.IServiceResponse;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.raptor.orchestrationv2.task.AsyncTask;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;

import javax.ws.rs.core.HttpHeaders;
import java.util.concurrent.CompletableFuture;

public class ApisellingioAuditDataTask  implements AsyncTask<IServiceResponse>, ITaskResultInjectable {

    private final String body;
    private final IServiceInvoker<String, String> apisellingioServiceInvoker;
    private final HttpHeaders headers;
    private final BaseApplicationRequest request;


    public ApisellingioAuditDataTask(BaseApplicationRequest request,
                             IServiceInvoker<String, String> apisellingioServiceInvoker,
                             HttpHeaders headers,
                             String body) {
        this.request = request;
        this.apisellingioServiceInvoker = apisellingioServiceInvoker;
        this.headers = headers;
        this.body = body;
    }

    @Override
    public CompletableFuture call() {
        return CompletableFuture.supplyAsync(() ->
                this.apisellingioServiceInvoker.getResponse(body,headers));
    }

    @Override
    public void addResult(Object o) {}
}
