package com.ebay.app.apisellingextsvc.service.dal.common;

public enum ReadSets {

    MATCHANY(-1), FULL(-2), LAST_MODIFIED_DATE(0);
    private int value;

    ReadSets(int v) {
        value = v;
    }

    public int getValue() {
        return value;
    }
}
