package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.CommentTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.CommentTypeCodeType;

public class CommentTypeMapper {
    private static final ImmutableMap<CommentTypeEnum, CommentTypeCodeType> mapName
            = new ImmutableMap.Builder<CommentTypeEnum, CommentTypeCodeType>()
            .put(CommentTypeEnum.POSITIVE, CommentTypeCodeType.POSITIVE)
            .put(CommentTypeEnum.NEGATIVE, CommentTypeCodeType.NEGATIVE)
            .put(CommentTypeEnum.NEUTRAL, CommentTypeCodeType.NEUTRAL)
            .put(CommentTypeEnum.WITHDRAWN, CommentTypeCodeType.WITHDRAWN)
            .put(CommentTypeEnum.UNKNOWN, CommentTypeCodeType.POSITIVE) // Current Prod is assuming Positive when Unknown
            .build();

    private CommentTypeMapper() {
    }

    public static CommentTypeCodeType map(CommentTypeEnum commentTypeEnum) {
        return mapName.getOrDefault(commentTypeEnum, CommentTypeCodeType.CUSTOM_CODE);
    }
}
