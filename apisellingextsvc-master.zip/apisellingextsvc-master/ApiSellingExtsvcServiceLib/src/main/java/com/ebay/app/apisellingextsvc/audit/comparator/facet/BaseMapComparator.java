package com.ebay.app.apisellingextsvc.audit.comparator.facet;
import com.ebay.app.apisellingextsvc.audit.comparator.BaseFacetComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class BaseMapComparator extends BaseFacetComparator {
    protected BaseMapComparator(ExtensiveComparator comparator) {
        super(comparator);
    }

    public boolean compare(JsonNode org, JsonNode tar, String path, JsonNode pattern, String key, IReport report) {
        boolean res = true;
        Map<String, JsonNode> map = new HashMap(tar.size());

        int i;
        String entryKey;
        for(i = 0; i < tar.size(); ++i) {
            entryKey = this.getMapKey(tar.get(i));
            if(entryKey != null)
            map.put(entryKey, tar.get(i));
        }

        boolean same;
        for(i = 0; i < org.size(); ++i) {
            entryKey = this.getMapKey(org.get(i));
            JsonNode entryValue = org.get(i);
            if (map.containsKey(entryKey)) {
                if (entryValue == null) {
                    same = map.get(entryKey) == null;
                } else {
                    String tmpPath = path + "[" + i + "]";
                    same = this.compareNode(org.get(i), (JsonNode)map.get(entryKey), pattern.get(0), tmpPath, entryKey, report);
                }

                res = same && res;
                map.remove(entryKey);
            } else {
                String tempPath = path + "[*]";
                same = this.excludes(tempPath, entryKey);
                this.printDiff(key, tempPath, this.keyStr(entryKey), "missing", same, report);
                res = same && res;
            }
        }

        for(Iterator var14 = map.entrySet().iterator(); var14.hasNext(); res = same && res) {
            Map.Entry<String, JsonNode> entry = (Map.Entry)var14.next();
            String tempPath = path + "[*]";
            same = this.excludes(tempPath, (String)entry.getKey());
            this.printDiff(key, tempPath, "missing", this.keyStr((String)entry.getKey()), same, report);
        }

        return res;
    }

    protected abstract String getMapKey(JsonNode var1);

    private String keyStr(String key) {
        return "Key:" + key;
    }
}
