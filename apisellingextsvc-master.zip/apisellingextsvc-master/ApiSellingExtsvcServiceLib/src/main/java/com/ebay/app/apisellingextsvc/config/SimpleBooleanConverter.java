package com.ebay.app.apisellingextsvc.config;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SimpleBooleanConverter {

    private static final Set<String> trueStrings = new HashSet<>(Arrays.asList("yes", "y", "true", "on", "1"));
    private static final Set<String> falseStrings = new HashSet<>(Arrays.asList("no", "n", "false", "off", "0"));

    public static Boolean convert(String value) {
        if (trueStrings.contains(value)) {
            return true;
        }
        if (falseStrings.contains(value)) {
            return false;
        }
        return false;
    }
}