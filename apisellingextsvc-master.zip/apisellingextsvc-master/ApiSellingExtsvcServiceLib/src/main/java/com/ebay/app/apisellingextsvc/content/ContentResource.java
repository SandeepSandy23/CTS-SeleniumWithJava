package com.ebay.app.apisellingextsvc.content;

public class ContentResource {

    public IContentHelper contentHelper;

    public ContentResource(IContentHelper contentHelper) {
        this.contentHelper = contentHelper;
    }

    public ContentResource() {

    }

}
