package com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign;


import com.ebay.af.common.flag.FlagMask;
import com.ebay.integ.dal.DalDOI;
import com.ebay.persistence.HiddenLocal;
import com.ebay.persistence.HiddenLocals;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "SELLER_CAMPAIGN_%")
@com.ebay.persistence.Table(alias = "S")
@HiddenLocals({@HiddenLocal(attrName = "fromDate", defaultType = 4),
        @HiddenLocal(attrName = "toDate", defaultType = 4)})
public interface SellerDiscountCampaign extends DalDOI {
    int FLAG_FIELD = 0;
    FlagMask IS_STORE_REDIRECT = FlagMask.createFlagMask("IsStoreRedirect", 0, 1);
    FlagMask IS_VERSION2 = FlagMask.createFlagMask("IsVersion2", 0, 2);
    FlagMask IS_OFFER_NON_EDITABLE = FlagMask.createFlagMask("IsOfferNonEditable", 0, 4);

    @Id
    @Column(
            name = "SELLER_CAMPAIGN_ID"
    )
    long getSellerCampaignId();

    void setSellerCampaignId(long var1);

    @Column(
            name = "SELLER_ID"
    )
    long getSellerId();

    void setSellerId(long var1);

    @Column(
            name = "SITE_ID"
    )
    int getSiteId();

    void setSiteId(int var1);

    @Column(
            name = "CAMPAIGN_NAME"
    )
    String getCampaignName();

    void setCampaignName(String var1);

    @Column(
            name = "CAMPAIGN_TYPE"
    )
    int getCampaignType();

    void setCampaignType(int var1);

    @Column(
            name = "CAMPAIGN_SUB_TYPE"
    )
    int getCampaignSubType();

    void setCampaignSubType(int var1);

    @Column(
            name = "CAMPAIGN_DESC"
    )
    String getCampaignDesc();

    void setCampaignDesc(String var1);

    @Column(
            name = "CAMPAIGN_STATUS"
    )
    int getCampaignStatus();

    void setCampaignStatus(int var1);

    @Column(
            name = "BUDGET_AMOUNT"
    )
    double getBudgetAmount();

    void setBudgetAmount(double var1);

    @Column(
            name = "REDEEMED_AMOUNT"
    )
    double getRedeemedAmount();

    void setRedeemedAmount(double var1);

    @Column(
            name = "CURRENCY_CODE"
    )
    String getCurrencyCode();

    void setCurrencyCode(String var1);

    @Column(
            name = "MARKETING_PRIORITY"
    )
    int getMarketingPriority();

    void setMarketingPriority(int var1);

    @Column(
            name = "CAMPAIGN_FLAGS_01"
    )
    long getCampaignFlags01();

    void setCampaignFlags01(long var1);

    @Column(
            name = "START_DATE"
    )
    Date getStartDate();

    void setStartDate(Date var1);

    @Column(
            name = "END_DATE"
    )
    Date getEndDate();
}
