package com.ebay.app.apisellingextsvc.application.common.request;

import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.EnvironmentContext;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.enums.APITypeEnum;
import com.ebay.platform.raptor.cosadaptor.token.ISecureTokenManager;
import com.ebay.raptor.content.api.IContentBuilderFactory;
import ebay.apis.eblbasecomponents.GetMyeBaySellingRequestType;
import lombok.Getter;

import javax.ws.rs.core.HttpHeaders;
import java.util.Optional;
import java.util.concurrent.Executor;

@Getter
public class GetMyeBaySellingRequest extends BaseApplicationRequest {
    public final GetMyeBaySellingRequestType requestType;
    private final  ISecureTokenManager tokenManager;

    public GetMyeBaySellingRequest(GetMyeBaySellingRequestType requestType,
            HttpHeaders headers,
            User user,
            IContentBuilderFactory contentBuilderFactory,
            ApiSellingExtSvcConfigValues configValues,
            EnvironmentContext environmentContext, TracerContext tracerContext, Executor executor,
            ISecureTokenManager tokenManager) {
        super(headers, user, contentBuilderFactory, configValues, environmentContext, tracerContext, requestType);
        this.setExecutor(executor);
        this.requestType = requestType;
        this.tokenManager = tokenManager;

    }

    @Override
    public String getName() {
        return APITypeEnum.GetMyeBaySelling.name();
    }

    @Override
    public String getErrorLanguage() {
        return Optional.ofNullable(requestType).map(GetMyeBaySellingRequestType::getErrorLanguage).orElse(null);
    }

}

