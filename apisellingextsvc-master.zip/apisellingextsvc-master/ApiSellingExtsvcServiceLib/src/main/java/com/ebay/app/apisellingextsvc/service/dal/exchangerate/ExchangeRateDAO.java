package com.ebay.app.apisellingextsvc.service.dal.exchangerate;

import com.ebay.app.apisellingextsvc.service.dal.common.ReadSets;
import com.ebay.integ.dal.dao.CacheableDao;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.dao.ObjectNotFoundException;
import com.ebay.integ.dal.ddr.ConstantToupleProvider;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.integ.dal.map.MappingIncludesAttribute;
import com.ebay.integ.dal.map.Query;
import com.ebay.integ.dal.map.QueryEngine;
import com.ebay.integ.dal.map.ReadSet;
import com.ebay.integ.dal.map.SelectQuery;
import com.ebay.integ.dal.map.SelectStatement;

import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class ExchangeRateDAO extends CacheableDao {
    public static final String TABLE_ALIAS = "rate";
    public static final String TABLE_NAME = "EBAY_EXCHANGE_RATES";
    private static final MappingIncludesAttribute[] m_ourDDRHints = {};
    private static final String FIND_ALL = "FIND_ALL";
    private static volatile ExchangeRateDAO s_instance;
    private static boolean m_mapInitialized = false;
    private static GenericMap<ExchangeRate> exchangeRateMap;


    protected ExchangeRateDAO() {
        super(ExchangeRateKeyManager.getInstance(), "ExchangeRate", ExchangeRateCacheBean.getInstance());
        if (!m_mapInitialized) {
            initMap();
        }
    }

    public static ExchangeRateDAO getInstance() {
        if (s_instance == null) {
            synchronized (ExchangeRateDAO.class) {
                if (s_instance == null) {
                    s_instance = new ExchangeRateDAO();
                }
            }
        }
        return s_instance;
    }

    public static void initMap() {
        if (m_mapInitialized) {
            return;
        }
        GenericMap<ExchangeRate> map = GenericMap
              .getMap(ExchangeRate.class);
        if (map == null) {
            map = new GenericMap<>(ExchangeRate.class);
        }
        map.setDalVersion("3.0");
        m_mapInitialized = true;
        map.registerToupleProvider(new ConstantToupleProvider(
              TABLE_NAME, "lookuphost"));
        map.setQueries(getRawQueries());
        map.setReadSets(getReadSets());
        map.init();
        exchangeRateMap = map;

    }

    private static Query[] getRawQueries() {
        return new Query[] {
              new SelectQuery(
                    FIND_ALL,
                    m_ourDDRHints,
                    new SelectStatement[] {new SelectStatement(
                          ReadSets.FULL.getValue(),
                          "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE rate.day_of_rate >= :m_dayOfRate")}, -1
              )
        };
    }

    private static ReadSet[] getReadSets() {
        return new ReadSet[] {
              new ReadSet(ReadSets.FULL.getValue(), null)};
    }

    private static Date truncate(Date date) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date);
        Calendar cal2 = Calendar.getInstance();
        cal2.clear();
        cal2.set(cal1.get(Calendar.YEAR), cal1.get(Calendar.MONTH), cal1.get(Calendar.DATE));
        return cal2.getTime();
    }

    public List<ExchangeRate> findRateByDay(Date date) throws FinderException {
        QueryEngine qe = new QueryEngine();
        List<ExchangeRate> results = new LinkedList<>();
        ExchangeRateCodeGenDoImpl protoDO = new ExchangeRateCodeGenDoImpl();
        protoDO.setDayOfRate(truncate(date));
        protoDO.setReadOnlyHint(true);
        qe.readMultiple(results, exchangeRateMap, protoDO, FIND_ALL, ReadSets.FULL.getValue());
        return results;
    }


    public ExchangeRate findExchangeRateByCurrencyId(int currencyId) throws ObjectNotFoundException {
        ExchangeRateCodeGenDoImpl protoDO = new ExchangeRateCodeGenDoImpl();
        protoDO.setFromCurrency(currencyId);
        List<ExchangeRate> results = (List<ExchangeRate>) this.globalCacheFetchSingle(protoDO, ExchangeRateKeyManager.FROM_CURRENCY);
        return results.get(0);
    }
}
