package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.utils.LogisticUtil;
import com.ebay.cosmos.LineItemXType;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.DeliveryDetailsType;
import ebay.apis.eblbasecomponents.DigitalDeliverySelectedType;
import ebay.apis.eblbasecomponents.DigitalDeliveryUserType;
import org.apache.commons.lang3.ObjectUtils;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class DigitalDeliverSelectedBuilder extends BaseFacetBuilder<DigitalDeliverySelectedType> {

    private final List<LogisticsPlan> logistics;
    private final LineItemXType lineItem;
    private final int trxVersion;

    public DigitalDeliverSelectedBuilder(Task task, List<LogisticsPlan> logistics, LineItemXType lineItem,
                                         int trxVersion) {
        super(task);
        this.logistics = logistics;
        this.lineItem = lineItem;
        this.trxVersion = trxVersion;
    }

    private static DigitalDeliveryUserType getSenderUser(@Nonnull DeliveryOptionType digitalDeliveryPackage) {
        List<SenderType> sender = digitalDeliveryPackage.getSender();
        String name = Optional.ofNullable(sender).flatMap(senders -> senders.stream().findFirst())
                .map(SenderType::getDisplayName)
                .map(Code::getDisplayName).orElse(null);

        String email = Optional.ofNullable(sender)
                .flatMap(senders -> senders.stream().findFirst())
                .map(SenderType::getContactInformation)
                .map(ContactDetailsType::getEmail)
                .flatMap(emailTypes -> emailTypes.stream().findFirst())
                .map(emailType -> emailType.getAddress())
                .orElse(null);

        DigitalDeliveryUserType result = null;
        if (!ObjectUtils.allNull(name, email)) {
            result = new DigitalDeliveryUserType();
            result.setName(name);
            result.setEmail(email);
        }

        return result;
    }

    private static DigitalDeliveryUserType getRecipientUser(@Nonnull DeliveryOptionType digitalDeliveryPackage) {
        List<RecipientType> recipientTypes = digitalDeliveryPackage.getRecipient();
        String name = Optional.ofNullable(recipientTypes).flatMap(recipient -> recipient.stream().findFirst())
                .map(RecipientType::getDisplayName)
                .map(Code::getDisplayName).orElse(null);

        String email = Optional.ofNullable(recipientTypes)
                .flatMap(recipient -> recipient.stream().findFirst())
                .map(RecipientType::getContactInformation)
                .map(ContactDetailsType::getEmail)
                .flatMap(emailTypes -> emailTypes.stream().findFirst())
                .map(EmailType::getAddress)
                .orElse(null);

        DigitalDeliveryUserType result = null;
        if (!ObjectUtils.allNull(name, email)) {
            result = new DigitalDeliveryUserType();
            result.setName(name);
            result.setEmail(email);
        }

        return result;
    }

    /**
     * package may has multi lineItem, use sourceId to find target item-transaction.
     *
     * @param logistics
     * @param sourceId
     * @return
     */
    private static DeliveryOptionType findDigitalDeliveryPackage(LogisticsPlan logistics, LineItemSource sourceId) {
        List<PackageType> packages = Optional.ofNullable(logistics.getSteps())
                .flatMap(steps -> steps.stream().findFirst())
                .map(step -> step.getStepExtension())
                .map(stepExtension -> stepExtension.getDigitalDeliveryStep())
                .map(digitalDeliveryStepExtension -> digitalDeliveryStepExtension.getPackage())
                .orElse(Collections.emptyList());

        DeliveryOptionType deliveryOptionType = packages.stream()
                .filter(packageType -> packageType.getPackageContents().getPackageLineItemId()
                        .stream().anyMatch(lineItemSource -> lineItemSource.getItemId().equals(sourceId.getItemId())
                                && lineItemSource.getTransactionId().equals(sourceId.getTransactionId())))
                .map(PackageType::getDeliveryOption)
                .findFirst()
                .orElse(null);
        return deliveryOptionType;
    }

    @Override
    protected DigitalDeliverySelectedType doBuild() {
        DigitalDeliverySelectedType result = null;

        if (trxVersion >= VersionConstant.VERSION_DIGITAL_DELIVERY) {
            Optional<LogisticsPlan> digitalDeliveryPlan = LogisticUtil.getDigitalDeliveryPlan(logistics);
            //flag to check if this is digital delivery
            if (digitalDeliveryPlan.isPresent()) {
                LogisticsPlan logisticsPlan = digitalDeliveryPlan.get();
                DeliveryOptionType digitalDeliveryPackage = findDigitalDeliveryPackage(logisticsPlan, lineItem.getSourceId());
                if (digitalDeliveryPackage != null) {
                    //build sender recipient
                    DigitalDeliveryUserType sender = getSenderUser(digitalDeliveryPackage);
                    DigitalDeliveryUserType recipient = getRecipientUser(digitalDeliveryPackage);
                    //check if all null, do not populate element
                    if (!ObjectUtils.allNull(sender, recipient)) {
                        //build detail
                        DeliveryDetailsType details = new DeliveryDetailsType();
                        details.setRecipient(recipient);
                        details.setSender(sender);//build result
                        result = new DigitalDeliverySelectedType();
                        result.setDeliveryDetails(details);
                        result.setDeliveryMethod(ApiSellingExtSvcConstants.Email);
                    }
                }
            }
        }

        return result;
    }
}
