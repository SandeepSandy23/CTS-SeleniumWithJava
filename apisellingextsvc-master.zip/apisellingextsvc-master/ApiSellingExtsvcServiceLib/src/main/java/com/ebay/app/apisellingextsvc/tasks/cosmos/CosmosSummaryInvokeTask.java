package com.ebay.app.apisellingextsvc.tasks.cosmos;

import com.ebay.app.apisellingextsvc.context.FindContractV2RequestContext;
import com.ebay.app.apisellingextsvc.service.client.model.CosmosRequest;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.cosmos.SummaryResponse;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;

import java.util.List;

public class CosmosSummaryInvokeTask implements Task<SummaryResponse>, ITaskResultInjectable {

    private CosmosRequest cosmosRequest;
    private final IServiceInvoker<FindContractV2RequestContext, SummaryResponse> cosmosInvoker;
    private final List<ErrorType> errorList;

    public CosmosSummaryInvokeTask(
            IServiceInvoker<FindContractV2RequestContext, SummaryResponse> cosmosInvoker,
            List<ErrorType> errorList) {
        this.cosmosInvoker = cosmosInvoker;
        this.errorList = errorList;
    }

    @Override
    public SummaryResponse call() {
        return this.cosmosInvoker.getResponse(buildCtx(), cosmosRequest.getHeaders());
    }


    private FindContractV2RequestContext buildCtx() {
        return FindContractV2RequestContext.createGetRequestContext(cosmosRequest.getQueryStr(),
                cosmosRequest.getHeaders());
    }

    @Override
    public void addResult(Object result) {
        this.cosmosRequest = (CosmosRequest) result;
    }
}