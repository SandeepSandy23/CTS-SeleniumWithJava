package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.ListingTypeCodeType;

public class ListingTypeMapper {

    private static final ImmutableMap<String, ListingTypeCodeType> mapName
            = new ImmutableMap.Builder<String, ListingTypeCodeType>()
            .put(ApiSellingExtSvcConstants.ITEM_LISTING_TYPE_FIXED_PRICE, ListingTypeCodeType.FIXED_PRICE_ITEM)
            .put(ApiSellingExtSvcConstants.ITEM_LISTING_TYPE_AUCTION, ListingTypeCodeType.CHINESE)
            .put(ApiSellingExtSvcConstants.ITEM_LISTING_SECOND_CHANCE_OFFER, ListingTypeCodeType.PERSONAL_OFFER)
            .put(ApiSellingExtSvcConstants.CLASSIFIED_AD, ListingTypeCodeType.AD_TYPE)
            .put(ApiSellingExtSvcConstants.ITEM_LISTING_TYPE_CHINESE_AUCTION, ListingTypeCodeType.CHINESE)
            .put(ApiSellingExtSvcConstants.LEAD_GENERATION, ListingTypeCodeType.LEAD_GENERATION)
            .put(ApiSellingExtSvcConstants.STORES_FIXED_PRICE, ListingTypeCodeType.STORES_FIXED_PRICE)
            .put(ApiSellingExtSvcConstants.PERSONAL_OFFER, ListingTypeCodeType.PERSONAL_OFFER)
            .put(ApiSellingExtSvcConstants.CUSTOM_CODE, ListingTypeCodeType.CUSTOM_CODE)
            .build();

    private ListingTypeMapper() {

    }

    public static ListingTypeCodeType map(String input) {
        return mapName.getOrDefault(input, ListingTypeCodeType.UNKNOWN);
    }
}
