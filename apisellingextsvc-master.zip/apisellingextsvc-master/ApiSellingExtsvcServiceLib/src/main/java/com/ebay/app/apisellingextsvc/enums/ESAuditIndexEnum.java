package com.ebay.app.apisellingextsvc.enums;

public enum ESAuditIndexEnum {
    GET_SELLER_TRANSACTIONS_MODIFIED_DATE("apisellingextsvc_audit_log_get_seller_transactions_by_modify_date/_doc"),
    GET_MYEBAY_SELLING("apisellingextsvc_audit_log_get_myebay_selling_2/_doc");
    private final String indexKey;

    ESAuditIndexEnum(String indexKey) {
        this.indexKey = indexKey;
    }

    public String getIndexName() {
        return indexKey;
    }
}
