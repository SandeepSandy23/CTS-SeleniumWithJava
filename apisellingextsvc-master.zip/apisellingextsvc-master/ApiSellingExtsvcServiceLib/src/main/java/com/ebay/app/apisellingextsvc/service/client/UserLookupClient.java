package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.app.apisellingextsvc.service.client.model.UserIdLookupResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserLookupClient extends BaseGingerClient<String, UserIdLookupResponse> {

    private static final Logger logger = LoggerFactory.getLogger(UserLookupClient.class);
    private static final String CLIENT_ID = "userinfo.lookupInternalId";

    public UserLookupClient() {
        super(UserIdLookupResponse.class);
    }

    @Override
    public GingerClientResponse<UserIdLookupResponse> getGingerResponse(GingerClientRequest<String> gingerRequest) {
        return processGetRequest(gingerRequest.getRequest());
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
