package com.ebay.app.apisellingextsvc.service.bof.shippingservice;

import com.ebay.app.apisellingextsvc.service.dal.shippingservice.ShippingServiceDoMock;

import java.util.List;

public class ShippingServiceListMock {

    private List<ShippingServiceDoMock> shippingServiceDoMockList;

    public List<ShippingServiceDoMock> getShippingServiceDoMockList() {
        return shippingServiceDoMockList;
    }

    public void setShippingServiceDoMockList(List<ShippingServiceDoMock> shippingServiceDoMockList) {
        this.shippingServiceDoMockList = shippingServiceDoMockList;
    }
}
