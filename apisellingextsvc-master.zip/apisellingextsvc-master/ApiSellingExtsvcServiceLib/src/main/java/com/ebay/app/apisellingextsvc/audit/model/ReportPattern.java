package com.ebay.app.apisellingextsvc.audit.model;

import com.ebay.app.apisellingextsvc.common.helper.FileHelper;
import com.ebay.app.apisellingextsvc.common.logger.DummyLogger;
import com.ebay.app.apisellingextsvc.common.logger.ILogger;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public class ReportPattern {

        private static final String OTHERS = "Others";
        private static final ConcurrentHashMap<String, ReportPattern> cache = new ConcurrentHashMap();
        private LinkedHashMap<String, Pattern> map = new LinkedHashMap();

        private ReportPattern() {
        }

        public static ReportPattern create(String path) {
        return create(path, DummyLogger.getInstance());
    }

        public static ReportPattern create(String path, ILogger logger) {
        if (cache.containsKey(path)) {
            return (ReportPattern)cache.get(path);
        } else {
            ReportPattern reportPattern = new ReportPattern();
            InputStream is = FileHelper.readResourceFileAsStream(path);
            if (is != null) {
                try {
                    BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
                    Throwable var5 = null;

                    try {
                        String line;
                        while((line = br.readLine()) != null) {
                            if (!line.trim().isEmpty()) {
                                String[] lineArr = line.split(",");
                                if (lineArr.length < 2) {
                                    logger.error("Bad pattern definition: " + line);
                                } else {
                                    reportPattern.addGroupPattern(lineArr[0], Pattern.compile(lineArr[1]));
                                }
                            }
                        }

                        cache.put(path, reportPattern);
                    } catch (Throwable var16) {
                        var5 = var16;
                        throw var16;
                    } finally {
                        if (br != null) {
                            if (var5 != null) {
                                try {
                                    br.close();
                                } catch (Throwable var15) {
                                    var5.addSuppressed(var15);
                                }
                            } else {
                                br.close();
                            }
                        }

                    }
                } catch (Exception var18) {
                    logger.error("Error loading report pattern: " + path, var18);
                }
            } else {
                logger.error("Could not find report pattern: " + path);
            }

            return reportPattern;
        }
    }

        public String getMatchName(String path) {
        Iterator var2 = this.map.entrySet().iterator();

        Map.Entry entry;
        do {
            if (!var2.hasNext()) {
                return "Others";
            }

            entry = (Map.Entry)var2.next();
        } while(!((Pattern)entry.getValue()).matcher(path).matches());

        return (String)entry.getKey();
    }

        private void addGroupPattern(String nameKey, Pattern pattern) {
        this.map.put(nameKey, pattern);
    }
    }

