package com.ebay.app.apisellingextsvc.tasks.models;

import java.util.HashMap;
import java.util.Map;

public class UserAddressPhoneModel {
    private Map<String, Boolean> userPhoneIdMap;

    public Map<String, Boolean> getSellerProdId() {
        if (userPhoneIdMap == null) {
            return new HashMap<>();
        }
        return userPhoneIdMap;
    }

    public void setSellerProdId(Map<String, Boolean> userPhoneIdMap) {
        this.userPhoneIdMap = userPhoneIdMap;
    }
}

