package com.ebay.app.apisellingextsvc.builders.proforma;

import com.ebay.app.apisellingextsvc.builders.BaseOrderTypeBuilder;
import com.ebay.app.apisellingextsvc.builders.EbayCollectAndRemitTaxBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.UserUtil;
import com.ebay.cosmos.*;
import com.ebay.cosmos.typeenum.ContractTypeEnum;
import com.ebay.order.common.v1.EntityTotal;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AddressType;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.OrderStatusCodeType;
import ebay.apis.eblbasecomponents.OrderType;

import java.util.Optional;

public class ProformaOrderBuilder extends BaseOrderTypeBuilder {


    private final ProformaOrderXType proformaOrder;


    public ProformaOrderBuilder(Task<?> task, ContractResponseType contractResponse,
                                int trxVersion, ApiSellingExtSvcConfigValues configValues) {
        super(task, trxVersion, configValues, contractResponse);
        this.proformaOrder = contractResponse.getProformaOrder();
    }

    @Override
    protected OrderType doBuild() {
        OrderType orderType = new OrderType();
        orderType.setOrderID(getOrderID());
        orderType.setAmountSaved(getAmountSaved());
        orderType.setOrderStatus(getOrderStatusCodeType());
        orderType.setCreatedTime(DateUtil.convertToXMLGregorianCalendar(proformaOrder.getCreationDate()));
        orderType.setAmountPaid(AmountTypeUtil.getDefaultZeroAmountType(proformaOrder));
        orderType.setAdjustmentAmount(AmountTypeUtil.getDefaultZeroAmountType(proformaOrder));
        orderType.setEIASToken(getEiasToken(proformaOrder.getBuyerCS()));
        orderType.setSellerEIASToken(getSellerEiasToken(proformaOrder.getSellerCS()));
        orderType.setCancelStatus(getCancelStatus(proformaOrder.getOrderStates()));
        orderType.setBuyerUserID(UserUtil.getUserName(proformaOrder.getBuyerCS()));
        orderType.setSellerUserID(getSellerUserId());
        orderType.setShippingAddress(getShippingAddress());
//        orderType.setTransactionArray(new ProformaOrderTransactionArrayBuilder(task, contractResponse, trxVersion,
//                apiTypeEnum, configValues)
//                .build());
        orderType.setContainseBayPlusTransaction(isContainseBayPlusTransaction(orderType.getTransactionArray()));
//        orderType.setCheckoutStatus(new ProformaOrderCheckoutStatusBuilder(task, proformaOrder).build());
        orderType.setEBayCollectAndRemitTax(new EbayCollectAndRemitTaxBuilder(task, proformaOrder.getAttributes(), trxVersion).build());
        orderType.setTotal(getTotal(Optional.ofNullable(
                proformaOrder.getOrderTotalSummary()).map(OrderTotal::getRunningTotal).orElse(null), proformaOrder.getPayments()));
        orderType.setSubtotal(getSubtotal(proformaOrder.getOrderTotal().getPriceLines()));
        return orderType;
    }

    private OrderStatusCodeType getOrderStatusCodeType() {
        OrderStateTypeCS orderStateTypeCS = proformaOrder.getOrderStates();
        return getOrderStatusCodeType(orderStateTypeCS);
    }

    private String getOrderID() {
        return Optional.ofNullable(contractResponse.getIdentifier())
                .map(ContractIdentifier::getPublicContractId)
                .orElse(null);
    }


    private AmountType getAmountSaved() {
        EntityTotal orderTotal = proformaOrder.getOrderTotal();
        OrderTotal orderTotalSummary = proformaOrder.getOrderTotalSummary();
        return getAmountSaved(orderTotal, orderTotalSummary);
    }

    private AddressType getShippingAddress() {
        if (ContractTypeEnum.COMMITMENT.equals(contractResponse.getContractType())) {
            return getEmptyShippingAddress();
        }

        //todo invoice need another datasource to complete address
        if (ContractTypeEnum.INVOICE.equals(contractResponse.getContractType())) {
            return null;
        }
        return null;
    }

    private String getSellerUserId() {

        if (trxVersion >= ApiSellingExtSvcConstants.COMPATIBILITY_LEVEL_839) {
            return UserUtil.getUserName(proformaOrder.getSellerCS());
        }

        return null;
    }

    /**
     * commitment didn't have a ship address. here use a response consist of empty strings.
     *
     * @return
     * @<code> <ShippingAddress>
     * <Name></Name>
     * <Street1></Street1>
     * <Street2></Street2>
     * <CityName></CityName>
     * <StateOrProvince></StateOrProvince>
     * <CountryName></CountryName>
     * <Phone></Phone>
     * <PostalCode></PostalCode>
     * </ShippingAddress>
     * </code>
     */
    private AddressType getEmptyShippingAddress() {
        AddressType emptyAddress = new AddressType();
        emptyAddress.setName("");
        emptyAddress.setStreet1("");
        emptyAddress.setCityName("");
        emptyAddress.setStateOrProvince("");
        emptyAddress.setCountryName("");
        emptyAddress.setPhone("");
        emptyAddress.setPostalCode("");
        return emptyAddress;
    }
}
