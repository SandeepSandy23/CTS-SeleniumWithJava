package com.ebay.app.apisellingextsvc.content;

import com.ebay.content.runtime.ContentInitializer;
import com.ebay.content.runtime.impl.ContentBuilderFactoryImpl;

import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;

public class ContentTestUtil {
    public static void initializeContentSource() {
        Enumeration<URL> sources;
        try {
            sources = ClassLoader.getSystemClassLoader().getResources("v4contentsource/");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        ContentInitializer.initialize(sources);
    }

    /**
     * content could have memory leak when multi thread initialization
     *
     * @see com.ebay.content.runtime.ContentInitializer#initialize(ClassLoader classloader)
     */
    public static IContentHelper createContentHelper(int siteId) {
        return new ContentHelper(new ContentBuilderFactoryImpl(), siteId, siteId, 3000L, 10);
    }
}
