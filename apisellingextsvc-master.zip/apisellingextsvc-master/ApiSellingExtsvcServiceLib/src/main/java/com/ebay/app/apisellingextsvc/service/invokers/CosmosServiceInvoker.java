package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.FindContractV2RequestContext;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.CosmosClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.cosmos.ContractResponse;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class CosmosServiceInvoker extends BaseServiceInvoker<FindContractV2RequestContext, ContractResponse, FindContractV2RequestContext> {

    // use for mock
    public static final String NAME = "CosmosServiceInvoker";

    public CosmosServiceInvoker(TracerContext tracerContext) {
        super(NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<FindContractV2RequestContext, ContractResponse> getGingerClient(
            FindContractV2RequestContext findContractV2RequestContext) {
        return new CosmosClient();
    }

    @Override
    protected GingerClientRequest<FindContractV2RequestContext> getGingerRequest(FindContractV2RequestContext findContractV2RequestContext,
                                                                                 HttpHeaders httpHeaders) {
        GingerClientRequest<FindContractV2RequestContext> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(findContractV2RequestContext);
        return gingerClientRequest;
    }

}
