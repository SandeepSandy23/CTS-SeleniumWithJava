package com.ebay.app.apisellingextsvc.enums;

public enum UserType {
    BUYER,
    SELLER,
    OTHER
}
