package com.ebay.app.apisellingextsvc.builders;

import com.ebay.cos.type.v3.base.CurrencyCodeEnum;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.DistributionType;
import com.ebay.order.common.v1.EntityTotal;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.common.collect.Lists;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.utils.AdjustmentHelper;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.AmountUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import ebay.apis.eblbasecomponents.AmountType;
import org.apache.commons.lang3.ObjectUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

public class LegacyOrderTotalBuilder extends BaseFacetBuilder<AmountType> {
    private final OrderCSXType order;

    public LegacyOrderTotalBuilder(Task task, OrderCSXType order) {
        super(task);
        this.order = order;
    }

    /**
     * coms seller running total = seller distribution - refunded seller collection
     * <p>
     * apixoio total = seller distribution - refunded seller collection + ebay_seller_fee - refunded ebay_seller_fee + shipping_partner
     */
    @Override
    protected AmountType doBuild() {
        Amount seller = PaymentUtil.getPaymentDistribution(order.getPayments(), ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_SELLER)
                .map(DistributionType::getTotalAmount).map(EntityTotal::getAmount).orElse(null);

        Amount ebaySellerFee = PaymentUtil.getPaymentDistribution(order.getPayments(),
                        ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_EBAY_SELLER_FEE)
                .map(DistributionType::getTotalAmount).map(EntityTotal::getAmount).orElse(null);

        Amount taxFee = PaymentUtil.getPaymentDistribution(order.getPayments(), ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_TAX_PARTNER)
                .map(DistributionType::getPriceLines)
                .flatMap(priceLines -> priceLines.stream().filter(priceLine -> PricelineTypeEnum.TAX_FEE == priceLine.getType())
                        .map(PriceLine::getAmount).findFirst()).orElse(null);
        List<Amount> shippingPartners = PaymentUtil.getPaymentDistributionList(order.getPayments(),
                        ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_SHIPPING_PARTNER).stream()
                .map(DistributionType::getTotalAmount).filter(Objects::nonNull)
                .map(EntityTotal::getAmount).filter(Objects::nonNull).collect(Collectors.toList());
        CurrencyCodeEnum currencyCodeEnum = Optional.ofNullable(seller).map(amount ->
                ObjectUtils.defaultIfNull(amount.getConvertedFromCurrency(), amount.getCurrency())).orElse(CurrencyCodeEnum.USD);

        List<Amount> refundEbaySellerFee =
                AdjustmentHelper.getCollection(order.getAdjustmentsCS(), ApiSellingExtSvcConstants.COLLECTION_TYPE_EBAY_SELLER_FEE);
        List<Amount> refundSeller =
                AdjustmentHelper.getCollection(order.getAdjustmentsCS(), ApiSellingExtSvcConstants.COLLECTION_TYPE_SELLER);
        List<Amount> refundTaxFee =
                AdjustmentHelper.getRefundedPriceLine(order.getAdjustmentsCS(), PricelineTypeEnum.TAX_FEE);
        BigDecimal fmmAmount = AmountUtil.sum(shippingPartners, Lists.newArrayList(seller, ebaySellerFee, taxFee));
        BigDecimal rmmAmount = AmountUtil.sum(refundEbaySellerFee, refundSeller, refundTaxFee);
        return AmountTypeUtil.getAmountType(currencyCodeEnum.name(),
                fmmAmount.subtract(rmmAmount).setScale(ApiSellingExtSvcConstants.SCALE_OF_DECIMAL, RoundingMode.HALF_UP).doubleValue());
    }
}
