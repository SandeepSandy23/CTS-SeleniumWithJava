package com.ebay.app.apisellingextsvc.config;

import java.util.List;

public interface IConfigProvider {
    <V> V getProperty(String var1, Class<V> var2, IConfigProviderContext var3) throws Exception;

    <V> List<V> getPropertyList(String var1, Class<V> var2, IConfigProviderContext var3) throws Exception;

}