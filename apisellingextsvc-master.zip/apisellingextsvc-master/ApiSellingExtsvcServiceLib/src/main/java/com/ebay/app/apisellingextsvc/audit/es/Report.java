package com.ebay.app.apisellingextsvc.audit.es;

import java.util.Map;

public class Report {

    private Request request;
    private Map<String, GroupMismatch> result;
    private Response response;

    public Request getRequest() {
        return request;
    }

    public void setRequest(Request request) {
        this.request = request;
    }

    public Map<String, GroupMismatch> getResult() {
        return result;
    }

    public void setResult(Map<String, GroupMismatch> result) {
        this.result = result;
    }

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }
}