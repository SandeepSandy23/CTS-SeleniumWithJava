package com.ebay.app.apisellingextsvc.common.constant;

import com.google.common.collect.ImmutableSet;

import java.math.BigDecimal;
import java.util.Set;

public final class ApiSellingExtSvcConstants {

    //Common chars
    public static final char HYPHEN = '-';
    public static final char SPACE = ' ';
    public static final char COLON = ':';
    public static final char COMMA = ',';
    public static final char BRACKET_LEFT = '[';
    public static final char BRACKET_RIGHT = ']';
    public static final char DOT = '.';

    //URL
    public static final String WWW = "www";
    public static final String SINGLE_SLASH = "/";

    public static final char VERTICAL_LINE = '|';

    //Store url constant
    public static final String STORE = "str";
    // Regex
    public static final String REG_DOT = "\\.";
    // redirection
    public static final String DATAFLOW = "dataflow";
    public static final String DATAFLOW_API_SELLINGIO = "apisellingio";
    //Scale of decimal
    public static final int SCALE_OF_DECIMAL = 2;
    //Item url constant
    public static final String ITM = "itm";
    public static final String ITEM = "item";

    //QueryParam
    public static final char QUERY_PARAM_QUESTION = '?';
    public static final String QUERY_PARAM_USERID = "userid";
    public static final char QUERY_PARAM_EQUALS = '=';
    public static final String QUERY_PARAM_AND = "&";
    public static final String QUERY_PARAM_FILTER = "filter";
    public static final String QUERY_PARAM_COMMA = ",";

    public static final String ITEM_PAGINATION = "paginationMode=lineItem";

    public static final char QUERY_PARAM_COLON = COLON;
    public static final String QUERY_PARAM_CREATION_DATE = "creationdate";
    public static final String QUERY_PARAM_LAST_MODIFIED_DATE = "lastmodifieddate";

    public static final String QUERY_PARAM_KEYS = "keys";
    public static final String QUERY_PARAM_USER_TYPE = "userType";
    public static final String QUERY_PARAM_LIMIT = "limit";
    public static final String QUERY_PARAM_OFFSET = "offset";
    public static final String QUERY_PARAM_PUID = "puid";
    public static final String QUERY_PARAM_Q = "q";
    public static final char QUERY_PARAM_Q_CHAR = 'q';
    public static final String QUERY_PARAM_SORT = "sort";
    public static final String QUERY_PARAM_FIELDS = "fields";
    public static final String QUERY_PARAM_Q_FIELD = "q_field";
    public static final String QUERY_PARAM_Q_OPERATOR = "q_operator";
    public static final String QUERY_PARAM_Q_VALUE = "q_value";
    public static final String LISTING_ID = "listing_id";
    public static final String EQUALS = "equals";
    public static final String QUERY_PARAM_FIELDGROUP = "fieldgroups";
    public static final String QUERY_PARAM_USECASE = "usecase";
    public static final String QUERY_PARAM_BEST_OFFER_DETAILS = "bestOfferDetails";
    public static final String GET_MYEBAY_SELLING = "GET_MYEBAY_SELLING";
    public static final String COMMAND = "cmd";
    public static final String VIEW_ITEM = "ViewItem";
    public static final String CGI = "cgi";
    // LAS
    public static final String QUERY_PARAM_COMPLETE_LISTING_COMPLETE_NOTES = "COMPLETE_LISTING,COMPLETE_NOTES";
    public static final String QUERY_PARAM_COMPLETE_LISTING = "COMPLETE_LISTING";
    public static final String QUERY_PARAM_MIN_VARIATION_INFO = "minVariationInfo";
    public static final String QUERY_PARAM_SELLER_TYPE = "sellertype";
    public static final String QUERY_PARAM_SELLER_TYPE_VALUE = "b";
    public static final String QUERY_PARAM_Q_SUMMARY = "q_summary";
    public static final String ACTUAL_END_DATE = "actualEndDate";
    public static final String LISTING_ACTIVE = "ACTIVE";
    public static final String LISTING_SCHEDULED = "SCHEDULED";
    public static final String LISTING_UNSOLD = "UNSOLD";
    public static final String LISTING_DELETED_UNSOLD = "DELETED";
    public static final String CATEGORY = "category";

    public static final Long REAL_ESTATE_CATEGORY_ID = 10542L;

    public static final String QUERY_PARAM_VARIATION_PRICE = "variationPrice";
    public static final String TRUE_VALUE = "true";
    public static final String ACTIONS = "actions";
    public static final String FILTER_VISIBILITY = "visibility";
    public static final String FILTER_FUNDING_STATUS = "fundingStatus";
    public static final String FILTER_SHIPMENT_STATUS = "shipmentStatus";
    public static final String EXCLUDE_ALL_VALID_RETURNS = "excludeAllValidReturns";
    public static final String EXCLUDE_ALL_VALID_CANCELLATIONS = "excludeAllValidCancellations";
    public static final String EXCLUDE_ALL_VALID_INQUIRIES = "excludeAllValidInquiries";
    public static final String INCLUDE_ALL_VALID_RETURNS = "includeAllValidReturns";
    public static final String INCLUDE_ALL_VALID_CANCELLATIONS = "includeAllValidCancellations";
    public static final String INCLUDE_ALL_VALID_INQUIRIES = "includeAllValidInquiries";
    public static final String QUERY_PARAM_VISIBILITY = "visibility";
    public static final String VISIBILITY_ACTIVE = "active";
    public static final String VISIBILITY_HIDDEN = "hidden";
    public static final String VISIBILITY_ALL = "all";
    public static final String FILTER_ORDER_STATE = "orderstate";
    public static final String ORDER_STATE_FAILED = "failed";
    public static final String ORDER_STATE_INITIALIZED = "initialized";

    public static final String QUERY_PARAM_USER_TYPE_BUYER = "BUYER";
    public static final String QUERY_PARAM_USER_TYPE_SELLER = "SELLER";
    public static final String QUERY_PARAM_USER_TYPE_SH_SELLER = "SHSELLER";
    public static final String QUERY_PARAM_FUND_STATUS = "fundstatus";
    public static final String QUERY_PARAM_PAGINATION_MODE = "paginationMode";
    public static final String QUERY_PARAM_ADDRESS = "address";
    public static final String LINE_ITEM = "lineItem";

    //USER_TYPE
    public static final String DUMMY_USER_ID_WHITELIST_CASE = "0";
    public static final String ZERO_STRING = "0";

    //GingerConfig
    public static final String GINGER_COMS = "";


    //ASYNC Task timeout
    public static final long TIMEOUT = 30000;
    public static final long APIXOIO_TIMEOUT = 60000;

    //OrderResponse paymentFromAccount Domain
    public static final String EBAY_DOMAIN = "EBAY";
    //OrderResponse paymentFromAccount IdPrefix
    public static final String IDENTIFIER_ACCOUNTID_PREFIX = "accountId:";

    // order level attribute
    public static final String ATTR_TAX_ENGINE_USED = "taxEngineUsed";
    public static final String TAX_NUMBER = "taxNumber";
    public static final String UNSUPPORTED_CURRENCY_PAYMENT = "UNSUPPORTED_CURRENCY_PAYMENT";
    public static final String UNILATERAL_PAYMENT = "UNILATERAL_PAYMENT";
    public static final String IS_PAYMENT_EBAY_INTERMEDIATED = "isPaymenteBayIntermediated";
    public static final String ATTR_CUID_ENABLED = "cuidEnabled";
    public static final String ATTR_LEGACY_ID = "legacyId";
    public static final String ATTR_CHECKOUT_SITE_ID = "checkoutSiteId";
    public static final String ATTR_TAX_COLLECT_TYPE = "taxCollectType";

    public static final String ATTR_TAX_TYPE = "taxType";
    public static final String ATTR_TAX_STATE = "taxState";
    public static final String ATTR_SELLER_DISTRIBUTION_TYPE = "sellerDistributionType";
    public static final String ATTR_FUNDING_SOURCE = "paymentOrFundingSource";
    public static final String ATTR_REASON = "reason";
    public static final String AU_GST_ENGINE = "AU_GST_ENGINE";
    public static final String EBAY_TAX_ENGINE = "EBAY_TAX_ENGINE";
    public static final String GST = "GST";
    public static final String CUSTOM = "Custom";
    public static final String TAX_TYPE_VAT = "VAT";
    public static final String TAX_TYPE_IMPORT_VAT = "IMPORT_VAT";
    public static final String TAX_TYPE_SALES_TAX = "SALES_TAX";
    public static final String EVTN = "EVTN";
    public static final String IMPORT_CHARGES = "IMPORT_CHARGES";
    public static final String INTL_LEG_COST = "INTERNATIONAL_LEG_COST";
    public static final String HAS_TAX_PARTNER = "hasTaxPartner";
    public static final String HAS_BUYER_NOTE_TO_SELLER = "hasBuyerNoteToSeller";
    public static final String ATTR_BRAND_NAME = "BRAND_NAME";
    public static final String ATTR_COLLECTED_TAX_PAID_STATUS = "CollectedTaxPaidStatus";
    public static final String ATTR_TAX_SUBTYPE = "taxSubType";
    public static final String ATTR_IS_MARKED_AS_PAID = "isMarkedAsPaid";
    public static final String ATTR_IS_MARKED_AS_SENT = "isMarkedAsSent";
    public static final String ATTR_IS_INFLIGHT_ORDER = "isInflightOrder";
    public static final String ATTR_EBAY_TAX_IDENTITY = "eBayTaxIdentity";
    public static final String ATTRIBUTE_PSEUDO_PURCHASE_ORDER_ID = "PSEUDO_PURCHASE_ORDER_ID";
    public static final String ATTRIBUTE_ORDER_ID = "ORDER_ID";

    public static final String ATTR_SELLER_ACCOUNT_FUND_STATUS = "sellerAccountFundStatus";
    public static final String ATTR_SELLER_ACCOUNT_FUND_ESTIMATE_DATE = "sellerAccountFundEstimateDate";
    public static final String ATTR_EBAY_LOCATION_ID = "ebayLocationId";
    public static final String ATTR_CONTRACT_ID = "CONTRACT_ID";
    public static final String ATTR_SALES_RECORD_NUMBER = "salesRecordNumber";
    public static final String ATTR_BEST_OFFER_ID = "bestOfferId";
    public static final String ATTR_SELLER_PRODUCT_ID = "SELLER_PRODUCT_ID";
    public static final String ATTR_SALE_TYPE = "SALE_TYPE";

    public static final String VAL_TAX_INCLUDED = "TAX_INCLUDED";
    public static final String VAL_TAX_EXCLUDED = "TAX_EXCLUDED";
    public static final String INVOICE_TO_SELLER = "INVOICE_TO_SELLER";

    // lineitem level attribute
    public static final String ATTR_COMS_COMMITMENT_TIME = "COMMITMENT_TIME";
    public static final String COMS_LISTING_SITE_ID = "LISTING_SITE_ID";
    public static final String COMS_TRANS_SITE_ID = "TRANSACTION_SITE_ID";
    public static final String PRIMARY_CATEGORY = "primaryCategory";

    public static final String LISTING_SITE_ID = "listingSiteID";
    public static final String ATTR_TRANS_SITE_ID = "transactionSiteID";
    public static final String COMS_SKU = "SKU";
    public static final String COMS_GUARANTEED_DELIVERY = "GUARANTEED_DELIVERY";
    public static final String COMS_VERSION = "version";
    public static final String COMS_VARIATION_SPECIFICS = "VARIATION_SPECIFICS";
    public static final String INSURANCE_OPTION = "insuranceOption";
    public static final String ITEM_AUTO_VEHICLE = "itemAutoVehicle";
    public static final String RETURN_ACCEPTED = "returnAccepted";
    public static final String CHARITY_SALE = "charitySale";
    public static final String PRIVATE_SALE = "privateSale";
    public static final String RETURN_CATEGORY_FLAG_ENABLED = "returnCategoryFlagEnabled";
    public static final String REVIEW_DISABLED = "reviewDisabled";
    public static final String ITEM_CONDITION_ID = "ITEM_CONDITION_ID";
    public static final String ITEM_CONDITION = "ITEM_CONDITION";
    public static final String ITEM_LOCATION = "ITEM_LOCATION";
    public static final String ITEM_LOCATION_POSTAL_CODE = "PostalCode";
    public static final String ITEM_LISTING_TYPE_FIXED_PRICE = "FIXED_PRICE";
    public static final String ITEM_LISTING_TYPE_AUCTION = "AUCTION";
    public static final String ITEM_LISTING_SECOND_CHANCE_OFFER = "SECOND_CHANCE_OFFER";
    public static final String ITEM_LISTING_TYPE_CHINESE_AUCTION = "CHINESE_AUCTION";
    public static final String CLASSIFIED_AD = "CLASSIFIED_AD";
    public static final String BUYER_PROTECTION_ELIGIBLE = "BUYER_PROTECTION_ELIGIBLE";

    public static final String LISTING_URL = "listingUrl";
    // payment attributes
    public static final String ATTRIBUTE_PAYMENT_HOLD_TYPE = "PaymentHoldType";

    // account attributes
    public static final String ATTRIBUTE_DOMAIN = "domain";

    // pickup attribute
    public static final String PICKUP_ATTR_PICKUP_INSTRUCTION = "PICKUP_INSTRUCTIONS";
    public static final String PICKUP_ATTR_LATITUDE = "LATITUDE";
    public static final String PICKUP_ATTR_LONGITUDE = "LONGITUDE";
    public static final String PICKUP_ATTR_TIMEZONE = "TIMEZONE";
    public static final String ATTR_REFERENCE_ID = "referenceId";
    public static final String PICKUP_ATTR_STORE_ID = "STORE_ID";
    public static final String PICKUP_ATTR_LOCATION_UUID = "LOCATION_UUID";
    public static final String METHOD_CODE_PICKUP = "PickUpDropOff";
    public static final String METHOD_CODE_IN_STORE_PICKUP = "InStorePickup";
    public static final String METHOD_CODE_CUSTOM_CODE = "CustomCode";
    public static final String BOPIS_PICKUP_METHOD = "InStorePickup";
    public static final String PICKUP_ATTR_PICKUP_CODE = "PICKUP_CODE";
    public static final String PICKUP_ATTR_MERCH_CODE = "merchantPickupCode";

    // payments facet
    public static final String COLLECTION_TYPE_BUYER = "BUYER";

    public static final String EBAY_FUNDED_PAYMENT_FOR_INCENTIVE = "EBAY_FUNDED_PAYMENT_FOR_INCENTIVE";

    public static final String COLLECTION_TYPE_BUYER_PLAN = "BUYER_PLAN";

    public static final String COLLECTION_TYPE_EBAY_FUNDED_PAYMENT = "EBAY_FUNDED_PAYMENT";

    // priceline type
    public static final String PRICELINE_TYPE_TOTAL_REFUND_AMOUNT = "TOTAL_REFUND_AMOUNT";
    public static final String PRICELINE_TYPE_FINAL_VALUE_FEE_VARIABLE = "FINAL_VALUE_FEE_VARIABLE";
    public static final String PRICELINE_TYPE_LISTING_UNIT_COST = "LISTING_UNIT_COST";
    public static final String PRICELINE_TYPE_DISCOUNTED_ITEM_COST = "DISCOUNTED_ITEM_COST";


    // collection
    public static final String COLLECTION_TYPE_SELLER = "SELLER";
    public static final String COLLECTION_TYPE_EBAY = "EBAY";
    public static final String COLLECTION_TYPE_TAX_PARTNER = "TAX_PARTNER";
    public static final String COLLECTION_TYPE_EBAY_REVENUE = "EBAY_REVENUE";

    public static final String COLLECTION_TYPE_EBAY_SELLER_FEE = "EBAY_SELLER_FEE";
    // distribution
    public static final String DISTRIBUTION_TYPE_SELLER = "SELLER";

    public static final String DISTRIBUTION_TYPE_BUYER = "BUYER";
    public static final String DISTRIBUTION_TYPE_TAX_PARTNER = "TAX_PARTNER";
    public static final String DISTRIBUTION_TYPE_AU_TAX_PARTNER = "AU_TAX_PARTNER";
    public static final Set<String> DISTRIBUTION_TYPE_TAX_PARTNER_SET
            = ImmutableSet.of(ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_TAX_PARTNER, ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_AU_TAX_PARTNER);

    public static final String DISTRIBUTION_TYPE_EBAY_SELLER_FEE = "EBAY_SELLER_FEE";
    public static final String DISTRIBUTION_TYPE_EBAY_EBAY = "EBAY";
    public static final String DISTRIBUTION_TYPE_SHIPPING_PARTNER = "SHIPPING_PARTNER";
    public static final String ATTRIBUTE_SELLER_ORDER_DISTRIBUTION = "SELLER_ORDER_DISTRIBUTION";
    public static final String ATTRIBUTE_SHIPPING_PARTNER = "SHIPPING_PARTNER_ORDER_DISTRIBUTION";
    public static final String ATTRIBUTE_MESSAGE = "message";
    public static final String ATTRIBUTE_PAYMENT_INSTRUMENT_VERSION = "PaymentInstrumentVersion";

    // Contract Summary
    public static final String SUMMARY_TOTAL_COUNT = "total";               // count for all pages
    public static final String SUMMARY_SUBTOTAL = "subtotal";
    public static final String SUMMARY_PAGE_TOTAL_COUNT = "pageTotal";      // count on current page (after pagination)
    public static final String SUMMARY_ITEM_COUNT = "itemCount";

    //buyer info
    public static final String ATTR_COUNTRY_ID = "COUNTRY_ID";
    public static final String ATTR_REGISTRATION_SITE_ID = "REGISTRATION_SITE_ID";
    public static final String ATTR_TAX_STATUS = "TAX_STATUS";

    //logistics
    public static final String ATTR_SHIPPING_SERVICE_ID = "shippingServiceId";
    public static final String ATTR_GET_IT_FAST = "isGetItFast";

    //header
    public static final String X_EBAY_OMS_VERSION = "X-EBAY-OMS-VERSION";
    public static final String X_EBAY_C_ENDUSERCTX = "X-EBAY-C-ENDUSERCTX";
    public static final String X_EBAY_C_CULTURAL_PREF = "X-EBAY-C-CULTURAL-PREF";
    public static final String X_EBAY_C_MARKETPLACE_ID = "X-EBAY-C-MARKETPLACE-ID";
    public static final String X_EBAY_C_TERRITORY_ID = "X-EBAY-C-TERRITORY-ID";
    public static final String ACCEPT_ENCODING = "accept-encoding";
    public static final String AUTHORIZATION = "authorization";
    public static final String CONTENT_TYPE = "content-type";
    public static final String ACCEPT = "accept";
    public static final String HOST = "host";
    public static final String EBAY_CLIENT_IP = "x-ebay-client-ip";
    public static final String X_EBAY_API_CALL_NAME = "X-EBAY-API-CALL-NAME";
    public static final String X_EBAY_API_COMPATIBILITY_LEVEL = "X-EBAY-API-COMPATIBILITY-LEVEL";
    public static final String X_EBAY_API_SITE_ID = "X-EBAY-API-SITEID";
    public static final String X_EBAY_SOA_OPERATION_NAME = "X-EBAY-SOA-OPERATION-NAME";
    public static final String SOAP_ACTION = "SOAPAction";
    public static final String CONTENT_TYPE_VALUE = "application/json";
    public static final String CACHE_CONTROL = "CACHE-CONTROL";
    public static final String USER_AGENT = "USER-AGENT";
    public static final String CONNECTION = "CONNECTION";
    public static final String X_EBAY_SOA_MESSAGE_PROTOCOL = "X-EBAY-SOA-MESSAGE-PROTOCOL";
    public static final String X_EBAY_SOA_REQUEST_ID = "X-EBAY-SOA-REQUEST-ID";
    public static final String X_EBAY_SOA_USE_CASE_NAME = "X-EBAY-SOA-USECASE-NAME";
    public static final String POSTMAN_TOKEN = "POSTMAN-TOKEN";
    public static final String X_EBAY_API_IAF_TOKEN = "X-EBAY-API-IAF-TOKEN";
    public static final String X_EBAY_REQUEST_ID = "X-EBAY-REQUEST-ID";
    public static final String X_EBAY_C_REQUEST_ID = "X-EBAY-C-REQUEST-ID";
    public static final String X_EBAY_CONSUMER_ID = "X-EBAY-CONSUMER-ID";
    public static final String X_EBAY_TF_AUTHORIZATION = "X-EBAY-TF-AUTHORIZATION";
    public static final String X_EBAY_CLIENT_ID = "X-EBAY-CLIENT-ID";
    // Programs
    public static final String PROGRAM_PSA = "PSA";
    public static final String PSA_LEGACY_WAREHOUSE_NAME = "PSA Warehouse";
    public static final String EBAY_MANAGED_SHIPPING = "EBAY_MANAGED_SHIPPING";

    //TODO ww move to config bean
    public static final int DEFAULT_FETCH_SIZE_ORDERS_INVOICES = 25;

    // List init size
    public static final int EMPTY = 0;

    // Bulk update action type
    public static final String MARK_AS_PAID = "mark_as_paid";
    public static final String MARK_AS_UNPAID = "mark_as_unpaid";
    public static final String MARK_AS_SHIPPED = "mark_as_shipped";
    public static final String MARK_AS_UNSHIPPED = "mark_as_unshipped";
    public static final String HIDE = "hide";
    public static final String UNHIDE = "unhide";
    public static final String ACK = "ack";
    public static final String UNACK = "unack";

    // Audit environment
    public static final String GLOBAL_CONFIG_PROPERTY = "global-config-delivery";

    // Common
    public static final String EMPTY_STRING = "";

    // v1 count
    public static final String ALL_COUNTS = "AllCounts";

    // contract v2 error domain
    public static final String ERROR_DOMAIN_APP = "Application";


    //Payment Method Name
    public static final String MONEY_ORDER = "Money order / Cashier's check";
    public static final String CIP = "Bank Deposit";
    public static final String PERSONAL_CHECK = "Personal check";
    public static final String OTHER = "Other payment method";
    public static final String CASH_ON_DELIVERY = "Cash on delivery";
    public static final String CASH_ON_PICKUP = "Pay on pickup";
    public static final String OTHER_ONLINE = "other online payment";
    public static final String MONEY_TRANSFER = "Money Transfer";
    public static final String POSTAL_TRANSFER = "Postal Transfer";
    public static final String GENERIC_CREDIT_CARD = "Other Credit Card Services";
    public static final String DELIVERY_AFTER_PAID = "Pay Money First, Delivery Afterwards";
    public static final String SEE_DESCRIPTION = "Other - See Payment Instructions for payment methods accepted";
    public static final String COD_DELIVERY_AFTER_PAID = "Same City COD, intra city use pay first &amp;  deliver after";
    public static final String LOAN_CHECK = "Loan Check";
    public static final String CASH_IN_PERSON = "Cash (in person)";
    public static final String VISA_MASTER = "Visa/MasterCard";
    public static final String AMERICAN_EXPRESS = "American Express";
    public static final String DISCOVER = "Discover";
    public static final String INTEGRATED_MCC = "Credit card";
    public static final String EM_ESCROW = "Escrow";
    public static final String MONEYBOOKERS = "Skrill";
    public static final String PAYMATE = "Paymate";
    public static final String PROPAY = "ProPay";
    public static final String PAYPAL = "PayPal";
    public static final String DIRECT_DEBIT = "Direct Debit";
    public static final String CC = "Credit Card";
    public static final String EMS_ESCROW = "ems escrow";
    public static final String CLICKANDBUY = "ClickandBuy";
    public static final String BML = "Bill Me Later";
    public static final String PAYPAL_NOLINK = "Credit Card Payment through PayPal";
    public static final String PAISAPAY = "paisapay";
    public static final String PAY_UPON_INVOICE = "Pay upon invoice";

    public static final String EXTERNAL_TRANSACTION_ID = "ExternalTransactionId";
    public static final String ATTR_PAYMENT_AGREEMENT_REFERENCE_NUMBER = "paymentAgreementReferenceNumber";
    public static final String ORDER = "ORDER";

    public static final String TASK_TIMEOUT = "TASK_TIMEOUT";
    public static final String EBAY_USER = "eBayUser";
    public static final String UNAVAILABLE = "Unavailable";
    public static final String EBAY_PAYEE = "eBay";
    public static final String PAYEE_PITNEY_BOWES = "PitneyBowes";

    public static final String ADDRESS_OWNER = "AddressOwner";
    public static final String EBAY = "EBAY";
    public static final String PAY_PAL = "Paypal";
    public static final String UNKNOWN = "Unknown";

    public static final String ORDER_TRANSACTION_TYPE_INCENTIVE = "INCENTIVE";
    public static final String ORDER_TRANSACTION_TYPE_GIFTCARD = "GIFTCARD";
    public static final String ORDER_TRANSACTION_TYPE_EBAY_BALANCE = "EBAY_BALANCE";

    public static final String SHIPPING_METHOD_CODE_OVERNIGHT = "ShippingMethodOvernight";

    //program relate constant
    public static final String FULFILLMENT = "FULFILLMENT";
    public static final String FULFILLMENT_BY = "FULFILLMENT_BY";
    public static final String PENDING = "PENDING";
    public static final String PASSED = "PASSED";

    // Amount
    public static final Double ZERO_AMOUNT = 0.0d;
    public static final BigDecimal ZERO_AMOUNT_BIG_DECIMAL = new BigDecimal(ZERO_STRING);

    // Build
    public static final String BUILD = "APISELLING_EXT_SVC";

    // Pagination constants
    public static final int MAX_MODIFIED_DURATION_DAYS = 30;
    public static final int MAX_NUMBER_OF_DAYS = 30;
    public static final int GMES_MAX_NUMBER_OF_DAYS = 60;
    public static final int GMES_DEFAULT_NUMBER_OF_DAYS = 30;
    public static final int SELLING_SUMMARY_DEFAULT_DAYS = 31;
    public static final int MAX_TOTAL_ENTRIES = 25000;
    public static final int MIN_NUMBER_OF_DAYS = 1;

    public static final int GST_DEFAULT_ENTRIES_PER_PAGE = 25;
    public static final int GMES_DEFAULT_ENTRIES_PER_PAGE = 200;
    public static final int MAXIMUM_ENTRIES_PER_PAGE = 200;
    public static final int MINIMUM_ENTRIES_PER_PAGE = 1;
    public static final int MINIMUM_PAGE_NUMBER = 1;
    public static final int MINIMUM_DURATION_IN_DAYS = 0;
    public static final int MAXIMUM_DURATION_IN_DAYS = 60;
    public static final boolean DEFAULT_INCLUDE_NOTES = false;
    public static final boolean DEFAULT_HIDE_VARIATIONS = false;

    public static final String INVALID_REQUEST = "Invalid Request";

    public static final String EBAY_VAULT = "eBay Vault";

    // Country name
    /**
     * apixoio - when pudo case it will read site id 3 as 230, which return Great Britain instead of United Kingdom
     */
    public static final String GREAT_BRITAIN = "Great Britain";

    public static final int COMPATIBILITY_LEVEL_827 = 827;

    public static final int COMPATIBILITY_LEVEL_839 = 839;

    public static final int COMPATIBILITY_LEVEL_879 = 879;

    public static final int COMPATIBILITY_LEVEL_893 = 893;

    public static final int COMPATIBILITY_LEVEL_887 = 887;

    public static final String INTRA_VAULT_TRANSFER = "INTRA_VAULT_TRANSFER";
    public static final String FULFILLMENT_FROM_VAULT = "FULFILLMENT_FROM_VAULT";
    public static final String SHIP_TO_VAULT = "SHIP_TO_VAULT";
    public static final String VAS_SUB_TYPE_NAME = "VAS_SUB_TYPE_NAME";
    public static final String VAULT = "VAULT";
    public static final String IS_REGISTRATION_ADDRESS = "IS_REGISTRATION_ADDRESS";
    public static final String BUYER_REGISTRATION_SITE_ID = "REGISTRATION_SITE_ID";

    public static final String CARRIER_USED = "carrierUsed";

    public static final int MIN_HOST = 10;
    public static final int MAX_HOST = 26;

    public static final String DEFAULT_USER_WRITE_HOST = "userwrite%host";
    public static final int PICKUP_DEFAULT_PRIORITY = 1;
    public static final String Email = "Email";

    public static final String BUYERS_CONSENT_TO_SHOW_PHONE_NUMBER = "buyersConsentToShowPhoneNumber";
    public static final String CHECKOUT_NAMESPACE = "Checkout";

    //shipping discount campaign id
    public static final Long SHIPPING_DISCOUNT_TYPE = 5L;
    public static final String SELLER_TAX_PERCENTAGE = "sellerTaxPercentage";

    public static final String DEFAULT_USER_ITEM_HOST = "useritem%host";

    public static final int DEFAULT_PURCHASE_QUANTITY = 1;

    public static final int DEFAULT_SITE_ID = 0;

    public static final String APPLICATION_EXCEPTION = "Application exception";
    public static final String IMMEDIATE_PAY = "IS_IMMEDIATE_PAY";


    public static final String INVOICE_TIME = "INVOICE_TIME";
    public static final String SKU = "SKU";
    public static final String SEP = "-";

    // payment instrument

    public static final String CREDIT_CARD = "CREDIT_CARD";
    public static final String SOFORT = "SOFORT";
    public static final String OTHER_FULL = "OTHER";
    public static final String PAYPAL_FULL = "PAYPAL";
    public static final String PAYPAL_ACCOUNT = "PAYPAL_ACCOUNT";
    public static final String PAYPAL_CREDIT = "PAYPAL_CREDIT";

    // GMES type

    public static final String SOLD_LIST = "SOLD_LIST";
    public static final String DELETED_FROM_SOLD_LIST = "DELETED_FROM_SOLD_LIST";
    public static final String DELETED_FROM_UNSOLD_LIST = "DELETED_FROM_UNSOLD_LIST";
    public static final String SELLING_SUMMARY = "SELLING_SUMMARY";
    public static final String SUMMARY = "SUMMARY";

    public static final String BUYER_SHIPPING_ADDRESS = "BUYER_SHIPPING_ADDRESS";

    public static final String ACTIVE_LIST_NAME = "ActiveList";
    public static final String DELETED_FROM_SOLD_LIST_NAME = "DeletedFromSoldList";
    public static final String DELETED_FROM_UNSOLD_LIST_NAME = "DeletedFromUnsoldList";
    public static final String SCHEDULED_LIST_NAME = "ScheduledList";
    public static final String SELLING_SUMMARY_NAME = "SellingSummary";
    public static final String SOLD_LIST_NAME = "SoldList";
    public static final String UNSOLD_LIST_NAME = "UnsoldList";

    // Limit svc
    public static final String REMAINING_METRICS = "REMAINING_METRICS";

    //Buyer guarantee Price constant setting as 20000.0
    public static final double BUYER_GUARANTEE_PRICE = 20000.0;
    public static final String BP_ITEM_PROFILES_CONSUMER = "SellerProfilesItemMapServiceConsumer";
    public static final String HEADER_GLOBAL_ID = "X-EBAY-SOA-GLOBAL-ID";
    public static final String HEADER_SECURITYID = "X-EBAY-SOA-SECURITY-USERID";
    public static final String MOTOR_DEPOSIT_ITEM = "MOTOR_DEPOSIT_ITEM";


    public static final String FEEDBACK_SCORE = "FEEDBACKSCORE";
    public static final String PROMO_SALE_START_TIME = "PROMO_SALE_START_TIME";
    public static final String PROMO_SALE_END_TIME = "PROMO_SALE_END_TIME";

    public static final String BUYER_USER_DATA_DELETED = "BUYER_USER_DATA_DELETED";
    public static final String BUYER_USER_DATA_DELETION_DATE = "BUYER_USER_DATA_DELETION_DATE";

    // Listing Type
    public static final String LEAD_GENERATION = "LEAD_GENERATION";
    public static final String STORES_FIXED_PRICE = "STORES_FIXED_PRICE";
    public static final String PERSONAL_OFFER = "PERSONAL_OFFER";
    public static final String CUSTOM_CODE = "CUSTOM_CODE";

    //Shipping
    public static final String NOT_SPECIFIED = "NOT_SPECIFIED";
    public static final String ACTUAL_RATE = "ACTUAL_RATE";
    public static final String CALCULATED_DOMESTIC_CALCULATED_INTERNATIONAL = "CALCULATEDDOMESTICCALCULATEDINTERNATIONAL";
    public static final String CALCULATED_DOMESTIC_FLAT_INTERNATIONAL = "CALCULATEDDOMESTICFLATINTERNATIONAL";
    public static final String FLAT_DOMESTIC_FLAT_INTERNATIONAL = "FLATDOMESTICFLATINTERNATIONAL";
    public static final String FLAT_DOMESTIC_CALCULATED_INTERNATIONAL = "FLATDOMESTICCALCULATEDINTERNATIONAL";
    public static final String CALCDOMESTIC_FLATINTL_RATE = "CALCDOMESTIC_FLATINTL_RATE";
    public static final String FLATDOMESTIC_CALCINTL_RATE = "FLATDOMESTIC_CALCINTL_RATE";
    public static final String FLAT_RATE = "FLAT_RATE";
    public static final String FREIGHT_RATE = "FREIGHT_RATE";

    public static final String ITEM_CONDITION_NAME = "itemConditionName";
    public static final String EBAY_NOTE_TEMPLATE =  "<!DOCTYPE html\n" + "    PUBLIC \"-//W3C//DTD HTML 4.01 " +
            "Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n" + "<tr class=\"Note1\">\n" + "   <td colspan=\"\"><img src=\"http://pics.qa.ebaystatic.com/aw/pics/spacer.gif\" width=\"5\" height=\"0\" alt=\"\">$EBAY_NOTE$</td>\n" + "</tr>";


}