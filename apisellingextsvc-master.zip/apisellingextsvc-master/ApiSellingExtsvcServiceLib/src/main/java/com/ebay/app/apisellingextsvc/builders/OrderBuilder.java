package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.GMESCosmosFieldUtil;
import com.ebay.app.apisellingextsvc.utils.OrderBuilderUtil;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.OrderStateTypeCS;
import com.ebay.cosmos.OrderTotal;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.RefundStatusEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.OrderType;

import java.util.Optional;


public class OrderBuilder extends BaseOrderTypeBuilder {

    private final OrderCSXType order;
    private final SiteContext siteContext;

    public OrderBuilder(Task<?> task,
                        int trxVersion,
                        ApiSellingExtSvcConfigValues configValues,
                        ContractResponseType contractResponse,
                        SiteContext siteContext) {
        super(task, trxVersion, configValues, contractResponse);
        this.order = contractResponse.getOrder();
        this.siteContext = siteContext;
    }

    @Override
    protected OrderType doBuild() {
        OrderType orderType = new OrderType();
        orderType.setOrderID(getOrderId());
        if (configValues.getIssueRefundEnabledCountries().contains(siteContext.viewingSiteId)) {
            AmountType refundAmount = OrderBuilderUtil.getRefundAmount(order);
            if (refundAmount != null && refundAmount.getValue() > 0) {
                orderType.setRefundAmount(refundAmount);
            }
            String refundStatus = OrderBuilderUtil.getRefundStatus(order);
            if (refundStatus != null && !"NONE".equals(refundStatus)) {
                orderType.setRefundStatus(refundStatus);
            }
        }
        orderType.setSubtotal(getSubtotal(order.getOrderTotal().getPriceLines()));
        orderType.setTotal(getTotal());
        return orderType;
    }

    private AmountType getTotal() {
        return GMESCosmosFieldUtil.getOrderTotal(order);
    }

    private String getOrderId() {
        Optional<Attribute> orderId = order.getAttributes().stream()
                .filter(x -> x.getName().equals(ApiSellingExtSvcConstants.ATTR_LEGACY_ID))
                .findFirst();
        if (orderId.isPresent()) {
            return orderId.get().getValue();
        }
        return null;
    }

    private String getRefundStatus() {
        RefundStatusEnum refundStatus = Optional.ofNullable(order)
                .map(OrderCSXType::getOrderStates)
                .map(OrderStateTypeCS::getRefundStatus)
                .orElse(null);
        if (refundStatus != null) {
            return refundStatus.value();
        }
        return null;
    }
}
