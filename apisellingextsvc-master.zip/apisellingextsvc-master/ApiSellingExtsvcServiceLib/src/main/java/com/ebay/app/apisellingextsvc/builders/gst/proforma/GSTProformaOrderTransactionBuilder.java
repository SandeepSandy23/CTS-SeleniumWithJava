package com.ebay.app.apisellingextsvc.builders.gst.proforma;

import com.ebay.app.apisellingextsvc.builders.ContainingOrderBuilder;
import com.ebay.app.apisellingextsvc.builders.gst.GSTOrderItemBuilder;
import com.ebay.app.apisellingextsvc.builders.proforma.ProformaOrderTransactionBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.service.bof.exchangerate.ExchangeRateBofImpl;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserInfo;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.MoneyExchangeHelper;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.TransactionType;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Map;

public class GSTProformaOrderTransactionBuilder extends ProformaOrderTransactionBuilder {
    private final ContractResponseType contractResponseType;
    private final List<DetailLevelCodeType> detailLevels;
    private final ProformaOrderLineItemXType lineItem;
    private final ApiSellingExtSvcConfigValues configValues;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final boolean includeContainingOrder;
    private final SiteContext siteContext;
    private final int trxVersion;
    private final Map<String, Item> svlsItemInfoMap;

    public GSTProformaOrderTransactionBuilder(Task<?> task,
                                              @Nonnull ContractResponseType contractResponseType,
                                              ProformaOrderLineItemXType lineItem,
                                              SiteContext siteContext,
                                              IContentHelper contentHelper,
                                              List<DetailLevelCodeType> detailLevels,
                                              ApiSellingExtSvcConfigValues configValues,
                                              int trxVersion,
                                              boolean includeContainingOrder,
                                              Map<Long, ListingActivity> itemIdListingActivityMap,
                                              Map<String, Item> svlsItemInfoMap) {
        super(task, contractResponseType.getProformaOrder(), lineItem, siteContext, contentHelper, detailLevels, configValues, trxVersion, itemIdListingActivityMap, svlsItemInfoMap);
        this.contractResponseType = contractResponseType;
        this.detailLevels = detailLevels;
        this.lineItem = lineItem;
        this.siteContext = siteContext;
        this.configValues = configValues;
        this.includeContainingOrder = includeContainingOrder;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.trxVersion = trxVersion;
        this.svlsItemInfoMap = svlsItemInfoMap;
    }

    @Override
    protected TransactionType doBuild() {
        TransactionType transaction = super.doBuild();
        transaction.setTransactionSiteID(getTransactionSiteId(lineItem.getAttribute(), ApiSellingExtSvcConstants.ATTR_TRANS_SITE_ID));
        transaction.setActualShippingCost(getActualCost(PricelineTypeEnum.SHIPPING_COST));
        transaction.setActualHandlingCost(getActualCost(PricelineTypeEnum.HANDLING_COST));
        transaction.setEBayPlusTransaction(isEbayPlusTransaction(lineItem.getPrograms()));
        transaction.setTransactionPrice(getTransactionPrice(lineItem.getUnitPrice()));
        transaction.setGuaranteedShipping(isGuaranteedShipping());
        transaction.setBestOfferSale(getBestOfferStatus(order.getAttributes()));
        transaction.setConvertedTransactionPrice(MoneyExchangeHelper.exchange(new ExchangeRateBofImpl(), transaction.getTransactionPrice(), siteContext.viewingSiteId));
        AmountType finalValueFee = getFinalValueFee();
        transaction.setItem(new GSTOrderItemBuilder(task, lineItem, configValues, itemIdListingActivityMap, svlsItemInfoMap, detailLevels, contentHelper).build());
        String transactionSiteId = AttributeUtil.findAttributeValue(lineItem.getAttribute(), ApiSellingExtSvcConstants.ATTR_TRANS_SITE_ID);
        if (transactionSiteId != null)
            transaction.setBuyerGuaranteePrice(AmountTypeUtil.getAmountType(Integer.parseInt(transactionSiteId),
                    ApiSellingExtSvcConstants.BUYER_GUARANTEE_PRICE));
        if (includeContainingOrder)
            transaction.setContainingOrder(new ContainingOrderBuilder(task, contractResponseType).build());
        transaction.setInventoryReservationID(transaction.getTransactionID());
        transaction.setEBayCollectAndRemitTax(getRemitTax(order.getAttributes(), trxVersion));
        // Adding amounts and converted amounts for proforma
        transaction.setAmountPaid(AmountTypeUtil.getDefaultZeroAmountType(order));
        transaction.setConvertedAmountPaid(MoneyExchangeHelper.exchange(new ExchangeRateBofImpl(), AmountTypeUtil.getDefaultZeroAmountType(order), siteContext.viewingSiteId));
        transaction.setAdjustmentAmount(AmountTypeUtil.getDefaultZeroAmountType(order));
        transaction.setConvertedAdjustmentAmount(transaction.getConvertedAmountPaid());
        return transaction;
    }
}
