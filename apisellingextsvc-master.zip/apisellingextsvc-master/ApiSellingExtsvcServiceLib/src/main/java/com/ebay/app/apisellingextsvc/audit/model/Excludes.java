package com.ebay.app.apisellingextsvc.audit.model;

import com.ebay.app.apisellingextsvc.common.helper.FileHelper;
import com.ebay.app.apisellingextsvc.common.logger.ILogger;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class Excludes {

        private static final String NULL = "null";
        private HashMap<String, HashSet<String>> map = new HashMap();

        private Excludes() {
    }

        public static Excludes create(String excludeFile, ILogger logger) {
        InputStream inputStream = FileHelper.readResourceFileAsStream(excludeFile);
        Excludes excludes = new Excludes();
        if (inputStream != null) {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
                Throwable var5 = null;

                try {
                    String line;
                    try {
                        while((line = br.readLine()) != null) {
                            getExcludeField(line, excludes);
                        }
                    } catch (Throwable var15) {
                        var5 = var15;
                        throw var15;
                    }
                } finally {
                    if (br != null) {
                        if (var5 != null) {
                            try {
                                br.close();
                            } catch (Throwable var14) {
                                var5.addSuppressed(var14);
                            }
                        } else {
                            br.close();
                        }
                    }

                }
            } catch (Exception var17) {
                logger.error("Error loading exclude: " + excludeFile, var17);
            }
        } else {
            logger.error("Could not find exclude: " + excludeFile);
        }

        return excludes;
    }

        public static Excludes create(List<String> excludeFieldList, ILogger logger) {
        Excludes excludes = new Excludes();
        if (excludeFieldList != null && !excludeFieldList.isEmpty()) {
            Iterator var3 = excludeFieldList.iterator();

            while(var3.hasNext()) {
                String fieldName = (String)var3.next();
                getExcludeField(fieldName, excludes);
            }

            return excludes;
        } else {
            logger.error("Exclude file list is empty");
            return excludes;
        }
    }

        private static void getExcludeField(String fieldName, Excludes excludes) {
        if (fieldName.contains("//")) {
            fieldName = fieldName.split("//")[0].trim();
        }

        if (fieldName.contains(":")) {
            String[] arr = fieldName.split(":");
            HashSet<String> set = (HashSet)excludes.map.get(arr[0].trim());
            if (set == null) {
                set = new HashSet();
            }

            set.add(arr[1].trim());
            excludes.map.put(arr[0].trim(), set);
        } else {
            excludes.map.put(fieldName.trim(), null);
        }

    }

        public boolean contains(String path, String key) {
        path = path.replaceAll("\\[\\d+\\]", "[*]");
        if (this.map.containsKey(path)) {
            String keyVal = key == null ? "null" : key;
            return ((HashSet)this.map.get(path)).contains(keyVal);
        } else {
            return false;
        }
    }

        public boolean contains(String path) {
        path = path.replaceAll("\\[\\d+\\]", "[*]");
        return this.map.containsKey(path);
    }
    }


