package com.ebay.app.apisellingextsvc.config;

import com.ebay.kernel.BaseEnum;
import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static java.util.Arrays.asList;

public class ConfigProviderUtil {

    private static final Logger LOGGER = Logger.getInstance(ConfigProviderUtil.class);
    private static final ObjectMapper JSON = new ObjectMapper();

    @SuppressWarnings("unchecked")
    public static <TypeT> TypeT formatValue(Object value, Class<TypeT> clazz) {

        if (value == null) {
            return null;
        }

        TypeT result = null;
        Class<TypeT> valueClazz = clazz;
        if (valueClazz == Byte.class) {
            result = (TypeT) Byte.valueOf(value.toString());
        } else if (valueClazz == Short.class) {
            result = (TypeT) Short.valueOf(value.toString());
        } else if (valueClazz == Integer.class) {
            result = (TypeT) Integer.valueOf(value.toString());
        } else if (valueClazz == Long.class) {
            result = (TypeT) Long.valueOf(value.toString());
        } else if (valueClazz == Float.class) {
            result = (TypeT) Float.valueOf(value.toString());
        } else if (valueClazz == Double.class) {
            result = (TypeT) Double.valueOf(value.toString());
        } else if (valueClazz == Boolean.class) {
            result = (TypeT) SimpleBooleanConverter.convert(value.toString());
        } else if (valueClazz == BigInteger.class) {
            result = (TypeT) BigInteger.valueOf(Long.parseLong(value.toString()));
        } else if (valueClazz == BigDecimal.class) {
            result = (TypeT) BigDecimal.valueOf(Double.parseDouble(value.toString()));
        } else if (List.class.isAssignableFrom(valueClazz)) {
            valueClazz = (Class<TypeT>) List.class;
            if (List.class.isAssignableFrom(value.getClass())) {
                result = (TypeT) new ArrayList<>((List<?>) value);
            } else if (value.getClass().isArray()) { // MDDF Datareader returns list as Arrays
                result = (TypeT) asList((Object[]) value);
            }
        } else if (valueClazz == String.class) {
            result = (TypeT) value.toString();
        } else if (valueClazz == String[].class) {
            if (value.getClass().isArray()) {
                result = (TypeT) value;
            } else if (value instanceof List) {
                result = (TypeT) ((List) value).toArray(new String[((List) value).size()]);
            }
        } else if (valueClazz == Properties.class) {
            if (value instanceof Properties) {
                result = (TypeT) value;
            } else if (value instanceof Map) {
                Map<Object, Object> mapValue = (Map<Object, Object>) value;
                Properties propValues = new Properties();
                for (Map.Entry<Object, Object> ent : mapValue.entrySet()) {
                    propValues.put(ent.getKey(), ent.getValue());
                }
                result = (TypeT) propValues;
            }
        } else if (valueClazz == HashMap.class) {
            if (Map.class.isAssignableFrom(value.getClass())) {
                result = (TypeT) new LinkedHashMap<>((Map<?, ?>) value);
            }
        } else if (Map.class.isAssignableFrom(valueClazz)) {
            valueClazz = (Class<TypeT>) Map.class;
            if (Map.class.isAssignableFrom(value.getClass())) {
                result = (TypeT) new LinkedHashMap<>((Map<?, ?>) value);
            }
        } else if (valueClazz.isEnum()) {
            result = (TypeT) Enum.valueOf(valueClazz.asSubclass(Enum.class), value.toString());
        } else if (isEbayEnum(valueClazz)) {
            result = getEbayEnum(value, valueClazz);
            if (result == null) {
                LOGGER.log(LogLevel.ERROR, "Value " + result + " is not valid for class" + valueClazz);
            }
        }
        // If expected value is not string, but stored value is string, try to convert using json
        if (result == null
                && String.class.equals(value.getClass())
                && !String.class.equals(valueClazz)) {
            try {
                result = JSON.readValue((String) value, valueClazz);
            } catch (IOException ioe) {
                LOGGER.log(LogLevel.ERROR, "Value " + result + " is not valid for class" + clazz);
            }
            if (result == null) {
                LOGGER.log(LogLevel.ERROR, "unsupported class type: " + clazz);
            }
        }

        return result;
    }

    private static <V> boolean isEbayEnum(Class<V> clazz) {
        return BaseEnum.class.isAssignableFrom(clazz);
    }

    @SuppressWarnings("unchecked")
    private static <TypeT> TypeT getEbayEnum(Object value, Class<TypeT> clazz) {
        int id = Integer.parseInt(value.toString());
        BaseEnum baseEnum = BaseEnum.getEnum(clazz, id);
        return (TypeT) baseEnum;
    }
}