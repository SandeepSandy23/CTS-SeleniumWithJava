package com.ebay.app.apisellingextsvc.enums;


public enum APITypeEnum {
    GetSellerTransactions,
    GetMyeBaySelling,
    GetSellerEvents,
    GetSellerList
}
