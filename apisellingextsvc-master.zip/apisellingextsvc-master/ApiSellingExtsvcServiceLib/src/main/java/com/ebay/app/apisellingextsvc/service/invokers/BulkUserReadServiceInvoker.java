package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserReadResponse;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.BulkUserReadServiceClient;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class BulkUserReadServiceInvoker extends BaseServiceInvoker<String, UserReadResponse, String>{

    public static final String NAME = "BulkUserReadServiceInvoker";

    public BulkUserReadServiceInvoker( TracerContext tracerContext) {
        super(NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<String, UserReadResponse> getGingerClient(String request) {
        return new BulkUserReadServiceClient();
    }

    @Override
        protected GingerClientRequest<String> getGingerRequest(String request, HttpHeaders httpHeaders) {
            GingerClientRequest<String> gingerClientRequest = new GingerClientRequest<>();
            MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
            addJsonHeaders(headers);
            removeHeadersForUserReadSvc(headers);
            gingerClientRequest.setHeaders(headers);
            gingerClientRequest.setRequest(request);
            return gingerClientRequest;
        }
}
