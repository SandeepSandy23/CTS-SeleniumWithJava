package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.application.common.response.GetMyeBaySellingResponse;
import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.ebay.kernel.calwrapper.CalEventHelper;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.ebay.app.apisellingextsvc.framework.binding.XmlSerializerFactory;
import com.ebay.app.apisellingextsvc.framework.outputselector.GraphMap;
import com.ebay.app.apisellingextsvc.framework.outputselector.OutputSelectorGenerator;
import com.ebay.app.apisellingextsvc.utils.XmlUtil;
import ebay.apis.eblbasecomponents.AbstractRequestType;
import ebay.apis.eblbasecomponents.AbstractResponseType;
import org.apache.commons.collections.CollectionUtils;

public class OutputSelectorTask implements Task<AbstractResponseType>, ITaskResultInjectable {

    private final AbstractRequestType request;
    private final AbstractResponseType response;

    public OutputSelectorTask(AbstractRequestType request, AbstractResponseType response) {
        this.request = request;
        this.response = response;
    }

    @Override
    public AbstractResponseType call() {
        if (CollectionUtils.isNotEmpty(request.getOutputSelector())) {
            GraphMap outputSelector = OutputSelectorGenerator.createOutputSelector(request.getOutputSelector(), response.getClass());
            XmlMapper xmlMapper = XmlSerializerFactory.getXmlMapper(outputSelector);
            try {
                String responseString = xmlMapper.writeValueAsString(response);

                if (GetSellerTransactionsResponse.class == response.getClass()) {
                    GetSellerTransactionsResponse getSellerTransactionsResponse =
                            XmlUtil.readResponseString(responseString, GetSellerTransactionsResponse.class);
                    return getSellerTransactionsResponse == null ? response : getSellerTransactionsResponse;
                } else if (GetMyeBaySellingResponse.class == response.getClass()) {
                    GetMyeBaySellingResponse getMyeBaySellingResponse =
                            XmlUtil.readResponseString(responseString, GetMyeBaySellingResponse.class);
                    return getMyeBaySellingResponse == null ? response : getMyeBaySellingResponse;
                }
            } catch (JsonProcessingException e) {
                CalEventHelper.writeException("out put selector", e);
                return response;
            }
        }
        return response;
    }

    @Override
    public void addResult(Object o) {

    }
}
