package com.ebay.app.apisellingextsvc.service.dal.shippingcarrier;

import com.ebay.integ.dal.cache2.BaseIntegCacheBean;
import com.ebay.integ.dal.cache2.CacheBeanInitializationException;
import com.ebay.kernel.bean.configuration.ConfigCategoryCreateException;

public class ShippingCarrierCacheBean extends BaseIntegCacheBean {

    public static final String CATEGORY_ID = "ebay.dal.CacheObject.ShippingCarrier";
    private static final long serialVersionUID = -3732771815319534098L;
    private static volatile ShippingCarrierCacheBean m_instance = null;

    private ShippingCarrierCacheBean() throws ConfigCategoryCreateException {
        super(createBeanConfigCategoryInfo(
                    CATEGORY_ID,
                    "com.ebay.domain.core.integ.CacheObject.ShippingCarrier",
                    "com.ebay.integ.CacheObject"),
              true,
              "ShippingCarrier",
              new ShippingCarrierCacheLoader(),
              ShippingCarrierKeyManager.getInstance(),
              86400, "03:00", 180, true, true, -1, 100, true);
    }

    public static ShippingCarrierCacheBean getInstance() {
        if (m_instance == null) {
            try {
                m_instance = new ShippingCarrierCacheBean();
            } catch (ConfigCategoryCreateException var1) {
                throw new CacheBeanInitializationException(var1, "ShippingCarrierCacheBean");
            }
        }

        return m_instance;
    }

}
