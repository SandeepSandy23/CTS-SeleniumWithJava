package com.ebay.app.apisellingextsvc.config;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.utils.IConfigHandler;
import lombok.Getter;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@Getter
public class ApiSellingExtSvcConfigValues {

    public final Integer version;
    /**
     * timeout of individual tasks in callable executor
     */
    public final Long taskTimeout;

    public final Integer varTitleSizeLimit;

    public final Boolean auditEnabled;

    public final Boolean gmesAuditEnabled;
    public final String omsVersion;

    public final Long contentCacheEvictTime;
    public final Integer contentCacheMaximumSize;

    public final List<String> euVatCountries;

    public final List<Integer> issueRefundEnabledCountries;

    public final Integer users_max_limit;

    public final String serviceVersion;

    /**
     * time in minutes for displaying buyer email address to seller
     */
    public final Integer minutesToDisplayEmailAddress;

    /**
     * <a href="https://jirap.corp.ebay.com/browse/TRXAPI-1952">TRXAPI-1952</a>
     *  as hard code part id in apixoio ApiControllerCommand.java, cobranch id is always 2,
     *  so we ignore cobranchId compare in apisellingextsvc.
     *
     *  ctxt.setPartnerId(VACConstants.PARTNER_EBAY);
     *
     * */
    public final Boolean enableSalesTaxOnboardingFeature;

    public final String esauthSecret;

    public final List<String> getSellerTransactionsAuditExcludeFields;

    public final List<String> getMyeBaySellingAuditExcludeFields;
    public final Boolean enableEbayReference;
    public final String euvatEbayVatId;

    public final List<String> shippingCarrierMapping;
    public final Integer modifiedDateMaxDaysBack;

    public final Integer sellingSummaryMaxVersion;
    public final Integer summaryMaxVersion;
    public final String siteApprovedForBuyerRegistrationAddress;
    public final Integer minimumSchemaVersion;
    public final Integer bpBatchSize;
    public final Boolean enableUserStatusValidationForGMES;
    public final Integer pictureDetailsVersion;
    public final List<String> gmesAuditSkipAppIDs;
    public final Double gmesSamplePercent;

    public final Integer gmesSoldDefaultDays;

    /**
     * <a href="https://jirap.corp.ebay.com/browse/TRXAPI-1952">TRXAPI-1952</a>
     * as hard code part id in apixoio ApiControllerCommand.java, cobranch id is always 2,
     * so we ignore cobranchId compare in apisellingextsvc.
     * <p>
     * ctxt.setPartnerId(VACConstants.PARTNER_EBAY);
     */
    public final Boolean loadDefaultBuyerAddressForCommitment;
    public final Boolean orderTotalCalculationLegacy;
    public final Set<String> orderTotalIncludeTaxEnabledAppName;
    public final Set<String> orderTotalIncludeTaxEnabledSellerId;
    public final Integer orderTotalIncludeTaxEnabledVersion;
    public final List<String> taxIdentifierList;
    public final Integer feedback_users_max_limit;
    public final Boolean isSVLSNewParallelCallOn;

    public ApiSellingExtSvcConfigValues(@Nonnull IConfigHandler configHandler) {
        this.version = configHandler.getValue("LOWEST_SUPPORT_VERSION", Integer.class, 1000);
        this.taskTimeout = configHandler.getValue(ApiSellingExtSvcConstants.TASK_TIMEOUT, Long.class, ApiSellingExtSvcConstants.TIMEOUT);
        this.varTitleSizeLimit = configHandler.getValue("VAR_TITLE_CHAR_UPPER_LIMIT", Integer.class, 127);
        this.auditEnabled = configHandler.getValue("AUDIT_ENABLED", Boolean.class, true);
        this.gmesAuditEnabled = configHandler.getValue("GMES_AUDIT_ENABLED", Boolean.class, false);
        this.omsVersion = configHandler.getValue("OMS_VERSION", String.class, "3.7.56");
        this.contentCacheEvictTime = configHandler.getValue("CONTENT_CACHE_EVICT_TIME", Long.class, 30000L);
        this.contentCacheMaximumSize = configHandler.getValue("CONTENT_CACHE_MAXIMUM_SIZE", Integer.class, 10);
        this.minutesToDisplayEmailAddress = configHandler.getValue("MINUTES_TO_DISPLAY_EMAIL_ADDRESS", Integer.class, 20160);
        this.enableSalesTaxOnboardingFeature = configHandler.getValue("ENABLE_SALES_TAX_ON_BOARDING_FEATURE", Boolean.class, false);
        this.loadDefaultBuyerAddressForCommitment = configHandler.getValue("LOAD_DEFAULT_BUYER_ADDRESS_FOR_COMMITMENT", Boolean.class,
                true);
        this.euVatCountries = configHandler.getValueList("EU_VAT_COUNTRIES", String.class, Collections.emptyList());
        this.issueRefundEnabledCountries = configHandler.getValueList("ISSUE_REFUND_ENABLED_COUNTRIES", Integer.class, Collections.emptyList());
        this.users_max_limit = configHandler.getValue("USERS_MAX_LIMIT", Integer.class, 200);
        this.getSellerTransactionsAuditExcludeFields = configHandler.getValueList("audit.GET_SELLER_TRANSACTIONS_AUDIT_EXCLUDE_FIELDS",
                String.class, Collections.emptyList());
        this.getMyeBaySellingAuditExcludeFields = configHandler.getValueList("audit.GET_MYEBAY_SELLING_AUDIT_EXCLUDE_FIELDS",
                String.class, Collections.emptyList());
        this.enableEbayReference = configHandler.getValue("ENABLE_EBAY_REFERENCE", Boolean.class, false);
        this.euvatEbayVatId = configHandler.getValue("EUVAT_EBAY_VAT_ID", String.class, "");
        this.esauthSecret = configHandler.getValue("ES_AUTH_SECRET", String.class, "MjA2OGE1OTJhOWEwNDYzOThjN2NiNmMyNmJmMGY1ZGM6NnZ3WkZma3dSWEpsajRKME5KYmFDRzMyU2dZb1owWkZxdmkwTUFLVVdBZ1JoUGQ3NzdablhuRFRtejlZcFpGUw==");
        this.modifiedDateMaxDaysBack = configHandler.getValue("MODIFIED_DATE_MAX_DAYS_BACK", Integer.class, 90);
        this.serviceVersion = configHandler.getValue("SERVICE_VERSION", String.class, "1271");
        this.sellingSummaryMaxVersion = configHandler.getValue("SELLING_SUMMARY_MAX_VERSION", Integer.class, 500);
        this.summaryMaxVersion = configHandler.getValue("SUMMARY_MAX_VERSION", Integer.class, 605);
        this.siteApprovedForBuyerRegistrationAddress = configHandler.getValue("BUYER_REGISTRATION_SITE", String.class, "77");
        this.minimumSchemaVersion = configHandler.getValue("MINIMUM_SCHEMA_VERSION", Integer.class, 347);
        this.bpBatchSize = configHandler.getValue("BP_BATCH_SIZE",Integer.class,30);
        this.shippingCarrierMapping = configHandler.getValueList("SHIPPING_CARRIER_MAPPING", String.class, Collections.emptyList());
        this.orderTotalCalculationLegacy = configHandler.getValue("ORDER_TOTAL_CALCULATION_LEGACY", Boolean.class, Boolean.TRUE);
        this.orderTotalIncludeTaxEnabledAppName = new HashSet<>(configHandler.getValueList("ORDER_TOTAL_INCLUDE_TAX_ENABLED_APP_NAME",
                String.class, Collections.emptyList()));
        this.orderTotalIncludeTaxEnabledSellerId = new HashSet<>(configHandler.getValueList("ORDER_TOTAL_INCLUDE_TAX_ENABLED_SELLER_ID",
                String.class, Collections.emptyList()));
        this.orderTotalIncludeTaxEnabledVersion = configHandler.getValue("ORDER_TOTAL_INCLUDE_TAX_ENABLED_VERSION", Integer.class, 99999);
        this.enableUserStatusValidationForGMES = configHandler.getValue("ENABLE_GMES_USER_VALIDATION", Boolean.class, false);
        this.pictureDetailsVersion = configHandler.getValue("PICTURE_DETAILS_VERSION", Integer.class, 439);
        this.taxIdentifierList = configHandler.getValueList("TAX_IDENTIFIER_SITE_LIST", String.class, Arrays.asList("101", "186"));
        this.gmesAuditSkipAppIDs =configHandler.getValueList("GMES_AUDIT_SKIP_APPIDS", String.class, Collections.emptyList());
        this.gmesSamplePercent = configHandler.getValue("GMES_SAMPLE_PERCENT",Double.class,1.0);
        this.feedback_users_max_limit = configHandler.getValue("FEEDBACK_USERS_MAX_LIMIT",Integer.class,15);
        this.isSVLSNewParallelCallOn = configHandler.getValue("IS_SVLS_NEW_PARALLEL_CALL_ON", Boolean.class, Boolean.FALSE);
        this.gmesSoldDefaultDays = configHandler.getValue("GMES_SOLD_DEFAULT_DAYS", Integer.class, 31);
    }
}
