package com.ebay.app.apisellingextsvc.enums;

public enum ShipmentEnum {
    notshipped("notshipped"),
    partiallyshipped("partiallyshipped"),
    shipped("shipped");

    private String name;
    private ShipmentEnum(String s) {
        name = s;
    }

    public boolean equalsName(String otherName){
        return (otherName == null)? false:name.equals(otherName);
    }

    public String toString(){
        return name;
    }
}
