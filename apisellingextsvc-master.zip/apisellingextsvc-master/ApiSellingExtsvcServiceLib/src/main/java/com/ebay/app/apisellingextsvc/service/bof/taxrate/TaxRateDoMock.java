package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import com.ebay.af.common.flag.FlagMask;

import java.util.Date;

public class TaxRateDoMock implements TaxRate {
    private int siteId;
    private int countryId;
    private double taxPercentage;

    @Override
    public int getSiteId() {
        return siteId;
    }

    @Override
    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    @Override
    public int getCountryId() {
        return countryId;
    }

    @Override
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    @Override
    public double getTaxPercentage() {
        return taxPercentage;
    }

    @Override
    public void setTaxPercentage(double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }

    @Override
    public boolean isEffective(Date var1) {
        return false;
    }

    @Override
    public Date getEffectiveDate() {
        return null;
    }

    @Override
    public void setEffectiveDate(Date var1) {

    }

    @Override
    public Date getTerminationDate() {
        return null;
    }

    @Override
    public void setTerminationDate(Date var1) {

    }

    @Override
    public String getUserState() {
        return null;
    }

    @Override
    public void setUserState(String var1) {

    }

    @Override
    public boolean equalsData(Object o) {
        return false;
    }

    @Override
    public boolean hasFlag(FlagMask flagMask) {
        return false;
    }

    @Override
    public void setFlag(FlagMask flagMask, boolean b) {

    }
}
