package com.ebay.app.apisellingextsvc.builders.gmes;

import com.ebay.app.apisellingextsvc.builders.BuyerBuilder;
import com.ebay.app.apisellingextsvc.builders.OrderTransactionBuilder;
import com.ebay.app.apisellingextsvc.builders.PaymentHoldDetailsBuilder;
import com.ebay.app.apisellingextsvc.builders.TransactionStatusBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.mappers.CommentTypeMapper;
import com.ebay.app.apisellingextsvc.mappers.FeedbackTypeMapper;
import com.ebay.app.apisellingextsvc.mappers.PaidStatusCodeMapper;
import com.ebay.app.apisellingextsvc.service.bof.exchangerate.ExchangeRateBofImpl;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.MoneyExchangeHelper;
import com.ebay.app.apisellingextsvc.utils.OrderBuilderUtil;
import com.ebay.app.apisellingextsvc.utils.SiteUtils;
import com.ebay.cos.las.type.BulkUserNoteResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.FeedbackInfoTypeCS;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.order.common.v1.AdjustmentStatusType;
import com.ebay.order.common.v1.AdjustmentType;
import com.ebay.order.common.v1.AdjustmentTypeEnumType;
import com.ebay.order.common.v1.FeedbackStatusTypeEnum;
import com.ebay.order.common.v1.LineItem;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.CurrencyCodeType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.FeedbackInfoType;
import ebay.apis.eblbasecomponents.TransactionPlatformCodeType;
import ebay.apis.eblbasecomponents.TransactionType;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class GMESOrderTransactionBuilder extends OrderTransactionBuilder {
    private final List<DetailLevelCodeType> detailLevels;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final IContentHelper contentHelper;
    private final BulkUserNoteResponse bulkUserNoteResponse;
    private final Integer version;
    private final ContractResponseType contractResponseType;

    public GMESOrderTransactionBuilder(Task<?> task,
                                       OrderCSXType order,
                                       LineItemXType lineItem,
                                       IContentHelper contentHelper,
                                       SiteContext siteContext,
                                       List<DetailLevelCodeType> detailLevels,
                                       ApiSellingExtSvcConfigValues configValues,
                                       int trxVersion,
                                       Map<Long, ListingActivity> itemIdListingActivityMap,
                                       BulkUserNoteResponse bulkUserNoteResponse,
                                       Integer version,
                                       ContractResponseType contractResponseType) {

        super(task, order, lineItem, siteContext, configValues, trxVersion);
        this.detailLevels = detailLevels;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.contentHelper = contentHelper;
        this.bulkUserNoteResponse = bulkUserNoteResponse;
        this.version = version;
        this.contractResponseType = contractResponseType;
    }

    @Override
    protected TransactionType doBuild() {
        TransactionType transaction = super.doBuild();
        transaction.setTotalTransactionPrice(getTotalTransactionPrice());
        transaction.setSellerPaidStatus(PaidStatusCodeMapper.map(order));
        transaction.setPlatform(TransactionPlatformCodeType.E_BAY);
        AmountType totalPrice = getTotalPrice();
        if (totalPrice != null) {
            transaction.setTotalPrice(totalPrice);
        }
        transaction.setItem(new GMESOrderItemBuilder(task, lineItem, configValues, itemIdListingActivityMap,
                detailLevels, bulkUserNoteResponse, version, siteContext,
                contractResponseType, contentHelper).build());
        transaction.setStatus(new TransactionStatusBuilder(task, order).build());
        transaction.setBuyer(new BuyerBuilder(task, trxVersion, configValues, contentHelper,
                order.getBuyer(), lineItem.getDatePurchased().getValue(), order.getAddress(), detailLevels).build());
        transaction.setTransactionPrice(
                getTransactionPrice(lineItem.getUnitCost(), lineItem.getDiscountedCost(), lineItem.getDepositItemFullUnitCost()));
        if (getBestOfferStatus(lineItem.getAttribute())) {
            CurrencyCodeType currency = transaction.getTransactionPrice().getCurrencyID();
            if (currency != null && !currency.equals(SiteUtils.getSiteCurrency(String.valueOf(siteContext.viewingSiteId)))) {
                transaction.setConvertedTransactionPrice(MoneyExchangeHelper.exchange(new ExchangeRateBofImpl(), transaction.getTransactionPrice(), siteContext.viewingSiteId));
            }
        }
        boolean isMultiLegShipping = isMultiLegShipping(order.getLogistics());
        if (isMultiLegShipping) {
            transaction.setIsMultiLegShipping(isMultiLegShipping);
        }
        setFeedbackCS(transaction);
        setFeedback(transaction);

//        if (PaymentHoldStatusCodeType.PAYMENT_HOLD.equals(transaction.getStatus().getPaymentHoldStatus())) {
//            transaction.setPaymentHoldDetails(new PaymentHoldDetailsBuilder(task, order).build());
//        }

        if (configValues.getIssueRefundEnabledCountries().contains(siteContext.viewingSiteId)) {
            String refundStatus = OrderBuilderUtil.getRefundStatus(order);
            if (refundStatus != null) {
                transaction.setRefundStatus(refundStatus);
            }

            AmountType refundAmount = OrderBuilderUtil.getRefundAmount(order);
            if (refundAmount != null && refundAmount.getValue() > 0) {
                transaction.setRefundAmount(refundAmount);
            }
        }

        return transaction;
    }

    private AmountType getTotalTransactionPrice() {
        AmountType depositItemFullUnitCost = Optional.of(this.lineItem)
                .map(LineItem::getDepositItemFullUnitCost)
                .map(AmountTypeUtil::getAmountType)
                .orElse(null);
        if (depositItemFullUnitCost != null) {
            return depositItemFullUnitCost;
        }
        AmountType discountedItemPrice = getPricelineCost(PricelineTypeEnum.DISCOUNTED_ITEM_COST);
        if (discountedItemPrice != null && discountedItemPrice.getValue() != ApiSellingExtSvcConstants.ZERO_AMOUNT) {
            return discountedItemPrice;
        }
        return getPricelineCost(PricelineTypeEnum.ITEM_COST);
    }

    protected AmountType getPricelineCost(PricelineTypeEnum targetType) {
        return Optional.of(this.lineItem).map(LineItem::getLineItemTotal)
                .flatMap(total -> total.getPriceLines().stream()
                        .filter(p -> targetType.equals(p.getType())).findFirst())
                .map(PriceLine::getAmount).map(AmountTypeUtil::getAmountType)
                .orElse(AmountTypeUtil.getDefaultZeroAmountType(order));
    }

    private void setFeedbackCS(TransactionType transaction) {
        FeedbackInfoTypeCS feedbackInfoCS = order.getLineItemTypes().stream()
                .filter(i -> i.getSourceId().getTransactionId().equals(transaction.getTransactionID()))
                .map(LineItemXType::getFeedbackInfoCS)
                .filter(Objects::nonNull)
                .findFirst()
                .orElse(null);

        if (feedbackInfoCS != null) {
            if (feedbackInfoCS.getBuyerFeedback().equals(FeedbackStatusTypeEnum.FEEDBACK_LEFT)) {
                transaction.setFeedbackReceived(new FeedbackInfoType());
                transaction.getFeedbackReceived().setCommentType(FeedbackTypeMapper.map(feedbackInfoCS.getDisplayTypeLeftByBuyer()));
            }
            if (feedbackInfoCS.getSellerFeedback().equals(FeedbackStatusTypeEnum.FEEDBACK_LEFT)) {
                transaction.setFeedbackLeft(new FeedbackInfoType());
                transaction.getFeedbackLeft().setCommentType(FeedbackTypeMapper.map(feedbackInfoCS.getDisplayTypeLeftBySeller()));
            }
        }
    }

    private void setFeedback(TransactionType transaction) {
        if (transaction.getFeedbackReceived() == null && transaction.getFeedbackLeft() == null) {
            com.ebay.order.common.v1.FeedbackInfoType feedbackInfo = order.getLineItemTypes().stream()
                    .filter(i -> i.getSourceId().getTransactionId().equals(transaction.getTransactionID()))
                    .map(LineItemXType::getFeedbackInfo)
                    .filter(Objects::nonNull)
                    .findFirst()
                    .orElse(null);

            if (feedbackInfo != null) {
                if (feedbackInfo.getBuyerFeedback().equals(FeedbackStatusTypeEnum.FEEDBACK_LEFT)) {
                    transaction.setFeedbackReceived(new FeedbackInfoType());
                    transaction.getFeedbackReceived().setCommentType(CommentTypeMapper.map(feedbackInfo.getBuyerFeedbackDetail().getCommentType()));
                }
                if (feedbackInfo.getSellerFeedback().equals(FeedbackStatusTypeEnum.FEEDBACK_LEFT)) {
                    transaction.setFeedbackReceived(new FeedbackInfoType());
                    transaction.getFeedbackReceived().setCommentType(CommentTypeMapper.map(feedbackInfo.getBuyerFeedbackDetail().getCommentType()));
                }
            }
        }
    }
}
