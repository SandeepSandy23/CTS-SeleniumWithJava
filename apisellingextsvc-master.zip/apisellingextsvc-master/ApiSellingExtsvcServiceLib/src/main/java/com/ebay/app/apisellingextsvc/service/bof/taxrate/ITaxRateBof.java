package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import java.util.Date;

public interface ITaxRateBof {
    TaxRate findActiveTaxRate(int siteId, int countryId, Date inputDate);
}
