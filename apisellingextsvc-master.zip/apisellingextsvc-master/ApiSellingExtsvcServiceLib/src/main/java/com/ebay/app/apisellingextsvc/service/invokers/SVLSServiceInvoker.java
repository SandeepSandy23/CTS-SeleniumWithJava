package com.ebay.app.apisellingextsvc.service.invokers;


import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.SVLSServiceClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.svls.SvlsRequest;
import com.ebay.selling.svls.item.Item;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;
import java.util.List;
import java.util.Map;

public class SVLSServiceInvoker extends BaseServiceInvoker<SvlsRequest,Item,SvlsRequest>  {

    // use for mock
    public static final String NAME = "SVLSServiceInvoker";
    public SVLSServiceInvoker(TracerContext tracerContext) {
        super( NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<SvlsRequest, Item> getGingerClient(SvlsRequest svlsRequest) {
        return new SVLSServiceClient();
    }

    protected GingerClientRequest<SvlsRequest> getGingerRequest(SvlsRequest svlsRequest, HttpHeaders httpHeaders) {
        GingerClientRequest<SvlsRequest> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        removeHeadersForUserReadSvc(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(svlsRequest);
        return gingerClientRequest;
    }
}
