package com.ebay.app.apisellingextsvc.service.dal.saleaggregator;

import com.ebay.integ.dal.DalDOI;
import com.ebay.persistence.Column;
import com.ebay.persistence.Table;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Table(name = "EBAY_ITEMS")
public interface SaleAggregator extends DalDOI {
    @Column(name = "SELLER_PRODUCT_ID")
    String getSellerProId();

    void setSellerProId(String sellerProId);

    @Id
    @Column(name = "ID")
    long getItemId();

    void setItemId(long itemId);

    @Column(name = "SELLER")
    long getSellerId();

    void setSellerId(long sellerId);


}
