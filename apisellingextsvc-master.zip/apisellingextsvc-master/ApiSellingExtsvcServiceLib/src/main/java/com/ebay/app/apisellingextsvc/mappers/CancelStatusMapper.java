package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.CancelStatusTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.CancelStatusCodeType;

public class CancelStatusMapper {

    private static final ImmutableMap<CancelStatusTypeEnum, CancelStatusCodeType> mapName
            = new ImmutableMap.Builder<CancelStatusTypeEnum, CancelStatusCodeType>()
            .put(CancelStatusTypeEnum.INVALID, CancelStatusCodeType.INVALID)
            .put(CancelStatusTypeEnum.NOT_APPLICABLE, CancelStatusCodeType.NOT_APPLICABLE)
            .put(CancelStatusTypeEnum.CANCEL_REQUESTED, CancelStatusCodeType.CANCEL_REQUESTED)
            .put(CancelStatusTypeEnum.CANCEL_PENDING, CancelStatusCodeType.CANCEL_PENDING)
            .put(CancelStatusTypeEnum.CANCEL_REJECTED, CancelStatusCodeType.CANCEL_REJECTED)
            .put(CancelStatusTypeEnum.CANCEL_CLOSED_NO_REFUND, CancelStatusCodeType.CANCEL_CLOSED_NO_REFUND)
            .put(CancelStatusTypeEnum.CANCEL_CLOSED_WITH_REFUND, CancelStatusCodeType.CANCEL_CLOSED_WITH_REFUND)
            .put(CancelStatusTypeEnum.CANCEL_CLOSED_UNKNOWN_REFUND, CancelStatusCodeType.CANCEL_CLOSED_UNKNOWN_REFUND)
            .put(CancelStatusTypeEnum.CANCEL_CLOSED_FOR_COMMITMENT, CancelStatusCodeType.CANCEL_CLOSED_FOR_COMMITMENT)
            .build();

    private CancelStatusMapper() {
    }

    public static CancelStatusCodeType map(CancelStatusTypeEnum cancelStatus) {
        return mapName.getOrDefault(cancelStatus, CancelStatusCodeType.NOT_APPLICABLE);
    }

}
