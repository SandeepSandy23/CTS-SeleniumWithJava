package com.ebay.app.apisellingextsvc.builders.gst.proforma;

import com.ebay.app.apisellingextsvc.builders.proforma.BaseTransactionArrayTypeBuilder;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.service.bof.saleaggregator.ISaleAggregatorBof;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserInfo;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GSTProformaOrderTransactionArrayBuilder extends BaseTransactionArrayTypeBuilder {
    private final ContractResponseType contractResponseType;
    private final ProformaOrderXType proformaOrder;
    private final int trxVersion;
    private final List<DetailLevelCodeType> detailLevels;
    private final ApiSellingExtSvcConfigValues configValues;
    private final ISaleAggregatorBof saleAggregatorBof;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final IContentHelper contentHelper;
    private final SellerProfileDataContext dataContext;
    private final boolean includeContainingOrder;
    private final SiteContext siteContext;

    private final  Map<String, Item> svlsItemInfoMap;

    public GSTProformaOrderTransactionArrayBuilder(Task<?> task,
                                                @Nonnull ContractResponseType contractResponseType,
                                                int trxVersion, SiteContext siteContext,
                                                IContentHelper contentHelper,
                                                List<DetailLevelCodeType> detailLevels,
                                                ApiSellingExtSvcConfigValues configValues,
                                                SellerProfileDataContext dataContext, ISaleAggregatorBof saleAggregatorBof,
                                                boolean includeContainingOrder,
                                                Map<Long, ListingActivity> itemIdListingActivityMap,
                                                Map<String, Item> svlsItemInfoMap ) {
        super(task, contractResponseType);
        this.contractResponseType = contractResponseType;
        this.proformaOrder = contractResponseType.getProformaOrder();
        this.trxVersion = trxVersion;
        this.siteContext = siteContext;
        this.contentHelper = contentHelper;
        this.detailLevels = detailLevels;
        this.configValues = configValues;
        this.dataContext = dataContext;
        this.saleAggregatorBof = saleAggregatorBof;
        this.includeContainingOrder = includeContainingOrder;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.svlsItemInfoMap = svlsItemInfoMap;
    }

    @Override
    protected List<TransactionType> doBuild() {

        List<TransactionType> transactionTypeList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(proformaOrder.getLineItemTypes())) {
            for (ProformaOrderLineItemXType lineItem : proformaOrder.getLineItemTypes()) {
                if (lineItem != null ) {
                    transactionTypeList.add(new GSTProformaOrderTransactionBuilder(task, contractResponseType, lineItem, siteContext, contentHelper, detailLevels,
                            configValues, trxVersion, includeContainingOrder, itemIdListingActivityMap, svlsItemInfoMap).build());
                }
            }
        }
        return transactionTypeList;
    }

}

