package com.ebay.app.apisellingextsvc.builders.gmes;

import com.ebay.app.apisellingextsvc.builders.proforma.BaseTransactionArrayTypeBuilder;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.cos.las.type.BulkUserNoteResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GMESProformaOrderTransactionArrayBuilder extends BaseTransactionArrayTypeBuilder {

    private final ProformaOrderXType proformaOrder;
    private final int trxVersion;
    private final List<DetailLevelCodeType> detailLevels;
    private final ApiSellingExtSvcConfigValues configValues;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final IContentHelper contentHelper;
    private final SiteContext siteContext;
    private final BulkUserNoteResponse bulkUserNoteResponse;
    private final ContractResponseType contractResponseType;

    public GMESProformaOrderTransactionArrayBuilder(Task<?> task,
                                                    @Nonnull ContractResponseType contractResponseType,
                                                    int trxVersion,
                                                    IContentHelper contentHelper,
                                                    List<DetailLevelCodeType> detailLevels,
                                                    ApiSellingExtSvcConfigValues configValues,
                                                    SiteContext siteContext,
                                                    Map<Long, ListingActivity> itemIdListingActivityMap,
                                                    BulkUserNoteResponse bulkUserNoteResponse) {
        super(task, contractResponseType);
        this.proformaOrder = contractResponseType.getProformaOrder();
        this.trxVersion = trxVersion;
        this.contentHelper = contentHelper;
        this.detailLevels = detailLevels;
        this.configValues = configValues;
        this.siteContext = siteContext;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.bulkUserNoteResponse = bulkUserNoteResponse;
        this.contractResponseType = contractResponseType;
    }

    @Override
    protected List<TransactionType> doBuild() {
        List<TransactionType> transactionTypeList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(proformaOrder.getLineItemTypes())) {
            for (ProformaOrderLineItemXType lineItem : proformaOrder.getLineItemTypes()) {
                if (lineItem != null) {
                    transactionTypeList.add(new GMESProformaOrderTransactionBuilder(task, proformaOrder, lineItem, siteContext, contentHelper, detailLevels,
                            configValues, trxVersion, itemIdListingActivityMap, bulkUserNoteResponse, contractResponseType).build());
                }
            }
        }
        return transactionTypeList;
    }

}
