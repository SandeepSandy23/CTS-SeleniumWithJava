package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.cos.las.type.BulkUserNote;
import com.ebay.cos.las.type.BulkUserNoteOP;
import com.ebay.cos.las.type.BulkUserNoteRequest;
import com.ebay.cos.las.type.BulkUserNoteResponse;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.order.common.v1.LineItemSource;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;
import org.springframework.util.CollectionUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class LASBulkUserNoteTask implements Task<BulkUserNoteResponse>, ITaskResultInjectable {

    private final Map<String, Object> resultMap = new HashMap<>();
    private final User user;
    private final IServiceInvoker<BulkUserNoteRequest, BulkUserNoteResponse> lasBulkUserNoteInvoker;
    private final List<ErrorType> errorList;
    private final Boolean includeNotes;

    private final HttpHeaders headers;

    public LASBulkUserNoteTask(
            IServiceInvoker<BulkUserNoteRequest, BulkUserNoteResponse> lasBulkUserNoteInvoker,
            List<ErrorType> errorList,
            HttpHeaders headers,
            User user, Boolean includeNotes) {
        this.lasBulkUserNoteInvoker = lasBulkUserNoteInvoker;
        this.errorList = errorList;
        this.user = user;
        this.headers = headers;
        this.includeNotes = includeNotes;
    }

    @Override
    public BulkUserNoteResponse call() {
        if (!Boolean.TRUE.equals(includeNotes)) {
            return null;
        }
        ContractResponse contractResponse = (ContractResponse) resultMap.get(ContractResponse.class.getName());
        List<ContractResponseType> contractResponseTypeList = Optional.ofNullable(contractResponse)
                .map(ContractResponse::getMembers)
                .orElse(Collections.emptyList());
        if (CollectionUtils.isEmpty(contractResponseTypeList)) {
            return null;
        }
        headers.getRequestHeaders().putSingle(ApiSellingExtSvcConstants.X_EBAY_C_ENDUSERCTX, HeaderUtil.getEndUserCtx(user.getUserName(), user.getUserId()));
        BulkUserNoteResponse bulkUserNotesResponse = this.lasBulkUserNoteInvoker.getResponse(getBulkUserNoteRequest(contractResponse), headers);
        return bulkUserNotesResponse;
    }

    public static BulkUserNoteRequest getBulkUserNoteRequest(ContractResponse cosmosResponse) {
        BulkUserNoteRequest bulkUserNoteRequest = new BulkUserNoteRequest();
        List<BulkUserNote> bulkUserNotes = new ArrayList<>();
        for (ContractResponseType member : cosmosResponse.getMembers()) {
            if (ContractResponseUtil.isOrder(member))
                for (LineItemXType lineItem : member.getOrder().getLineItemTypes()) {
                    BulkUserNote bulkUserNote = new BulkUserNote();
                    bulkUserNote.setOp(BulkUserNoteOP.GET);
                    Optional.ofNullable(lineItem.getSourceId())
                            .map(LineItemSource::getTransactionId)
                            .ifPresent(transactionId -> bulkUserNote.setTransactionId(Long.parseLong(transactionId)));
                    Optional.ofNullable(lineItem.getSourceId())
                            .map(LineItemSource::getItemId)
                            .ifPresent(itemId -> bulkUserNote.setListingId(Long.parseLong(itemId)));
                    bulkUserNotes.add(bulkUserNote);
                }
            if (ContractResponseUtil.isProformaOrder(member))
                for (ProformaOrderLineItemXType proformalineItem : member.getProformaOrder().getLineItemTypes()) {
                    BulkUserNote bulkUserNote = new BulkUserNote();
                    bulkUserNote.setOp(BulkUserNoteOP.GET);
                    Optional.ofNullable(proformalineItem.getSourceId())
                            .map(LineItemSource::getTransactionId)
                            .ifPresent(transactionId -> bulkUserNote.setTransactionId(Long.parseLong(transactionId)));
                    Optional.ofNullable(proformalineItem.getSourceId())
                            .map(LineItemSource::getItemId)
                            .ifPresent(itemId -> bulkUserNote.setListingId(Long.parseLong(itemId)));
                    bulkUserNotes.add(bulkUserNote);
                }
        }
        bulkUserNoteRequest.setBulkUserNotes(bulkUserNotes.toArray(new BulkUserNote[bulkUserNotes.size()]));
        return bulkUserNoteRequest;
    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
