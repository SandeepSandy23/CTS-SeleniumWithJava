package com.ebay.app.apisellingextsvc.audit.comparator;

import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

public interface IJsonNodeComparator {
    boolean customCompareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report);
}
