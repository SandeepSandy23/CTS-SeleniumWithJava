package com.ebay.app.apisellingextsvc.config;

import com.ebay.app.apisellingextsvc.utils.IConfigHandler;
import com.ebay.raptorio.globalconfig.impl.GlobalConfigPropertySource;

import java.util.Collections;

public class ApiSellingExtSvcConfig {

    public static IConfigHandler getConfig(GlobalConfigPropertySource globalConfig, Integer siteId) {
        GlobalConfigProvider globalConfigProvider = new GlobalConfigProvider(globalConfig, siteId);
        return new ConfigHandler(Collections.singletonList(globalConfigProvider));
    }

    // public static IConfigHandler getConfigTest(IConfigProvider configOverride, String requestConfig) {
    //     return ServiceConfig.getConfigTest(configOverride, requestConfig, CONFIG_FILENAME);
    // }

}
