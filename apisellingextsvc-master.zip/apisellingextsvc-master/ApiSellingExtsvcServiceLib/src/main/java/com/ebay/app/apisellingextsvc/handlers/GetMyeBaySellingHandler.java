package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import com.ebay.app.apisellingextsvc.application.common.response.GetMyeBaySellingResponse;
import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.exception.ApplicationException;
import com.ebay.app.apisellingextsvc.service.invokers.UserReadServiceInvoker;
import com.ebay.app.apisellingextsvc.tasks.GMES.GMESActiveContainerTask;
import com.ebay.app.apisellingextsvc.tasks.GMES.GMESDeletedSoldContainerTask;
import com.ebay.app.apisellingextsvc.tasks.GMES.GMESDeletedUnsoldContainerTask;
import com.ebay.app.apisellingextsvc.tasks.GMES.GMESResponseBuilderTask;
import com.ebay.app.apisellingextsvc.tasks.GMES.GMESScheduledContainerTask;
import com.ebay.app.apisellingextsvc.tasks.GMES.GMESSoldContainerTask;
import com.ebay.app.apisellingextsvc.tasks.GMES.GMESSummaryContainerTask;
import com.ebay.app.apisellingextsvc.tasks.GMES.GMESUnsoldContainerTask;
import com.ebay.app.apisellingextsvc.tasks.OutputSelectorTask;
import com.ebay.app.apisellingextsvc.tasks.UserReadServiceInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.filter.BasicRequestValidatorFilter;
import com.ebay.app.apisellingextsvc.tasks.filter.GetMyeBaySellingRequestFilter;
import com.ebay.app.apisellingextsvc.tasks.filter.IFilter;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.app.apisellingextsvc.utils.TaskOrchestrationUtil;
import com.ebay.raptor.orchestrationv2.task.TaskConfiguration;
import ebay.apis.eblbasecomponents.AckCodeType;
import ebay.apis.eblbasecomponents.ErrorType;
import io.opentelemetry.context.Scope;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Main handler class for orchestrating the service calls and building response
 */
public class GetMyeBaySellingHandler extends ApiSellingExtApplicationHandler<GetMyeBaySellingResponse> {

    private final GetMyeBaySellingRequest request;

    private final Executor executor;

    public GetMyeBaySellingHandler(GetMyeBaySellingRequest request, Executor executor) {
        super(request.getHeaders());
        this.request = request;
        this.executor = executor;
    }

    public static GetMyeBaySellingResponse getResponse(GetMyeBaySellingRequest request, Executor executor) {
        GetMyeBaySellingHandler getMyeBaySellingHandler =
                new GetMyeBaySellingHandler(request, executor);

        GetMyeBaySellingAuditHandler audit = null;
        if (request.getConfigValues().getGmesAuditEnabled() &&  sampleReadyForAudit(request)){
            audit = new  GetMyeBaySellingAuditHandler(request);
        }

        ApiSellingExtApplicationProcessor<GetMyeBaySellingResponse> apiSellingExtApplicationHandler =
                new ApiSellingExtApplicationProcessor<GetMyeBaySellingResponse>(
                        request,
                        getMyeBaySellingHandler,
                        audit,
                        getFilters(request)
                );
        return apiSellingExtApplicationHandler.handle().response;
    }

    private static boolean sampleReadyForAudit(GetMyeBaySellingRequest request) {
       return !request.getConfigValues().getGmesAuditSkipAppIDs().contains(HeaderUtil.getHeader(request.getHeaders(),
                                                                                          ApiSellingExtSvcConstants.X_EBAY_SOA_USE_CASE_NAME)) && Math.random() < request.getConfigValues().getGmesSamplePercent();
    }

    private static List<IFilter> getFilters(GetMyeBaySellingRequest request) {
        return Arrays.asList(
                new BasicRequestValidatorFilter(request, request.contentResource, request.requestType.getErrorLanguage(), request.getConfigValues()),
                new GetMyeBaySellingRequestFilter(request.getConfigValues(), request.requestType, request.contentResource)
        );
    }

    @Override
    public GetMyeBaySellingResponse handle() {

        try (Scope scope = getOpenTeleSpan(); io.opentracing.Scope tracerScope = createTracerSpan()) {


            //All container tasks
            GMESSoldContainerTask soldContainerTask = new GMESSoldContainerTask(request, executor, request.requestType.getDetailLevel());
            GMESActiveContainerTask activeContainerTask = new GMESActiveContainerTask(request, executor, request.requestType.getDetailLevel());
            GMESDeletedSoldContainerTask deletedSoldContainerTask = new GMESDeletedSoldContainerTask(request, executor, request.requestType.getDetailLevel());
            GMESScheduledContainerTask scheduledContainerTask = new GMESScheduledContainerTask(request, executor, request.requestType.getDetailLevel());
            GMESUnsoldContainerTask gmesUnsoldContainerTask = new GMESUnsoldContainerTask(request, executor, request.requestType.getDetailLevel());
            GMESDeletedUnsoldContainerTask gmesDeletedUnsoldContainerTask = new GMESDeletedUnsoldContainerTask(request, executor, request.requestType.getDetailLevel());
            GMESSummaryContainerTask summaryContainerTask = new GMESSummaryContainerTask(request, executor, request.requestType.getDetailLevel());
            GMESResponseBuilderTask gmesResponseBuilderTask = new GMESResponseBuilderTask(request.getErrorList());

            //Task Configurations
            TaskConfiguration getMyeBaySellingResponseBuilderTaskConfig = TaskOrchestrationUtil
                    .createTaskConfiguration(soldContainerTask, activeContainerTask, deletedSoldContainerTask,
                            scheduledContainerTask, gmesUnsoldContainerTask, gmesDeletedUnsoldContainerTask, summaryContainerTask);

            if (request.configValues.enableUserStatusValidationForGMES) {
                //User Validation
                UserReadServiceInvokeTask userReadServiceInvokeTask = new UserReadServiceInvokeTask(new UserReadServiceInvoker(this.request.getTracerContext()), request.getErrorList(), this.request.getHeaders(), this.request.getUser().getUserId(), this.request.contentResource);
                getMyeBaySellingResponseBuilderTaskConfig.addDependency(userReadServiceInvokeTask);
                request.orchestrator.execute(userReadServiceInvokeTask);
            }

            //Execute Tasks
            request.orchestrator.execute(soldContainerTask);
            request.orchestrator.execute(activeContainerTask);
            request.orchestrator.execute(deletedSoldContainerTask);
            request.orchestrator.execute(scheduledContainerTask);
            request.orchestrator.execute(gmesUnsoldContainerTask);
            request.orchestrator.execute(gmesDeletedUnsoldContainerTask);
            request.orchestrator.execute(summaryContainerTask);

            CompletableFuture<GetMyeBaySellingResponse> gmesResponsebuilderTaskFuture = request.orchestrator.execute(gmesResponseBuilderTask, getMyeBaySellingResponseBuilderTaskConfig);
            GetMyeBaySellingResponse getMyeBaySellingResponse = (GetMyeBaySellingResponse) TaskOrchestrationUtil.safeGet(gmesResponsebuilderTaskFuture);
            return (GetMyeBaySellingResponse) TaskOrchestrationUtil.safeGet(request.orchestrator.execute(new OutputSelectorTask(request.getRequestType(), getMyeBaySellingResponse)));
        } finally {
            this.request.getTracerContext().getOpenTeleParentSpan().end();
            this.request.getTracerContext().getOpenTracingParentSpan().finish();
        }

    }

    private Scope getOpenTeleSpan() {
        return this.request.getTracerContext()
                           .getOpenTeleParentSpan()
                           .makeCurrent();
    }

    private io.opentracing.Scope createTracerSpan() {
        return this.request.getTracerContext()
                           .getOpenTracingTracer()
                           .scopeManager()
                           .activate(this.request.getTracerContext().getOpenTracingParentSpan(), true);
    }

    @Override
    protected GetMyeBaySellingResponse handleException(ApplicationException e) {
        GetMyeBaySellingResponse resp = new GetMyeBaySellingResponse();
        resp.setAck(AckCodeType.FAILURE);
        resp.getErrors().add((ErrorType) e.entity);
        resp.setBuild(ApiSellingExtSvcConstants.BUILD);
        return resp;
    }

}
