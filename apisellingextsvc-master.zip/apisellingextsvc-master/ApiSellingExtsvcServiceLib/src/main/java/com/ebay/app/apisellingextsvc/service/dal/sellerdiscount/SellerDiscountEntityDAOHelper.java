package com.ebay.app.apisellingextsvc.service.dal.sellerdiscount;

import com.ebay.integ.dal.BaseDo2;

import java.util.Calendar;

public class SellerDiscountEntityDAOHelper {
    private static final SellerDiscountEntityDAOHelper s_instance = new SellerDiscountEntityDAOHelper();
    private static final int TABLE_HINT_ENTITY = 1;
    private final Calendar partitionStartDateOffset = Calendar.getInstance();

    private SellerDiscountEntityDAOHelper() {
        this.partitionStartDateOffset.clear();
        this.partitionStartDateOffset.set(1, 2005);
        this.partitionStartDateOffset.set(6, 1);
    }

    public static SellerDiscountEntityDAOHelper getInstance() {
        return s_instance;
    }


    public void setFinderHints(BaseDo2 dataObj) {
        this.setHint(dataObj);
        dataObj.setReadOnlyHint(true);
    }

    public void setHint(BaseDo2 dataObj) {
        dataObj.setTableHint(TABLE_HINT_ENTITY);
    }

}
