package com.ebay.app.apisellingextsvc.audit.comparator.facet;

import com.ebay.app.apisellingextsvc.audit.comparator.CustomExtComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.IJsonNodeComparator;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

import javax.annotation.Nonnull;

public class ItemTitleComparator implements IJsonNodeComparator {

    private final CustomExtComparator comparator;

    public ItemTitleComparator(CustomExtComparator comparator) {
        this.comparator = comparator;
    }

    /**
     * keep only printable chars, e.g. convert "🌷Farmona Natural" to "Farmona Natural"
     *
     * @param text original string
     * @return trimmed string
     */
    private String trimNonPrintableChars(@Nonnull String text) {
        return text.replaceAll("[^\\x00-\\x7F]", "");
    }

    @Override
    public boolean customCompareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        if (pattern.isTextual()) {
            if (!trimNonPrintableChars(org.textValue()).equals(trimNonPrintableChars(tar.textValue()))) {
                comparator.printDiff(key, path, org.asText(), tar.asText(), false, report);
                return false;
            } else {
                return true;
            }
        } else {
            return comparator.defaultCompareNode(org, tar, pattern, path, key, report);
        }
    }
}
