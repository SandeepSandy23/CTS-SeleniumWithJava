package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;

public class ItemHostInfoDoImpl extends ItemHostInfoCodeGenDoImpl implements ItemHostInfo {
    public ItemHostInfoDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public void beforeSave() {
        super.beforeSave();
        this.set_hostId(this.getHostId());
    }
    
}

