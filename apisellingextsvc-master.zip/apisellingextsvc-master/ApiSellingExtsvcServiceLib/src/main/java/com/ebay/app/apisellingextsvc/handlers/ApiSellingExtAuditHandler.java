package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.application.common.request.BaseApplicationRequest;
import com.ebay.app.apisellingextsvc.application.common.response.IServiceResponse;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.tasks.audit.ApisellingioAuditDataTask;
import com.ebay.app.apisellingextsvc.utils.Headers;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;

public abstract class ApiSellingExtAuditHandler<T> implements IAuditHandler<T> {

    protected CompletableFuture<IServiceResponse> apisellingioResponseFuture;
    protected HttpHeaders httpHeaders;
    protected ApiSellingExtSvcConfigValues configValue;
    private final BaseApplicationRequest request;


    public ApiSellingExtAuditHandler(BaseApplicationRequest request) {
        this.request = request;
    }

    @Override
    public void preAction(IServiceInvoker<String, String> apisellingioServiceInvoker) {
            ApisellingioAuditDataTask apisellingioAuditDataTask = new ApisellingioAuditDataTask(
                    this.request,
                    apisellingioServiceInvoker,
                    this.httpHeaders,
                    createRequestBody());
            apisellingioResponseFuture = request.orchestrator.execute(apisellingioAuditDataTask);
    }

    @Override
    public void doAudit(T t) {

    }

    abstract protected String createRequestBody();

    protected Headers createRequestHeader(HttpHeaders headers) {
        Headers newHeaders = new Headers();
        if (headers != null && headers.getRequestHeaders() != null) {
            for (String key : headers.getRequestHeaders().keySet()) {
                for (String value : headers.getRequestHeader(key)) {
                    newHeaders.getRequestHeaders().add(key, value);
                }
            }
        }
        newHeaders.getRequestHeaders().remove("DATAFLOW");
        newHeaders.getRequestHeaders().remove("dataflow");
        // force to get old trading api response
        newHeaders.getRequestHeaders().putSingle("dataflow", "apisellingio");
        logHeader(newHeaders);
        return newHeaders;
    }

    private void logHeader(Headers httpHeaders) {
        List<String> headerStr = new ArrayList<>();
        if (httpHeaders.getRequestHeaders() != null) {
            for (Entry<String, List<String>> entry : httpHeaders.getRequestHeaders().entrySet()) {
                String s = entry.getKey() + "=" + entry.getValue().toString();
                headerStr.add(s);
            }
        }
        CalLogger.info("redirect to apisellingio header", headerStr.toString());
    }

}
