package com.ebay.app.apisellingextsvc.common.constant;

/**
 * <pre>
 * <a href="https://developer.ebay.com/DevZone/XML/docs/HowTo/eBayWS/eBaySchemaVersioning.html#VersionSupportSchedule">VersionSupportSchedule</a>
 *
 * As of February 2020, the lowest supported version is 1097.
 * </pre>
 */
public final class VersionConstant {

    // Schema Version Lowest Supported Version as of
    //  1097 February 2020
    //  1123 August 2020
    //  1149 February 2021
    //  1175 August 2021
    //  1201 February 2022
    //  1227 August 2022
    // public static final int LOWEST_SUPPORT_VERSION = 1097;
    // public static final int VERSION_UPI_CONTAINER_ADDED = 757;
    // public static final int VERSION_EXTERNALTRAN_STATUS = 827;
    // public static final int VERSION_PAYMENTS_CONTAINER = 827;
    // public static final int VERSION_REFUND_CONTAINER = 831;
    // public static final int VERSION_PICKUPSELECTED_CONTAINER = 831;
    // public static final int VERSION_DB_OPTIMIZATION = 839;
    // public static final int VERSION_EBAYNOW = 849;
    public static final int VERSION_PROGESSIVE_XO = 849;
    // public static final int VERSION_BOPIS_OMS = 867;
    public static final int VERSION_PUDO = 875;
    // public static final int VERSION_POSTTRANSACTION = 879;
    public static final int VERSION_ESTIMATED_DELIVERY = 883;
    public static final int VERSION_PAYUPONINVOICE = 887;
    public static final int VERSION_SME_CHANGES = 891;
    // public static final int VERSION_ORDER_REFERENCE_KEY = 893;
    public static final int VERSION_SME_CHANGES_ITEM_DISOCUNTS = 895;
    public static final int VERSION_SELLER_DISCOUNTS = 943;
    public static final int VERSION_GUARANTEED_SHIPPING = 981;
    public static final int VERSION_GUARANTEED_DELIVERY = 1019;
    public static final int VERSION_HANDLEBY_DATE = 991;
    public static final int VERSION_BUYER_VATSTATUS = 1001;
    public static final int VERSION_PRIVACY = 1019;
    public static final int VERSION_AU_GST = 1067;
    public static final int VERSION_EU_VAT = 1211;
    public static final int VERSION_FR_VAT = 1225;
    // public static final int VERSION_EXPOSE_UNIQUE_ID = 1113;

    public static final int SHOW_IMCC_MAX_VERSION = 1275;

    public static final int SHOW_TRANS_INQUIRY_STATUS_VERSION = 879;

    public static final int POPULATE_ZERO_FOR_AMOUNT_PAID_VERSION_781 = 781;

    public static final int VERSION_DIGITAL_DELIVERY = 935;

    public static boolean isGreaterEqualThan(int requestVersion, int compareVersion) {
        return requestVersion >= compareVersion;
    }

    public static boolean isLessEqualThan(int requestVersion, int compareVersion) {
        return requestVersion <= compareVersion;
    }
}
