package com.ebay.app.apisellingextsvc.context;

import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class TracerContext {

    Tracer openTeleTracer;
    Span openTeleParentSpan;
    io.opentracing.Tracer openTracingTracer;
    io.opentracing.Span openTracingParentSpan;

}
