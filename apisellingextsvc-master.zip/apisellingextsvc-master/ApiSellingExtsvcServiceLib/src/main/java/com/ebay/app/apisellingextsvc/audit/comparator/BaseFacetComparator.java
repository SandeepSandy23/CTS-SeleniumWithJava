package com.ebay.app.apisellingextsvc.audit.comparator;

import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

public abstract class BaseFacetComparator implements IFacetComparator {
    private final ExtensiveComparator comparator;

    protected BaseFacetComparator(ExtensiveComparator comparator) {
        this.comparator = comparator;
    }

    protected String getValue(JsonNode node) {
        return this.comparator.getValueString(node);
    }

    protected void printDiff(String key, String path, String org, String tar, boolean success, IReport report) {
        this.comparator.printDiff(key, path, org, tar, success, report);
    }

    protected void printInfo(String key, String path, String org, String tar, IReport report) {
        this.comparator.printInfo(key, path, org, tar, report);
    }

    protected boolean excludes(String path, String key) {
        return this.comparator.excludes.contains(path, key);
    }

    protected boolean compareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        return this.comparator.compareNode(org, tar, pattern, path, key, report);
    }
}
