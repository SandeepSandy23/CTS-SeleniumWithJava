package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.application.common.response.GetMyeBaySellingResponse;
import com.ebay.app.apisellingextsvc.context.Summary;
import com.ebay.app.apisellingextsvc.service.invokers.model.ActiveModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.DeletedFromSoldModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.DeletedFromUnsoldModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.ScheduledModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.UnsoldModel;
import com.ebay.app.apisellingextsvc.utils.AckUtils;
import com.ebay.oms.response.ErrorData;
import com.ebay.oms.response.IServiceResponse;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;
import ebay.apis.eblbasecomponents.PaginatedOrderTransactionArrayType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class GMESResponseBuilderTask implements Task<GetMyeBaySellingResponse>, ITaskResultInjectable {

    private final List<ErrorType> errorList;
    private final Map<String, Object> resultMap = new HashMap<>();

    public GMESResponseBuilderTask(List<ErrorType> errorList) {
        this.errorList = errorList;
    }

    @Override
    public GetMyeBaySellingResponse call() {
        //collect all the container responses tasks and build the final response
        GetMyeBaySellingResponse response = new GetMyeBaySellingResponse();
        DeletedFromSoldModel deletedFromSoldModel = (DeletedFromSoldModel) resultMap.get(DeletedFromSoldModel.class.getName());
        ActiveModel activeModel = (ActiveModel) resultMap.get(ActiveModel.class.getName());
        response.setSoldList((PaginatedOrderTransactionArrayType) resultMap.get(PaginatedOrderTransactionArrayType.class.getName()));
        if (activeModel != null) {
            response.setActiveList(activeModel.getPaginatedItemArrayType());
        }
        UnsoldModel unsoldModel = (UnsoldModel) resultMap.get(UnsoldModel.class.getName());
        if (unsoldModel != null) {
            response.setUnsoldList(unsoldModel.getPaginatedItemArrayType());
        }
        ScheduledModel scheduledModel = (ScheduledModel) resultMap.get(ScheduledModel.class.getName());
        if (scheduledModel != null) {
            response.setScheduledList(scheduledModel.getPaginatedItemArrayType());
        }
        Summary summaryResponse = (Summary) resultMap.get(Summary.class.getName());
        if (summaryResponse != null) {
            response.setSummary(summaryResponse.getMyeBaySellingSummaryType());
            response.setSellingSummary(summaryResponse.getSellingSummaryType());
        }

        if (deletedFromSoldModel != null) {
            response.setDeletedFromSoldList(deletedFromSoldModel.getDeletedFromSoldList());
        }
        DeletedFromUnsoldModel deletedFromUnsoldModel = (DeletedFromUnsoldModel) resultMap.get(DeletedFromUnsoldModel.class.getName());
        if (deletedFromUnsoldModel != null) {
            response.setDeletedFromUnsoldList(deletedFromUnsoldModel.getPaginatedItemArrayType());
        }

        AckUtils.populateAckAndErrors(errorList, response);
        return response;
    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
