package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.lib.lasng.model.ShippingTypeInfo.CostTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.ShippingTypeCodeType;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.ACTUAL_RATE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.CALCDOMESTIC_FLATINTL_RATE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.CALCULATED_DOMESTIC_CALCULATED_INTERNATIONAL;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.FLATDOMESTIC_CALCINTL_RATE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.FLAT_DOMESTIC_FLAT_INTERNATIONAL;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.FLAT_RATE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.FREIGHT_RATE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.NOT_SPECIFIED;

public class ShippingTypeCodeTypeMapper {
    private static final ImmutableMap<String, ShippingTypeCodeType> mapName
            = new ImmutableMap.Builder<String, ShippingTypeCodeType>()
            .put(CostTypeEnum.CALCULATED.toString(), ShippingTypeCodeType.CALCULATED)
            .put(ACTUAL_RATE, ShippingTypeCodeType.CALCULATED)
            .put(CostTypeEnum.CALCULATEDDOMESTICFLATINTERNATIONAL.toString(), ShippingTypeCodeType.CALCULATED_DOMESTIC_FLAT_INTERNATIONAL)
            .put(CALCULATED_DOMESTIC_CALCULATED_INTERNATIONAL, ShippingTypeCodeType.CALCULATED)
            .put(CALCDOMESTIC_FLATINTL_RATE, ShippingTypeCodeType.CALCULATED_DOMESTIC_FLAT_INTERNATIONAL)
            .put(CostTypeEnum.FLAT.toString(), ShippingTypeCodeType.FLAT)
            .put(FLAT_RATE, ShippingTypeCodeType.FLAT)
            .put(FREIGHT_RATE, ShippingTypeCodeType.FREIGHT)
            .put(CostTypeEnum.FLATDOMESTICCALCULATEDINTERNATIONAL.toString(), ShippingTypeCodeType.FLAT_DOMESTIC_CALCULATED_INTERNATIONAL)
            .put(FLAT_DOMESTIC_FLAT_INTERNATIONAL, ShippingTypeCodeType.FLAT)
            .put(FLATDOMESTIC_CALCINTL_RATE, ShippingTypeCodeType.FLAT_DOMESTIC_CALCULATED_INTERNATIONAL)
            .put(CostTypeEnum.FREIGHT.toString(), ShippingTypeCodeType.FREIGHT)
            .put(NOT_SPECIFIED, ShippingTypeCodeType.NOT_SPECIFIED)
            .build();

    private ShippingTypeCodeTypeMapper() {
    }

    public static ShippingTypeCodeType map(String key) {
        return mapName.getOrDefault(key, ShippingTypeCodeType.CUSTOM_CODE);
    }

}
