package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.mappers.ShippingCarrierMapper;
import com.ebay.app.apisellingextsvc.service.bof.shippingcarrier.IShippingCarrierBof;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.app.apisellingextsvc.utils.ProgramUtil;
import com.ebay.app.apisellingextsvc.utils.TaxUtil;
import com.ebay.cos.type.v3.base.CurrencyCodeEnum;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.OrderTotal;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.lib.lasng.model.CoreInfo;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.lib.lasng.model.ShippingInfo;
import com.ebay.lib.lasng.model.ShippingServiceInfo;
import com.ebay.lib.lasng.model.ShippingTypeInfo;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.Code;
import com.ebay.order.common.v1.DeliveryEstimate;
import com.ebay.order.common.v1.FulfillmentStatusType;
import com.ebay.order.common.v1.LineItem;
import com.ebay.order.common.v1.LineItemSource;
import com.ebay.order.common.v1.LogisticsPlan;
import com.ebay.order.common.v1.LogisticsStep;
import com.ebay.order.common.v1.LogisticsStepTypeEnumType;
import com.ebay.order.common.v1.PackageContentsType;
import com.ebay.order.common.v1.PackageType;
import com.ebay.order.common.v1.ProgramType;
import com.ebay.order.common.v1.ShippingCostPlan;
import com.ebay.order.common.v1.ShippingMethod;
import com.ebay.order.common.v1.ShippingOption;
import com.ebay.order.common.v1.ShippingStepExtension;
import com.ebay.order.common.v1.Tax;
import com.ebay.order.common.v1.TimeEstimate;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.CalculatedShippingRateType;
import ebay.apis.eblbasecomponents.SalesTaxType;
import ebay.apis.eblbasecomponents.ShipmentTrackingDetailsType;
import ebay.apis.eblbasecomponents.ShippingDetailsType;
import ebay.apis.eblbasecomponents.ShippingTypeCodeType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.ebay.app.apisellingextsvc.utils.LogisticUtil.getShippingType;

public class TransactionShippingDetailsBuilder extends BaseFacetBuilder<ShippingDetailsType> {

    private OrderCSXType order;
    private ProformaOrderXType proformaOrder;
    private final List<ProgramType> programs;
    private final List<? extends LogisticsPlan> logisticsPlan;
    private final String lineItemId;
    private final CurrencyCodeEnum currencyCodeEnum;
    private LineItemXType lineItem;
    private final List<Attribute> attributes;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final int trxVersion;
    private final ApiSellingExtSvcConfigValues configValues;
    private final IShippingCarrierBof shippingCarrierBof;

    private static final String EBAY_FAST_AND_FREE = "EBAY_FAST_AND_FREE";
    private static final String FAST_AND_FREE = "FAST_AND_FREE";
    private static final String PROGRAM_EBAY_MANAGED_SHIPPING = "EBAY_MANAGED_SHIPPING";
    private final Map<String, Item> svlsInfoItemMap;

    private final LineItemSource sourceId;

    public TransactionShippingDetailsBuilder(Task<?> task,
                                             OrderCSXType order,
                                             LineItemXType lineItem,
                                             ApiSellingExtSvcConfigValues configValues,
                                             IShippingCarrierBof shippingCarrierBof,
                                             int trxVersion,
                                             Map<Long, ListingActivity> itemIdListingActivityMap,
                                             Map<String, Item> svlsInfoItemMap
                                             ) {
        super(task);
        this.order = order;
        this.programs = order.getPrograms();
        this.attributes = lineItem.getAttribute();
        logisticsPlan = order.getLogistics();
        lineItemId = lineItem.getLineItemId();
        currencyCodeEnum = order.getOrderTotalSummary().getTotal().getAmount().getCurrency();
        this.lineItem = lineItem;
        this.trxVersion = trxVersion;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.configValues = configValues;
        this.shippingCarrierBof = shippingCarrierBof;
        this.svlsInfoItemMap = svlsInfoItemMap;
        this.sourceId = lineItem.getSourceId();
    }

    public TransactionShippingDetailsBuilder(Task<?> task,
                                             ProformaOrderXType proformaOrder,
                                             ProformaOrderLineItemXType lineItem,
                                             ApiSellingExtSvcConfigValues configValues,
                                             int trxVersion,
                                             Map<Long, ListingActivity> itemIdListingActivityMap,
                                             Map<String, Item> svlsInfoItemMap ) {
        super(task);
        this.proformaOrder = proformaOrder;
        this.programs = proformaOrder.getPrograms();
        this.attributes = lineItem.getAttribute();
        logisticsPlan = proformaOrder.getLogisticsOptions();
        lineItemId = Long.toString(lineItem.getLineItemId());
        currencyCodeEnum = proformaOrder.getOrderTotalSummary().getTotal().getAmount().getCurrency();
        this.trxVersion = trxVersion;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.configValues = configValues;
        this.shippingCarrierBof = null;
        this.svlsInfoItemMap = svlsInfoItemMap;
        this.sourceId = lineItem.getSourceId();
    }

    /**
     * https://developer.ebay.com/devzone/xml/Docs/Reference/ebay/types/ShippingDetailsType.html#GetItFast
     * <p>
     * Get it fast field is deprecated
     */
    @Override
    protected ShippingDetailsType doBuild() {
        ShippingDetailsType shippingDetails = new ShippingDetailsType();
        ShippingTypeCodeType shippingType;
        if (order != null) {
            shippingType = getShippingDetailsShippingType(false);
            shippingDetails.setSalesTax(getOrderSalesTaxType());
            shippingDetails.setTaxTable(new TaxTableBuilder(task, order, lineItem).build());
            shippingDetails.getShipmentTrackingDetails().addAll(getShipmentTrackingDetails());
            // SOAPI-1039 - Removed this logic as its not returned in V3 as well in new GIT
            // shippingDetails.setShippingRateType(getShippingRateType());
            shippingDetails.setShippingServiceUsed(getShippingServiceUsed());
            shippingDetails.setEBayEstimatedLabelCost(getEBayEstimatedLabelCost());
        } else { //proformaOrder != null
            shippingType = getShippingDetailsShippingType(true);
            shippingDetails.setSalesTax(getProformaSalesTaxType());
            shippingDetails.setTaxTable(new TaxTableBuilder(task, proformaOrder).build());
        }
        shippingDetails.setCalculatedShippingRate(getCalculatedShippingRate(shippingType));
        shippingDetails.setShippingType(shippingType);
        shippingDetails.setCODCost(getCODCost());

        // Returning the default values
        shippingDetails.setGetItFast(Boolean.FALSE); // Deco approved to deprecate
        shippingDetails.setChangePaymentInstructions(Boolean.TRUE); // Deco approved to deprecate
        shippingDetails.setPaymentEdited(Boolean.TRUE); // Deco approved to deprecate?
        shippingDetails.setThirdPartyCheckout(Boolean.FALSE); // Deco approved to deprecate
        shippingDetails.setSellingManagerSalesRecordNumber(getSellingManagerSalesRecordNumber());
        return shippingDetails;
    }

    private static Item getItem(LineItemSource sourceId, Map<String, Item> svlsItemInfoMap) {
        return Optional.ofNullable(sourceId)
                .map(LineItemSource::getItemId)
                .map(itemId-> svlsItemInfoMap.get(itemId))
                .orElse(null);
    }

    private AmountType getEBayEstimatedLabelCost() {
        if (programs.stream().noneMatch(program -> PROGRAM_EBAY_MANAGED_SHIPPING.equals(program.getName()))) {
            return null;
        }
        return AmountTypeUtil.getDefaultZeroAmountType(order);
    }

    private Integer getSellingManagerSalesRecordNumber() {
        return Optional.ofNullable(attributes)
                    .map(it -> AttributeUtil.findAttributes(it, ApiSellingExtSvcConstants.ATTR_SALES_RECORD_NUMBER))
                    .map(Attribute::getValue)
                    .filter(StringUtils::isNumeric)
                    .map(Integer::new).orElse(null);
    }

    private boolean getExpeditedService(List<ShippingOption> shippingOptions) {
        for (ShippingOption shippingOption : shippingOptions) {
            List<String> estimateTreatment = Optional.ofNullable(shippingOption)
                    .map(ShippingOption::getDeliveryEstimate)
                    .map(DeliveryEstimate::getTimeEstimate)
                    .map(TimeEstimate::getEstimateTreatment)
                    .orElse(new ArrayList<>());

            List<String> expeditedService = estimateTreatment.stream()
                    .filter(et -> et.equals(FAST_AND_FREE) || et.equals(EBAY_FAST_AND_FREE))
                    .collect(Collectors.toList());
            if (expeditedService.size() >= 1) {
                return true;
            }
        }
        return false;
    }


    private AmountType getShippingServiceCost() {
        // isHalfSale wll always false, since this field has been deprecated
        // todo
        // prod order 04-07825-82568
        return Optional.of(order).map(OrderCSXType::getOrderTotalSummary)
                .map(OrderTotal::getOriginalShippingCost)
                .map(AmountTypeUtil::getAmountType)
                .orElse(null);
    }

    // select * from ebay_checkout_trans where rownum<10  and created_time > sysdate -30 and bitand(checkout_flags7, 128)!=128 and bitand
    // (checkout_flags, 4)=4 and oms_details like '%INVOICE_TO_SELLER%'
    private SalesTaxType getOrderSalesTaxType() {

        /*
          As per V3 GST response, salesTax is not returned for AG Vault order.
          So skipping now to match with V3 response
          Refer: OrderId 25-00035-35575
         */
        if (ProgramUtil.isAGVaultOrder(order.getPrograms())) {
            return null;
        }

        // if distribution does not have tax partner
        // 01-00021-70798 <-- true
        // 07-00021-54875
        if (!PaymentUtil.hasTaxPartnerDistribution(order.getPayments())) {
            SalesTaxType salesTax = new SalesTaxType();
            Tax tax = lineItem.getTax();
            salesTax.setShippingIncludedInTax(TaxUtil.isShippingIncludedInTax(tax));
            if (tax != null) {
                salesTax.setSalesTaxState(tax.getSalesTaxState());
                if (tax.getSalesTaxPercentage() != null) {
                    salesTax.setSalesTaxPercent(tax.getSalesTaxPercentage().floatValue());
                }
            }

            // For EIS order, not to return the salesTax as is from COSMOS
            // We shouldn't be exposing the full salesTax amount to seller, as
            // some of them are seller not aware of like IMPORT_TAX and INTL_LEG_TAX
            if (order.getTaxTotal() != null
                    && order.getTaxTotal().getTax() != null
                    && order.getTaxTotal().getTax().getAmount() != null && !ProgramUtil.isExportsOrder(order.getPrograms())) {
                Amount amount = order.getTaxTotal().getTax().getAmount();
                // 06-00021-38810
                salesTax.setSalesTaxAmount(AmountTypeUtil.getAmountType(amount));
            } else {
                salesTax.setSalesTaxAmount(AmountTypeUtil.getAmountType(currencyCodeEnum.name(), ApiSellingExtSvcConstants.ZERO_AMOUNT));
            }
            return salesTax;
        }
        return null;
    }

    private SalesTaxType getProformaSalesTaxType() {
        SalesTaxType salesTaxType = new SalesTaxType();
        salesTaxType.setSalesTaxPercent(0f);
        salesTaxType.setShippingIncludedInTax(false);
        return salesTaxType;
    }


    private ShippingTypeCodeType getShippingDetailsShippingType(boolean isProformaOrder) {
        /* If the order program is Vault, then V3 returns NotSpecified
           In COSMOS logistics, for AG order the second step is handled by eBay
           in that case returns NotSpecified. To easy check we can check the program directly
         */
        if (!ProgramUtil.isAGVaultOrder(programs)) {
            if (lineItemId != null && logisticsPlan != null) {
                return getShippingType(logisticsPlan, lineItemId, isProformaOrder);
            }
        }
        return ShippingTypeCodeType.NOT_SPECIFIED;
    }

    private String getShippingServiceUsed() {
        /*
          No need to return ShippingServiceUsed for GSP order as per V3 GST response
          Refer : OrderId 13-00034-29513
         */
        if (ProgramUtil.isGSPOrder(programs)) {
            return null;
        }
        return Optional.ofNullable(getShippingMethod())
                .map(ShippingMethod::getShippingMethodCode)
                .map(Code::getValue).orElse(null);
    }

//    private ShippingRateTypeCodeType getShippingRateType() {
//        ShippingMethod shippingMethod = getShippingMethod();
//        ShippingRateTypeCodeType shippingRateTypeCodeType = null;
//
//        if (Optional.ofNullable(shippingMethod).map(ShippingMethod::getCarrier).map(Code::getDisplayName).map("USPS"::equals).orElse(false)) {
//            try {
//                // This will always throw error currently as the majority of shipping method is STANDARD. This will be fixed once we get this info from Shipping Service and there's a replacement available
//                // TODO Update once Shipping Service replacement is available
//                shippingRateTypeCodeType =  ShippingRateTypeCodeType.fromValue(Optional.ofNullable(shippingMethod).map(ShippingMethod::getShippingMethodCategory).map(Code::getValue).get());
//            } catch (IllegalArgumentException illegalArgumentException) {
//                CalLogger.warn("Error when getting shipping rate type", ExceptionUtils.getStackTrace(illegalArgumentException));
//                return null;
//            }
//        }
//        return shippingRateTypeCodeType;
//    }

    protected List<ShipmentTrackingDetailsType> getShipmentTrackingDetails() {
        List<ShippingStepExtension> shippingStepExtensions = order.getLogistics().stream()
                .filter(Objects::nonNull)
                .filter(logisticsPlan -> FulfillmentStatusType.NOT_STARTED != logisticsPlan.getFulfillmentStatus())
                .map(LogisticsPlan::getSteps).filter(Objects::nonNull)
                .flatMap(Collection::stream).filter(Objects::nonNull)
                .map(LogisticsStep::getStepExtension).filter(Objects::nonNull)
                .map(LogisticsStep.StepExtension::getShippingStep).filter(Objects::nonNull)
                .collect(Collectors.toList());

        List<ShipmentTrackingDetailsType> trackingDetails = new ArrayList<>();
        HashSet<String> trackingIds = new HashSet<>();

        String lineItemId = Optional.ofNullable(this.lineItem).map(LineItemXType::getLineItemId).orElse(null);

        for (ShippingStepExtension step : shippingStepExtensions) {
            for (PackageType packageType : step.getPackage()) {

                if (!isInCurrentPackage(lineItemId, packageType)) {
                    continue;
                }

                String trackingId = Optional.ofNullable(packageType)
                        .map(PackageType::getPackageExtn)
                        .map(PackageType.PackageExtn::getShippingPackageExtn)
                        .map(PackageType.PackageExtn.ShippingPackageExtn::getTrackingId)
                        .orElse(null);
                //may not unique
                if (StringUtils.isEmpty(trackingId) || !trackingIds.add(trackingId)) {
                    continue;
                }

                //try get from package attribute, else from shipping option
                String carrier = getCarrierUsedFromAttribute(packageType);

                if (StringUtils.isAllEmpty(trackingId, carrier)) {
                    continue;
                }

                ShipmentTrackingDetailsType detail = new ShipmentTrackingDetailsType();
                detail.setShipmentTrackingNumber(trackingId);
                detail.setShippingCarrierUsed(carrier);
                trackingDetails.add(detail);
            }
        }

        return trackingDetails;
    }

    private String getCarrierUsedFromAttribute(PackageType pkg) {
        if (pkg != null) {
            String carrierUsedAttributeValue = AttributeUtil.findAttributeValue(pkg.getAttributes(),
                    ApiSellingExtSvcConstants.CARRIER_USED);
            return ShippingCarrierMapper.convertToCarrierName(shippingCarrierBof, carrierUsedAttributeValue,
                    configValues);
        }
        return null;
    }

    private boolean isInCurrentPackage(String lineItemId, PackageType packageType) {
        return Optional.ofNullable(packageType).map(PackageType::getPackageContents)
                .map(PackageContentsType::getPackageLineItemId)
                .flatMap(lineItemSources -> lineItemSources.stream()
                        .filter(lineItemSource -> lineItemSource.getLineItemId() != null)
                        .filter(lineItemSource -> lineItemSource.getLineItemId().equals(lineItemId))
                        .findFirst())
                .isPresent();
    }

    private CalculatedShippingRateType getCalculatedShippingRate(ShippingTypeCodeType shippingType) {
        /*
          To match with the condition is V3 GST, we have CalculatedShippingRate is
          emitted only when the ShippingType code is CALCULATED, FLAT_DOMESTIC_CALCULATED_INTERNATIONAL,
          CALCULATED_DOMESTIC_FLAT_INTERNATIONAL
         */
        if (shippingType == ShippingTypeCodeType.CALCULATED ||
                shippingType == ShippingTypeCodeType.FLAT_DOMESTIC_CALCULATED_INTERNATIONAL ||
                shippingType == ShippingTypeCodeType.CALCULATED_DOMESTIC_FLAT_INTERNATIONAL) {
            CalculatedShippingRateType calculatedShippingRateType = new CalculatedShippingRateType();
            calculatedShippingRateType.setOriginatingPostalCode(getOriginatingPostalCode());
            if (order != null) {
                Optional<String> itemId = order.getLineItemTypes().stream()
                        .filter(Objects::nonNull)
                        .map(LineItem::getSourceId)
                        .filter(Objects::nonNull)
                        .map(LineItemSource::getItemId)
                        .findFirst();
                ListingActivity listingActivity = itemIdListingActivityMap.get(Long.parseLong(itemId.get()));
                setPackagingHandlingCosts(calculatedShippingRateType, listingActivity);
            } else { //proformaOrder != null
                calculatedShippingRateType.setPackagingHandlingCosts(AmountTypeUtil.getZeroAmountType(currencyCodeEnum.name()));
            }
            return calculatedShippingRateType;
        }
        return null;
    }

    private AmountType getCODCost() {
        return Optional.ofNullable(logisticsPlan)
                .flatMap(logisticsPlans -> logisticsPlans.stream().findFirst())
                .map(LogisticsPlan::getSteps).filter(CollectionUtils::isNotEmpty)
                .flatMap(steps -> steps.stream().filter(step -> step.getStepType() == LogisticsStepTypeEnumType.SHIPPING).findFirst())
                .map(LogisticsStep::getStepExtension)
                .map(LogisticsStep.StepExtension::getShippingStep)
                .map(ShippingStepExtension::getShippingOptions).filter(CollectionUtils::isNotEmpty)
                .flatMap(shippingOptions -> shippingOptions.stream().findFirst())
                .map(ShippingOption::getShippingCostPlan)
                .map(ShippingCostPlan::getCashOnDeliveryFee)
                .map(AmountTypeUtil::getAmountType).orElse(null); // Modified to return null instead of 0 amount
    }

    private void setPackagingHandlingCosts(CalculatedShippingRateType calculatedShippingRateType, ListingActivity listingActivity) {
        Optional<Double> packagingHandlingCost = Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getShipping)
                .map(ShippingInfo::getShippingTypes)
                .map(Collection::stream)
                .flatMap(Stream::findFirst)
                .map(ShippingTypeInfo::getServices)
                .map(Collection::stream)
                .flatMap(Stream::findFirst)
                .map(ShippingServiceInfo::getPackageHandlingCostValue);

        if (packagingHandlingCost.isPresent()) {
            calculatedShippingRateType.setPackagingHandlingCosts(AmountTypeUtil.getAmountType(currencyCodeEnum.name(), packagingHandlingCost.get()));
        } else {
            calculatedShippingRateType.setPackagingHandlingCosts(AmountTypeUtil.getAmountType(currencyCodeEnum.name(), ApiSellingExtSvcConstants.ZERO_AMOUNT));
        }
    }

    private String getOriginatingPostalCode() {
        if (order != null) {
            JSONObject jsonObject = new JSONObject(AttributeUtil.findAttribute(attributes, "ITEM_LOCATION").map(Attribute::getValue).orElse("{}"));
            String key = "PostalCode";
            if (jsonObject.has(key)) {
                return jsonObject.getString(key);
            }
            return null;
        }
        return AttributeUtil.findAttribute(attributes, "ORIGIN_POSTAL_CODE").map(Attribute::getValue).orElse(null);
    }

    private ShippingMethod getShippingMethod() {
        return Optional.ofNullable(order).map(OrderCSXType::getLogistics)
                .flatMap(logisticsPlans -> logisticsPlans.stream().findFirst())
                .map(LogisticsPlan::getSteps).filter(CollectionUtils::isNotEmpty)
                .flatMap(logisticsSteps -> logisticsSteps.stream().findFirst())
                .map(LogisticsStep::getStepExtension)
                .map(LogisticsStep.StepExtension::getShippingStep)
                .filter(Objects::nonNull)
                .map(ShippingStepExtension::getShippingOptions).filter(CollectionUtils::isNotEmpty)
                .flatMap(shippingOptions -> shippingOptions.stream().findFirst())
                .map(ShippingOption::getShipppingMethod).orElse(null);
    }
}
