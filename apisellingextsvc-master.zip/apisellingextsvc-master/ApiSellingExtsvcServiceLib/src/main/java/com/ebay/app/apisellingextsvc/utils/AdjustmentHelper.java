package com.ebay.app.apisellingextsvc.utils;


import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.cosmos.AdjustmentTypeCS;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.AdjustmentStatusType;
import com.ebay.order.common.v1.AdjustmentType;
import com.ebay.order.common.v1.AdjustmentTypeEnumType;
import com.ebay.order.common.v1.CollectionType;
import com.ebay.order.common.v1.DistributionType;
import com.ebay.order.common.v1.EntityTotal;
import com.ebay.order.common.v1.PaymentAdjustmentType;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.google.common.collect.ImmutableSet;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AdjustmentHelper {

    private static final ImmutableSet<AdjustmentTypeEnumType> ADJUSTMENT_TYPES =
            ImmutableSet.of(AdjustmentTypeEnumType.REFUND, AdjustmentTypeEnumType.PAYOUT);

    @Nonnull
    public static Amount getRefundUnitRate(OrderCSXType order) {
        return order.getAdjustmentsCS().stream().filter(AdjustmentHelper::validAdjustment)
                .map(AdjustmentTypeCS::getTypeExtension)
                .filter(Objects::nonNull)
                .map(AdjustmentType.TypeExtension::getPaymentAdjustment)
                .filter(Objects::nonNull)
                .map(PaymentAdjustmentType::getDistribution)
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .filter(distribution -> ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_BUYER.equals(distribution.getType()))
                .map(DistributionType::getTotalAmount)
                .filter(Objects::nonNull)
                .map(EntityTotal::getAmount)
                .findFirst().orElse(new Amount(ApiSellingExtSvcConstants.ZERO_AMOUNT, PaymentUtil.getOrderDefaultAmountCurrency(order)));
    }

    public static BigDecimal sumRefundExcept(List<AdjustmentTypeCS> adj, Set<String> set) {
        return adj.stream()
                .filter(AdjustmentHelper::validAdjustment)
                .map(AdjustmentTypeCS::getTypeExtension)
                .filter(Objects::nonNull)
                .map(AdjustmentType.TypeExtension::getPaymentAdjustment)
                .filter(Objects::nonNull)
                .map(PaymentAdjustmentType::getCollection)
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .filter(collection -> !set.contains(collection.getType()))
                .map(CollectionType::getTotalAmount)
                .filter(Objects::nonNull)
                .map(EntityTotal::getAmount)
                .map(amount -> amount.getConvertedFromValue() != null ? amount.getConvertedFromValue() : amount.getValue())
                .map(BigDecimal::new)
                .reduce(BigDecimal::add)
                .map(sumAmount -> sumAmount.setScale(ApiSellingExtSvcConstants.SCALE_OF_DECIMAL, RoundingMode.HALF_UP))
                .orElse(BigDecimal.ZERO);
    }

    public static boolean validAdjustment(AdjustmentTypeCS adj) {
        return ADJUSTMENT_TYPES.contains(adj.getAdjustmentType()) && AdjustmentStatusType.SUCCESS == adj.getStatus();
    }

    public static List<Amount> getCollection(List<AdjustmentTypeCS> adj, String collectionType) {
        return adj.stream()
                .filter(AdjustmentHelper::validAdjustment)
                .map(AdjustmentTypeCS::getTypeExtension)
                .filter(Objects::nonNull)
                .map(AdjustmentType.TypeExtension::getPaymentAdjustment)
                .filter(Objects::nonNull)
                .map(PaymentAdjustmentType::getCollection)
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .filter(collection -> collectionType.equals(collection.getType()))
                .map(CollectionType::getTotalAmount)
                .filter(Objects::nonNull)
                .map(EntityTotal::getAmount)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public static List<Amount> getRefundedPriceLine(List<AdjustmentTypeCS> adj, PricelineTypeEnum priceLineType) {
        return adj.stream()
                .filter(AdjustmentHelper::validAdjustment)
                .map(AdjustmentTypeCS::getTypeExtension).filter(Objects::nonNull)
                .map(AdjustmentType.TypeExtension::getPaymentAdjustment).filter(Objects::nonNull)
                .map(PaymentAdjustmentType::getCollection).filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .map(CollectionType::getTotalAmount).filter(Objects::nonNull)
                .map(EntityTotal::getPriceLines).filter(Objects::nonNull)
                .flatMap(Collection::stream).filter(Objects::nonNull)
                .filter(priceLine -> priceLineType == priceLine.getType())
                .map(PriceLine::getAmount).filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

}
