package com.ebay.app.apisellingextsvc.service.dal.sellerdiscount;


import com.ebay.af.common.flag.FlagMask;

import java.util.Date;

public class SellerDiscountEntityMock implements SellerDiscountEntity {
    private int originalShippingService;
    private long transactionId;
    private long itemId;
    private long sellerId;

    @Override
    public long getSellerDiscountEntityId() {
        return 0;
    }

    @Override
    public void setSellerDiscountEntityId(long var1) {

    }

    @Override
    public int getPartitionKey() {
        return 0;
    }

    @Override
    public void setPartitionKey(int var1) {

    }

    @Override
    public long getBuyerId() {
        return 0;
    }

    @Override
    public void setBuyerId(long var1) {

    }

    @Override
    public long getSellerId() {
        return this.sellerId;
    }

    @Override
    public void setSellerId(long var1) {
        this.sellerId = var1;
    }

    @Override
    public long getCheckoutCartId() {
        return 0;
    }

    @Override
    public void setCheckoutCartId(long var1) {

    }

    @Override
    public long getItemId() {
        return this.itemId;
    }

    @Override
    public void setItemId(long var1) {
        this.itemId = var1;
    }

    @Override
    public long getTransactionId() {
        return this.transactionId;
    }

    @Override
    public void setTransactionId(long var1) {
        this.transactionId = var1;
    }

    @Override
    public long getOrderId() {
        return 0;
    }

    @Override
    public void setOrderId(long var1) {

    }

    @Override
    public long getTransactionQuantity() {
        return 0;
    }

    @Override
    public void setTransactionQuantity(long var1) {

    }

    @Override
    public double getOriginalItemPrice() {
        return 0;
    }

    @Override
    public void setOriginalItemPrice(double var1) {

    }

    @Override
    public double getItemPrice() {
        return 0;
    }

    @Override
    public void setItemPrice(double var1) {

    }

    @Override
    public double getShippingFee() {
        return 0;
    }

    @Override
    public void setShippingFee(double var1) {

    }

    @Override
    public double getShippingDiscountAmount() {
        return 0;
    }

    @Override
    public void setShippingDiscountAmount(double var1) {

    }

    @Override
    public int getCurrencyId() {
        return 0;
    }

    @Override
    public void setCurrencyId(int var1) {

    }

    @Override
    public int getOriginalShippingService() {
        return this.originalShippingService;
    }

    @Override
    public void setOriginalShippingService(int var1) {
        this.originalShippingService = var1;
    }

    @Override
    public int getPromoShippingService() {
        return 0;
    }

    @Override
    public void setPromoShippingService(int var1) {

    }

    @Override
    public int getDiscountStatus() {
        return 0;
    }

    @Override
    public void setDiscountStatus(int var1) {

    }

    @Override
    public long getSellerCampaignId() {
        return 0;
    }

    @Override
    public void setSellerCampaignId(long var1) {

    }

    @Override
    public long getRuleInstanceId() {
        return 0;
    }

    @Override
    public void setRuleInstanceId(long var1) {

    }

    @Override
    public long getPrimaryItemId() {
        return 0;
    }

    @Override
    public void setPrimaryItemId(long var1) {

    }

    @Override
    public Date getCreationDate() {
        return null;
    }

    @Override
    public void setCreationDate(Date var1) {

    }

    @Override
    public Date getLastModifiedDate() {
        return null;
    }

    @Override
    public void setLastModifiedDate(Date var1) {

    }

    @Override
    public long getSellerProductBundleId() {
        return 0;
    }

    @Override
    public void setSellerProductBundleId(long var1) {

    }

    @Override
    public String getDebugInfo() {
        return null;
    }

    @Override
    public void setDebugInfo(String var1) {

    }

    @Override
    public String getTitle() {
        return null;
    }

    @Override
    public void setTitle(String var1) {

    }

    @Override
    public Date getTransactionDate() {
        return null;
    }

    @Override
    public void setTransactionDate(Date var1) {

    }

    @Override
    public long getFlags01() {
        return 0;
    }

    @Override
    public void setFlags01(long var1) {

    }

    @Override
    public String getSellerProduct() {
        return null;
    }

    @Override
    public void setSellerProduct(String var1) {

    }

    @Override
    public int getProcessedFlag() {
        return 0;
    }

    @Override
    public void setProcessedFlag(int var1) {

    }

    @Override
    public long getOfferchecksumid() {
        return 0;
    }

    @Override
    public void setOfferchecksumid(long var1) {

    }

    @Override
    public String getOfferTier() {
        return null;
    }

    @Override
    public void setOfferTier(String var1) {

    }

    @Override
    public int getOfferRank() {
        return 0;
    }

    @Override
    public void setOfferRank(int var1) {

    }

    @Override
    public int getOfferType() {
        return 0;
    }

    @Override
    public void setOfferType(int var1) {

    }

    @Override
    public int getOfferSubType() {
        return 0;
    }

    @Override
    public void setOfferSubType(int var1) {

    }

    @Override
    public int getShippingDiscountStatus() {
        return 0;
    }

    @Override
    public void setShippingDiscountStatus(int var1) {

    }

    @Override
    public String getOfferMessage() {
        return null;
    }

    @Override
    public void setOfferMessage(String var1) {

    }

    @Override
    public String getOfferConditionalMessage() {
        return null;
    }

    @Override
    public void setOfferConditionalMessage(String var1) {

    }

    @Override
    public boolean equalsData(Object o) {
        return false;
    }

    @Override
    public boolean hasFlag(FlagMask flagMask) {
        return false;
    }

    @Override
    public void setFlag(FlagMask flagMask, boolean b) {

    }
}
