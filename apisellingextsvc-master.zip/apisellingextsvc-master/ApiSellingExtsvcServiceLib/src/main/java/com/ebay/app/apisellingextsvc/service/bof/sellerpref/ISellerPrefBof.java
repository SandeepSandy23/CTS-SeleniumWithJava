package com.ebay.app.apisellingextsvc.service.bof.sellerpref;

import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPref;

public interface ISellerPrefBof {

    SellerPref findBySellerId(long sellerId);
}
