package com.ebay.app.apisellingextsvc.config;

import com.ebay.raptorio.globalconfig.impl.GlobalConfigPropertySource;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MockGlobalConfig extends GlobalConfigPropertySource {

    Map<String, Object> properties = new ConcurrentHashMap<>();

    /**
     * Name doesn't matter for mock
     */
    public MockGlobalConfig(String name) {
        super(name);
    }

    public void put(String key, Object val) {
        properties.put(key, val);
    }

    @Override
    public Object getProperty(String name) {
        return properties.get(name);
    }
}
