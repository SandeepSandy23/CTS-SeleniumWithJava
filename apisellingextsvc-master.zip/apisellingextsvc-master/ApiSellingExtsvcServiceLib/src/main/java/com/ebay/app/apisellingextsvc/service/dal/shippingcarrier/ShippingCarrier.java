package com.ebay.app.apisellingextsvc.service.dal.shippingcarrier;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "SHIPPING_CARRIER")
@com.ebay.persistence.Table(alias = "Carrier")
public interface ShippingCarrier {


    @Column(name = "CARRIER_ENUM_ID")
    int getCarrierEnumId();

    void setCarrierEnumId(int carrierEnumId);

    @Column(name = "SHIPPING_CARRIER_NAME")
    String getShippingCarrierName();

    void setShippingCarrierName(String shippingCarrierName);

}
