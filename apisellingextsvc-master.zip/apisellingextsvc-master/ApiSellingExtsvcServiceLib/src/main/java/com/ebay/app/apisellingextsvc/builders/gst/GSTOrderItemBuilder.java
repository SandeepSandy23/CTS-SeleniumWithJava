package com.ebay.app.apisellingextsvc.builders.gst;

import com.ebay.app.apisellingextsvc.builders.OrderItemBuilder;
import com.ebay.app.apisellingextsvc.builders.ShippingBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.enums.ContentBundleEnum;
import com.ebay.app.apisellingextsvc.mappers.ListingStatusMapper;
import com.ebay.app.apisellingextsvc.tasks.GMES.ListingActivitiesNGUtil;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.SiteUtils;
import com.ebay.content.runtime.api.IContentMap;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.lib.lasng.model.BestOfferTerms;
import com.ebay.lib.lasng.model.CategoryInfo;
import com.ebay.lib.lasng.model.CoreInfo;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.lib.lasng.model.ListingLifecycle;
import com.ebay.lib.lasng.model.PricingInfo;
import com.ebay.lib.lasng.model.VariationInfo;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.LogisticsPlan;
import com.ebay.order.common.v1.ShippingStepExtension;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.BuyerProtectionCodeType;
import ebay.apis.eblbasecomponents.CategoryType;
import ebay.apis.eblbasecomponents.CharityType;
import ebay.apis.eblbasecomponents.CurrencyCodeType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.InventoryTrackingMethodCodeType;
import ebay.apis.eblbasecomponents.ItemType;
import ebay.apis.eblbasecomponents.ListingDetailsType;
import ebay.apis.eblbasecomponents.ListingStatusCodeType;
import ebay.apis.eblbasecomponents.SellingStatusType;
import ebay.apis.eblbasecomponents.SiteCodeType;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class GSTOrderItemBuilder extends OrderItemBuilder {
    private final IContentHelper contentHelper;
    private static final String ITEM_APPLICATION_DATA = "ITEM_APPLICATION_DATA";
    private final List<Attribute> lineItemAttributes;
    private List<LogisticsPlan> logistics;
    private final AmountType finalValueFee;
    private final boolean finalValueFeeReturned;
    private final List<DetailLevelCodeType> detailLevels;

    public GSTOrderItemBuilder(Task task, LineItemXType lineItem, List<LogisticsPlan> logistics, ApiSellingExtSvcConfigValues configValues,
                               AmountType finalValueFee, Map<Long, ListingActivity> itemIdListingActivityMap,
                               Map<String, Item> svlsItemInfoMap, List<DetailLevelCodeType> detailLevels, IContentHelper contentHelper) {
        super(task, lineItem, configValues, itemIdListingActivityMap,svlsItemInfoMap, detailLevels);
        this.lineItemAttributes = lineItem.getAttribute();
        this.finalValueFeeReturned = finalValueFee != null;
        this.logistics = logistics;
        this.finalValueFee = finalValueFee;
        this.detailLevels = detailLevels;
        this.contentHelper = contentHelper;
    }

    public GSTOrderItemBuilder(Task task, ProformaOrderLineItemXType lineItem, ApiSellingExtSvcConfigValues configValues,
                               Map<Long, ListingActivity> itemIdListingActivityMap, Map<String, Item> svlsItemInfoMap,
                               List<DetailLevelCodeType> detailLevels, IContentHelper contentHelper) {
        super(task, lineItem, configValues, itemIdListingActivityMap,svlsItemInfoMap, detailLevels);
        this.lineItemAttributes = lineItem.getAttribute();
        this.finalValueFeeReturned = proformaFinalValueFeeReturned(lineItem);
        this.detailLevels = detailLevels;
        this.finalValueFee = null;
        this.contentHelper = contentHelper;
    }

    @Override
    protected ItemType doBuild() {
        ItemType itemType = super.doBuild();
        if (CommonUtil.shouldExposeForReturnAllOrEmpty(detailLevels)) {
            itemType.setStartPrice(getStartPrice());
        }
        itemType.setApplicationData(getApplicationData());
        itemType.setIntegratedMerchantCreditCardEnabled(false);
        if (CommonUtil.shouldExposeForReturnAllOrEmpty(detailLevels)) {
            Optional.ofNullable(listingActivity).map(ListingActivity::getCore).map(CoreInfo::getCategory).map(CategoryInfo::getPrimaryCategoryId)
                    .map(String::valueOf).map(this::getCategory).ifPresent(itemType::setPrimaryCategory);
            Optional.ofNullable(listingActivity).map(ListingActivity::getCore).map(CoreInfo::getCategory).map(CategoryInfo::getSecondaryCategoryId)
                    .map(String::valueOf).map(this::getCategory).ifPresent(itemType::setSecondaryCategory);
            itemType.setSite(getListingSite());
        }
        ShippingStepExtension shippingStep = ShippingBuilder.getShippingSteps(logistics);

        itemType.setGetItFast(isGetItFast(shippingStep));
        setSellingStatus(itemType.getSellingStatus());
        Integer conditionId = getItemConditionId();
        itemType.setConditionID(conditionId);
        itemType.setConditionDisplayName((conditionId != null) ? getConditionDisplayName(String.valueOf(conditionId)) : null);
        itemType.setApplicationData(getApplicationData());
        itemType.setAutoPay(isAutoPay(lineItemAttributes));
        itemType.setCharity(isCharityType(lineItemAttributes));
        itemType.setPrivateListing(isPrivateSale());
        String currency = ListingActivitiesNGUtil.getCurrency(listingActivity);
        if (currency != null) {
            itemType.setCurrency(CurrencyCodeType.fromValue(currency));
        }
        itemType.setInventoryTrackingMethod(getInventoryTrackingMethod());
        itemType.setBuyerProtection(getBuyerProtection());
        itemType.setListingDetails(getListingDetails());

       if (item != null && item.getLotSize() != null) {
            itemType.setLotSize(item.getLotSize());
        }
        return itemType;
    }

    /**
     * StartPrice - Format is Auction then StartPrice, format is Fixed then COSMOS ITEM_COST price
     *
     * @return
     */
    private AmountType getStartPrice() {
        PricingInfo pricingInfo = Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getPrice)
                .orElse(null);

        CoreInfo.FormatEnum format = Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getFormat)
                .orElse(null);
        if (format != null && pricingInfo != null) {
            if (ApiSellingExtSvcConstants.ITEM_LISTING_TYPE_FIXED_PRICE.equals(format.getValue())) {
                return getCurrentPrice();
            } else if (ApiSellingExtSvcConstants.ITEM_LISTING_TYPE_CHINESE_AUCTION.equals(format.getValue()) ||
                    ApiSellingExtSvcConstants.ITEM_LISTING_TYPE_AUCTION.equals(format.getValue())) {
                if (pricingInfo.getStartPrice() != null) {
                    return AmountTypeUtil.getAmountType(pricingInfo.getCurrency(),
                            pricingInfo.getStartPrice());
                }
            }
        }
        return null;
    }

    private void setSellingStatus(SellingStatusType sellingStatusType) {
        sellingStatusType.setListingStatus(getListingStatus());
        sellingStatusType.setCurrentPrice(getCurrentPrice());
        Long variationId = getVariationId();
        if(null != variationId && variationId != 0 ) {
            VariationInfo variationInfo = getVariationInfo(variationId,listingActivity);
            sellingStatusType.setQuantitySold(getSoldVariationQuantity(variationInfo));
        } else {
            sellingStatusType.setQuantitySold(getSoldQuantity());
        }
        sellingStatusType.setFinalValueFee(finalValueFeeReturned ? finalValueFee : null);
        sellingStatusType.setBidCount(getBidCount());
    }

    private ListingStatusCodeType getListingStatus() {
        ListingStatusCodeType status = Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getLifecycle)
                .map(ListingLifecycle::getStatus)
                .map(ListingStatusMapper::map)
                .orElse(ListingStatusCodeType.CUSTOM_CODE);

        if (status == ListingStatusCodeType.ENDED && finalValueFeeReturned) {
            return ListingStatusCodeType.COMPLETED;
        }
        return status;
    }

    private CategoryType getCategory(String id) {
        CategoryType category = new CategoryType();
        category.setCategoryID(id);
        return category;
    }

    private InventoryTrackingMethodCodeType getInventoryTrackingMethod() {
        Boolean isManagedBySKU = Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getIsManagedBySKU).orElse(Boolean.FALSE);
        if (isManagedBySKU.booleanValue()) {
            return InventoryTrackingMethodCodeType.SKU;
        }
        return InventoryTrackingMethodCodeType.ITEM_ID;
    }

    private Boolean isAutoPay(List<Attribute> attribute) {
        String value = AttributeUtil.findAttribute(attribute, ApiSellingExtSvcConstants.IMMEDIATE_PAY)
                .map(Attribute::getValue)
                .orElse(null);

        return Boolean.parseBoolean(value);
    }

    private CharityType isCharityType(List<Attribute> attribute) {
        Boolean isCharity = AttributeUtil.findAttribute(attribute, ApiSellingExtSvcConstants.CHARITY_SALE)
                .map(Attribute::getValue)
                .map(Boolean::parseBoolean)
                .orElse(false);

        if (isCharity) {
            CharityType charityType = new CharityType();
            charityType.setCharityListing(true);
            return charityType;
        }
        return null;
    }

    private SiteCodeType getListingSite() {
        return AttributeUtil.findAttribute(lineItemAttributes, ApiSellingExtSvcConstants.LISTING_SITE_ID)
                .map(attribute -> SiteUtils.getSiteCode(attribute.getValue())).orElse(null);
    }

    private Integer getItemConditionId() {
        return AttributeUtil.findAttribute(lineItemAttributes, ApiSellingExtSvcConstants.ITEM_CONDITION_ID)
                .map(attribute -> Integer.valueOf(attribute.getValue())).orElse(null);
    }

    private String getApplicationData() {
        return AttributeUtil.findAttribute(lineItemAttributes, ITEM_APPLICATION_DATA).map(Attribute::getValue).orElse(null);
    }

    private boolean proformaFinalValueFeeReturned(ProformaOrderLineItemXType proformaOrderLineItemXType) {
        return AttributeUtil.findAttribute(proformaOrderLineItemXType.getAttribute(), "finalValueFeeCreditRequestSent")
                .map(Attribute::getValue).orElse("").equals("true");
    }

    private String getConditionDisplayName(String conditionId) {
        IContentMap contentMap = this.contentHelper.getContentManager()
                .getContentMap(ContentBundleEnum.ItemContent, ApiSellingExtSvcConstants.ITEM_CONDITION_NAME);
        if (contentMap.get(conditionId) != null) {
            return contentMap.get(conditionId).toString();
        } else {
            CalLogger.warn("GSTOrderItemBuilder - ItemId with invalid conditionId", getItemId() + "-" + conditionId);
            return null;
        }
    }

    private Boolean isPrivateSale() {
        return AttributeUtil.findAttribute(lineItemAttributes, ApiSellingExtSvcConstants.PRIVATE_SALE)
                .map(Attribute::getValue).map(Boolean::parseBoolean).orElse(false);
    }

    private BuyerProtectionCodeType getBuyerProtection() {
        boolean isItemEligible = AttributeUtil.findAttribute(lineItemAttributes, ApiSellingExtSvcConstants.BUYER_PROTECTION_ELIGIBLE)
                .map(Attribute::getValue).map(Boolean::parseBoolean).orElse(false);
        return isItemEligible ? BuyerProtectionCodeType.ITEM_ELIGIBLE : BuyerProtectionCodeType.ITEM_INELIGIBLE;
    }


    private Boolean isGetItFast(ShippingStepExtension shippingStep) {
        return Optional.ofNullable(shippingStep)
                .map(ShippingStepExtension::getAttributes)
                .orElse(Collections.emptyList())
                .stream()
                .filter(attribute -> ApiSellingExtSvcConstants.ATTR_GET_IT_FAST.equals(attribute.getName()))
                .findFirst()
                .map(attribute -> Boolean.parseBoolean(attribute.getValue()))
                .orElse(false);
    }

    public ListingDetailsType getListingDetails() {
        ListingDetailsType listingDetailsType = super.getListingDetails();
        listingDetailsType.setCheckoutEnabled(true);
        listingDetailsType.setHasReservePrice(hasReservePrice());
        Long relistId = Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore).map(CoreInfo::getRelistId).orElse(null);
        if (relistId != null) {
            listingDetailsType.setRelistedItemID(relistId.toString());
        }

        Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getBestOfferTerms)
                .map(BestOfferTerms::getAutoDeclineThresholdPrice)
                .map(minimumBestOfferPrice -> AmountTypeUtil.getAmountType(minimumBestOfferPrice.getCurrency().name(), minimumBestOfferPrice.getValue()))
                .ifPresent(listingDetailsType::setMinimumBestOfferPrice);

        return listingDetailsType;
    }

}