package com.ebay.app.apisellingextsvc.service.dal.exchangerate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = ExchangeRateDAO.TABLE_NAME)
@com.ebay.persistence.Table(alias = ExchangeRateDAO.TABLE_ALIAS)
public interface ExchangeRate {

    @Column(name = "DAY_OF_RATE")
    Date getDayOfRate();

    void setDayOfRate(Date var1);

    @Column(name = "FROM_CURRENCY")
    int getFromCurrency();

    void setFromCurrency(int fromCurrency);

    @Column(name = "RATE")
    double getRate();

    void setRate(double rate);

}
