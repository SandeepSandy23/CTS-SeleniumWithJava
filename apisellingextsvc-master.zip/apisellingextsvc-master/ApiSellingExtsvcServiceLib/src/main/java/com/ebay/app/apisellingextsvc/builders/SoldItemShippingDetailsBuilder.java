package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.mappers.ShippingTypeCodeTypeMapper;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.lib.lasng.model.CoreInfo;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.lib.lasng.model.ShippingInfo;
import com.ebay.lib.lasng.model.ShippingTypeInfo;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ShippingDetailsType;

import java.util.List;
import java.util.Optional;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.CALCULATED_DOMESTIC_FLAT_INTERNATIONAL;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.FLAT_DOMESTIC_CALCULATED_INTERNATIONAL;

public class SoldItemShippingDetailsBuilder extends ItemShippingDetailsBuilder {

    private final ListingActivity listingActivity;

    public SoldItemShippingDetailsBuilder(Task<?> task, ListingActivitiesDetail listingActivitiesDetail,
                                          ContractResponseType contractResponseType, ListingActivity listingActivity) {
        super(task, listingActivitiesDetail, contractResponseType);
        this.listingActivity = listingActivity;
    }

    @Override
    public ShippingDetailsType doBuild() {
        ShippingDetailsType shippingDetailsType = super.doBuild();
        setShippingType(shippingDetailsType, listingActivity);
        return shippingDetailsType;
    }

    // Use case needed for selected shipping types only: FLAT_DOMESTIC_CALCULATED_INTERNATIONAL
    // and CALCULATED_DOMESTIC_FLAT_INTERNATIONAL
    // The mapper for LAS and LANSNG response conversion does not convert the shipping types correctly. It uses
    // the first shipping type available. We'll instead use all the shipping type values and use the mapper to get
    // the correct shipping type.
    private void setShippingType(ShippingDetailsType shippingDetailsType, ListingActivity listingActivity) {
        Optional<List<ShippingTypeInfo>> shippingInfo = Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore).map(CoreInfo::getShipping)
                .map(ShippingInfo::getShippingTypes);
        if (shippingInfo.isPresent()) {
            StringBuilder sellerSelectedShipping = new StringBuilder();
            for (ShippingTypeInfo shippingTypeInfo : shippingInfo.get()) {
                sellerSelectedShipping.append(shippingTypeInfo.getCostType().toString());
                sellerSelectedShipping.append(shippingTypeInfo.getShippingType().getValue());
            }
            if (CALCULATED_DOMESTIC_FLAT_INTERNATIONAL.equals(sellerSelectedShipping.toString())
                    || FLAT_DOMESTIC_CALCULATED_INTERNATIONAL.equals(sellerSelectedShipping.toString())) {
                shippingDetailsType.setShippingType(ShippingTypeCodeTypeMapper.map(sellerSelectedShipping.toString()));
            }
        }
    }
}
