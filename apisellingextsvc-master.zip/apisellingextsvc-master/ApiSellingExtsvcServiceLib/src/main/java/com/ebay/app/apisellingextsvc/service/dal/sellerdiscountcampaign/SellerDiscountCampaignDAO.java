package com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign;


import com.ebay.integ.dal.DalRuntimeException;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.DDRException;
import com.ebay.integ.dal.ddr.ModulusToupleProvider;
import com.ebay.integ.dal.ddr.MultiToupleProvider;
import com.ebay.integ.dal.ddr.ToupleProvider;
import com.ebay.integ.dal.map.*;
import com.ebay.persistence.DALVersion;
import com.ebay.persistence.QueryGenerator;
import com.ebay.persistence.QueryGenerator.Type;

import java.util.*;

@DALVersion("3.0")
public class SellerDiscountCampaignDAO extends BaseDao2 {
    public static final String FINDCAMPAIGNSBYIDS = "FINDCAMPAIGNSBYIDS";
    static MappingIncludesAttribute[] m_ourDDRHints = new MappingIncludesAttribute[0];
    static MappingIncludesAttribute[] m_campaignIdHints = new MappingIncludesAttribute[0];
    private static boolean m_mapInitialized = false;
    private static volatile SellerDiscountCampaignDAO s_instance;
    private static SellerDiscountCampaignCodeGenDoImpl s_noFetchProtoDO;
    private static GenericMap<SellerDiscountCampaign> s_map;
    private static final String HINT0 = "m_sellerId";
    private static final String HINT1 = "m_sellerCampaignId";

    protected SellerDiscountCampaignDAO() {
        if (!m_mapInitialized) {
            initMap();
        }

    }

    public static SellerDiscountCampaignDAO getInstance() {
        if (s_instance == null) {
            synchronized (SellerDiscountCampaignDAO.class) {
                if (s_instance == null) {
                    s_instance = new SellerDiscountCampaignDAO();
                }
            }
        }

        return s_instance;
    }

    public static void initMap() {
        if (!m_mapInitialized) {
            GenericMap<SellerDiscountCampaign> map = GenericMap.getMap(SellerDiscountCampaign.class);
            if (map == null) {
                map = new GenericMap(SellerDiscountCampaign.class);
            }

            map.setDalVersion("3.0");
            m_mapInitialized = true;
            s_map = map;
            s_noFetchProtoDO = new SellerDiscountCampaignDoImpl(null, map);
            s_noFetchProtoDO.setSellerId(-1L);
            s_noFetchProtoDO.setSellerCampaignId(-1L);

            try {
                map.registerToupleProvider(getToupleProvider());
            } catch (NullPointerException var2) {
                throw new DalRuntimeException("DAL not properly initialized.");
            }

            map.setTableJoins(getTableJoins(map));
            map.setQueries(getRawQueries(map));
            map.setReadSets(getReadSets(map));
            initHintGroups(map);
            map.init();
        }
    }

    private static ToupleProvider getToupleProvider() throws DDRException {
        ToupleProvider tpH0 = new ModulusToupleProvider("SELLER_CAMPAIGN_%", "incentive%host", "m_sellerId");
        ToupleProvider tpH1 = new ModulusToupleProvider("SELLER_CAMPAIGN_%", "incentive%host", "m_sellerCampaignId");
        Map<String, ToupleProvider> mapTPs = new HashMap(2);
        mapTPs.put(HINT0, tpH0);
        mapTPs.put(HINT1, tpH1);
        return new MultiToupleProvider(mapTPs);
    }

    protected static void initHintGroups(GenericMap<SellerDiscountCampaign> map) {
        m_ourDDRHints = new MappingIncludesAttribute[]{map.getLocalFieldMapping(1)};
        m_campaignIdHints = new MappingIncludesAttribute[]{map.getLocalFieldMapping(0)};
    }

    @QueryGenerator(
            factory = "InQueryFactory",
            type = Type.Select,
            variant = "Select Query with IN Clause"
    )
    public List<SellerDiscountCampaign> findCampaignsByIds(List<Long> keyValues) throws FinderException {
        List<SellerDiscountCampaign> protoDos = new ArrayList(keyValues.size());
        QueryEngine qe = new QueryEngine();
        Iterator var4 = keyValues.iterator();

        Long keydef;
        while (var4.hasNext()) {
            keydef = (Long)var4.next();
            SellerDiscountCampaignDoImpl protoDo = new SellerDiscountCampaignDoImpl(this, s_map);
            protoDo.setLocalOnly(true);
            protoDo.setSellerCampaignId(keydef);
            protoDos.add(protoDo);
        }

        List<SellerDiscountCampaign> result = new ArrayList();
        qe.readMultiple(result, s_map, protoDos, "FINDCAMPAIGNSBYIDS", ReadSets.FULL.value, null, m_campaignIdHints);
        return result;
    }


    protected static Query[] getRawQueries(GenericMap<SellerDiscountCampaign> map) {
        Query[] queries = new Query[]{
                new SelectQuery(FINDCAMPAIGNSBYIDS, m_campaignIdHints,
                        new SelectStatement[]{
                                new SelectStatement(ReadSets.FULL.value,
                                        "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> " +
                                                "WHERE S.SELLER_CAMPAIGN_ID IN <IN>:m_sellerCampaignId</IN> AND (<JOIN/>)")},
                        -1,
                        new SelectSetParms(20, 10, 100, s_noFetchProtoDO)),
        };
        return queries;
    }

    protected static TableJoin[] getTableJoins(GenericMap<SellerDiscountCampaign> map) {
        TableJoin[] tableJoins = new TableJoin[0];
        return tableJoins;
    }

    protected static ReadSet[] getReadSets(GenericMap<SellerDiscountCampaign> map) {
        ReadableMapping budgetAmountFm = (ReadableMapping)map.getLocalFieldMapping(8);
        ReadableMapping campaignDescFm = (ReadableMapping)map.getLocalFieldMapping(6);
        ReadableMapping campaignFlags01Fm = (ReadableMapping)map.getLocalFieldMapping(12);
        ReadableMapping campaignNameFm = (ReadableMapping)map.getLocalFieldMapping(3);
        ReadableMapping campaignStatusFm = (ReadableMapping)map.getLocalFieldMapping(7);
        ReadableMapping campaignTypeFm = (ReadableMapping)map.getLocalFieldMapping(4);
        ReadableMapping currencyCodeFm = (ReadableMapping)map.getLocalFieldMapping(10);
        ReadableMapping endDateFm = (ReadableMapping)map.getLocalFieldMapping(14);
        ReadableMapping marketingPriorityFm = (ReadableMapping)map.getLocalFieldMapping(11);
        ReadableMapping redeemedAmountFm = (ReadableMapping)map.getLocalFieldMapping(9);
        ReadableMapping sellerCampaignIdFm = (ReadableMapping)map.getLocalFieldMapping(0);
        ReadableMapping sellerIdFm = (ReadableMapping)map.getLocalFieldMapping(1);
        ReadableMapping siteIdFm = (ReadableMapping)map.getLocalFieldMapping(2);
        ReadableMapping startDateFm = (ReadableMapping)map.getLocalFieldMapping(13);
        ReadableMapping restrictionTypeFm = (ReadableMapping)map.getLocalFieldMapping(15);
        ReadableMapping ruleTemplateIdFm = (ReadableMapping)map.getLocalFieldMapping(16);
        ReadableMapping deletedDateFm = (ReadableMapping)map.getLocalFieldMapping(17);
        ReadableMapping redirectCategoryIdFm = (ReadableMapping)map.getLocalFieldMapping(20);
        ReadableMapping sbeLastProcessedDateFm = (ReadableMapping)map.getLocalFieldMapping(21);
        ReadableMapping campaignImgUrlFm = (ReadableMapping)map.getLocalFieldMapping(22);
        ReadableMapping campaignImgMd5Fm = (ReadableMapping)map.getLocalFieldMapping(23);
        ReadableMapping campaignSubType = (ReadableMapping)map.getLocalFieldMapping(5);
        ReadSet[] readSets = new ReadSet[]{new ReadSet(ReadSets.CAMPAIGNDETAILSREADSET.value,
                new ReadableMapping[]{sellerCampaignIdFm, sellerIdFm, siteIdFm, campaignNameFm, campaignTypeFm, campaignDescFm,
                        campaignStatusFm, budgetAmountFm, redeemedAmountFm, currencyCodeFm, marketingPriorityFm, campaignFlags01Fm,
                        startDateFm, endDateFm, restrictionTypeFm, ruleTemplateIdFm, deletedDateFm, redirectCategoryIdFm,
                        sbeLastProcessedDateFm, campaignImgUrlFm, campaignImgMd5Fm, campaignSubType}),
                new ReadSet(ReadSets.FULL.value, (ReadableMapping[])null)};
        return readSets;
    }

    public enum ReadSets {
        CAMPAIGNDETAILSREADSET(1),
        MATCHANY(-1),
        FULL(-2);

        int value;

        ReadSets(int v) {
            this.value = v;
        }

        public int getValue() {
            return this.value;
        }

    }
}

