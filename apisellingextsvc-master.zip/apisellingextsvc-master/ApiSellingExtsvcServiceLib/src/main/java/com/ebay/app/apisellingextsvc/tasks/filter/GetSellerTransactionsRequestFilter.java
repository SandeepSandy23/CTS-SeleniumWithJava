package com.ebay.app.apisellingextsvc.tasks.filter;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.content.IContentManager;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;

import com.ebay.app.apisellingextsvc.framework.outputselector.OutputSelectorGenerator;
import com.ebay.app.apisellingextsvc.handlers.ExceptionHandler;
import com.ebay.app.apisellingextsvc.utils.ConfigurableUtils;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import ebay.apis.eblbasecomponents.GetSellerTransactionsRequestType;
import ebay.apis.eblbasecomponents.GetSellerTransactionsResponseType;
import ebay.apis.eblbasecomponents.PaginationType;
import org.springframework.util.CollectionUtils;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

public class GetSellerTransactionsRequestFilter implements IFilter {

    private final GetSellerTransactionsRequestType request;
    private final ContentResource contentResource;

    public GetSellerTransactionsRequestFilter(
            GetSellerTransactionsRequestType request,
            ContentResource contentResource) {
        this.request = request;
        this.contentResource = contentResource;
    }

    @Override
    public void doFilter() {
        IContentManager errorContentManager = contentResource.contentHelper.getErrorContentManager();
        doTimeFiltering(errorContentManager);
        // Check if user-inputted pagination are in a valid range
        doPaginationFiltering(errorContentManager);
        // Check if the value of outputSelector is invalid
        doOutputSelectorFiltering(errorContentManager);
        // Populate any null pagination fields to default fields: https://jirap.corp.ebay.com/browse/SOAPI-842
        setDefaultFields();
    }

    private void doTimeFiltering(IContentManager errorContentManager) {
        if (request.getNumberOfDays() != null) {
            if (request.getNumberOfDays() > ApiSellingExtSvcConstants.MAX_NUMBER_OF_DAYS || request.getNumberOfDays() < ApiSellingExtSvcConstants.MIN_NUMBER_OF_DAYS) {
                CalLogger.error("Request Filter Error", "NumberOfDays exceeds maximum.");
                ExceptionHandler.throwException(ApplicationError.EXCEED_MODIFIED_DATE, errorContentManager);
            }
        } else {
            if (request.getModTimeFrom() != null) {
                if (request.getModTimeTo() != null) {
                    long modTimeFromMillis = request.getModTimeFrom().toGregorianCalendar().getTimeInMillis();
                    long modTimeToMillis = request.getModTimeTo().toGregorianCalendar().getTimeInMillis();
                    if (DateUtil.getDaysBetween(modTimeFromMillis + 1, modTimeToMillis) >= ApiSellingExtSvcConstants.MAX_MODIFIED_DURATION_DAYS) {
                        CalLogger.error("Request Filter Error", "ModTime range is greater than maximum duration.");
                        ExceptionHandler.throwException(ApplicationError.EXCEED_MODIFIED_DATE, errorContentManager);
                    } else if (modTimeFromMillis > modTimeToMillis) {
                        CalLogger.error("Request Filter Error", "ModTimeFrom is greater than modTimeTo.");
                        ExceptionHandler.throwException(ApplicationError.INVALID_MOD_DATE_FROM, errorContentManager);
                    }
                }
                if (request.getModTimeFrom().compare(DateUtil.getDatetimeNow()) > 0) {
                    CalLogger.error("Request Filter Error", "ModDateFrom is in the future.");
                    ExceptionHandler.throwException(ApplicationError.INVALID_MOD_DATE_FROM, errorContentManager);
                }
            }
        }
    }

    private void checkFieldValid(IContentManager errorContentManager) {
        String outputSelector[] = request.getOutputSelector().toArray(new String[0]);

        ArrayList parsedOS = ConfigurableUtils.parseOutputSelectors(outputSelector);
        Map errorsList = ConfigurableUtils.validate(OutputSelectorGenerator.getGraphMap(parsedOS, GetSellerTransactionsResponseType.class).getMap(), parsedOS);

        if (!CollectionUtils.isEmpty(errorsList) && !CollectionUtils.isEmpty(errorsList.values())) {
            String[] valuesArray = (String[]) errorsList.values().toArray(new String[0]);
            CalLogger.error("Request Filter Error", "One or more of the output selectors is incorrect." + errorsList.values().toString());
            ExceptionHandler.throwException(ApplicationError.OUTPUT_SELECTOR_INVALID, errorContentManager, Collections.EMPTY_LIST, valuesArray);
        }
    }


    private void doOutputSelectorFiltering(IContentManager errorContentManager) {
        if(CollectionUtils.isEmpty(request.getOutputSelector())) {
            return;
        }
        checkFieldValid(errorContentManager);
    }

    private void doPaginationFiltering(IContentManager errorContentManager) {
        if (request.getPagination() != null) {
            if (request.getPagination().getEntriesPerPage() != null) {
                int entriesPerPage = request.getPagination().getEntriesPerPage();
                if (entriesPerPage > ApiSellingExtSvcConstants.MAXIMUM_ENTRIES_PER_PAGE || entriesPerPage < ApiSellingExtSvcConstants.MINIMUM_ENTRIES_PER_PAGE) {
                    CalLogger.error("Request Filter Error", "EntriesPerPage parameter is out of range.");
                    ExceptionHandler.throwException(ApplicationError.PARAM_OUT_OF_RANGE, errorContentManager, Arrays.asList("TransactionsPerPage", "1", "200"), "TransactionsPerPage", "1", "200");
                }
            }

            if (request.getPagination().getPageNumber() != null) {
                int pageNumber = request.getPagination().getPageNumber();
                if (pageNumber < ApiSellingExtSvcConstants.MINIMUM_PAGE_NUMBER) {
                    CalLogger.error("Request Filter Error", "PageNumber parameter is out of range.");
                    ExceptionHandler.throwException(ApplicationError.PARAM_OUT_OF_RANGE, errorContentManager, Arrays.asList("PageNumber", "1", ""), "PageNumber", "1", "");
                }
            }
        }
    }

    private void setDefaultFields() {
        //Pagination
        if (request.getPagination() == null) {
            request.setPagination(new PaginationType());
        }

        //EntriesPerPage
        if (request.getPagination().getEntriesPerPage() == null) {
            request.getPagination().setEntriesPerPage(ApiSellingExtSvcConstants.GST_DEFAULT_ENTRIES_PER_PAGE);
        }

        //PageNumber
        if (request.getPagination().getPageNumber() == null) {
            request.getPagination().setPageNumber(ApiSellingExtSvcConstants.MINIMUM_PAGE_NUMBER);
        }
    }
}
