package com.ebay.app.apisellingextsvc.builders.gmes;

import com.ebay.app.apisellingextsvc.builders.BaseTransactionArrayTypeBuilder;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.cos.las.type.BulkUserNoteResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GMESOrderTransactionArrayBuilder extends BaseTransactionArrayTypeBuilder {

    private final OrderCSXType order;
    private final int trxVersion;
    private final List<DetailLevelCodeType> detailLevels;
    private final ApiSellingExtSvcConfigValues configValues;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final IContentHelper contentHelper;
    private final BulkUserNoteResponse bulkUserNoteResponse;
    private final SiteContext siteContext;
    private final Integer version;
    private final ContractResponseType contractResponseType;

    public GMESOrderTransactionArrayBuilder(Task<?> task,
                                            @Nonnull ContractResponseType contractResponseType,
                                            int trxVersion,
                                            IContentHelper contentHelper,
                                            SiteContext siteContext,
                                            List<DetailLevelCodeType> detailLevels,
                                            ApiSellingExtSvcConfigValues configValues,
                                            Map<Long, ListingActivity> itemIdListingActivityMap,
                                            BulkUserNoteResponse bulkUserNoteResponse,
                                            Integer version) {

        super(task, contractResponseType);
        this.order = contractResponseType.getOrder();
        this.trxVersion = trxVersion;
        this.contentHelper = contentHelper;
        this.siteContext = siteContext;
        this.detailLevels = detailLevels;
        this.configValues = configValues;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.bulkUserNoteResponse = bulkUserNoteResponse;
        this.version = version;
        this.contractResponseType = contractResponseType;
    }

    @Override
    protected List<TransactionType> doBuild() {

        List<TransactionType> transactionTypeList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(order.getLineItemTypes())) {
            for (LineItemXType lineItem : order.getLineItemTypes()) {
                if (lineItem != null && shouldBuildTransaction(order.getLineItemTypes().size(), lineItem.getSourceId())) {
                    transactionTypeList.add(new GMESOrderTransactionBuilder(task, order, lineItem, contentHelper, siteContext,
                            detailLevels, configValues, trxVersion, itemIdListingActivityMap, bulkUserNoteResponse, version, contractResponseType).build());
                }
            }
        }

        return transactionTypeList;
    }
}
