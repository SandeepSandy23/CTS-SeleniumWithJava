package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.service.bof.exchangerate.ExchangeRateBofImpl;
import com.ebay.app.apisellingextsvc.service.bof.shippingcarrier.ShippingCarrierBofImpl;
import com.ebay.app.apisellingextsvc.service.bof.shippingservice.ShippingServiceBofImpl;
import com.ebay.app.apisellingextsvc.service.bof.taxrate.TaxRateBofImpl;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPrefCodeGenDoImpl;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPrefFlags;
import com.ebay.app.apisellingextsvc.service.invokers.model.SellerDiscountCampaignModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.SellerDiscountEntityModel;
import com.ebay.app.apisellingextsvc.tasks.models.SellerProdDataModel;
import com.ebay.app.apisellingextsvc.tasks.models.UserAddressPhoneModel;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class LoadGetSellerTransactionsDataTask implements Task<SellerProfileDataContext>, ITaskResultInjectable {
    private final Map<String, Object> resultMap = new HashMap<>();
    public static final String TASK_NAME = "LoadGetSellerTransactionDataTask";
    private final SellerProfileDataContext dataContext;

    public LoadGetSellerTransactionsDataTask() {
        dataContext = new SellerProfileDataContext(
                new TaxRateBofImpl(),
                new ShippingServiceBofImpl(),
                new ShippingCarrierBofImpl(),
                new ExchangeRateBofImpl());
    }

    @Override
    public SellerProfileDataContext call() {
        if(resultMap.get(SellerDiscountEntityModel.class.getName()) != null) {
            SellerDiscountEntityModel sdModel = (SellerDiscountEntityModel)resultMap.get(SellerDiscountEntityModel.class.getName());
            dataContext.setSellerDiscountMap(sdModel.getSellerDiscountEntityMap());
        }
        if (resultMap.get(SellerDiscountCampaignModel.class.getName()) != null) {
            SellerDiscountCampaignModel sdcModel = (SellerDiscountCampaignModel) resultMap.get(SellerDiscountCampaignModel.class.getName());
            dataContext.setSellerDiscountCampaignMap(sdcModel.getSellerDiscountCampaignMap());
        }
        if (resultMap.get(SellerProdDataModel.class.getName()) != null) {
            SellerProdDataModel spdModel = (SellerProdDataModel) resultMap.get(SellerProdDataModel.class.getName());
            dataContext.setSellerProdMap(spdModel.getSellerProdId());
        }
        if (resultMap.get(SellerPrefCodeGenDoImpl.class.getName()) != null) {
            dataContext.setSellerRequirePhoneNumber(getIsSellerRequirePhoneNumber((SellerPrefCodeGenDoImpl)
                    resultMap.get(SellerPrefCodeGenDoImpl.class.getName())));
        }
        if (resultMap.get(UserAddressPhoneModel.class.getName()) != null) {
            UserAddressPhoneModel uapm = (UserAddressPhoneModel)
                    resultMap.get(UserAddressPhoneModel.class.getName());
            dataContext.setUserAddressIdShowPhoneMap(uapm.getSellerProdId());
        }
        return dataContext;
    }

    private boolean getIsSellerRequirePhoneNumber(SellerPrefCodeGenDoImpl sellerPref) {
        return sellerPref.hasFlag(SellerPrefFlags.REQUIRE_PHONE_FOR_SHIPPING_MASK);
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
