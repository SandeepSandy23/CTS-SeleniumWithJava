package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.service.bof.sellerdiscountcampaign.ISellerDiscountCampaignBof;
import com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign.SellerDiscountCampaign;
import com.ebay.app.apisellingextsvc.service.invokers.model.SellerDiscountCampaignModel;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.app.apisellingextsvc.utils.TypeCastUtil;
import com.ebay.coms.type.v1.PromotionTypeEnumType;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.order.common.v1.Promotion;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.common.collect.ImmutableSet;
import org.apache.commons.collections.CollectionUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class LoadSellerCampaignsTask implements Task, ITaskResultInjectable {

    private Map<String, Object> resultMap = new HashMap<>();
    private static final ImmutableSet<String> sellerDiscountSet = ImmutableSet.of(
            PromotionTypeEnumType.SELLER_DISCOUNTED_PROMOTIONAL_OFFER.value());
    private final ISellerDiscountCampaignBof sellerDiscountCampaignBof;


    public LoadSellerCampaignsTask(ISellerDiscountCampaignBof sellerDiscountCampaignBof) {
        this.sellerDiscountCampaignBof = sellerDiscountCampaignBof;
    }

    @Override
    public SellerDiscountCampaignModel call() {
        List<Long> campaignsList = getCampaignsList((ContractResponse) resultMap.get(ContractResponse.class.getName()));
        if (campaignsList == null || campaignsList.isEmpty()) {
            return new SellerDiscountCampaignModel(new HashMap<>());
        }
        List<SellerDiscountCampaign> results = sellerDiscountCampaignBof.findCampaignsByIds(campaignsList);
        return new SellerDiscountCampaignModel(getResultMap(results));
    }

    private List<Long> getCampaignsList(ContractResponse contractResponse) {
        List<Long> campaignsList = Optional.ofNullable(contractResponse)
                .map(ContractResponse::getMembers)
                .orElse(Collections.emptyList())
                .stream()
                .filter(ContractResponseUtil::isOrder)
                .map(ContractResponseType::getOrder)
                .filter(Objects::nonNull)
                .flatMap(item -> item.getLineItemTypes().stream())
                .filter(item -> CollectionUtils.isNotEmpty(item.getPromotionsCS()))
                .flatMap(item -> item.getPromotionsCS().stream())
                .filter(item -> sellerDiscountSet.contains(item.getType()) && !ApiSellingExtSvcConstants.SHIPPING_DISCOUNT_TYPE.equals(item.getCode()))
                .map(Promotion::getCode)
                .map(TypeCastUtil::parseLong)
                .collect(Collectors.toList());
        return campaignsList;
    }

    private Map<Long, SellerDiscountCampaign> getResultMap(List<SellerDiscountCampaign> result) {
        if (CollectionUtils.isEmpty(result)) {
            return new HashMap<>();
        }
        return result.stream()
                .collect(Collectors.toMap(item -> item.getSellerCampaignId(),
                    Function.identity(),
                    (v1, v2) -> v1
                ));
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
