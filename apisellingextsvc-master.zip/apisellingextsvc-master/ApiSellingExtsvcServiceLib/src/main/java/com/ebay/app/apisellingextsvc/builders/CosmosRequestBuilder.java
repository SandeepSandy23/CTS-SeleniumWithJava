package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.service.client.model.CosmosRequest;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.app.apisellingextsvc.utils.Headers;
import com.ebay.globalenv.SiteEnum;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class CosmosRequestBuilder {

    // note: getOrdersTransaction doesn't support time range,
    // * GetOrders
    //  - If time range and order id present, ignore time range
    //  - CreateTimeFrom/CreateTimeTo date filters are ignored if the NumberOfDays date filter is used in the request, or if one or more order IDs
    //  are passed in the request.
    //  - ModTimeFrom/ModTimeTo date filters are ignored if the CreateTimeFrom/CreateTimeTo or NumberOfDays date filters are used in the request,
    //  or if one or more order IDs are passed in the request.
    //  - If OrderIDs are used in the request, all other filter criteria are ignored.
    //  - The NumberOfDays filter will take precedence over the date range filters if both are included in the request.

    // * GetOrdersTransaction
    //  - Does not have time range in request
    //  - Does not have NumberOfDays
    //
    // * GetItemTransaction
    //  - Does not have CreateTime range in request

    // * GetMyeBaySelling
    // - Does not have paginationMode in param
    // - Has Visibility param

    private String itemId;
    private String transactionId;
    private List<String> orderIds;
    /**
     * entryPerPage Min: 1. Max: 200. Default: 25.
     */
    private Integer entryPerPage;
    private Integer pageNumber;
    private Calendar createDateFrom;
    private Calendar createDateTo;
    private Calendar modDateFrom;
    private Calendar modDateTo;
    private String userType;
    private String userId;
    private String userName;
    private String detailLevel;
    private String sortOrder;
    private String orderStatus;
    private HttpHeaders requestHeaders;
    private Boolean hasPaginationMode;
    private VisibilityValue visibilityValue;
    private String fundingStatus;
    private String shipmentStatus;
    private String omsVersion;

    public CosmosRequestBuilder omsVersion(String omsVersion) {
        this.omsVersion = omsVersion;
        return this;
    }

    public CosmosRequestBuilder userName(String userName) {
        this.userName = userName;
        return this;
    }

    public CosmosRequestBuilder userId(String userId) {
        this.userId = userId;
        return this;
    }

    public CosmosRequestBuilder requestHeader(HttpHeaders requestHeaders) {
        this.requestHeaders = requestHeaders;
        return this;
    }

    public CosmosRequestBuilder modDateFrom(Calendar modDateFrom) {
        this.modDateFrom = modDateFrom;
        return this;
    }

    public CosmosRequestBuilder createDateFrom(Calendar createDateFrom) {
        this.createDateFrom = createDateFrom;
        return this;
    }

    public CosmosRequestBuilder createDateTo(Calendar createDateTo) {
        this.createDateTo = createDateTo;
        return this;
    }

    public CosmosRequestBuilder modDateTo(Calendar modDateTo) {
        this.modDateTo = modDateTo;
        return this;
    }

    public CosmosRequestBuilder detailLevel(String detailLevel) {
        this.detailLevel = detailLevel;
        return this;
    }

    public CosmosRequestBuilder sortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
        return this;
    }

    public CosmosRequestBuilder userType(String userType) {
        this.userType = userType;
        return this;
    }
    
    public CosmosRequestBuilder entryPerPage(Integer entryPerPage) {
        this.entryPerPage = entryPerPage;
        return this;
    }

    public CosmosRequestBuilder pageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
        return this;
    }

    public CosmosRequestBuilder hasPaginationMode(Boolean hasPaginationMode) {
        this.hasPaginationMode = hasPaginationMode;
        return this;
    }

    public CosmosRequestBuilder visibilityValue(VisibilityValue visibilityValue) {
        this.visibilityValue = visibilityValue;
        return this;
    }

    public CosmosRequestBuilder fundingStatus(String fundingStatus) {
        this.fundingStatus = fundingStatus;
        return this;
    }

    public CosmosRequestBuilder shipmentStatus(String shipmentStatus) {
        this.shipmentStatus = shipmentStatus;
        return this;
    }

    public CosmosRequest build() {
        return new CosmosRequest(buildCosmosQueryStr(), buildCosmosHeader(), getPageNumber(), getEntryPerPage());
    }

    public CosmosRequest buildSummary() {
        return new CosmosRequest(buildCosmosQuerySummaryStr(), buildCosmosHeader(), getPageNumber(), getEntryPerPage());
    }

    private String buildCosmosQueryStr() {
        List<String> query = new ArrayList<>();
        query.add(buildKeys());
        query.add(buildFieldGroup());
        query.add(buildUserType());
        query.add(buildFilter());
        query.add(buildSort());
        query.add(buildPagination());
        if (hasPaginationMode) {
            query.add(buildPaginationMode());
        }
        query.add(buildAddressQuery());
        return query.stream().filter(StringUtils::isNotBlank).collect(Collectors.joining(ApiSellingExtSvcConstants.QUERY_PARAM_AND));
    }

    private String buildCosmosQuerySummaryStr() {
        List<String> query = new ArrayList<>();
        query.add(buildSummaryFields());
        query.add(buildUserType());
        query.add(buildFilter());
        return query.stream().filter(StringUtils::isNotBlank).collect(Collectors.joining(ApiSellingExtSvcConstants.QUERY_PARAM_AND));
    }

    private String buildPaginationMode() {
        return buildSingleQuery(ApiSellingExtSvcConstants.QUERY_PARAM_PAGINATION_MODE, ApiSellingExtSvcConstants.LINE_ITEM);
    }

    private String buildAddressQuery() {
        return buildSingleQuery(ApiSellingExtSvcConstants.QUERY_PARAM_FIELDS, ApiSellingExtSvcConstants.QUERY_PARAM_ADDRESS);
    }

    private String buildPagination() {
        Integer limit = getEntryPerPage();
        Integer offset = getOffSet(limit);
        return buildSingleQuery(ApiSellingExtSvcConstants.QUERY_PARAM_LIMIT, limit.toString())
                + ApiSellingExtSvcConstants.QUERY_PARAM_AND
                + buildSingleQuery(ApiSellingExtSvcConstants.QUERY_PARAM_OFFSET, offset.toString());

    }

    private Integer getOffSet(Integer limit) {
        return Math.multiplyExact(getPageNumber() - 1, limit);
    }

    private Integer getPageNumber() {
        Integer pn = ObjectUtils.defaultIfNull(pageNumber, 1);
        return Math.max(pn, ApiSellingExtSvcConstants.MINIMUM_PAGE_NUMBER); // minimum pageNumber is 1
    }

    private Integer getEntryPerPage() {
        Integer limit = ObjectUtils.defaultIfNull(entryPerPage, ApiSellingExtSvcConstants.GST_DEFAULT_ENTRIES_PER_PAGE);
        limit = Math.min(limit, ApiSellingExtSvcConstants.MAXIMUM_ENTRIES_PER_PAGE); // maximum entryPerPage is 200
        limit = Math.max(limit, ApiSellingExtSvcConstants.MINIMUM_ENTRIES_PER_PAGE); // minimum entryPerPage is 1
        return limit;
    }

    private String buildSort() {
        if (sortOrder != null) {
            return buildSingleQuery(ApiSellingExtSvcConstants.QUERY_PARAM_SORT, this.sortOrder);
        }
        return null;
    }

    private String buildFilter() {
        String key = ApiSellingExtSvcConstants.QUERY_PARAM_FILTER + ApiSellingExtSvcConstants.QUERY_PARAM_EQUALS;
        List<String> values = new ArrayList<>();
        values.add(buildDateRangeFilterValue());
        String str = values.stream().filter(StringUtils::isNotBlank).collect(Collectors.joining(ApiSellingExtSvcConstants.QUERY_PARAM_COMMA));
        if (visibilityValue != null) {
            str = str.concat("," + ApiSellingExtSvcConstants.FILTER_VISIBILITY + ":" + visibilityValue.getName());
        }
        if (fundingStatus != null) {
            str = str.concat("," + ApiSellingExtSvcConstants.FILTER_FUNDING_STATUS + ":{" + fundingStatus + "}");
        }
        if (shipmentStatus != null) {
            str = str.concat("," + ApiSellingExtSvcConstants.FILTER_SHIPMENT_STATUS + ":{" + shipmentStatus + "}");
        }
        return StringUtils.isNotBlank(str) ? key + str : null;
    }

    private String buildUserType() {
        if (this.userType != null) {
            return buildSingleQuery(ApiSellingExtSvcConstants.QUERY_PARAM_USER_TYPE, this.userType.toLowerCase(Locale.US));
        }
        return null;
    }

    private String buildSingleQuery(String key, String val) {
        return key + ApiSellingExtSvcConstants.QUERY_PARAM_EQUALS + val;
    }

    private String buildDateRangeFilterValue() {
        StringBuilder sb = new StringBuilder();
        if (CollectionUtils.isEmpty(orderIds)) {
            String cdFromStr = DateUtil.convert(createDateFrom);
            String cdToStr = DateUtil.convert(createDateTo);
            String mdFromStr = DateUtil.convert(modDateFrom);
            String mdToStr = DateUtil.convert(modDateTo);
            if (cdFromStr != null) {
                // The maximum date range that may be specified with the CreateTimeFrom and CreateTimeTo fields is 90 days.
                // CreateTimeFrom/CreateTimeTo date filters are ignored if the NumberOfDays date filter is used in the request,
                // or if one or more order IDs are passed in the request.
                sb.append(ApiSellingExtSvcConstants.QUERY_PARAM_CREATION_DATE)
                        .append(ApiSellingExtSvcConstants.COLON)
                        .append(ApiSellingExtSvcConstants.BRACKET_LEFT)
                        .append(cdFromStr)
                        .append(ApiSellingExtSvcConstants.DOT)
                        .append(ApiSellingExtSvcConstants.DOT);
                if (cdToStr != null) {
                    sb.append(cdToStr);
                }
                sb.append(ApiSellingExtSvcConstants.BRACKET_RIGHT);
            } else if (modDateFrom != null
                    && createDateFrom == null
                    && createDateTo == null) {
                // https://developer.ebay.com/devzone/xml/docs/Reference/eBay/GetOrders.html#Request.ModTimeFrom
                // ModTimeFrom/ModTimeTo date filters are ignored if the CreateTimeFrom/CreateTimeTo
                // or NumberOfDays date filters are used in the request,
                // or if one or more order IDs are passed in the request.
                sb.append(ApiSellingExtSvcConstants.QUERY_PARAM_LAST_MODIFIED_DATE)
                        .append(ApiSellingExtSvcConstants.COLON)
                        .append(ApiSellingExtSvcConstants.BRACKET_LEFT)
                        .append(mdFromStr)
                        .append(ApiSellingExtSvcConstants.DOT)
                        .append(ApiSellingExtSvcConstants.DOT);
                if (mdToStr != null) {
                    sb.append(mdToStr);
                }
                sb.append(ApiSellingExtSvcConstants.BRACKET_RIGHT);
            }
        }
        return sb.length() > 0 ? sb.toString() : null;
    }

    private String buildFieldGroup() {
        // todo no need full group, e.g., we don't need action url
        String key = ApiSellingExtSvcConstants.QUERY_PARAM_FIELDGROUP + ApiSellingExtSvcConstants.QUERY_PARAM_EQUALS;
        return key + "full";
    }

    private String buildSummaryFields() {
        StringBuilder sb = new StringBuilder();
        sb.append(ApiSellingExtSvcConstants.SUMMARY_SUBTOTAL)
                .append(ApiSellingExtSvcConstants.COMMA)
                .append(ApiSellingExtSvcConstants.SUMMARY_TOTAL_COUNT)
                .append(ApiSellingExtSvcConstants.COMMA)
                .append(ApiSellingExtSvcConstants.SUMMARY_ITEM_COUNT);
        String key = ApiSellingExtSvcConstants.QUERY_PARAM_FIELDS + ApiSellingExtSvcConstants.QUERY_PARAM_EQUALS;
        return key + sb.toString();
    }

    private String buildKeys() {
        String key = ApiSellingExtSvcConstants.QUERY_PARAM_KEYS + ApiSellingExtSvcConstants.QUERY_PARAM_EQUALS;
        String val = null;
        if (CollectionUtils.isNotEmpty(orderIds)) {
            val = StringUtils.join(orderIds, ApiSellingExtSvcConstants.QUERY_PARAM_COMMA);
        }
        return val != null ? key + val : null;
    }

    private HttpHeaders buildCosmosHeader() {
        HttpHeaders headers = new Headers();
        String siteId = ObjectUtils.defaultIfNull(
                HeaderUtil.getHeader(requestHeaders, ApiSellingExtSvcConstants.X_EBAY_API_SITE_ID),
                "0");
        headers.getRequestHeaders().putSingle(ApiSellingExtSvcConstants.X_EBAY_C_MARKETPLACE_ID,
                SiteEnum.get(Integer.parseInt(siteId)).getName());
        headers.getRequestHeaders().putSingle(ApiSellingExtSvcConstants.X_EBAY_C_ENDUSERCTX,
                HeaderUtil.getEndUserCtx(userName, userId));
        headers.getRequestHeaders().putSingle(ApiSellingExtSvcConstants.X_EBAY_OMS_VERSION,
                omsVersion);
        return headers;
    }

    public enum VisibilityValue {
        ACTIVE("active"),
        HIDDEN("hidden");

        private final String name;

        VisibilityValue(String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }
    }

}
