package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.json.CustomObjectMapper;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.app.apisellingextsvc.service.client.model.GingerResponseType;
import com.ebay.jaxrs.client.EndpointUri;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import java.net.SocketTimeoutException;
import java.util.List;
import java.util.Map.Entry;
import java.util.Optional;

public abstract class BaseGingerClient<R, Q> {

    private static final String CAL_LOG_TIMEOUT = "_Timeout";
    private static final ImmutableMap<String, String> encodingCharMap = ImmutableMap.of(
            "\\{", "%7B",
            "}", "%7D",
            "\\|", "%7C"
    );

    private Class<Q> responseTypeClass;

    public BaseGingerClient(Class<Q> responseTypeClass) {
        this.responseTypeClass = responseTypeClass;
    }

    public abstract GingerClientResponse<Q> getGingerResponse(GingerClientRequest<R> gingerRequest);

    public abstract String getTargetBase();

    public abstract Logger getLogger();

    public Class<Q> getResponseTypeClass() {
        return responseTypeClass;
    }

    public void setResponseTypeClass(Class<Q> responseTypeClass) {
        this.responseTypeClass = responseTypeClass;
    }

    protected Client getOrRegisterGingerClient() {
        return GingerClientFactory.getInstance().getClientById(getTargetBase());
    }

    @Nonnull
    protected GingerClientResponse<Q> processGetRequest(
            String uri, List<Pair<String,Object>> queryParams, @Nullable MultivaluedMap<String, Object> headermap) {
        Client client = getOrRegisterGingerClient();
        if (client != null) {
            try {
                String endpoint = (String) client.getConfiguration().getProperty(EndpointUri.KEY);
                WebTarget target = client.target(endpoint + processInvalidCharEncoding(uri));
                if (CollectionUtils.isNotEmpty(queryParams)) {
                    for (Pair<String, Object> queryParam : queryParams) {
                        target = target.queryParam(queryParam.getLeft(),queryParam.getRight());
                    }
                }
                Invocation.Builder builder = target.request(MediaType.APPLICATION_JSON_TYPE);
                if (headermap != null) {
                    builder = builder.headers(headermap);
                }
                Response res = builder.get();
                if(res.getStatus() == HttpStatus.SC_OK) {
                    String response = res.readEntity(String.class);
                    return extractClientResponse(response);
                } else {
                    throw new RuntimeException("Failed to get response: "+res.getStatus());
                }
            } catch (RuntimeException e) {
                return handleGingerClientException(e);
            }
        }
        return new GingerClientResponse<>();
    }

    protected GingerClientResponse<Q> processGetRequest(String uri) {
        return processGetRequest(uri, null, null);
    }

    protected GingerClientResponse<Q> processPostRequest(
            String uri, GingerClientRequest<R> contentRequest) {
        return processPostRequest(uri, contentRequest.getHeaders(), contentRequest);
    }

    protected GingerClientResponse<Q> processPostRequest(
            String uri, MultivaluedMap<String, Object> headermap, GingerClientRequest<R> request) {
        return processPostRequest(uri,headermap,request,false);
    }

    protected GingerClientResponse<Q> processPostRequest(
            String uri, MultivaluedMap<String, Object> headermap, GingerClientRequest<R> request, boolean isGraphqlQuery) {
        Client client = getOrRegisterGingerClient();
        MediaType mediaType = (isGraphqlQuery) ? new MediaType("application", "graphql") : MediaType.APPLICATION_JSON_TYPE;
        if (client != null && request.isRequestDataAvailable()) {
            String endpoint = (String) client.getConfiguration().getProperty(EndpointUri.KEY);
            WebTarget target = client.target(endpoint).path(uri);
            try {
                CalLogger.info("target URI", target.getUri().toString());
                ObjectMapper mapper = new ObjectMapper();
                Response res = target.request(MediaType.APPLICATION_JSON_TYPE).headers(headermap)
                        .post(Entity.entity(request.getRequest(), mediaType));
                String response = res.readEntity(String.class);
                return extractClientResponse(response);
            } catch (RuntimeException e) {
                return handleGingerClientException(e);
            }
        }
        return createFailureResponse();
    }


    protected GingerClientResponse<Q> processPostRequestWithRetry(
            String uri, MultivaluedMap<String, Object> headermap, GingerClientRequest<R> request, boolean skipRetry) {
        Client client = getOrRegisterGingerClient();
        if (client != null && request.isRequestDataAvailable()) {
            String endpoint = (String) client.getConfiguration().getProperty(EndpointUri.KEY);
            WebTarget target = client.target(endpoint).path(uri);
            //Adding retry for 1 time if exception occurs
            //This retry should be removed after the LASNG provides the new param to query the item details.
            try {
                CalLogger.info("target URI", target.getUri().toString());
                Response res = target.request(MediaType.APPLICATION_JSON_TYPE).headers(headermap)
                        .post(Entity.entity(request.getRequest(), MediaType.APPLICATION_JSON_TYPE));
                String response = res.readEntity(String.class);
                return extractClientResponse(response);
            } catch (RuntimeException e) {
                if (!skipRetry) {
                    boolean isSocketTimeOutException = Optional.of(e).map(Throwable::getCause).map(Throwable::getCause)
                            .map(Throwable::getCause).filter(t -> t instanceof SocketTimeoutException).isPresent();
                    if (isSocketTimeOutException) {
                        processPostRequestWithRetry(uri, headermap, request, true);
                    }
                }
                return handleGingerClientException(e);
            }
        }
        return createFailureResponse();
    }


    protected GingerClientResponse<Q> processPostRequest(
            String uri, MultivaluedMap<String, Object> headermap, List<Pair<String,Object>> queryParams , GingerClientRequest<R> request) {
        Client client = getOrRegisterGingerClient();
        if (client != null && request.isRequestDataAvailable()) {
            String endpoint = (String) client.getConfiguration().getProperty(EndpointUri.KEY);
            CalLogger.info("endpoint", endpoint);
            CalLogger.info("path", uri);
            WebTarget target = client.target(endpoint).path(uri);
            if (CollectionUtils.isNotEmpty(queryParams)) {
                for (Pair<String, Object> queryParam : queryParams) {
                    target = target.queryParam(queryParam.getLeft(),queryParam.getRight());
                }
            }
            try {
                CalLogger.info("target URI", target.getUri().toString());

                String response = target.request(MediaType.APPLICATION_JSON_TYPE).headers(headermap)
                        .post(Entity.entity(request.getRequest(), MediaType.APPLICATION_JSON_TYPE), String.class);

                return extractClientResponse(response);
            } catch (RuntimeException e) {
                if (e instanceof WebApplicationException) {
                    CalLogger.info(getClass().getSimpleName(), ((WebApplicationException) e).getResponse().readEntity(String.class));
                }
                return handleGingerClientException(e);
            }
        }
        return createFailureResponse();
    }

    protected GingerClientResponse<Q> processGetStoreRequest(
            String uri, MultivaluedMap<String, Object> headermap) {
        Client client = getOrRegisterGingerClient();
        if (client != null) {
            try {
                String endpoint = (String) client.getConfiguration().getProperty(EndpointUri.KEY);
                WebTarget target = client.target(endpoint + processInvalidCharEncoding(uri));
                Invocation.Builder builder = target.request(MediaType.APPLICATION_JSON_TYPE);
                if (headermap != null) {
                    builder = builder.headers(headermap);
                }

                Response res = builder.get();
                if(res.getStatus() == HttpStatus.SC_OK) {
                    String response = res.readEntity(String.class);
                    return extractClientResponse(response);
                } else if(res.getStatus() == HttpStatus.SC_BAD_REQUEST) {
                    // If not store seller, shows CAL info message
                    CalLogger.warn("StoreEntSvcClient", "Error calling store service, seller may not be a store seller");
                }
            } catch (RuntimeException exp) {
                CalLogger.error("StoreEntSvcClient", "Error calling store service");
            }
        }
        return createFailureResponse();
    }

    protected GingerClientResponse<Q> processGetSVLSRequest(String uri,MultivaluedMap<String, Object> headermap) {
        Client client = getOrRegisterGingerClient();
        if (client != null) {
            try {
                String endpoint = (String) client.getConfiguration().getProperty(EndpointUri.KEY);
                WebTarget target = client.target(endpoint + processInvalidCharEncoding(uri));
                Invocation.Builder builder = target.request(MediaType.APPLICATION_JSON_TYPE);
                if (headermap != null) {
                    builder = builder.headers(headermap);
                }

                Response res = builder.get();
                if(res.getStatus() == HttpStatus.SC_OK) {
                    String response = res.readEntity(String.class);
                    return extractClientResponse(response);
                } else if(res.getStatus() == HttpStatus.SC_BAD_REQUEST) {
                    CalLogger.warn("SVLSServiceClient", "itemId / versionId not found in SVLS- "+ uri);
                }
            } catch (RuntimeException exp) {
                CalLogger.error("SVLSServiceClient", "Error calling svls service");
            }
        }
        return createFailureResponse();
    }

    protected GingerClientResponse<Q> processPostESRequest(
            String uri, MultivaluedMap<String, Object> headermap, GingerClientRequest<R> request) {
        Client client = getOrRegisterGingerClient();
        MediaType mediaType =  MediaType.APPLICATION_JSON_TYPE;
        if (client != null && request.isRequestDataAvailable()) {
            String endpoint = (String) client.getConfiguration().getProperty(EndpointUri.KEY);
            WebTarget target = client.target(endpoint).path(uri);
            try {
                headermap.add("Content-Type" ,MediaType.APPLICATION_JSON);
                CalLogger.info("target URI", target.getUri().toString());
                ObjectMapper mapper = new ObjectMapper();
                String response = target.request(MediaType.APPLICATION_JSON_TYPE).headers(headermap)
                        .post(Entity.entity(request.getRequest(), mediaType), String.class);
                return extractClientResponse(response);
            } catch (RuntimeException e) {
                return handleGingerClientException(e);
            }
        }
        return createFailureResponse();
    }
    protected GingerClientResponse<Q> processApisellingioRequest(
            MultivaluedMap<String, Object> headermap, GingerClientRequest<R> request) {
        Client client = getOrRegisterGingerClient();
        if (client != null && request.isRequestDataAvailable()) {
            String endpoint = (String) client.getConfiguration().getProperty(EndpointUri.KEY);
           WebTarget target = client.target(endpoint);
            try {
                String response = target.request(MediaType.APPLICATION_XML_TYPE).headers(headermap)
                        .post(Entity.entity(request.getRequest(), MediaType.APPLICATION_XML_TYPE), String.class);
                return extractClientResponse(response);
            } catch (RuntimeException e) {
                return handleGingerClientException(e);
            }
        }
        return createFailureResponse();
    }

    @SuppressWarnings("unchecked")
    @Nonnull
    protected GingerClientResponse<Q> extractClientResponse(String response) {
        GingerClientResponse<Q> gingerResponse = new GingerClientResponse<>();
        if (response != null) {
            gingerResponse.setResponseType(GingerResponseType.SUCCESS);
            try {
                if (!String.class.equals(responseTypeClass)) {
                    Q gingerData = CustomObjectMapper.getInstance().readValue(response, responseTypeClass);
                    gingerResponse.setResponse(gingerData);
                } else {
                    gingerResponse.setResponse((Q) response);
                }
            } catch (Exception e) {
                getLogger().error(e.getMessage());
            }
        }
        return gingerResponse;
    }

    protected GingerClientResponse<Q> createFailureResponse() {
        return createResponse(GingerResponseType.FAILURE);
    }

    protected String processInvalidCharEncoding(String url) {
        String res = url;
        if (StringUtils.isNotBlank(res)) {
            for (Entry<String, String> entry : encodingCharMap.entrySet()) {
                res = res.replaceAll(entry.getKey(), entry.getValue());
            }
        }
        return res;
    }

    @Nonnull
    private GingerClientResponse<Q> handleGingerClientException(@Nonnull RuntimeException exception) {
        Optional<Throwable> timeoutFinder = Optional.of(exception).map(Throwable::getCause).map(Throwable::getCause)
                .map(Throwable::getCause).filter(t -> t instanceof SocketTimeoutException);
        if (timeoutFinder.isPresent()) {
            CalLogger.error(getClass().getSimpleName() + CAL_LOG_TIMEOUT, ApiSellingExtSvcConstants.EMPTY_STRING);
            return createResponse(GingerResponseType.TIMEOUT);
        } else {
            CalLogger.error(getClass().getSimpleName(), exception.getMessage());
            return createResponse(GingerResponseType.FAILURE);
        }
    }

    @Nonnull
    private GingerClientResponse<Q> createResponse(GingerResponseType responseType) {
        GingerClientResponse<Q> gingerResponse = new GingerClientResponse<>();
        gingerResponse.setResponseType(responseType);
        return gingerResponse;
    }
}
