package com.ebay.app.apisellingextsvc.audit.comparator.facet;


import com.ebay.app.apisellingextsvc.audit.comparator.CustomExtComparator;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.ebay.app.apisellingextsvc.common.helper.DateHelper;
import com.fasterxml.jackson.databind.JsonNode;
import com.ebay.app.apisellingextsvc.audit.comparator.IJsonNodeComparator;



import java.util.regex.Pattern;

public class DateTimeComparator implements IJsonNodeComparator {
    private static final Long TIME_DIFF_ACCURANCY = 10 * 60 * 1000L;
    private final CustomExtComparator comparator;

    public DateTimeComparator(CustomExtComparator comparator) {
        this.comparator = comparator;
    }

    @Override
    public boolean customCompareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        if (pattern.isTextual()) {
            if (!org.textValue().equals(tar.textValue())) {
                if (Pattern.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}.*", org.textValue())
                        && Pattern.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}.*", tar.textValue())) {
                    long orgDate = DateHelper.parseDateString(org.textValue()).getTime();
                    long tarDate = DateHelper.parseDateString(tar.textValue()).getTime();
                    long diff = Math.abs(orgDate - tarDate);
                    if (diff < TIME_DIFF_ACCURANCY) {
                        return true;
                    } else {
                        comparator.printDiff(key, path, org.asText(), tar.asText(), false, report);
                        return false;
                    }
                }
                return comparator.defaultCompareNode(org, tar, pattern, path, key, report);
            } else {
                return true;
            }
        } else {
            return comparator.defaultCompareNode(org, tar, pattern, path, key, report);
        }
    }
}

