package com.ebay.app.apisellingextsvc.config;

import com.ebay.raptorio.globalconfig.impl.GlobalConfigPropertySource;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GlobalConfigProvider implements IConfigProvider {

    private static final String GLOBAL_CONFIG_PREFIX = "apisellingextsvccfg.root.site.";
    private static final String GLOBAL_SITE = "GLOBAL";
    private static final Character DOT = '.';
    private final GlobalConfigPropertySource globalConfig;
    private final Integer siteId;

    public GlobalConfigProvider(GlobalConfigPropertySource globalConfig, Integer siteId) {
        this.globalConfig = globalConfig;
        this.siteId = siteId;
    }

    @Override
    public <V> V getProperty(String s, Class<V> clazz, IConfigProviderContext configProviderContext) {
        if (globalConfig != null) {
            String siteKey = GLOBAL_CONFIG_PREFIX + siteId + DOT + s;
            String globalKey = GLOBAL_CONFIG_PREFIX + GLOBAL_SITE + DOT + s;
            for (String key : Arrays.asList(siteKey, globalKey)) {
                if (globalConfig.getProperty(key) != null) {
                    return ConfigProviderUtil.formatValue(globalConfig.getProperty(key), clazz);
                }
            }
        }
        return null;
    }

    @Override
    public <V> List<V> getPropertyList(String s, Class<V> clazz, IConfigProviderContext configProviderContext) {
        if (globalConfig != null) {
            String siteKey = GLOBAL_CONFIG_PREFIX + siteId + DOT + s;
            String globalKey = GLOBAL_CONFIG_PREFIX + GLOBAL_SITE + DOT + s;
            for (String key: Arrays.asList(siteKey, globalKey)) {
                List<String> keyProperties = Arrays.asList(globalConfig.getPropertyNames())
                        .stream().filter(item -> item.contains(key)).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(keyProperties)) {
                    List<V> list = new ArrayList<>(keyProperties.size());
                    for (String actualKey : keyProperties) {
                        Object o = globalConfig.getProperty(actualKey);
                        if (o == null) {
                            continue;
                        }
                        V value = ConfigProviderUtil.formatValue(o, clazz);
                        if (value != null) {
                            list.add(value);
                        }
                    }
                    return list;
                }
                // This is needed for testing with config
                Object varObj = globalConfig.getProperty(key) == null ?
                        globalConfig.getProperty(globalKey) : globalConfig.getProperty(key);
                if (varObj instanceof List) {
                    return (List<V>) varObj;
                }
            }
        }
        return null;
    }
}
