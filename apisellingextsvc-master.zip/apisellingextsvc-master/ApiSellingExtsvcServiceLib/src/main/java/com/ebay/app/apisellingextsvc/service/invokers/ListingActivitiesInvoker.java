package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.ListingsContext;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.ListingsClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.cos.las.type.ListingActivitiesResponse;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class ListingActivitiesInvoker extends BaseServiceInvoker<ListingsContext, ListingActivitiesResponse, ListingsContext> {

    public static final String NAME = "ListingActivitiesInvoker";

    public ListingActivitiesInvoker(TracerContext tracerContext) {
        super(NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<ListingsContext, ListingActivitiesResponse> getGingerClient(ListingsContext listingsContext) {
        return new ListingsClient();
    }

    @Override
    protected GingerClientRequest<ListingsContext> getGingerRequest(ListingsContext listingsContext, HttpHeaders httpHeaders) {
        GingerClientRequest<ListingsContext> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(listingsContext);
        return gingerClientRequest;
    }
}
