package com.ebay.app.apisellingextsvc.context;

import com.ebay.globalenv.SiteEnum;

public class SiteContext {

    public final int viewingSiteId;

    public SiteContext(int viewingSiteId) {
        this.viewingSiteId = viewingSiteId;
    }

    public static SiteContext create(int viewingSiteId) {
        return new SiteContext(viewingSiteId);
    }

    public static SiteContext createMock() {
        return new SiteContext(SiteEnum.EBAY_US.getId());
    }

}
