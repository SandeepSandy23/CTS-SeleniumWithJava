package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;

import java.util.List;

public interface BaseTask<T> extends Task<T>, ITaskResultInjectable {

    /**
     * Here is your opportunity to do some short circuiting. Implement this method and provide your
     * short-circuit logic. call this method before proceeding your execution in @call().
     *
     * @return true
     */
    default boolean isPreConditionMet() {
        return true;
    }
}
