package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.FundingStatusTypeEnum;
import com.ebay.order.common.v1.OrderStateType;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.OrderStatusCodeType;

import java.util.function.Function;

public class OrderStatusMapper {

    private static final ImmutableMap<OrderStateType, Function<FundingStatusTypeEnum, OrderStatusCodeType>> mapName
            = new ImmutableMap.Builder<OrderStateType, Function<FundingStatusTypeEnum, OrderStatusCodeType>>()
            .put(OrderStateType.COMMITED, findingStatus -> OrderStatusCodeType.ACTIVE)
            .put(OrderStateType.CREATED, findingStatus ->
                    findingStatus == FundingStatusTypeEnum.FUNDED ? OrderStatusCodeType.COMPLETED : OrderStatusCodeType.ACTIVE)
            .put(OrderStateType.CANCELLED, findingStatus -> OrderStatusCodeType.CANCELLED)
            .put(OrderStateType.CANCEL_PENDING, findingStatus -> OrderStatusCodeType.CANCEL_PENDING)
            .build();

    private OrderStatusMapper() {
    }

    public static OrderStatusCodeType map(OrderStateType orderStatus, FundingStatusTypeEnum fundingStatusTypeEnum) {
        Function<FundingStatusTypeEnum, OrderStatusCodeType> getOrderStatus = mapName.get(orderStatus);
        return getOrderStatus != null ? getOrderStatus.apply(fundingStatusTypeEnum) : OrderStatusCodeType.CUSTOM_CODE;
    }

}
