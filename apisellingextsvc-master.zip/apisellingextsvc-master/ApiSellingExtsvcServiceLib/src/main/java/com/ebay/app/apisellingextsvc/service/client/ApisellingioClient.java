package com.ebay.app.apisellingextsvc.service.client;


import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApisellingioClient extends BaseGingerClient<String, String> {

    private static final Logger logger = LoggerFactory.getLogger(ApisellingioClient.class);

    private static final String CLIENT_ID = "apisellingio";

    public ApisellingioClient() {
        super(String.class);
    }

    @Override
    public GingerClientResponse<String> getGingerResponse(GingerClientRequest<String> request) {
        return processApisellingioRequest(request.getHeaders(), request);
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
