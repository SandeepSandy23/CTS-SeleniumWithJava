package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.ProgramUtil;
import com.ebay.cosmos.LineItemTotal;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.Code;
import com.ebay.order.common.v1.DateTime;
import com.ebay.order.common.v1.LineItemFulfillmentInfo;

import com.ebay.order.common.v1.LogisticsPlan;
import com.ebay.order.common.v1.LogisticsStep;
import com.ebay.order.common.v1.LogisticsStepTypeEnumType;
import com.ebay.order.common.v1.Order;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.order.common.v1.ShippingMethod;
import com.ebay.order.common.v1.ShippingOption;
import com.ebay.order.common.v1.ShippingStepExtension;

import com.ebay.order.common.v1.TimeEstimate;

import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.ShippingPackageInfoType;
import ebay.apis.eblbasecomponents.ShippingServiceOptionsType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ebay.order.common.v1.LogisticsStepTypeEnumType.SHIPPING;

public class TransactionShippingServiceSelectedBuilder extends ShippingBuilder {

    private int trxVersion;
    private OrderCSXType order;
    private ProformaOrderXType proformaOrder;
    private LineItemXType lineItem;
    private final LogisticsStep logisticsStep;
    private String lineItemId;
    private static final String EXPEDITED = "EXPEDITED";

    public TransactionShippingServiceSelectedBuilder(Task<?> task, int trxVersion, OrderCSXType order, LineItemXType lineItem) {
        super(task);
        this.trxVersion = trxVersion;
        this.order = order;
        this.lineItem = lineItem;
        this.lineItemId = lineItem.getLineItemId();

        int sequence = ProgramUtil.isExportsOrder(order.getPrograms()) ? 2 : 1;
        this.logisticsStep = Optional.of(order)
                .map(Order::getLogistics).orElse(Collections.emptyList()).stream()
                .flatMap(logisticsPlan -> logisticsPlan.getSteps().stream())
                .filter(logisticsStep -> logisticsStep.getSequence() == sequence)
                .filter(logisticsStep -> SHIPPING.equals(logisticsStep.getStepType()))
                .findFirst().orElse(null);
    }

    public TransactionShippingServiceSelectedBuilder(Task task, ProformaOrderXType proformaOrder) {
        super(task);
        this.proformaOrder = proformaOrder;

        this.logisticsStep = Optional.of(proformaOrder)
                .map(ProformaOrderXType::getLogisticsOptions).orElse(Collections.emptyList()).stream()
                .flatMap(logisticsPlan -> logisticsPlan.getSteps().stream())
                .filter(logisticsStep -> SHIPPING.equals(logisticsStep.getStepType()))
                .findFirst().orElse(null);
    }


    @Override
    protected ShippingServiceOptionsType doBuild() {
        //Populate Transaction Level Shipping Service Selected
        if (order != null) {
            return getOrderTransactionLevelShippingServiceSelected();
        } else if (proformaOrder != null) {
            return getProformaTransactionLevelShippingServiceSelected();
        }
        return null;
    }

    private ShippingServiceOptionsType getOrderTransactionLevelShippingServiceSelected() {
        ShippingServiceOptionsType shippingServiceOptions = null;
        List<ShippingPackageInfoType> shippingPackages = getShippingPackageInfo(order, lineItemId, trxVersion);
        if (shippingPackages.isEmpty()) {
            return null;
        }
        shippingServiceOptions = new ShippingServiceOptionsType();
        shippingServiceOptions.getShippingPackageInfo().addAll(shippingPackages);
        //shippingServiceOptions.setExpeditedService(isExpeditedService()); TODO: deprecated field?
        shippingServiceOptions.setImportCharge(getPriceLineAmount(PricelineTypeEnum.IMPORT_CHARGES));
        shippingServiceOptions.setShippingServiceCost(getShippingServiceCost());
        //ShippingDays shippingDays = getShippingTimeInDays(); TODO: deprecated field?
        //shippingServiceOptions.setShippingTimeMin(shippingDays.minDays); TODO: deprecated field?
        //shippingServiceOptions.setShippingTimeMax(shippingDays.maxDays); TODO: deprecated field?
        shippingServiceOptions.setShippingService(getShippingService());
        return shippingServiceOptions;
    }

    private ShippingServiceOptionsType getProformaTransactionLevelShippingServiceSelected() {
        ShippingServiceOptionsType shippingServiceOptions = new ShippingServiceOptionsType();
        shippingServiceOptions.setShippingService(getShippingService());
        shippingServiceOptions.setShippingServiceCost(AmountTypeUtil.getDefaultZeroAmountType(proformaOrder));
        return shippingServiceOptions;
    }

    /*private ShippingDays getShippingTimeInDays() {
        Optional<LineItemFulfillmentInfo> lineItemFulfillmentInfo = Optional.ofNullable(logisticsStep)
                .map(LogisticsStep::getLineItemFufillmentInfo).map(Collection::stream)
                .flatMap(Stream::findFirst);

        if (lineItemFulfillmentInfo.isPresent()) {
            ShippingDays shippingDays = new ShippingDays();
            shippingDays.minDays = getMinDays(lineItemFulfillmentInfo.get().getMinEstimateDate());
            shippingDays.maxDays = getMaxDays(lineItemFulfillmentInfo.get().getMaxEstimateDate());
            return shippingDays;
        }
        return null;
    }

    private int getMaxDays(DateTime maxEstimateDate) {
        int diffInDays = 0;
        if (maxEstimateDate != null && maxEstimateDate.getValue() != null
                && maxEstimateDate.getValue().getTime() > order.getCreationDate().getValue().getTime()) {
            diffInDays = DateUtil.getDiffDateTimeInDays(order.getCreationDate(), maxEstimateDate);
        }
        return Math.max(diffInDays, 0);
    }

    private int getMinDays(DateTime minEstimateDate) {
        int diffInDays = 0;
        if (minEstimateDate != null && minEstimateDate.getValue() != null
                && minEstimateDate.getValue().getTime() > order.getCreationDate().getValue().getTime()) {
            diffInDays = DateUtil.getDiffDateTimeInDays(order.getCreationDate(), minEstimateDate);

        }
        return Math.max(diffInDays, 0);
    }*/

    private AmountType getShippingServiceCost() {
        if (lineItemId == null) {
            AmountType shippingCost = getPriceLineAmount(PricelineTypeEnum.SHIPPING_COST);
            AmountType handlingCost = getPriceLineAmount(PricelineTypeEnum.HANDLING_COST);
            return AmountTypeUtil.sum(shippingCost, handlingCost);

        }

        return Optional.of(lineItem)
                .map(LineItemXType::getLineItemTotalSummary)
                .map(LineItemTotal::getShippingCost)
                .map(AmountTypeUtil::getAmountType)
                .orElse(null);
    }


    private String getShippingService() {
        return Optional.ofNullable(logisticsStep)
                .map(LogisticsStep::getStepExtension)
                .map(LogisticsStep.StepExtension::getShippingStep)
                .map(ShippingStepExtension::getShippingOptions).orElse(Collections.emptyList()).stream().findFirst()
                .map(ShippingOption::getShipppingMethod)
                .map(ShippingMethod::getShippingMethodCode)
                .map(Code::getValue).orElse(null);
    }

    /*private Boolean isExpeditedService() {
        Optional<Code> shippingMethodCategory = Optional.ofNullable(logisticsStep)
                .map(LogisticsStep::getStepExtension)
                .map(LogisticsStep.StepExtension::getShippingStep)
                .map(ShippingStepExtension::getShippingOptions).orElse(Collections.emptyList()).stream().findFirst()
                .map(ShippingOption::getShipppingMethod)
                .map(ShippingMethod::getShippingMethodCategory);
        return shippingMethodCategory.isPresent() && EXPEDITED.equals(shippingMethodCategory.get().getValue());
    }*/

    private AmountType getPriceLineAmount(PricelineTypeEnum priceLineType) {
        AmountType amountType = null;
        if (order != null && order.getOrderTotal() != null
                && CollectionUtils.isNotEmpty(order.getOrderTotal().getPriceLines())) {
            for (PriceLine priceLine : order.getOrderTotal().getPriceLines()) {
                if (priceLine != null && priceLineType.equals(priceLine.getType())
                        && priceLine.getAmount() != null
                        && priceLine.getAmount().getCurrency() != null
                        && StringUtils.isNotEmpty(priceLine.getAmount().getCurrency().getCurrencyName())) {
                    amountType = AmountTypeUtil.getAmountType(priceLine.getAmount());
                }
            }
        }
        return amountType;
    }



    private static class ShippingDays {
        private int minDays;
        private int maxDays;
    }
}
