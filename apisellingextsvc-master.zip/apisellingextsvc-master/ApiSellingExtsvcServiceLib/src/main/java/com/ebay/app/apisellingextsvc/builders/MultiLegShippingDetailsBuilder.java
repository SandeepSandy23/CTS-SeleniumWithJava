package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.service.bof.shippingservice.IShippingServiceBof;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.ShippingServiceUtil;
import com.ebay.cosmos.LineItemXType;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.EntityTotal;
import com.ebay.order.common.v1.LogisticsPlan;
import com.ebay.order.common.v1.LogisticsStep;
import com.ebay.order.common.v1.LogisticsStepTypeEnumType;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.order.common.v1.ShippingStepExtension;
import com.ebay.order.common.v1.ShippingTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AddressType;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.MultiLegShipmentType;
import ebay.apis.eblbasecomponents.MultiLegShippingDetailsType;
import ebay.apis.eblbasecomponents.MultiLegShippingServiceType;
import ebay.apis.eblbasecomponents.ShippingServiceOptionsType;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import static com.ebay.order.common.v1.LogisticsStepTypeEnumType.SHIPPING;

public class MultiLegShippingDetailsBuilder extends BaseFacetBuilder<MultiLegShippingDetailsType> {
    private final List<LineItemXType> lineItems;
    private final List<LogisticsPlan> logistics;
    protected final AddressType shipmentAddress;
    protected final ShippingServiceOptionsType shippingServiceOptionsType;
    private final IShippingServiceBof shippingServiceBof;

    public MultiLegShippingDetailsBuilder(Task<?> task,
                                          @Nonnull List<LogisticsPlan> logistics,
                                          @Nonnull List<LineItemXType> lineItems,
                                          @Nonnull IShippingServiceBof shippingServiceBof,
                                          @Nonnull ShippingServiceOptionsType shippingServiceOptionsType,
                                          @Nonnull AddressType shipmentAddress) {
        super(task);
        this.logistics = logistics;
        this.lineItems = lineItems;
        this.shippingServiceOptionsType = shippingServiceOptionsType;
        this.shippingServiceBof = shippingServiceBof;
        this.shipmentAddress = shipmentAddress;
    }

    @Override
    protected MultiLegShippingDetailsType doBuild() {
        MultiLegShippingDetailsType multiLegShippingDetailsType = new MultiLegShippingDetailsType();
        MultiLegShipmentType multiLegShipmentType = new MultiLegShipmentType();
        multiLegShipmentType.setShippingServiceDetails(getShippingServiceDetails());
        multiLegShipmentType.setShipToAddress(shipmentAddress);

        ShippingStepExtension shippingStep = ShippingBuilder.getShippingSteps(logistics);
        int shippingServiceId = getShippingServiceId(shippingStep);

        Integer[] days = ShippingServiceUtil.getShippingTimeInDays(shippingServiceBof, shippingServiceId);
        multiLegShipmentType.setShippingTimeMin(days[0]);
        multiLegShipmentType.setShippingTimeMax(days[1]);

        multiLegShippingDetailsType.setSellerShipmentToLogisticsProvider(multiLegShipmentType);
        return multiLegShippingDetailsType;
    }



    private int getShippingServiceId(ShippingStepExtension shippingStep) {
        return AttributeUtil.findAttribute(shippingStep.getAttributes(), ApiSellingExtSvcConstants.ATTR_SHIPPING_SERVICE_ID)
                .map(Attribute::getValue).map(Integer::valueOf).orElse(ApiSellingExtSvcConstants.EMPTY);
    }

    private MultiLegShippingServiceType getShippingServiceDetails() {
        MultiLegShippingServiceType multiLegShippingServiceType = new MultiLegShippingServiceType();
        multiLegShippingServiceType.setShippingService(getShippingMethodCode());
        multiLegShippingServiceType.setTotalShippingCost(getDomesticShippingCost());
        return multiLegShippingServiceType;
    }

    private AmountType getDomesticShippingCost() {
        if (CollectionUtils.isEmpty(lineItems)) {
            return null;
        }
        return lineItems.stream().map(LineItemXType::getLineItemTotal)
                .map(EntityTotal::getPriceLines)
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .filter(item -> PricelineTypeEnum.DOMESTIC_LEG_COST == item.getType())
                .filter(Objects::nonNull)
                .map(PriceLine::getAmount)
                .filter(Objects::nonNull)
                .reduce((x, y) -> new Amount(BigDecimal.valueOf(x.getValue())
                        .add(BigDecimal.valueOf(y.getValue())).doubleValue(),
                        y.getCurrency() != null ? y.getCurrency() : x.getCurrency()))
                .map(AmountTypeUtil::getAmountType).orElse(null);
    }

    private String getShippingMethodCode() {
        String res = null;
        if (CollectionUtils.isNotEmpty(logistics)) {
            for (LogisticsPlan logisticsPlan : logistics) {
                if (logisticsPlan != null && CollectionUtils.isNotEmpty(logisticsPlan.getSteps())) {
                    for (LogisticsStep logisticsStep : logisticsPlan.getSteps()) {
                        res = ShippingBuilder.getShippingMethodCodeValue(res, logisticsStep);
                        if (logisticsStep != null && LogisticsStepTypeEnumType.DIGITAL.equals(logisticsStep.getStepType())) {
                            return ApiSellingExtSvcConstants.SHIPPING_METHOD_CODE_OVERNIGHT;
                        }
                        if (res != null) {
                            return res;
                        }
                    }
                }
            }
        }
        return res;
    }
}
