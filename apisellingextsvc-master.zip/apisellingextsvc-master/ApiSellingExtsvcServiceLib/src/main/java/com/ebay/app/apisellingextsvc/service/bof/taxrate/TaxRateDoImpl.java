package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;

import java.util.Date;

public class TaxRateDoImpl extends TaxRateCodeGenDoImpl implements TaxRate {
    public TaxRateDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public boolean isEffective(Date date) {
        Date effectiveDate = this.getEffectiveDate();
        Date terminationDate = this.getTerminationDate();
        if (date == null) {
            return false;
        } else {
            boolean result;
            if (effectiveDate != null && effectiveDate.after(date)) {
                result = false;
            } else result = terminationDate == null || !terminationDate.before(date);

            return result;
        }
    }
}
