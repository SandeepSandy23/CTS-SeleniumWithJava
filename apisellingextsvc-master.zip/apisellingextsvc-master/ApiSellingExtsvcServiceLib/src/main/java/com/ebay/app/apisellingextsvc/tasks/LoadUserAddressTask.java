package com.ebay.app.apisellingextsvc.tasks;


import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPrefCodeGenDoImpl;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.tasks.models.UserAddressPhoneModel;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.tide.app.addressbook.AccountAddress;
import com.ebay.tide.app.addressbook.Attribute;
import com.ebay.tide.app.addressbook.request.AddressCorrelationRequest;
import com.ebay.tide.app.addressbook.request.BulkGetAddressRequest;
import com.ebay.tide.app.addressbook.response.AddressCorrelationResponse;
import com.ebay.tide.app.addressbook.response.BulkGetAddressResponse;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPref;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPrefFlags;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.math.NumberUtils;

import javax.annotation.Nonnull;
import javax.ws.rs.core.HttpHeaders;
import java.util.*;

public class LoadUserAddressTask implements Task, ITaskResultInjectable {
    private Map<String, Object> resultMap = new HashMap<>();
    public static final String TASK_NAME = "LoadUserAddressTask";

    private final IServiceInvoker<BulkGetAddressRequest, BulkGetAddressResponse> addressBookServiceInvoker;
    private final HttpHeaders headers;

    public LoadUserAddressTask(
                               HttpHeaders headers,
                               IServiceInvoker<BulkGetAddressRequest, BulkGetAddressResponse> addressBookServiceInvoker) {
        this.headers = headers;
        this.addressBookServiceInvoker = addressBookServiceInvoker;
    }

    @Override
    public UserAddressPhoneModel call() {
        UserAddressPhoneModel model = new UserAddressPhoneModel();

        //do not load buyer setting if seller pref turn off.
        SellerPrefCodeGenDoImpl sellerPref = (SellerPrefCodeGenDoImpl) resultMap.get(SellerPrefCodeGenDoImpl.class.getName());
        if (sellerPref == null || !sellerPref.hasFlag(SellerPrefFlags.REQUIRE_PHONE_FOR_SHIPPING_MASK)) {
            return model;
        }

        //return if no data return from cosmosng
        ContractResponse contractResponse = (ContractResponse) resultMap.get(ContractResponse.class.getName());
        List<ContractResponseType> members = Optional.ofNullable(contractResponse)
                .map(ContractResponse::getMembers).orElse(null);
        if (CollectionUtils.isEmpty(members)) {
            return model;
        }

        //get addressId and userId map
        Map<Long, Long> addressUserIdMap = getAddressUserIdMap(members);

        //bulk get address
        model.setSellerProdId(bulkGetAddress(addressUserIdMap));

        return model;
    }

    private Map<String, Boolean> bulkGetAddress(Map<Long, Long> addressUserIdMap) {
        Map<String, Boolean> result = new HashMap<>();
        BulkGetAddressRequest request = getBulkGetAddressRequest(addressUserIdMap);
        if (CollectionUtils.isEmpty(request.getRequests())) return result;
        BulkGetAddressResponse bulkGetAddressResponse = addressBookServiceInvoker.getResponse(request, headers);
        buildResponse(bulkGetAddressResponse, result);
        return result;
    }

    private BulkGetAddressRequest getBulkGetAddressRequest(Map<Long, Long> addressUserIdMap) {
        BulkGetAddressRequest request = new BulkGetAddressRequest();

        request.setRequests(new ArrayList<>());
        addressUserIdMap.forEach((addressId, userId) -> {
            AddressCorrelationRequest addressCorrelationRequest = new AddressCorrelationRequest();
            addressCorrelationRequest.setAddressId(String.valueOf(addressId));
            addressCorrelationRequest.setLegacyUserId(String.valueOf(userId));
            request.getRequests().add(addressCorrelationRequest);
        });
        return request;
    }

    private void buildResponse(BulkGetAddressResponse bulkGetAddressResponse, Map<String, Boolean> result) {

        List<AddressCorrelationResponse> addressCorrelationResponses = Optional.ofNullable(bulkGetAddressResponse)
                .map(BulkGetAddressResponse::getResponses).orElse(null);

        if (CollectionUtils.isNotEmpty(addressCorrelationResponses)) {
            addressCorrelationResponses.forEach(resp -> {
                boolean buyerConsentShowPhoneNumber = Optional.ofNullable(resp.getAddress())
                        .map(AccountAddress::getGlobalAttributes)
                        .flatMap(attributes -> attributes.stream()
                                .filter(attr -> attr.getName().equals(ApiSellingExtSvcConstants.BUYERS_CONSENT_TO_SHOW_PHONE_NUMBER))
                                .filter(attr -> attr.getNameSpace().equals(ApiSellingExtSvcConstants.CHECKOUT_NAMESPACE))
                                .findFirst())
                        .map(Attribute::getValue)
                        .map(Boolean::valueOf)
                        .orElse(false);

                result.put(resp.getAddressId(), buyerConsentShowPhoneNumber);

                CalLogger.info("buyer consent to show phone number", " addressId=" + resp.getAddress()
                        + ", buyerConsentShowPhoneNumber=" + buyerConsentShowPhoneNumber);
            });
        }
    }

    private Map<Long, Long> getAddressUserIdMap(List<ContractResponseType> members) {
        Map<Long, Long> addressUserIdMap = new HashMap<>();

        members.forEach(member -> {
            Long addressId = getAddressId(member);
            if (addressId == null) {
                return;
            }

            Long buyerId = getBuyerId(member);
            if (buyerId == null) {
                return;
            }

            addressUserIdMap.put(addressId, buyerId);
        });
        return addressUserIdMap;
    }

    private Long getAddressId(ContractResponseType member) {
        return Optional.ofNullable(member)
                .map(ContractResponseType::getOrder)
                .map(Order::getAddress)
                .flatMap(addresses -> addresses.stream().filter(address -> address.getType() == AddressType.BUYER_SHIPPING_ADDRESS).findFirst())
                .map(OrderAddressType::getAddressId)
                .map(Identifier::getBaseIdentifier)
                .filter(NumberUtils::isDigits)
                .map(Long::parseLong)
                .orElse(null);
    }

    private Long getBuyerId(ContractResponseType member) {
        return Optional.ofNullable(member)
                .map(ContractResponseType::getOrder)
                .map(Order::getBuyer)
                .map(User::getUserIdentifier)
                .map(UserIdentifier::getUserId)
                .filter(NumberUtils::isDigits)
                .map(Long::parseLong)
                .orElse(null);
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result))resultMap.put(result.getClass().getName(), result);
    }
}
