package com.ebay.app.apisellingextsvc.service.invokers.model;

import com.ebay.app.apisellingextsvc.service.dal.sellerdiscountcampaign.SellerDiscountCampaign;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * wrapper class to differentiate data in orchestrator dependency since Map<?,?> response of invoker is
 * generic
 *
 */
@AllArgsConstructor
@Getter
public class SellerDiscountCampaignModel {
    Map<Long, SellerDiscountCampaign> sellerDiscountCampaignMap;
}
