package com.ebay.app.apisellingextsvc.audit.comparator.facet;


import com.ebay.app.apisellingextsvc.audit.comparator.CustomExtComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.IJsonNodeComparator;
import com.ebay.app.apisellingextsvc.audit.report.IReport;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.Objects;

public class BuyerCheckoutMessageComparator implements IJsonNodeComparator {
    public static final String NEW_LINE = "\n";
    public static final String EMPTY = "";

    private final CustomExtComparator comparator;

    public BuyerCheckoutMessageComparator(CustomExtComparator comparator) {
        this.comparator = comparator;
    }

    @Override
    public boolean customCompareNode(JsonNode org, JsonNode tar, JsonNode pattern, String path, String key, IReport report) {
        if (pattern.isTextual()) {
            if (Objects.equals(org, tar)) {
                return true;
            }
            if (!pattern.isTextual()) {
                return comparator.defaultCompareNode(org, tar, pattern, path, key, report);
            }

            boolean result = Objects.equals(normalize(org), normalize(tar));
            if (!result) {
                comparator.printDiff(key, path, String.valueOf(org), String.valueOf(tar), result, report);
            }
            return result;
        } else {
            return comparator.defaultCompareNode(org, tar, pattern, path, key, report);
        }
    }

    private String normalize(JsonNode org) {
        return org.textValue().replace(NEW_LINE, EMPTY).trim();
    }
}
