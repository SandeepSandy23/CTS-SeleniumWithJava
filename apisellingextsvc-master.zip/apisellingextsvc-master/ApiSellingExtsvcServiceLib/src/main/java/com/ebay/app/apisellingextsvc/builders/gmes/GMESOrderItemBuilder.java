package com.ebay.app.apisellingextsvc.builders.gmes;

import com.ebay.app.apisellingextsvc.builders.OrderItemBuilder;
import com.ebay.app.apisellingextsvc.builders.SoldItemShippingDetailsBuilder;
import com.ebay.app.apisellingextsvc.builders.SoldItemVariationsBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.enums.ContentBundleEnum;
import com.ebay.app.apisellingextsvc.tasks.GMES.ListingActivitiesNGUtil;
import com.ebay.app.apisellingextsvc.tasks.GMES.ListingActivitiesUtil;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.ContractResponseUtil;
import com.ebay.app.apisellingextsvc.utils.ItemTitleUtil;
import com.ebay.cos.las.type.BulkUserNote;
import com.ebay.cos.las.type.BulkUserNoteResponse;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.Listing;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.lib.lasng.mapper.ListingActivityToListingActivitiesDetailMapper;
import com.ebay.lib.lasng.model.AdditionalAttributesInfo;
import com.ebay.lib.lasng.model.BuyingInfo;
import com.ebay.lib.lasng.model.CoreInfo;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.lib.lasng.model.ListingLifecycle;
import com.ebay.lib.lasng.model.PricingInfo;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.LineItem;
import com.ebay.order.common.v1.LineItemSource;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.ItemType;
import ebay.apis.eblbasecomponents.ListingTypeCodeType;
import ebay.apis.eblbasecomponents.PictureDetailsType;
import ebay.apis.eblbasecomponents.ReasonHideFromSearchCodeType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ebay.app.apisellingextsvc.utils.ViewItemURLUtil.buildViewItemURLForNaturalSearch;
import static com.ebay.app.apisellingextsvc.utils.ViewItemURLUtil.getViewItemUrl;

public class GMESOrderItemBuilder extends OrderItemBuilder {

    private final BulkUserNoteResponse bulkUserNoteResponse;
    private final Integer version;
    private final ApiSellingExtSvcConfigValues configValues;
    protected final SiteContext siteContext;
    private final LineItemSource sourceId;
    private final ContractResponseType contractResponseType;
    private final List<DetailLevelCodeType> detailLevels;

    private final IContentHelper contentHelper;

    public GMESOrderItemBuilder(Task task,
                                LineItemXType lineItem,
                                ApiSellingExtSvcConfigValues configValues,
                                Map<Long, ListingActivity> itemIdListingActivityMap,
                                List<DetailLevelCodeType> detailLevels,
                                BulkUserNoteResponse bulkUserNoteResponse,
                                Integer version,
                                SiteContext siteContext,
                                ContractResponseType contractResponseType,
                                IContentHelper contentHelper) {
        super(task, lineItem, configValues, itemIdListingActivityMap, null, detailLevels);
        this.bulkUserNoteResponse = bulkUserNoteResponse;
        this.sourceId = lineItem.getSourceId();
        this.version = version;
        this.configValues = configValues;
        this.siteContext = siteContext;
        this.contractResponseType = contractResponseType;
        this.contentHelper = contentHelper;
        this.detailLevels = detailLevels;
    }

    public GMESOrderItemBuilder(Task task,
                                ProformaOrderLineItemXType lineItem,
                                ApiSellingExtSvcConfigValues configValues,
                                Map<Long, ListingActivity> itemIdListingActivityMap,
                                List<DetailLevelCodeType> detailLevels,
                                BulkUserNoteResponse bulkUserNoteResponse,
                                Integer version,
                                SiteContext siteContext,
                                ContractResponseType contractResponseType,
                                IContentHelper contentHelper) {
        super(task, lineItem, configValues, itemIdListingActivityMap, null, detailLevels);
        this.bulkUserNoteResponse = bulkUserNoteResponse;
        this.sourceId = lineItem.getSourceId();
        this.version = version;
        this.configValues = configValues;
        this.siteContext = siteContext;
        this.contentHelper = contentHelper;
        this.contractResponseType = contractResponseType;
        this.detailLevels = detailLevels;
    }

    @Override
    protected ItemType doBuild() {
        ItemType itemType = super.doBuild();
        itemType.setStartPrice(getStartPrice());
        itemType.setBuyItNowPrice(getGMESBuyItNowPrice());
        itemType.setListingDetails(getListingDetails());
        itemType.setTitle(getItemTitle());
        // If unavailable in LAS, use from COSMOS
        String SKU = getSKU();
        if (StringUtils.isNotEmpty(SKU)) {
            itemType.setSKU(SKU);
        } else {
            itemType.setSKU(super.getSKU());
        }
        setConvertedPrices(itemType);
        if (version >= configValues.pictureDetailsVersion) {
            itemType.setPictureDetails(new PictureDetailsType());
        }
//        itemType.setQuantityAvailable(getAvailableQuantity());
        if (!itemType.getListingType().equals(ListingTypeCodeType.FIXED_PRICE_ITEM)) {
            AmountType reservePrice = ListingActivitiesNGUtil.getReservePrice(listingActivity);
            if (reservePrice != null && reservePrice.getValue() > 0) {
                itemType.setReservePrice(reservePrice);
            }
        }
        Long watchCount = getWatchCount();
        if (watchCount > 0) {
            itemType.setWatchCount(watchCount);
        }
        ListingActivitiesDetail listingActivitiesDetail = ListingActivityToListingActivitiesDetailMapper.map(listingActivity);
        itemType.setShippingDetails(new SoldItemShippingDetailsBuilder(task, listingActivitiesDetail, contractResponseType, listingActivity).build());
        itemType.setVariations(new SoldItemVariationsBuilder(task, listingActivitiesDetail, itemType.getSellingStatus(), sourceId.getVariationId()).build());
        Boolean isReserveMet = isReserveMet();
        if (isReserveMet) {
            itemType.getSellingStatus().setReserveMet(true);
        }
        itemType.setPrivateNotes(getPrivateNotes(itemType));
        if (ContractResponseUtil.isOrder(contractResponseType) && Optional.ofNullable(contractResponseType).map(ContractResponseType::getOrder).map(OrderCSXType::getBuyerNotesToSeller).isPresent()) {
            itemType.setEBayNotes(StringUtils.replace(ApiSellingExtSvcConstants.EBAY_NOTE_TEMPLATE, "$EBAY_NOTE$",
                    contentHelper.getContentManager().getText(ContentBundleEnum.MessageContent, "NOTE_HAS_BUYER_NOTE")));
        }
        try {
            itemType.setTimeLeft(getTimeLeft());
        } catch (DatatypeConfigurationException e) {
            CalLogger.error("Time left duration error", ExceptionUtils.getStackTrace(e));
        }
        String listingSite = String.valueOf(siteContext.viewingSiteId);
        if (itemType.getListingDetails() != null) {
            itemType.getListingDetails().setViewItemURL(getViewItemUrl(itemType.getItemID(), itemType.getTitle(), listingSite));
            itemType.getListingDetails().setViewItemURLForNaturalSearch(buildViewItemURLForNaturalSearch(listingActivitiesDetail, itemType.getItemID(), itemType.getTitle(), listingSite));
        }
        return itemType;
    }

    /**
     * StartPrice - Format is Auction then StartPrice, if Classified_ad then currentPrice
     * No startPrice if Format is Fixed
     *
     * @return
     */
    private AmountType getStartPrice() {
        CoreInfo.FormatEnum format = ListingActivitiesNGUtil.getFormat(listingActivity);
        if (CoreInfo.FormatEnum.AUCTION.equals(format)) {
            return ListingActivitiesNGUtil.getStartPrice(listingActivity);
        } else if (CoreInfo.FormatEnum.CLASSIFIED_AD.equals(format)) {
            return ListingActivitiesNGUtil.getCurrentPrice(listingActivity);
        }
        return null;
    }

    private void setConvertedPrices(ItemType itemType) {
        int siteId = siteContext.viewingSiteId;
        itemType.getListingDetails().setConvertedBuyItNowPrice(ListingActivitiesUtil.getConvertedAmount(itemType.getBuyItNowPrice(), siteId));
        itemType.getListingDetails().setConvertedReservePrice(ListingActivitiesUtil.getConvertedAmount(itemType.getReservePrice(), siteId));
        itemType.getListingDetails().setConvertedStartPrice(ListingActivitiesUtil.getConvertedAmount(itemType.getStartPrice(), siteId));
        itemType.getSellingStatus().setConvertedCurrentPrice(ListingActivitiesUtil.getConvertedAmount(itemType.getSellingStatus().getCurrentPrice(), siteId));
    }

    private String getPrivateNotes(ItemType itemType) {
        // from LAS response, find matching itemID and transactionId
        return Optional.ofNullable(bulkUserNoteResponse)
                .map(BulkUserNoteResponse::getBulkUserNotes)
                .filter(CollectionUtils::isNotEmpty)
                .flatMap(notes -> notes.stream().filter(note -> note.getListingId() == Long.parseLong(itemType.getItemID()) && note.getTransactionId() == Long.parseLong(sourceId.getTransactionId()))
                        .findFirst())
                .map(BulkUserNote::getUserNote)
                .orElse(null);
    }

    private Long getQuestionCount() {
        return Long.valueOf(Optional.ofNullable(listingActivity)
                .map(ListingActivity::getAdditionalAttributes)
                .map(AdditionalAttributesInfo::getBuyingInfo)
                .map(BuyingInfo::getUnansweredQuestionCount)
                .orElse(0));
    }

    private Duration getTimeLeft() throws DatatypeConfigurationException {
        LocalDateTime endTime = Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getLifecycle)
                .map(ListingLifecycle::getEndTime)
                .orElse(null);
        if (endTime != null) {
            java.time.Duration duration = java.time.Duration.between(LocalDateTime.now(ZoneOffset.UTC), endTime.atZone(ZoneId.of("UTC")));
            return ListingActivitiesUtil.getDuration(duration.get(ChronoUnit.SECONDS));
        }
        return null;
    }

    private Boolean isReserveMet() {
        return Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getPrice)
                .map(PricingInfo::getHasBidsWithReserveMet)
                .orElse(Boolean.FALSE);
    }

    private Boolean getIsDuplicateListing() {
        return Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getIsDuplicateListing)
                .orElse(false);
    }

    private Boolean getIsOutOfStock() {
        return Optional.ofNullable(listingActivity).map(ListingActivity::getCore)
                .map(CoreInfo::getQuantity)
                .map(i -> i.getOutOfStock())
                .orElse(false);
    }

    private ReasonHideFromSearchCodeType getReasonHideFromSearch() {
        if (getIsDuplicateListing()) {
            return ReasonHideFromSearchCodeType.DUPLICATE_LISTING;
        }
        if (getIsOutOfStock()) {
            return ReasonHideFromSearchCodeType.OUT_OF_STOCK;
        }
        return null;
    }

    private Long getWatchCount() {
        return Long.valueOf(Optional.ofNullable(listingActivity)
                .map(ListingActivity::getAdditionalAttributes)
                .map(AdditionalAttributesInfo::getBuyingInfo)
                .map(BuyingInfo::getWatchCount)
                .orElse(0));
    }

    /**
     * BuyItNowPrice - emit for both auction and fixed price to match V3
     *
     * @return
     */
    protected AmountType getGMESBuyItNowPrice() {
        PricingInfo pricingInfo = Optional.ofNullable(listingActivity)
                .map(ListingActivity::getCore)
                .map(CoreInfo::getPrice)
                .orElse(null);
        if (pricingInfo != null) {
            Double price = pricingInfo.getBuyItNowPrice();
            if (price != null) {
                return AmountTypeUtil.getAmountType(pricingInfo.getCurrency(),
                        price);
            }
        }
        return null;
    }

    protected String getSKU() {
        ListingActivitiesDetail listingActivitiesDetail = ListingActivityToListingActivitiesDetailMapper.map(listingActivity);
        return Optional.ofNullable(listingActivitiesDetail)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getListingSKU)
                .orElse(null);
    }

    protected String getItemTitle() {
        ListingActivitiesDetail listingActivitiesDetail = ListingActivityToListingActivitiesDetailMapper.map(listingActivity);
        Text title = Optional.ofNullable(listingActivitiesDetail)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getTitle).orElse(null);
        if (title != null) {
            List<Attribute> itemSkuDetails = null;
            if (ContractResponseUtil.isOrder(contractResponseType)) {
                itemSkuDetails = contractResponseType.getOrder().getLineItemTypes().stream().findFirst()
                        .map(LineItem::getItemSkuDetails).orElse(null);
            } else if (ContractResponseUtil.isProformaOrder(contractResponseType)) {
                itemSkuDetails = contractResponseType.getProformaOrder().getLineItemTypes().stream().findFirst()
                        .map(ProformaOrderLineItemXType::getItemSkuDetails).orElse(null);
            }
            if (CollectionUtils.isNotEmpty(itemSkuDetails)) {
                String variationSKU = title.getContent() +
                        ApiSellingExtSvcConstants.BRACKET_LEFT +
                        itemSkuDetails.stream()
                                .map(Attribute::getValue)
                                .collect(Collectors.joining(String.valueOf(ApiSellingExtSvcConstants.COMMA))) +
                        ApiSellingExtSvcConstants.BRACKET_RIGHT;
                return ItemTitleUtil.truncateString(variationSKU, configValues.varTitleSizeLimit);

            }
            return ItemTitleUtil.truncateString(title.getContent(), configValues.varTitleSizeLimit);
        }
        return null;
    }
}
