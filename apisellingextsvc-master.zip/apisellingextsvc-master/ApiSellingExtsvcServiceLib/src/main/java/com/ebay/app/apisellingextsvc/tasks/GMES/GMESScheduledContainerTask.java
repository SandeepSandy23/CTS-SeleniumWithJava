package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import com.ebay.app.apisellingextsvc.context.ListingsContext;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.mappers.ItemSortTypeCodeTypeMapper;
import com.ebay.app.apisellingextsvc.service.invokers.ListingActivitiesInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.model.ResponseModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.ScheduledModel;
import com.ebay.app.apisellingextsvc.tasks.GetItemProfilesTask;
import com.ebay.app.apisellingextsvc.tasks.ListingActivitiesTask;
import com.ebay.app.apisellingextsvc.utils.CommonUtil;
import com.ebay.app.apisellingextsvc.utils.PaginationUtil;
import com.ebay.app.apisellingextsvc.utils.TaskOrchestrationUtil;
import com.ebay.app.apisellingextsvc.utils.TracerUtil;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.common.collect.ImmutableList;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.ItemListCustomizationType;
import ebay.apis.eblbasecomponents.ItemSortTypeCodeType;
import ebay.apis.eblbasecomponents.PaginatedItemArrayType;
import ebay.apis.eblbasecomponents.PaginationType;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.context.Scope;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.ACTIONS;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.GET_MYEBAY_SELLING;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.LISTING_SCHEDULED;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_BEST_OFFER_DETAILS;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_COMPLETE_LISTING_COMPLETE_NOTES;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_FIELDGROUP;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_FIELDS;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_FILTER;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_MIN_VARIATION_INFO;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_Q_SUMMARY;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_USECASE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.QUERY_PARAM_VARIATION_PRICE;
import static com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants.TRUE_VALUE;

public class GMESScheduledContainerTask implements Task<ResponseModel>, ITaskResultInjectable {
    private final Map<String, Object> resultMap = new HashMap<>();
    private final GetMyeBaySellingRequest request;
    private final Executor executor;
    private final List<DetailLevelCodeType> detailLevels;

    public GMESScheduledContainerTask(GetMyeBaySellingRequest request, Executor executor,
                                      List<DetailLevelCodeType> detailLevels) {
        this.request = request;
        this.executor = executor;
        this.detailLevels = detailLevels;
    }

    @Override
    public ResponseModel call() {
        if (!CommonUtil.isRequiredContainer(request.getRequestType().getScheduledList(), detailLevels)) return null;

        Span openTeleChildSpan =
                TracerUtil.getOpenTeleChildSpan(this.getClass().getSimpleName(), this.request.getTracerContext());
        io.opentracing.Span openTracerChildSpan =
                TracerUtil.getOpenTracerChildSpan(this.getClass().getSimpleName(), this.request.getTracerContext());
        TracerContext updatedParentTracerContext =
                new TracerContext(this.request.getTracerContext().getOpenTeleTracer(),
                        openTeleChildSpan,
                        this.request.getTracerContext().getOpenTracingTracer(),
                        openTracerChildSpan);

        try (Scope scope = TracerUtil.startOpenTeleChildSpan(openTeleChildSpan, this.request.getTracerContext());
             io.opentracing.Scope tracerScope =
                     TracerUtil.startOpenTracerChildSpan(openTracerChildSpan, this.request.getTracerContext())) {
            ItemListCustomizationType scheduledList = request.getRequestType().getScheduledList();
            PaginationType paginationType = scheduledList.getPagination();
            ItemSortTypeCodeType sortType =
                    Optional.ofNullable(scheduledList.getSort()).orElse(ItemSortTypeCodeType.START_TIME);
            // SOAPI-1164 fetch LAS with notes all the time but filter eBayNotes and privateNotes in our side.
//            String includeNotesFlag = QUERY_PARAM_COMPLETE_LISTING;
//            if (scheduledList.isIncludeNotes() != null && scheduledList.isIncludeNotes()) {
//                includeNotesFlag = QUERY_PARAM_COMPLETE_LISTING_COMPLETE_NOTES;
//            }
            ImmutableList<Pair<String, Object>> queryParams = ImmutableList.of(
                    ImmutablePair.of(QUERY_PARAM_FIELDGROUP, QUERY_PARAM_COMPLETE_LISTING_COMPLETE_NOTES),
                    ImmutablePair.of(QUERY_PARAM_MIN_VARIATION_INFO, TRUE_VALUE),
                    ImmutablePair.of(QUERY_PARAM_Q_SUMMARY, TRUE_VALUE),
                    ImmutablePair.of(QUERY_PARAM_FILTER, LISTING_SCHEDULED),
                    ImmutablePair.of(QUERY_PARAM_VARIATION_PRICE, TRUE_VALUE),
                    ImmutablePair.of(QUERY_PARAM_FIELDS, ACTIONS),
                    ImmutablePair.of(QUERY_PARAM_USECASE, GET_MYEBAY_SELLING),
                    ImmutablePair.of(QUERY_PARAM_BEST_OFFER_DETAILS, TRUE_VALUE),
                    ImmutablePair.of("limit", paginationType.getEntriesPerPage()),
                    ImmutablePair.of("offset", PaginationUtil.getOffSet(paginationType)),
                    ImmutablePair.of("sort", ItemSortTypeCodeTypeMapper.map(sortType, ItemSortTypeCodeTypeMapper.Service.LAS, "scheduledStartDate")));
            ListingsContext listingsContext = new ListingsContext(queryParams, request.getHeaders());
            ListingActivitiesTask listingActivitiesTask = new ListingActivitiesTask(
                    new ListingActivitiesInvoker(updatedParentTracerContext), request.getErrorList(),
                    request.getHeaders(), this.request.getUser(), listingsContext);
            GetItemProfilesTask getItemProfilesTask = new GetItemProfilesTask(this.request.getUser(),
                    this.request.getTokenManager(),
                    this.request.getRequestSiteId(),
                    this.request.getConfigValues(),
                    executor);
            GMESScheduledBuildListingsContainerTask buildListingsContainerTask =
                    new GMESScheduledBuildListingsContainerTask(listingActivitiesTask, paginationType,
                            this.request.getContentResource(), this.request.getErrorList(),
                            BooleanUtils.isFalse(scheduledList.isIncludeNotes()),
                            BooleanUtils.isTrue(request.getRequestType().isHideVariations()));

            request.orchestrator.execute(listingActivitiesTask);
            request.orchestrator.execute(getItemProfilesTask,
                    TaskOrchestrationUtil.createTaskConfiguration(listingActivitiesTask));
            CompletableFuture<PaginatedItemArrayType> buildListingTaskFuture =
                    request.orchestrator.execute(buildListingsContainerTask,
                            TaskOrchestrationUtil.createTaskConfiguration(getItemProfilesTask, listingActivitiesTask));
            return new ScheduledModel((PaginatedItemArrayType) TaskOrchestrationUtil.safeGet(buildListingTaskFuture));
        } finally {
            openTeleChildSpan.end();
            openTracerChildSpan.finish();
        }
    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
