package com.ebay.app.apisellingextsvc.application.common.response;


import javax.ws.rs.core.HttpHeaders;
public class ServiceResponse<T> {
    public final T response;
    public final HttpHeaders headers;

    public ServiceResponse(T response, HttpHeaders headers) {
        this.response = response;
        this.headers = headers;
    }
}
