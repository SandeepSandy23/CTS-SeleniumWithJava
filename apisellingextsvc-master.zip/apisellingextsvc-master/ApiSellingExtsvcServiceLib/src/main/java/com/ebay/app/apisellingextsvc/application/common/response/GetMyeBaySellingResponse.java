package com.ebay.app.apisellingextsvc.application.common.response;

import com.ebay.marketplace.services.ErrorData;
import ebay.apis.eblbasecomponents.GetMyeBaySellingResponseType;

import javax.xml.bind.annotation.XmlAttribute;
import java.util.List;

//Wrapper response class, we can add errors, and diagnostic infos if needed here
public class GetMyeBaySellingResponse extends GetMyeBaySellingResponseType implements IServiceResponse {

    private List<ErrorData> warnings;

    /**
     * <a href="https://github.com/FasterXML/jackson-dataformat-xml/issues/18#issuecomment-446546133">remove child xmlns</a>
     * No getter required for serialization. Do not delete this
     */
    @XmlAttribute(name = "xmlns", required = true)
    private final String xmlns = "urn:ebay:apis:eBLBaseComponents";

    public void setWarnings(List<ErrorData> warnings) {
        this.warnings = warnings;
    }

    public List<ErrorData> getWarnings() {
        return warnings;
    }
}
