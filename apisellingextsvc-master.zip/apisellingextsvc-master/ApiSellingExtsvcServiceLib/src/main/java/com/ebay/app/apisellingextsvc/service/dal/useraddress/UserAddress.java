package com.ebay.app.apisellingextsvc.service.dal.useraddress;

import com.ebay.integ.dal.DalDOI;
import com.ebay.persistence.Column;
import com.ebay.persistence.Table;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Table(name = "EBAY_USER_ADDRESSES")
public interface UserAddress extends DalDOI {

    @Id
    @Column(name = "ID")
    long getId();

    void setId(long id);

    @Column(name = "USER_ID")
    long getUserId();

    void setUserId(long userId);

    @Column(name = "FLAGS")
    long getFlags();

    void setFlags(long id);

}
