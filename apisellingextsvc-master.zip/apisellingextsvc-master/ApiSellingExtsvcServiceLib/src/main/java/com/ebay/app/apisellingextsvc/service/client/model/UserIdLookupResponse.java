package com.ebay.app.apisellingextsvc.service.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserIdLookupResponse {

    public String statusCode;
    public Integer responseStatus;
    @JsonProperty("internal_id")
    public Long internalId;
    public String username;
}
