package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import java.io.Serializable;
import java.util.Comparator;

public class FindItemComparator implements Comparator, Serializable {
    FindItemComparator() {
    }

    public int compare(Object arg0, Object arg1) {
        RangeBasedToupleHolder holder = (RangeBasedToupleHolder) arg0;
        long itemId = (Long) arg1;
        if (holder.getRangeStart() > itemId) {
            return 1;
        } else {
            return holder.getRangeEnd() < itemId ? -1 : 0;
        }
    }
}
