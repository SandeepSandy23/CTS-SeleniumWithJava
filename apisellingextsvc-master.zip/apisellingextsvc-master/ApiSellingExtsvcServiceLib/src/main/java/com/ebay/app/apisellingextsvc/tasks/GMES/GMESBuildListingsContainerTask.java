package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.builders.ItemVariationsBuilder;
import com.ebay.app.apisellingextsvc.builders.PaginationResultBuilder;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.service.invokers.model.BulkUserInfoModel;
import com.ebay.app.apisellingextsvc.service.invokers.model.ItemProfilesModel;
import com.ebay.app.apisellingextsvc.utils.ListingCodeTypeUtil;
import com.ebay.app.apisellingextsvc.utils.NumberUtil;
import com.ebay.cos.las.type.ListingActivitiesDetail;
import com.ebay.cos.las.type.ListingActivitiesResponse;
import com.ebay.cos.type.v3.core.listing.Listing;
import com.ebay.cos.type.v3.core.listing.termsAndPolicies.LogisticsTerms;
import com.ebay.cos.type.v3.core.listing.termsAndPolicies.TermsAndPolicies;
import com.ebay.cos.type.v3.core.logistics.ShippingCostPlan;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.ShippingCostPlanType;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.BestOfferDetailsType;
import ebay.apis.eblbasecomponents.ErrorType;
import ebay.apis.eblbasecomponents.ItemArrayType;
import ebay.apis.eblbasecomponents.ItemType;
import ebay.apis.eblbasecomponents.ListingTypeCodeType;
import ebay.apis.eblbasecomponents.PaginatedItemArrayType;
import ebay.apis.eblbasecomponents.PaginationType;
import ebay.apis.eblbasecomponents.ShippingDetailsType;
import org.apache.commons.lang3.exception.ExceptionUtils;

import javax.xml.datatype.DatatypeConfigurationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class GMESBuildListingsContainerTask implements Task<PaginatedItemArrayType>, ITaskResultInjectable {
    protected final Map<String, Object> resultMap = new HashMap<>();
    private final PaginationType paginationType;
    private final Task<?> task;
    private final ContentResource contentResource;
    private final List<ErrorType> errorList;
    private final Boolean includeNotes;
    private final Boolean isHideVariations;

    public GMESBuildListingsContainerTask(Task<?> task, PaginationType paginationType,
                                          ContentResource contentResource, List<ErrorType> errorList,
                                          boolean includeNotes, boolean isHideVariations) {
        this.task = task;
        this.paginationType = paginationType;
        this.contentResource = contentResource;
        this.errorList = errorList;
        this.includeNotes = includeNotes;
        this.isHideVariations = isHideVariations;
    }

    @Override
    public PaginatedItemArrayType call() {
        ItemProfilesModel bpItemProfilesModel = (ItemProfilesModel) resultMap.get(ItemProfilesModel.class.getName());
        BulkUserInfoModel bulkUserInfoModel = (BulkUserInfoModel) resultMap.get(BulkUserInfoModel.class.getName());
        ListingActivitiesResponse listingActivitiesResponse = (ListingActivitiesResponse) resultMap.get(ListingActivitiesResponse.class.getName());

        if (null != listingActivitiesResponse && null != listingActivitiesResponse.getMembers()) {
            PaginatedItemArrayType paginatedItemArrayType = new PaginatedItemArrayType();
            ItemArrayType itemArrayType = new ItemArrayType();
            paginatedItemArrayType.setItemArray(itemArrayType);
            for (ListingActivitiesDetail listingActivity : listingActivitiesResponse.getMembers()) {
                ItemType itemType = new ItemType();
                populateItemType(itemType, listingActivity, bulkUserInfoModel, bpItemProfilesModel);
                itemArrayType.getItem().add(itemType);
            }
            paginatedItemArrayType.setPaginationResult(new PaginationResultBuilder().buildListingsPagination(listingActivitiesResponse, paginationType, this.contentResource, this.errorList));
            return paginatedItemArrayType;
        }
        return null;
    }

    protected void populateItemType(ItemType itemType, ListingActivitiesDetail listingActivity, BulkUserInfoModel bulkUserInfoModel, ItemProfilesModel bpItemProfilesModel) {
        BestOfferDetailsType bestOfferDetailsType = ListingActivitiesUtil.getBestOfferDetails(listingActivity);
        if (bestOfferDetailsType != null && bestOfferDetailsType.getBestOfferCount() > 0) {
            itemType.setBestOfferDetails(bestOfferDetailsType);
        }
        if (this.includeNotes) {
            itemType.setEBayNotes(ListingActivitiesUtil.getEBayNotes(listingActivity));
//                itemType.setPrivateNotes(ListingActivitiesUtil.getPrivateNotes(listingActivity));
        }
        itemType.setTitle(ListingActivitiesUtil.getTitle(listingActivity));
//        Boolean itemHideFromSearch = ListingActivitiesUtil.isItemHideFromSearch(listingActivity);
//        if (itemHideFromSearch) {
//            itemType.setHideFromSearch(itemHideFromSearch);
//        }
        itemType.setItemID(ListingActivitiesUtil.getItemId(listingActivity));
//                itemType.setPictureDetails(ListingActivitiesUtil.getPictureDetails(listingActivity));

        itemType.setQuantity(NumberUtil.nullIfZero(ListingActivitiesUtil.getQuantity(listingActivity)));
        itemType.setQuantityAvailable(ListingActivitiesUtil.getAvailableQuantity(listingActivity));
//        ReasonHideFromSearchCodeType reasonHideFromSearch =
//                ListingActivitiesUtil.getReasonHideFromSearch(listingActivity);
//        if (null != reasonHideFromSearch) {
//            itemType.setReasonHideFromSearch(reasonHideFromSearch);
//        }
        itemType.setReservePrice(ListingActivitiesUtil.getReservePrices(listingActivity).getKey());
        itemType.setListingType(ListingActivitiesUtil.getListingCodeType(listingActivity));
        itemType.setBuyItNowPrice(ListingActivitiesUtil.getBuyItNowPrices(listingActivity).getKey());
        itemType.setSellingStatus(ListingActivitiesUtil.getSellingStatus(listingActivity, bulkUserInfoModel));
        itemType.setSKU(ListingActivitiesUtil.getSKU(listingActivity));
        itemType.setStartPrice(ListingActivitiesUtil.getStartPrices(listingActivity).getKey());
        try {
            itemType.setTimeLeft(ListingActivitiesUtil.getTimeLeft(listingActivity));
        } catch (DatatypeConfigurationException e) {
            CalLogger.error("Time left duration error", ExceptionUtils.getStackTrace(e));
        }
        if (!isHideVariations) {
            itemType.setVariations(new ItemVariationsBuilder(task, listingActivity, itemType.getSellingStatus()).doBuild());
        }
        Long watchCount = ListingActivitiesUtil.getWatchCount(listingActivity);
        if (null != watchCount && watchCount > 0L) {
            itemType.setWatchCount(watchCount);
        }
        itemType.setListingDetails(ListingActivitiesUtil.getListingDetails(itemType, listingActivity));
        Optional.ofNullable(bpItemProfilesModel).map(ItemProfilesModel::getItemProfiles)
                .map(s -> s.get(Long.parseLong(itemType.getItemID()))).ifPresent(itemType::setSellerProfiles);
        itemType.setLeadCount(NumberUtil.nullIfZero(ListingActivitiesUtil.getLeadCount(listingActivity)));
    }

    protected ShippingDetailsType removeZeroShippingCostOptions(ShippingDetailsType shippingDetailsType, ListingActivitiesDetail listingActivity) {
        boolean isFreeShippingAvailable = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getListing)
                .map(Listing::getTermsAndPolicies)
                .map(TermsAndPolicies::getLogisticsTerms)
                .map(LogisticsTerms::getFreeShippingAvailable)
                .orElse(false);

        boolean isCalculatedOrNotSpecified = Optional.ofNullable(listingActivity)
                .map(ListingActivitiesDetail::getShippingCostPlan)
                .map(ShippingCostPlan::getCostPlanType)
                .map(t -> ShippingCostPlanType.CALCULATED.name().equals(t) || ShippingCostPlanType.NOT_SPECIFIED.name().equals(t))
                .orElse(false);
        if (!isFreeShippingAvailable && !isCalculatedOrNotSpecified) {
            shippingDetailsType.getShippingServiceOptions()
                    .removeIf(t -> Optional.ofNullable(t.getShippingServiceCost())
                            .map(AmountType::getValue)
                            .orElse(0.0) == 0.0);
        }
        return shippingDetailsType;
    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}