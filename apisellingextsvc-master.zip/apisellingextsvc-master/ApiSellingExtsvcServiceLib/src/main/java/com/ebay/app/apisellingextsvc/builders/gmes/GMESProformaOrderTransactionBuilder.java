package com.ebay.app.apisellingextsvc.builders.gmes;

import com.ebay.app.apisellingextsvc.builders.proforma.ProformaOrderTransactionBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.mappers.FeedbackTypeMapper;
import com.ebay.app.apisellingextsvc.mappers.PaidStatusCodeMapper;
import com.ebay.app.apisellingextsvc.service.bof.exchangerate.ExchangeRateBofImpl;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.MoneyExchangeHelper;
import com.ebay.app.apisellingextsvc.utils.SiteUtils;
import com.ebay.cos.las.type.BulkUserNoteResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.FeedbackInfoTypeCS;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.order.common.v1.FeedbackStatusTypeEnum;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.CurrencyCodeType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.FeedbackInfoType;
import ebay.apis.eblbasecomponents.PaidStatusCodeType;
import ebay.apis.eblbasecomponents.TransactionType;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class GMESProformaOrderTransactionBuilder extends ProformaOrderTransactionBuilder {
    private final ProformaOrderXType order;
    private final ProformaOrderLineItemXType lineItem;
    private final ApiSellingExtSvcConfigValues configValues;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    private final List<DetailLevelCodeType> detailLevels;
    private final int trxVersion;
    private final BulkUserNoteResponse bulkUserNoteResponse;
    private final ContractResponseType contractResponseType;

    public GMESProformaOrderTransactionBuilder(Task<?> task,
                                               ProformaOrderXType order,
                                               ProformaOrderLineItemXType lineItem,
                                               SiteContext siteContext,
                                               IContentHelper contentHelper,
                                               List<DetailLevelCodeType> detailLevels,
                                               ApiSellingExtSvcConfigValues configValues,
                                               int trxVersion,
                                               Map<Long, ListingActivity> itemIdListingActivityMap,
                                               BulkUserNoteResponse bulkUserNoteResponse,
                                               ContractResponseType contractResponseType) {
        super(task, order, lineItem, siteContext, contentHelper, detailLevels, configValues, trxVersion, itemIdListingActivityMap, null);
        this.order = order;
        this.lineItem = lineItem;
        this.configValues = configValues;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        this.detailLevels = detailLevels;
        this.trxVersion = trxVersion;
        this.bulkUserNoteResponse = bulkUserNoteResponse;
        this.contractResponseType = contractResponseType;
    }

    @Override
    protected TransactionType doBuild() {
        TransactionType transaction = super.doBuild();
        transaction.setSellerPaidStatus(PaidStatusCodeMapper.map(order));
        transaction.setTotalTransactionPrice(getTotalTransactionPrice());
        transaction.setItem(new GMESOrderItemBuilder(task, lineItem, configValues, itemIdListingActivityMap,
                                                     detailLevels, bulkUserNoteResponse, trxVersion, siteContext,
                                                     contractResponseType, contentHelper).build());
        if (getBestOfferStatus(lineItem.getAttribute())) {
            transaction.setTransactionPrice(getTransactionPrice(lineItem.getUnitPrice()));
            CurrencyCodeType currency = transaction.getTransactionPrice().getCurrencyID();
            if (currency != null && !currency.equals(SiteUtils.getSiteCurrency(String.valueOf(siteContext.viewingSiteId)))) {
                transaction.setConvertedTransactionPrice(MoneyExchangeHelper.exchange(new ExchangeRateBofImpl(), transaction.getTransactionPrice(), siteContext.viewingSiteId));
            }
        }
        Boolean isGuaranteedShipping = isGuaranteedShipping();
        if (Boolean.TRUE.equals(isGuaranteedShipping)) {
            transaction.setGuaranteedShipping(isGuaranteedShipping);
        }
        boolean bestOfferStatus = getBestOfferStatus(order.getAttributes());
        if (bestOfferStatus) {
            transaction.setBestOfferSale(bestOfferStatus);
        }

        setFeedbackCS(transaction);
        return transaction;
    }

    private AmountType getTotalTransactionPrice() {
        AmountType discountedItemPrice = getPricelineCost(PricelineTypeEnum.DISCOUNTED_ITEM_COST);
        if (discountedItemPrice != null && discountedItemPrice.getValue() != ApiSellingExtSvcConstants.ZERO_AMOUNT) {
            return discountedItemPrice;
        }
        return getPricelineCost(PricelineTypeEnum.ITEM_COST);
    }

    protected AmountType getPricelineCost(PricelineTypeEnum targetType) {
        return Optional.of(this.lineItem).map(ProformaOrderLineItem::getLineItemTotal)
                       .flatMap(total -> total.getPriceLines().stream()
                        .filter(p -> targetType.equals(p.getType())).findFirst())
                       .map(PriceLine::getAmount).map(AmountTypeUtil::getAmountType)
                       .orElse(AmountTypeUtil.getDefaultZeroAmountType(order));
    }

    private void setFeedbackCS(TransactionType transaction) {
        FeedbackInfoTypeCS feedbackInfoCS = order.getLineItemTypes().stream()
                .filter(i -> i.getSourceId().getTransactionId().equals(transaction.getTransactionID()))
                .map(ProformaOrderLineItemXType::getFeedbackInfo)
                .filter(Objects::nonNull)
                .findFirst()
                .orElse(null);

        if (feedbackInfoCS != null) {
            if (feedbackInfoCS.getBuyerFeedback().equals(FeedbackStatusTypeEnum.FEEDBACK_LEFT)) {
                transaction.setFeedbackReceived(new FeedbackInfoType());
                transaction.getFeedbackReceived().setCommentType(FeedbackTypeMapper.map(feedbackInfoCS.getDisplayTypeLeftByBuyer()));
            }
            if (feedbackInfoCS.getSellerFeedback().equals(FeedbackStatusTypeEnum.FEEDBACK_LEFT)) {
                transaction.setFeedbackLeft(new FeedbackInfoType());
                transaction.getFeedbackLeft().setCommentType(FeedbackTypeMapper.map(feedbackInfoCS.getDisplayTypeLeftBySeller()));
            }
        }
    }
}