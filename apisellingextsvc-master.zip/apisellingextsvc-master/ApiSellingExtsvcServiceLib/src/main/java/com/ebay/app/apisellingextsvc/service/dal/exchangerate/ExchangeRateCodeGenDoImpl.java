package com.ebay.app.apisellingextsvc.service.dal.exchangerate;

import com.ebay.integ.dal.BaseDo3;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;

import java.util.Date;

public class ExchangeRateCodeGenDoImpl extends BaseDo3 implements ExchangeRate {

    public static final long serialVersionUID = 1L;
    public static final int DAYOFRATE = BaseDo3.NUM_FIELDS;
    public static final int FROMCURRENCY = BaseDo3.NUM_FIELDS + 1;
    public static final int RATE = BaseDo3.NUM_FIELDS + 2;
    @SuppressWarnings("hiding")
    public static final int NUM_FIELDS = BaseDo3.NUM_FIELDS + 3;
    @SuppressWarnings("hiding")
    public static final int NUM_SUBOBJECT_FIELDS = BaseDo3.NUM_SUBOBJECT_FIELDS;
    public double m_rate;
    public int m_fromCurrency;
    public Date m_dayOfRate;

    public ExchangeRateCodeGenDoImpl() {
        super(ExchangeRateDAO.getInstance(), GenericMap
              .getInitializedMap(ExchangeRate.class));
    }

    public ExchangeRateCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public double getRate() {
        loadValue(RATE);
        return m_rate;
    }


    public void setRate(double p_rate) {
        this.m_rate = p_rate;
        setDirty(RATE);
    }

    @Override
    public Date getDayOfRate() {
        loadValue(DAYOFRATE);
        return this.m_dayOfRate;
    }

    @Override
    public void setDayOfRate(Date m_dayOfRate) {
        this.m_dayOfRate = m_dayOfRate;
    }

    public int getFromCurrency() {
        loadValue(FROMCURRENCY);
        return m_fromCurrency;
    }

    public void setFromCurrency(int p_fromCurrency) {
        this.m_fromCurrency = p_fromCurrency;
    }


    @Override
    public int getNumFields() {
        return NUM_FIELDS;
    }

    @Override
    public int getNumSubObjects() {
        return NUM_SUBOBJECT_FIELDS;
    }
}
