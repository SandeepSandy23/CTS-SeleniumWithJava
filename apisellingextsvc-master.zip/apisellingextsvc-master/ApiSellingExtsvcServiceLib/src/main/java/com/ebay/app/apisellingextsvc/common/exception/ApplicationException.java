package com.ebay.app.apisellingextsvc.common.exception;

import javax.ws.rs.core.Response;

public class ApplicationException extends RuntimeException {
    private static final long serialVersionUID = -4501388273826057534L;
    public final Response.Status status;
    public final Object entity;

    public ApplicationException(Throwable cause, Response.Status status, Object errorResponse) {
        super(cause);
        this.status = status;
        this.entity = errorResponse;
    }

    public ApplicationException(Throwable t) {
        this(t, Response.Status.INTERNAL_SERVER_ERROR, (Object)null);
    }

    public ApplicationException(Response.Status status, Object errorResponse) {
        super(errorResponse != null ? errorResponse.toString() : null);
        this.status = status;
        this.entity = errorResponse;
    }
}