package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import com.ebay.integ.dal.ddr.DetailedTableTouple;

public class RangeBasedToupleHolder {
    private long m_rangeStart;
    private long m_rangeEnd;
    private DetailedTableTouple m_primaryTouple;
    private DetailedTableTouple m_readOnlyTouple;

    public RangeBasedToupleHolder(long rangeStart, long rangeEnd, DetailedTableTouple primaryTouple, DetailedTableTouple readOnlyTouple) {
        this.m_rangeStart = rangeStart;
        this.m_rangeEnd = rangeEnd;
        this.m_primaryTouple = primaryTouple;
        this.m_readOnlyTouple = readOnlyTouple;
    }

    public long getRangeStart() {
        return this.m_rangeStart;
    }

    public long getRangeEnd() {
        return this.m_rangeEnd;
    }

    public DetailedTableTouple getPrimaryTouple() {
        return this.m_primaryTouple;
    }

    public DetailedTableTouple getReadOnlyTouple() {
        return this.m_readOnlyTouple;
    }

    public DetailedTableTouple getTouple(boolean readOnly) {
        return readOnly ? this.getReadOnlyTouple() : this.getPrimaryTouple();
    }
}
