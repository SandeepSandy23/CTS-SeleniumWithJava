package com.ebay.app.apisellingextsvc.builders.proforma;

import com.ebay.app.apisellingextsvc.builders.AbstractOrderTransactionBuilder;
import com.ebay.app.apisellingextsvc.builders.BuyerBuilder;
import com.ebay.app.apisellingextsvc.builders.ProgramBuilder;
import com.ebay.app.apisellingextsvc.builders.TransactionShippingDetailsBuilder;
import com.ebay.app.apisellingextsvc.builders.TransactionShippingServiceSelectedBuilder;
import com.ebay.app.apisellingextsvc.builders.TransactionStatusBuilder;
import com.ebay.app.apisellingextsvc.builders.VariationBuilder;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.IContentHelper;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.CheckoutStatusUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.PriceLine;
import com.ebay.order.common.v1.PricelineTypeEnum;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.selling.svls.item.Item;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.CompleteStatusCodeType;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.TransactionType;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ProformaOrderTransactionBuilder extends AbstractOrderTransactionBuilder {


    protected final ProformaOrderXType order;
    private final List<DetailLevelCodeType> detailLevels;
    protected final ProformaOrderLineItemXType lineItem;
    private final ApiSellingExtSvcConfigValues configValues;
    private final int trxVersion;
    private final Map<Long, ListingActivity> itemIdListingActivityMap;
    protected final IContentHelper contentHelper;
    protected final SiteContext siteContext;
    private Map<String, Item> svlsInfoItemMap;

    public ProformaOrderTransactionBuilder(Task<?> task,
                                           ProformaOrderXType order,
                                           ProformaOrderLineItemXType lineItem,
                                           SiteContext siteContext,
                                           IContentHelper contentHelper,
                                           List<DetailLevelCodeType> detailLevels,
                                           ApiSellingExtSvcConfigValues configValues,
                                           int trxVersion,
                                           Map<Long, ListingActivity> itemIdListingActivityMap,
                                           Map<String, Item> svlsInfoItemMap) {
        super(task, trxVersion);
        this.order = order;
        this.contentHelper = contentHelper;
        this.detailLevels = detailLevels;
        this.lineItem = lineItem;
        this.configValues = configValues;
        this.trxVersion = trxVersion;
        this.siteContext = siteContext;
        this.itemIdListingActivityMap = itemIdListingActivityMap;
        if(svlsInfoItemMap!=null) {
            this.svlsInfoItemMap = svlsInfoItemMap;
        }
    }

    @Override
    protected TransactionType doBuild() {
        TransactionType transaction = super.doBuild();

//        transaction.setExtendedOrderID(getExtendedOrderID());
        transaction.setTransactionID(lineItem.getSourceId().getTransactionId());
        transaction.setQuantityPurchased(lineItem.getQuantityPurchased());
        transaction.setOrderLineItemID(lineItem.getSourceId().getLookupKey());
        //COMS-11907 In new trading api, just set the transaction id to this field.
        transaction.setCreatedDate(getCreatedDate(order.getCreationDate(), lineItem.getAttribute()));
        AmountType finalValueFee = getFinalValueFee();
        transaction.setFinalValueFee(finalValueFee);
        transaction.setShippingServiceSelected(new TransactionShippingServiceSelectedBuilder(task, order).build());
        transaction.setGuaranteedDelivery(isGuaranteedDelivery(lineItem.getLineItemFlags()));
        transaction.setShippingDetails(new TransactionShippingDetailsBuilder(task, order, lineItem, configValues, trxVersion, itemIdListingActivityMap, svlsInfoItemMap).build());
        boolean isMultiLegShipping = isMultiLegShipping(order.getLogisticsOptions());
        if (isMultiLegShipping) {
            transaction.setIsMultiLegShipping(isMultiLegShipping);
        }
        transaction.setGuaranteedDelivery(isGuaranteedDelivery(lineItem.getLineItemFlags()));

        transaction.setTaxes(new ProformaOrderTaxBuilder(task, order.getOrderTotalSummary(), order.getAttributes()).build());
        transaction.setStatus(new TransactionStatusBuilder(task, order).build());
        transaction.setVariation(new VariationBuilder(task, configValues,
                lineItem.getItemSkuDetails(), lineItem.getInventoryDetails(), lineItem.getAttribute(), lineItem.getTitle()).build());
        transaction.setBuyer(new BuyerBuilder(task, trxVersion, configValues, contentHelper,
                order.getBuyerCS(), lineItem.getDatePurchased().getValue(), null, detailLevels).build());

        transaction.setProgram(new ProgramBuilder(task, order, detailLevels).build());
        transaction.setPaidTime(PaymentUtil.getLatestPaidTime(order));
        return transaction;
    }

    protected AmountType getActualCost(PricelineTypeEnum targetType) {
        if (order.getOrderStates() != null && isCheckOutCompleted(order)) {
            return Optional.of(this.lineItem).map((ProformaOrderLineItemXType t) -> t.getLineItemTotal())
                    .flatMap(total -> total.getPriceLines().stream()
                            .filter(p -> targetType.equals(p.getType())).findFirst())
                    .map(PriceLine::getAmount).map(AmountTypeUtil::getAmountType)
                    .orElse(AmountTypeUtil.getDefaultZeroAmountType(order.getOrderTotalSummary()));
        }

        return null;
    }

    private boolean isCheckOutCompleted(ProformaOrderXType order) {
        return CheckoutStatusUtil.proformaOrderCheckoutStatus(order.getOrderStates())
                == CompleteStatusCodeType.COMPLETE;
    }

    protected Boolean getRemitTax(List<Attribute> attributes, int trxVersion) {
        Boolean res = false;
        if (VersionConstant.isGreaterEqualThan(trxVersion, VersionConstant.VERSION_AU_GST)) {
            String taxType = AttributeUtil.findAttribute(attributes, ApiSellingExtSvcConstants.ATTR_TAX_TYPE)
                    .map(Attribute::getValue)
                    .orElse(null);
            return PaymentUtil.hasEbayCollectedTax(order.getAttributes())
                    || ApiSellingExtSvcConstants.INVOICE_TO_SELLER.equalsIgnoreCase(taxType);
        }
        return res;
    }

    /**
     * todo
     *
     * @return
     */
    protected AmountType getFinalValueFee() {
        return null;
    }

    protected AmountType getTransactionPrice(Amount unitPrice) {
        return AmountTypeUtil.getAmountType(unitPrice);
    }

    /*private String getExtendedOrderID() {
        return null;
    }*/
}

