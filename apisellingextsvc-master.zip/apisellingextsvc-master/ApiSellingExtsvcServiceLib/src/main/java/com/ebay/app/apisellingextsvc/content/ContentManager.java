package com.ebay.app.apisellingextsvc.content;

import com.ebay.content.runtime.api.IContentElement;
import com.ebay.content.runtime.api.IContentMap;
import com.ebay.content.runtime.api.IContentStructure;
import com.ebay.raptor.content.api.IContentBuilder;
import com.ebay.app.apisellingextsvc.context.ErrorMessage;
import com.ebay.app.apisellingextsvc.enums.ContentBundleEnum;
import org.apache.commons.collections.MapUtils;

import java.util.Map;

/**
 * <a href="http://raptor.io.corp.ebay.com/raptor%20io/0.14.x/content/docs/content-concept.md">http://raptor.io.corp.ebay.com/raptor%20io/0.14
 * .x/content/docs/content-concept.md</a>
 */
public class ContentManager implements IContentManager {

    private static final String CONTENT_PATH = "tradingapi";
    private static final String SHORT_MSG = "shortMessage";
    private static final String LONG_MSG = "longMessage";

    private final IContentBuilder contentBuilder;

    private ContentManager(IContentBuilder contentBuilder) {
        this.contentBuilder = contentBuilder;
    }

    public static ContentManager createContentManager(IContentBuilder contentBuilder) {
        return new ContentManager(contentBuilder);
    }

    public String getText(ContentBundleEnum bundle, String key) {
        IContentElement contentElement = contentBuilder
                .buildContentElement(CONTENT_PATH + "/" + bundle.name() + "/" + key);
        return contentElement.getText();
    }


    // public String getDynamicText(ContentBundleEnum bundle, String key, Map<String, String> param) {
    //     IContentUnit contentUnit = contentBuilder
    //             .buildContentUnit(CONTENT_PATH + "/" + bundle.name() + "/" + key);
    //     String text = null;
    //     if (contentUnit instanceof IContentElement) {
    //         IContentElement element = (IContentElement) contentUnit;
    //         text = element.getText(param);
    //     }
    //     return text;
    // }

    @Override
    public IContentStructure getContentStructure(ContentBundleEnum bundle, String key) {
        return contentBuilder
                .buildContentStructure(CONTENT_PATH + "/" + bundle.name() + "/" + key);
    }

    @Override
    public IContentMap getContentMap(ContentBundleEnum bundle, String key) {
        return contentBuilder.buildContentMap(CONTENT_PATH + "/" + bundle.name() + "/" + key);
    }

    @Override
    public String getContentMapValue(ContentBundleEnum bundle, String key, String mapKey) {
        IContentElement contentElement = getContentMap(bundle, key).get(mapKey);
        return contentElement.getText();
    }

    @Override
    public ErrorMessage getErrorMessage(String key, Map<String, String> replaceMap) {
        IContentStructure contentStructure = getContentStructure(ContentBundleEnum.ErrorContent, key);
        IContentElement shortMessage = contentStructure.getField(SHORT_MSG);
        IContentElement longMessage = contentStructure.getField(LONG_MSG);
        if (MapUtils.isNotEmpty(replaceMap)) {
            return new ErrorMessage(shortMessage.getText(replaceMap), longMessage.getText(replaceMap));
        } else {
            return new ErrorMessage(shortMessage.getText(), longMessage.getText());
        }
    }

}
