package com.ebay.app.apisellingextsvc.common.logger;

public interface ILogger {
    void warn(String var1);

    void error(String var1);

    void error(String var1, Throwable var2);
}
