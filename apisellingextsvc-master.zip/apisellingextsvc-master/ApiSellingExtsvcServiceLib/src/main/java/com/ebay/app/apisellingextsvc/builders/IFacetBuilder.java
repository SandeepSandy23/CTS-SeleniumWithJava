package com.ebay.app.apisellingextsvc.builders;

public interface IFacetBuilder<T> {

    T build();

}
