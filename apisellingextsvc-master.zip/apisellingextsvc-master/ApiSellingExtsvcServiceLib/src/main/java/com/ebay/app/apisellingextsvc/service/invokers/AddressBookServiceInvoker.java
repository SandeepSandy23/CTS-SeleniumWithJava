package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.tide.app.addressbook.request.BulkGetAddressRequest;
import com.ebay.tide.app.addressbook.response.BulkGetAddressResponse;
import com.ebay.app.apisellingextsvc.service.client.AddressBookServiceClient;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class AddressBookServiceInvoker extends BaseServiceInvoker<BulkGetAddressRequest, BulkGetAddressResponse, BulkGetAddressRequest> {

    // use for mock
    public static final String NAME = "AddressBookServiceInvoker";

    public AddressBookServiceInvoker(TracerContext tracerContext) {
        super(NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<BulkGetAddressRequest, BulkGetAddressResponse> getGingerClient(BulkGetAddressRequest request) {
        return new AddressBookServiceClient();
    }

    @Override
    protected GingerClientRequest<BulkGetAddressRequest> getGingerRequest(BulkGetAddressRequest request, HttpHeaders httpHeaders) {
        GingerClientRequest<BulkGetAddressRequest> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(request);
        return gingerClientRequest;
    }

}
