package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.v1.Attribute;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

public class AttributeUtil {

    public static boolean hasAttributeInsensitive(List<Attribute> attributes, @Nonnull String key, @Nonnull String value) {
        return findAttribute(attributes, key).map(Attribute::getValue)
                .map(value::equalsIgnoreCase).orElse(false);
    }

    public static Optional<Attribute> findAttribute(List<Attribute> attributes, @Nonnull String key) {
        if (Objects.isNull(attributes)) {
            return Optional.empty();
        }
        return attributes.stream().filter(att -> key.equalsIgnoreCase(att.getName())).findFirst();
    }

    public static boolean hasAttribute(List<Attribute> attributes, @Nonnull String key, @Nonnull String value) {
        return findAttribute(attributes, key).map(Attribute::getValue)
                .map(value::equals).orElse(false);
    }

    public static Map<String, String> getOrderAttributeMap(@Nonnull OrderCSXType order) {
        return order.getAttributes().stream().filter(attribute -> attribute.getName() != null)
                .collect(Collectors.toMap(Attribute::getName, attribute -> Optional.ofNullable(attribute.getValue()).orElse("")));
    }

    public static boolean isTaxExcludeInSellerDistribution(List<Attribute> attributes) {
        return findAttribute(attributes, ApiSellingExtSvcConstants.ATTR_SELLER_DISTRIBUTION_TYPE).map(Attribute::getValue)
                .map(ApiSellingExtSvcConstants.VAL_TAX_EXCLUDED::equals).orElse(false);
    }

    public static boolean isTaxIncludeInSellerDistribution(List<Attribute> attributes) {
        return findAttribute(attributes, ApiSellingExtSvcConstants.ATTR_SELLER_DISTRIBUTION_TYPE).map(Attribute::getValue)
                .map(ApiSellingExtSvcConstants.VAL_TAX_INCLUDED::equals).orElse(false);
    }

    public static Attribute findAttributes(List<Attribute> attributes, @Nonnull String key) {
        return findAttribute(attributes,key).orElse(null);
    }

    public static String findAttributeValue(List<Attribute> attributes, @Nonnull String key) {
        return findAttribute(attributes, key).map(Attribute::getValue).orElse(null);
    }

    public static Attribute createAttribute(String name, String val) {
        Attribute at = new Attribute();
        at.setName(name);
        at.setValue(val);
        return at;
    }

}
