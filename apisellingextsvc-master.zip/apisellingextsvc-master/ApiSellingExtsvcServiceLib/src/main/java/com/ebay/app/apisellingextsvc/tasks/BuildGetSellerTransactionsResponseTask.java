package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.ebay.app.apisellingextsvc.builders.PaginationResultBuilder;
import com.ebay.app.apisellingextsvc.builders.SellerBuilder;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.content.ContentResource;
import com.ebay.app.apisellingextsvc.context.SellerProfileDataContext;
import com.ebay.app.apisellingextsvc.context.SiteContext;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import com.ebay.app.apisellingextsvc.handlers.ExceptionHandler;
import com.ebay.app.apisellingextsvc.service.client.model.StoreEditEntityClient.StoreEditEntityResponse;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserReadResponse;
import com.ebay.app.apisellingextsvc.service.invokers.model.FeedBackPercentageModel;
import com.ebay.app.apisellingextsvc.utils.AckUtils;
import com.ebay.cosmos.ContractResponse;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import ebay.apis.eblbasecomponents.ErrorType;
import ebay.apis.eblbasecomponents.GetSellerTransactionsRequestType;
import ebay.apis.eblbasecomponents.PaginationResultType;
import ebay.apis.eblbasecomponents.TransactionArrayType;
import ebay.apis.eblbasecomponents.UserType;
import org.apache.commons.collections.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class BuildGetSellerTransactionsResponseTask implements Task<GetSellerTransactionsResponse>, ITaskResultInjectable {

    private Map<String, Object> resultMap = new HashMap<>();
    private final List<ErrorType> errorList;
    private final SiteContext siteContext;
    private final User userCtx;
    private final List<DetailLevelCodeType> detailLevels;
    private final int trxVersion;
    private final ApiSellingExtSvcConfigValues configValues;
    private final  ContentResource contentResource;
    private final GetSellerTransactionsRequestType requestType;

    public BuildGetSellerTransactionsResponseTask(List<ErrorType> errorList, SiteContext siteContext, User userCtx, int trxVersion, ApiSellingExtSvcConfigValues configValues,
                                                  ContentResource contentResource, GetSellerTransactionsRequestType requestType) {
        this.errorList = errorList;
        this.siteContext = siteContext;
        this.userCtx = userCtx;
        this.detailLevels = requestType.getDetailLevel();
        this.trxVersion = trxVersion;
        this.configValues = configValues;
        this.contentResource = contentResource;
        this.requestType = requestType;
    }

    @Override
    public GetSellerTransactionsResponse call() {
        SellerProfileDataContext dataContext =
                (SellerProfileDataContext) resultMap.get(SellerProfileDataContext.class.getName());
        ContractResponse cosmosResponse = (ContractResponse) resultMap.get(ContractResponse.class.getName());
        TransactionArrayType transactionArrayType = (TransactionArrayType) resultMap.get(TransactionArrayType.class.getName());
        UserReadResponse userReadResponse = (UserReadResponse) resultMap.get(UserReadResponse.class.getName());
        StoreEditEntityResponse storeEditEntityResponse = (StoreEditEntityResponse) resultMap.get(StoreEditEntityResponse.class.getName());
        String storeIdentifier = Optional.ofNullable(storeEditEntityResponse).map(StoreEditEntityResponse::getStoreUrlIdentifier).orElse(null);
        FeedBackPercentageModel feedBackPercentageModel = (FeedBackPercentageModel) resultMap.get(FeedBackPercentageModel.class.getName());
        GetSellerTransactionsResponse response = new GetSellerTransactionsResponse();
        PaginationResultType paginationResultType = new PaginationResultType();

        /* Commenting this error condition as of now.
        if (paginationType.getPageNumber() > 1 && cosmosResponse != null && cosmosResponse.getTotal() == 0) {
            ExceptionHandler.throwException(ApplicationError.INVALID_PAGINATION_INPUT, this.contentResource.contentHelper.getErrorContentManager());
        } */

        if (userReadResponse == null){
            ExceptionHandler.throwException(ApplicationError.SYSTEM_ERROR, this.contentResource.contentHelper.getErrorContentManager());
        }

        boolean hasMoreTransactions = false;
        paginationResultType = new PaginationResultBuilder().buildCosmosPagination(cosmosResponse, requestType.getPagination());
        if (paginationResultType.getTotalNumberOfPages() != null) {
            hasMoreTransactions = paginationResultType.getTotalNumberOfPages() > requestType.getPagination().getPageNumber();
        }
        // SOAPI-864 - PayPal default value false as per audit
        response.setPayPalPreferred(false);
        response.setPaginationResult(paginationResultType);
        response.setHasMoreTransactions(hasMoreTransactions);
        response.setTransactionsPerPage(requestType.getPagination().getEntriesPerPage());
        response.setPageNumber(requestType.getPagination().getPageNumber());
        //ReturnedTransactionCountActual - We cannot get this count directly from cosmos response. It is not based on transaction.
        //We are considering transaction array size for count
        Integer returnedTransactionCount = (transactionArrayType != null && CollectionUtils.isNotEmpty(transactionArrayType.getTransaction())) ? transactionArrayType.getTransaction().size() : 0;
        response.setReturnedTransactionCountActual(returnedTransactionCount);

        UserType user =  new SellerBuilder(this, trxVersion, siteContext, configValues, userReadResponse, dataContext, storeIdentifier, detailLevels, feedBackPercentageModel.getFeedBackPercentageMap()).build();
        response.setSeller(user);

        if(transactionArrayType == null) {
            ExceptionHandler.logException(errorList, ApplicationError.PARTIAL_ERROR, this.contentResource.contentHelper.getErrorContentManager());
        }  else if (CollectionUtils.isNotEmpty(transactionArrayType.getTransaction())) {
                response.setTransactionArray(transactionArrayType);
        }

        AckUtils.populateAckAndErrors(errorList, response);
        return response;
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
