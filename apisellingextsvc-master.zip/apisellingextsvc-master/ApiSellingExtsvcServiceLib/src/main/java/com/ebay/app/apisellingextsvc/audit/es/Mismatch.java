package com.ebay.app.apisellingextsvc.audit.es;


public class Mismatch {

    private String field;
    private String expected;
    private String actual;
    private String key;

    public Mismatch(String field, String expected, String actual, String key) {
        this.field = field;
        this.expected = expected;
        this.actual = actual;
        this.key = key;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getExpected() {
        return expected;
    }

    public void setExpected(String expected) {
        this.expected = expected;
    }

    public String getActual() {
        return actual;
    }

    public void setActual(String actual) {
        this.actual = actual;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
