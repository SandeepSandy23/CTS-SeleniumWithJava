package com.ebay.app.apisellingextsvc.service.bof.sellerpref;


import com.ebay.af.common.flag.FlagMask;
import com.ebay.af.common.flag.FlagUtil;
import com.ebay.app.apisellingextsvc.service.dal.sellerpref.SellerPref;

public class SellerPrefDataMock implements SellerPref {

    private long sellerId;
    private long shippingPrefsFlags;


    @Override
    public long getSellerId() {
        return this.sellerId;
    }

    @Override
    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    @Override
    public long getShippingPrefsFlags() {
        return this.shippingPrefsFlags;
    }

    @Override
    public void setShippingPrefsFlags(long shippingPrefsFlags) {
        this.shippingPrefsFlags = shippingPrefsFlags;
    }

    @Override
    public boolean equalsData(Object other) {
        return false;
    }

    @Override
    public boolean hasFlag(FlagMask flagMask) {
        return FlagUtil.checkMaskedValue(this.shippingPrefsFlags, flagMask);
    }

    @Override
    public void setFlag(FlagMask flagMask, boolean b) {

    }
}
