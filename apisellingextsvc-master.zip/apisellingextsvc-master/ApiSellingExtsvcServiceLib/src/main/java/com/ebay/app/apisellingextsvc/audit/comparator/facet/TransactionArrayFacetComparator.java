package com.ebay.app.apisellingextsvc.audit.comparator.facet;

import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.fasterxml.jackson.databind.JsonNode;

public class TransactionArrayFacetComparator extends BaseMapComparator {

    private static final String KEY = "TransactionID";

    public TransactionArrayFacetComparator(ExtensiveComparator comparator) {
        super(comparator);
    }

    @Override
    protected String getMapKey(JsonNode jsonNode) {
        return getValue(jsonNode.get(KEY));
    }

    @Override
    public boolean qualified(JsonNode org, JsonNode tar, String path) {
        return org.isArray() && tar.isArray()
                && path.endsWith("TransactionArray.Transaction");
    }
}
