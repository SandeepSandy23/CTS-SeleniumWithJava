package com.ebay.app.apisellingextsvc.config;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.utils.IConfigHandler;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.exception.ExceptionUtils;

import java.util.List;

public class ConfigHandler implements IConfigHandler {

    private final List<IConfigProvider> providers;

    public ConfigHandler(List<IConfigProvider> providers) {
        this.providers = providers;
    }

    @Override
    public <V> V getValue(String s, Class<V> clazz, V v) {
        V value = null;
        try {
            for (IConfigProvider provider : providers) {
                value = provider.getProperty(s, clazz, null);
                if (value != null) {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            CalLogger.warn("ConfigHandler", e.getMessage());
        }
        if (value == null) {
            value = v;
        }
        return value;
    }

    @Override
    public <V> List<V> getValueList(String s, Class<V> clazz, List<V> list) {
        List<V> valuelList = null;
        try {
            for (IConfigProvider provider : providers) {
                valuelList = provider.getPropertyList(s, clazz, null);
                if (CollectionUtils.isNotEmpty(valuelList)) {
                    return valuelList;
                }
            }
        } catch (Exception e) {
            CalLogger.warn("ConfigHandler", ExceptionUtils.getStackTrace(e));
        }

        return list;
    }
}
