package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.Summary;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.SummaryUtil;
import com.ebay.cos.las.type.ListingActivitiesResponse;
import com.ebay.cosmos.SummaryResponse;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.ebay.rm.limit.enforcement.types.ActivityMetric;
import com.ebay.rm.limit.enforcement.types.ActivityMetricDetails;
import com.ebay.rm.limit.enforcement.types.CheckSellingLimitStatusResponse;
import ebay.apis.eblbasecomponents.AmountType;
import ebay.apis.eblbasecomponents.GetMyeBaySellingRequestType;
import ebay.apis.eblbasecomponents.ItemListCustomizationType;
import ebay.apis.eblbasecomponents.MyeBaySellingSummaryType;
import ebay.apis.eblbasecomponents.SellingSummaryType;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class GMESBuildSummaryTask implements Task<Summary>, ITaskResultInjectable {

    private final Map<String, Object> resultMap = new HashMap<>();
    private final GetMyeBaySellingRequestType requestType;
    private final GetMyeBaySellingRequest request;


    public GMESBuildSummaryTask(GetMyeBaySellingRequest request) {
        this.requestType = request.getRequestType();
        this.request = request;
    }

    @Override
    public Summary call() {
        SummaryResponse cosmosSummaryResponse = (SummaryResponse) resultMap.get(SummaryResponse.class.getName());
        CheckSellingLimitStatusResponse limitStatusResponse = (CheckSellingLimitStatusResponse) resultMap.get(CheckSellingLimitStatusResponse.class.getName());
        ListingActivitiesResponse lasResponse = (ListingActivitiesResponse) resultMap.get(ListingActivitiesResponse.class.getName());

        if (cosmosSummaryResponse == null) {
            return null;
        }

        Summary summaryContainer = new Summary();
        summaryContainer.setMyeBaySellingSummaryType(getSummary(cosmosSummaryResponse, limitStatusResponse,lasResponse));
        if (isSellingSummaryPreConditionMet()) {
            summaryContainer.setSellingSummaryType(getSellingSummary(cosmosSummaryResponse, lasResponse));
        }
        return summaryContainer;
    }

    private void setLimitStatus(MyeBaySellingSummaryType summary, CheckSellingLimitStatusResponse limitStatusResponse) {
        ActivityMetric activityMetric = Optional.ofNullable(limitStatusResponse)
                .map(CheckSellingLimitStatusResponse::getActivityMetricDetails)
                .map(ActivityMetricDetails::getActivityMetrics)
                .orElse(Collections.emptyList())
                .stream()
                .filter(i -> ApiSellingExtSvcConstants.REMAINING_METRICS.equals(i.getMetricType()))
                .findFirst()
                .orElse(null);
        if (activityMetric != null) {
            AmountType amountLimitRemaining = Optional.ofNullable(activityMetric.getAmountValue())
                    .map(AmountTypeUtil::getAmountType)
                    .orElse(null);
            summary.setAmountLimitRemaining(amountLimitRemaining);
            summary.setQuantityLimitRemaining(activityMetric.getQtyValue());
        }
    }

    private void setListingSummary(MyeBaySellingSummaryType summary, ListingActivitiesResponse lasResponse) {
        Optional.ofNullable(lasResponse)
                .map(ListingActivitiesResponse::getSummary)
                .ifPresent(t -> {
                    summary.setActiveAuctionCount(t.getBidsReserveMet());
                    summary.setAuctionSellingCount(t.getAuctions());
                    summary.setClassifiedAdCount(t.getAds());
                    summary.setTotalListingsWithLeads(t.getWithLeads());
                    summary.setTotalAuctionSellingValue(AmountTypeUtil.getAmountType(t.getTotalValueAuctionWithBidsReserveMet()));
                });

    }

    private MyeBaySellingSummaryType getSummary(SummaryResponse summaryResponse, CheckSellingLimitStatusResponse limitStatusResponse,
            ListingActivitiesResponse lasResponse) {
        MyeBaySellingSummaryType summary = new MyeBaySellingSummaryType();
        summary.setTotalSoldCount(summaryResponse.getItemCount());
        summary.setTotalSoldValue(SummaryUtil.getTotalSoldValue(summaryResponse));
        summary.setSoldDurationInDays(SummaryUtil.getSoldDurationInDays(requestType.getSoldList(), request.configValues));
        summary.setAuctionBidCount(0);
        summary.setClassifiedAdOfferCount(0);
        summary.setTotalLeadCount(0);
        setLimitStatus(summary, limitStatusResponse);
        setListingSummary(summary, lasResponse);
        return summary;
    }

    private SellingSummaryType getSellingSummary(SummaryResponse summaryResponse, ListingActivitiesResponse lasResponse) {
        SellingSummaryType sellingSummary = new SellingSummaryType();
        sellingSummary.setTotalSoldCount(summaryResponse.getItemCount());
        sellingSummary.setTotalSoldValue(SummaryUtil.getTotalSoldValue(summaryResponse));
        sellingSummary.setSoldDurationInDays(SummaryUtil.getSoldDurationInDays(requestType.getSoldList(), request.configValues));
        sellingSummary.setAuctionBidCount(0);
        setListingSummary(sellingSummary, lasResponse);
        return sellingSummary;
    }

    private void setListingSummary(SellingSummaryType sellingSummary, ListingActivitiesResponse lasResponse) {
        Optional.ofNullable(lasResponse)
                .map(ListingActivitiesResponse::getSummary)
                .ifPresent(t -> {
                    sellingSummary.setActiveAuctionCount(t.getBidsReserveMet());
                    sellingSummary.setAuctionSellingCount(t.getAuctions());
                    sellingSummary.setTotalAuctionSellingValue(AmountTypeUtil.getAmountType(t.getTotalValueAuctionWithBidsReserveMet()));
                });
    }

    /**
     * Selling summary container is always returned when version < 501 unless include == false
     */
    private Boolean isSellingSummaryPreConditionMet() {
        if (request.getTrxVersion() > this.request.getConfigValues().sellingSummaryMaxVersion) {
            return false;
        }
        return Optional.ofNullable(request.requestType.getSellingSummary())
                .map(ItemListCustomizationType::isInclude)
                .orElse(true);
    }

    @Override
    public void addResult(Object result) {
        if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}