package com.ebay.app.apisellingextsvc.audit.reporter;

public class GetMyeBaySellingReporter extends BaseAuditReporter {

        // TODO: CHANGE THIS
        private static final String PATTERN_PATH = "audit/report/mismatch_grouping_getMyeBaySelling.pattern";

        public GetMyeBaySellingReporter() {
            super(PATTERN_PATH);

        }
}
