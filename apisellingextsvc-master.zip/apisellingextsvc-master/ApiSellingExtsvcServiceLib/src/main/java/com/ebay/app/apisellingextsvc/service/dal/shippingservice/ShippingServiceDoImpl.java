package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.af.common.flag.FlagMask;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;

public class ShippingServiceDoImpl extends ShippingServiceCodeGenDoImpl implements ShippingService {
    public ShippingServiceDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    protected long getDataValue(FlagMask flagMask) {
        int dataId = flagMask.getDataId();
        return dataId == 1 ? (long)this.getFlags() : super.getDataValue(flagMask);
    }
}
