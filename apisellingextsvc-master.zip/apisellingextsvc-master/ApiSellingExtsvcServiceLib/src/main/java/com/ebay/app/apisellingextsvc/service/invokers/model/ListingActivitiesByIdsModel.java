package com.ebay.app.apisellingextsvc.service.invokers.model;

import com.ebay.app.apisellingextsvc.service.dal.sellerdiscount.SellerDiscountEntity;
import com.ebay.lib.lasng.model.ListingActivity;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;


/**
 * wrapper class to differentiate data in orchestrator dependency since Map<?,?> response of invoker is
 * generic
 *
 */
@AllArgsConstructor
@Getter
public class ListingActivitiesByIdsModel {
    Map<Long, ListingActivity> itemIdListingActivityMap;
}
