package com.ebay.app.apisellingextsvc.service.dal.shippingcarrier;

import com.ebay.integ.dal.BaseDo2;
import com.ebay.integ.dal.BaseDo3;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;

import java.util.Date;

public class ShippingCarrierCodeGenDoImpl extends BaseDo3 implements ShippingCarrier {
    public static final int SHIPPINGCARRIERID = 0;
    public static final int SHIPPINGCARRIERNAME = 1;
    public static final int SITEID = 2;
    public static final int SHIPPINGCARRIERSTATUS = 3;
    public static final int CREATIONDATE = 4;
    public static final int LASTMODIFIEDDATE = 5;
    public static final int TRACKINGURL = 6;
    public static final int CARRIERLOGOURL = 7;
    public static final int CARRIERENUMID = 8;
    public static final int FLAGS01 = 9;
    public static final int NUM_FIELDS = 10;
    public static final int NUM_SUBOBJECT_FIELDS = 0;
    public long m_shippingCarrierId;
    public String m_shippingCarrierName;
    public int m_siteId;
    public int m_shippingCarrierStatus;
    public Date m_creationDate;
    public Date m_lastModifiedDate;
    public String m_trackingUrl;
    public String m_carrierLogoUrl;
    public int m_carrierEnumId;
    public long m_flags01;

    public ShippingCarrierCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public int getNumFields() {
        return 10;
    }

    public int getNumSubObjects() {
        return 0;
    }

    public long getShippingCarrierId() {
        this.loadValue(0);
        return this.m_shippingCarrierId;
    }

    public void setShippingCarrierId(long shippingCarrierId) {
        this.m_shippingCarrierId = shippingCarrierId;
        this.setDirty(0);
    }

    public String getShippingCarrierName() {
        this.loadValue(1);
        return this.m_shippingCarrierName;
    }

    public void setShippingCarrierName(String shippingCarrierName) {
        this.m_shippingCarrierName = shippingCarrierName;
        this.setDirty(1);
    }

    public int getSiteId() {
        this.loadValue(2);
        return this.m_siteId;
    }

    public void setSiteId(int siteId) {
        this.m_siteId = siteId;
        this.setDirty(2);
    }

    public int getShippingCarrierStatus() {
        this.loadValue(3);
        return this.m_shippingCarrierStatus;
    }

    public void setShippingCarrierStatus(int shippingCarrierStatus) {
        this.m_shippingCarrierStatus = shippingCarrierStatus;
        this.setDirty(3);
    }

    public Date getCreationDate() {
        this.loadValue(4);
        return this.m_creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.m_creationDate = creationDate;
        this.setDirty(4);
    }

    public Date getLastModifiedDate() {
        this.loadValue(5);
        return this.m_lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.m_lastModifiedDate = lastModifiedDate;
        this.setDirty(5);
    }

    public String getTrackingUrl() {
        this.loadValue(6);
        return this.m_trackingUrl;
    }

    public void setTrackingUrl(String trackingUrl) {
        this.m_trackingUrl = trackingUrl;
        this.setDirty(6);
    }

    public String getCarrierLogoUrl() {
        this.loadValue(7);
        return this.m_carrierLogoUrl;
    }

    public void setCarrierLogoUrl(String carrierLogoUrl) {
        this.m_carrierLogoUrl = carrierLogoUrl;
        this.setDirty(7);
    }

    public int getCarrierEnumId() {
        this.loadValue(8);
        return this.m_carrierEnumId;
    }

    public void setCarrierEnumId(int m_carrierEnumIdm_) {
        this.m_carrierEnumId = m_carrierEnumIdm_;
        this.setDirty(8);
    }

    public long getFlags01() {
        this.loadValue(9);
        return this.m_flags01;
    }

    public void setFlags01(long m_flags01m_) {
        this.m_flags01 = m_flags01m_;
        this.setDirty(9);
    }

    public Object getSubObject(int subObjConst) {
        Object theObj = null;
        switch (subObjConst) {
            default:
                theObj = super.getSubObject(subObjConst);
                return theObj;
        }
    }

    public Object loadSubObject(int subObjConst, int readSet) {
        Object theObj = null;
        switch (subObjConst) {
            default:
                theObj = super.loadSubObject(subObjConst, readSet);
                return theObj;
        }
    }

    private void copyFieldsFrom_Batch0(ShippingCarrierCodeGenDoImpl from) {
        if (!this.isLoaded(0) && from.isLoaded(0)) {
            this.m_shippingCarrierId = from.m_shippingCarrierId;
            this.copyFieldState(from, 0);
        }

        if (!this.isLoaded(1) && from.isLoaded(1)) {
            this.m_shippingCarrierName = from.m_shippingCarrierName;
            this.copyFieldState(from, 1);
        }

        if (!this.isLoaded(2) && from.isLoaded(2)) {
            this.m_siteId = from.m_siteId;
            this.copyFieldState(from, 2);
        }

        if (!this.isLoaded(3) && from.isLoaded(3)) {
            this.m_shippingCarrierStatus = from.m_shippingCarrierStatus;
            this.copyFieldState(from, 3);
        }

        if (!this.isLoaded(4) && from.isLoaded(4)) {
            this.m_creationDate = copyDate(from.m_creationDate);
            this.copyFieldState(from, 4);
        }

        if (!this.isLoaded(5) && from.isLoaded(5)) {
            this.m_lastModifiedDate = copyDate(from.m_lastModifiedDate);
            this.copyFieldState(from, 5);
        }

        if (!this.isLoaded(6) && from.isLoaded(6)) {
            this.m_trackingUrl = from.m_trackingUrl;
            this.copyFieldState(from, 6);
        }

        if (!this.isLoaded(7) && from.isLoaded(7)) {
            this.m_carrierLogoUrl = from.m_carrierLogoUrl;
            this.copyFieldState(from, 7);
        }

        if (!this.isLoaded(8) && from.isLoaded(8)) {
            this.m_carrierEnumId = from.m_carrierEnumId;
            this.copyFieldState(from, 8);
        }

        if (!this.isLoaded(9) && from.isLoaded(9)) {
            this.m_flags01 = from.m_flags01;
            this.copyFieldState(from, 9);
        }

    }

    public void copyFieldsFrom(BaseDo2 copyFromObj) {
        super.copyFieldsFrom(copyFromObj);
        if (copyFromObj != null && copyFromObj instanceof ShippingCarrierCodeGenDoImpl) {
            ShippingCarrierCodeGenDoImpl from = (ShippingCarrierCodeGenDoImpl) copyFromObj;
            this.copyFieldsFrom_Batch0(from);
        }

        this.makeFieldsNullAndLoaded();
    }

    private void makeFieldsNullAndLoaded_Batch0() {
        if (!this.isLoaded(0)) {
            this.setLoadedField(0);
            this.setNull(0);
        }

        if (!this.isLoaded(1)) {
            this.setLoadedField(1);
            this.setNull(1);
        }

        if (!this.isLoaded(2)) {
            this.setLoadedField(2);
            this.setNull(2);
        }

        if (!this.isLoaded(3)) {
            this.setLoadedField(3);
            this.setNull(3);
        }

        if (!this.isLoaded(4)) {
            this.setLoadedField(4);
            this.setNull(4);
        }

        if (!this.isLoaded(5)) {
            this.setLoadedField(5);
            this.setNull(5);
        }

        if (!this.isLoaded(6)) {
            this.setLoadedField(6);
            this.setNull(6);
        }

        if (!this.isLoaded(7)) {
            this.setLoadedField(7);
            this.setNull(7);
        }

        if (!this.isLoaded(8)) {
            this.setLoadedField(8);
            this.setNull(8);
        }

        if (!this.isLoaded(9)) {
            this.setLoadedField(9);
            this.setNull(9);
        }

    }

    private void makeFieldsNullAndLoaded() {
        this.makeFieldsNullAndLoaded_Batch0();
    }
}
