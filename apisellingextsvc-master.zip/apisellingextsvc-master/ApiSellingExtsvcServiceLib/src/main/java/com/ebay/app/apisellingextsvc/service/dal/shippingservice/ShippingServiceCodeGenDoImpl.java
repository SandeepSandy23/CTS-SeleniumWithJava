package com.ebay.app.apisellingextsvc.service.dal.shippingservice;


import com.ebay.af.common.types.RawString;
import com.ebay.integ.dal.BaseDo2;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;

import java.lang.reflect.Field;
import java.util.Date;

public abstract class ShippingServiceCodeGenDoImpl extends BaseDo2 implements ShippingServiceCodeGen {
    public static final int SHIPPINGSERVICEID = 0;
    public static final int SITEID = 1;
    public static final int LOCALIZEDNAME = 2;
    public static final int SERVICENAMESUPERSCRIPT = 3;
    public static final int CARRIERID = 4;
    public static final int DESCRIPTION = 5;
    public static final int GENERIC = 6;
    public static final int DISPLAYORDERFLATRATE = 7;
    public static final int DOMESTIC = 8;
    public static final int FLATRATE = 9;
    public static final int CALCULATEDRATE = 10;
    public static final int FREIGHT = 11;
    public static final int FASTSHIPPING = 12;
    public static final int LOCALSHIPPING = 13;
    public static final int CODSHIPPING = 14;
    public static final int BPPSHIPPING = 15;
    public static final int MINDELIVERYTIME = 16;
    public static final int MAXDELIVERYTIME = 17;
    public static final int MAXWEIGHTLIMIT = 18;
    public static final int MAXWEIGHTLIMITUNITS = 19;
    public static final int ENABLED = 20;
    public static final int CONNSHIPSERVICENAME = 21;
    public static final int FLAGS = 22;
    public static final int TRAININTRODUCED = 23;
    public static final int CREATIONDATE = 24;
    public static final int LASTMODIFIEDDATE = 25;
    public static final int APISOAPSERVICECODE = 26;
    public static final int CARRIERSERVICECODE = 27;
    public static final int AREDIMREQD = 28;
    public static final int DISPLAYORDERCALCRATE = 29;
    public static final int VALIDPACKAGETYPELIST = 30;
    public static final int DEPRECATEMSGSTARTDATE = 31;
    public static final int DEPRECATEEFFECTIVEDATE = 32;
    public static final int MAPPEDTOSHIPPINGSERVICEID = 33;
    public static final int DEPRECATEMSGTYPE = 34;
    public static final int ISWEIGHTREQUIRED = 35;
    public static final int COSTCAPGROUP = 36;
    public static final int SHIPPINGSERVICETOKEN = 37;
    public static final int SOURCECOUNTRY = 38;
    public static final int VERIFYPHONENUMBER = 39;
    public static final int NUM_FIELDS = 40;
    public static final int NUM_SUBOBJECT_FIELDS = 0;
    public int m_shippingServiceId;
    public int m_siteId;
    public String m_localizedName;
    public String m_serviceNameSuperscript;
    public int m_carrierId;
    public String m_description;
    public int m_generic;
    public int m_displayOrderFlatRate;
    public int m_domestic;
    public int m_flatRate;
    public int m_calculatedRate;
    public int m_freight;
    public int m_fastShipping;
    public int m_localShipping;
    public int m_codShipping;
    public int m_bppShipping;
    public int m_minDeliveryTime;
    public int m_maxDeliveryTime;
    public int m_maxWeightLimit;
    public int m_maxWeightLimitUnits;
    public int m_enabled;
    public String m_connShipServiceName;
    public int m_flags;
    public int m_trainIntroduced;
    public Date m_creationDate;
    public Date m_lastModifiedDate;
    public String m_apiSoapServiceCode;
    public String m_carrierServiceCode;
    public int m_areDimReqd;
    public int m_displayOrderCalcRate;
    public String m_validPackageTypeList;
    public Date m_deprecateMsgStartDate;
    public Date m_deprecateEffectiveDate;
    public int m_mappedToShippingServiceId;
    public int m_deprecateMsgType;
    public int m_isWeightRequired;
    public int m_costCapGroup;
    public String m_shippingServiceToken;
    public int m_sourceCountry;
    public int m_verifyPhoneNumber;

    public ShippingServiceCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    public int getNumFields() {
        return 40;
    }

    public int getNumSubObjects() {
        return 0;
    }

    public int getShippingServiceId() {
        this.loadValue(0);
        return this.m_shippingServiceId;
    }

    public void setShippingServiceId(int shippingServiceId) {
        this.m_shippingServiceId = shippingServiceId;
        this.setDirty(0);
    }

    public int getSiteId() {
        this.loadValue(1);
        return this.m_siteId;
    }

    public void setSiteId(int siteId) {
        this.m_siteId = siteId;
        this.setDirty(1);
    }

    public String getLocalizedName() {
        this.loadValue(2);
        return this.m_localizedName;
    }

    public void setLocalizedName(String localizedName) {
        this.m_localizedName = localizedName;
        this.setDirty(2);
    }

    public String getServiceNameSuperscript() {
        this.loadValue(3);
        return this.m_serviceNameSuperscript;
    }

    public void setServiceNameSuperscript(String serviceNameSuperscript) {
        this.m_serviceNameSuperscript = serviceNameSuperscript;
        this.setDirty(3);
    }

    public int getCarrierId() {
        this.loadValue(4);
        return this.m_carrierId;
    }

    public void setCarrierId(int carrierId) {
        this.m_carrierId = carrierId;
        this.setDirty(4);
    }

    public String getDescription() {
        this.loadValue(5);
        return this.m_description;
    }

    public void setDescription(String description) {
        this.m_description = description;
        this.setDirty(5);
    }

    public int getGeneric() {
        this.loadValue(6);
        return this.m_generic;
    }

    public void setGeneric(int generic) {
        this.m_generic = generic;
        this.setDirty(6);
    }

    public int getDisplayOrderFlatRate() {
        this.loadValue(7);
        return this.m_displayOrderFlatRate;
    }

    public void setDisplayOrderFlatRate(int displayOrderFlatRate) {
        this.m_displayOrderFlatRate = displayOrderFlatRate;
        this.setDirty(7);
    }

    public int getDomestic() {
        this.loadValue(8);
        return this.m_domestic;
    }

    public void setDomestic(int domestic) {
        this.m_domestic = domestic;
        this.setDirty(8);
    }

    public int getFlatRate() {
        this.loadValue(9);
        return this.m_flatRate;
    }

    public void setFlatRate(int flatRate) {
        this.m_flatRate = flatRate;
        this.setDirty(9);
    }

    public int getCalculatedRate() {
        this.loadValue(10);
        return this.m_calculatedRate;
    }

    public void setCalculatedRate(int calculatedRate) {
        this.m_calculatedRate = calculatedRate;
        this.setDirty(10);
    }

    public int getFreight() {
        this.loadValue(11);
        return this.m_freight;
    }

    public void setFreight(int freight) {
        this.m_freight = freight;
        this.setDirty(11);
    }

    public int getFastShipping() {
        this.loadValue(12);
        return this.m_fastShipping;
    }

    public void setFastShipping(int fastShipping) {
        this.m_fastShipping = fastShipping;
        this.setDirty(12);
    }

    public int getLocalShipping() {
        this.loadValue(13);
        return this.m_localShipping;
    }

    public void setLocalShipping(int localShipping) {
        this.m_localShipping = localShipping;
        this.setDirty(13);
    }

    public int getCodShipping() {
        this.loadValue(14);
        return this.m_codShipping;
    }

    public void setCodShipping(int codShipping) {
        this.m_codShipping = codShipping;
        this.setDirty(14);
    }

    public int getBppShipping() {
        this.loadValue(15);
        return this.m_bppShipping;
    }

    public void setBppShipping(int bppShipping) {
        this.m_bppShipping = bppShipping;
        this.setDirty(15);
    }

    public int getMinDeliveryTime() {
        this.loadValue(16);
        return this.m_minDeliveryTime;
    }

    public void setMinDeliveryTime(int minDeliveryTime) {
        this.m_minDeliveryTime = minDeliveryTime;
        this.setDirty(16);
    }

    public int getMaxDeliveryTime() {
        this.loadValue(17);
        return this.m_maxDeliveryTime;
    }

    public void setMaxDeliveryTime(int maxDeliveryTime) {
        this.m_maxDeliveryTime = maxDeliveryTime;
        this.setDirty(17);
    }

    public int getMaxWeightLimit() {
        this.loadValue(18);
        return this.m_maxWeightLimit;
    }

    public void setMaxWeightLimit(int maxWeightLimit) {
        this.m_maxWeightLimit = maxWeightLimit;
        this.setDirty(18);
    }

    public int getMaxWeightLimitUnits() {
        this.loadValue(19);
        return this.m_maxWeightLimitUnits;
    }

    public void setMaxWeightLimitUnits(int maxWeightLimitUnits) {
        this.m_maxWeightLimitUnits = maxWeightLimitUnits;
        this.setDirty(19);
    }

    public int getEnabled() {
        this.loadValue(20);
        return this.m_enabled;
    }

    public void setEnabled(int enabled) {
        this.m_enabled = enabled;
        this.setDirty(20);
    }

    public String getConnShipServiceName() {
        this.loadValue(21);
        return this.m_connShipServiceName;
    }

    public void setConnShipServiceName(String connShipServiceName) {
        this.m_connShipServiceName = connShipServiceName;
        this.setDirty(21);
    }

    public int getFlags() {
        this.loadValue(22);
        return this.m_flags;
    }

    public void setFlags(int flags) {
        this.m_flags = flags;
        this.setDirty(22);
    }

    public int getTrainIntroduced() {
        this.loadValue(23);
        return this.m_trainIntroduced;
    }

    public void setTrainIntroduced(int trainIntroduced) {
        this.m_trainIntroduced = trainIntroduced;
        this.setDirty(23);
    }

    public Date getCreationDate() {
        this.loadValue(24);
        return this.m_creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.m_creationDate = creationDate;
        this.setDirty(24);
    }

    public Date getLastModifiedDate() {
        this.loadValue(25);
        return this.m_lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.m_lastModifiedDate = lastModifiedDate;
        this.setDirty(25);
    }

    public String getApiSoapServiceCode() {
        this.loadValue(26);
        return this.m_apiSoapServiceCode;
    }

    public void setApiSoapServiceCode(String apiSoapServiceCode) {
        this.m_apiSoapServiceCode = apiSoapServiceCode;
        this.setDirty(26);
    }

    public String getCarrierServiceCode() {
        this.loadValue(27);
        return this.m_carrierServiceCode;
    }

    public void setCarrierServiceCode(String carrierServiceCode) {
        this.m_carrierServiceCode = carrierServiceCode;
        this.setDirty(27);
    }

    public int getAreDimReqd() {
        this.loadValue(28);
        return this.m_areDimReqd;
    }

    public void setAreDimReqd(int areDimReqd) {
        this.m_areDimReqd = areDimReqd;
        this.setDirty(28);
    }

    public int getDisplayOrderCalcRate() {
        this.loadValue(29);
        return this.m_displayOrderCalcRate;
    }

    public void setDisplayOrderCalcRate(int displayOrderCalcRate) {
        this.m_displayOrderCalcRate = displayOrderCalcRate;
        this.setDirty(29);
    }

    public String getValidPackageTypeList() {
        this.loadValue(30);
        return this.m_validPackageTypeList;
    }

    public void setValidPackageTypeList(String validPackageTypeList) {
        this.m_validPackageTypeList = validPackageTypeList;
        this.setDirty(30);
    }

    public Date getDeprecateMsgStartDate() {
        this.loadValue(31);
        return this.m_deprecateMsgStartDate;
    }

    public void setDeprecateMsgStartDate(Date deprecateMsgStartDate) {
        this.m_deprecateMsgStartDate = deprecateMsgStartDate;
        this.setDirty(31);
    }

    public Date getDeprecateEffectiveDate() {
        this.loadValue(32);
        return this.m_deprecateEffectiveDate;
    }

    public void setDeprecateEffectiveDate(Date deprecateEffectiveDate) {
        this.m_deprecateEffectiveDate = deprecateEffectiveDate;
        this.setDirty(32);
    }

    public int getMappedToShippingServiceId() {
        this.loadValue(33);
        return this.m_mappedToShippingServiceId;
    }

    public void setMappedToShippingServiceId(int mappedToShippingServiceId) {
        this.m_mappedToShippingServiceId = mappedToShippingServiceId;
        this.setDirty(33);
    }

    public int getDeprecateMsgType() {
        this.loadValue(34);
        return this.m_deprecateMsgType;
    }

    public void setDeprecateMsgType(int deprecateMsgType) {
        this.m_deprecateMsgType = deprecateMsgType;
        this.setDirty(34);
    }

    public int getIsWeightRequired() {
        this.loadValue(35);
        return this.m_isWeightRequired;
    }

    public void setIsWeightRequired(int isWeightRequired) {
        this.m_isWeightRequired = isWeightRequired;
        this.setDirty(35);
    }

    public int getCostCapGroup() {
        this.loadValue(36);
        return this.m_costCapGroup;
    }

    public void setCostCapGroup(int costCapGroup) {
        this.m_costCapGroup = costCapGroup;
        this.setDirty(36);
    }

    public String getShippingServiceToken() {
        this.loadValue(37);
        return this.m_shippingServiceToken;
    }

    public void setShippingServiceToken(String shippingServiceToken) {
        this.m_shippingServiceToken = shippingServiceToken;
        this.setDirty(37);
    }

    public int getSourceCountry() {
        this.loadValue(38);
        return this.m_sourceCountry;
    }

    public void setSourceCountry(int sourceCountry) {
        this.m_sourceCountry = sourceCountry;
        this.setDirty(38);
    }

    public int getVerifyPhoneNumber() {
        this.loadValue(39);
        return this.m_verifyPhoneNumber;
    }

    public void setVerifyPhoneNumber(int verifyPhoneNumber) {
        this.m_verifyPhoneNumber = verifyPhoneNumber;
        this.setDirty(39);
    }

    public Object getSubObject(int subObjConst) {
        Object theObj = null;
        switch (subObjConst) {
            default:
                theObj = super.getSubObject(subObjConst);
                return theObj;
        }
    }

    public Object loadSubObject(int subObjConst, int readSet) {
        Object theObj = null;
        switch (subObjConst) {
            default:
                theObj = super.loadSubObject(subObjConst, readSet);
                return theObj;
        }
    }

    public boolean equalsData(BaseDo2 other) {
        if (other == null) {
            return false;
        } else if (other == this) {
            return true;
        } else if (!(other instanceof ShippingServiceCodeGenDoImpl)) {
            return false;
        } else if (!super.equalsData(other)) {
            return false;
        } else {
            ShippingServiceCodeGenDoImpl cmpDo = (ShippingServiceCodeGenDoImpl)other;
            String className = this.getClass().getName();
            String packageName = className.substring(0, className.lastIndexOf("."));
            String myClassName = packageName + ".ShippingServiceCodeGenDoImpl";
            Class myClass = null;

            try {
                myClass = Class.forName(myClassName);
            } catch (ClassNotFoundException var15) {
                return false;
            }

            Field[] fields = myClass.getDeclaredFields();

            for (int i = 0; i < fields.length; ++i) {
                Field f = fields[i];
                if (f.getModifiers() == 1 && f.getModifiers() != 8) {
                    String fieldType = f.getType().getName();

                    try {
                        boolean isEqual = true;
                        if (fieldType.equals("int")) {
                            isEqual = safeEquals(f.getInt(this), f.getInt(cmpDo));
                        } else if (fieldType.equals("long")) {
                            isEqual = safeEquals(f.getLong(this), f.getLong(cmpDo));
                        } else if (fieldType.equals("float")) {
                            isEqual = safeEquals(f.getFloat(this), f.getFloat(cmpDo));
                        } else if (fieldType.equals("double")) {
                            isEqual = safeEquals(f.getDouble(this), f.getDouble(cmpDo));
                        } else if (fieldType.equals("boolean")) {
                            isEqual = safeEquals(f.getBoolean(this), f.getBoolean(cmpDo));
                        } else if (fieldType.endsWith("RawString")) {
                            RawString a = (RawString)f.get(this);
                            RawString b = (RawString)f.get(cmpDo);
                            isEqual = safeEquals(a, b);
                        } else if (fieldType.endsWith("java.util.Date")) {
                            Date a = (Date)f.get(this);
                            Date b = (Date)f.get(cmpDo);
                            isEqual = safeEquals(a, b);
                        } else {
                            isEqual = safeEquals(f.get(this), f.get(cmpDo));
                        }

                        if (!isEqual) {
                            return false;
                        }
                    } catch (IllegalAccessException var14) {
                        return false;
                    }
                }
            }

            return true;
        }
    }

    private void copyFieldsFrom_Batch0(ShippingServiceCodeGenDoImpl from) {
        if (!this.isLoaded(0) && from.isLoaded(0)) {
            this.m_shippingServiceId = from.m_shippingServiceId;
            this.copyFieldState(from, 0);
        }

        if (!this.isLoaded(1) && from.isLoaded(1)) {
            this.m_siteId = from.m_siteId;
            this.copyFieldState(from, 1);
        }

        if (!this.isLoaded(2) && from.isLoaded(2)) {
            this.m_localizedName = from.m_localizedName;
            this.copyFieldState(from, 2);
        }

        if (!this.isLoaded(3) && from.isLoaded(3)) {
            this.m_serviceNameSuperscript = from.m_serviceNameSuperscript;
            this.copyFieldState(from, 3);
        }

        if (!this.isLoaded(4) && from.isLoaded(4)) {
            this.m_carrierId = from.m_carrierId;
            this.copyFieldState(from, 4);
        }

        if (!this.isLoaded(5) && from.isLoaded(5)) {
            this.m_description = from.m_description;
            this.copyFieldState(from, 5);
        }

        if (!this.isLoaded(6) && from.isLoaded(6)) {
            this.m_generic = from.m_generic;
            this.copyFieldState(from, 6);
        }

        if (!this.isLoaded(7) && from.isLoaded(7)) {
            this.m_displayOrderFlatRate = from.m_displayOrderFlatRate;
            this.copyFieldState(from, 7);
        }

        if (!this.isLoaded(8) && from.isLoaded(8)) {
            this.m_domestic = from.m_domestic;
            this.copyFieldState(from, 8);
        }

        if (!this.isLoaded(9) && from.isLoaded(9)) {
            this.m_flatRate = from.m_flatRate;
            this.copyFieldState(from, 9);
        }

        if (!this.isLoaded(10) && from.isLoaded(10)) {
            this.m_calculatedRate = from.m_calculatedRate;
            this.copyFieldState(from, 10);
        }

        if (!this.isLoaded(11) && from.isLoaded(11)) {
            this.m_freight = from.m_freight;
            this.copyFieldState(from, 11);
        }

        if (!this.isLoaded(12) && from.isLoaded(12)) {
            this.m_fastShipping = from.m_fastShipping;
            this.copyFieldState(from, 12);
        }

        if (!this.isLoaded(13) && from.isLoaded(13)) {
            this.m_localShipping = from.m_localShipping;
            this.copyFieldState(from, 13);
        }

        if (!this.isLoaded(14) && from.isLoaded(14)) {
            this.m_codShipping = from.m_codShipping;
            this.copyFieldState(from, 14);
        }

        if (!this.isLoaded(15) && from.isLoaded(15)) {
            this.m_bppShipping = from.m_bppShipping;
            this.copyFieldState(from, 15);
        }

        if (!this.isLoaded(16) && from.isLoaded(16)) {
            this.m_minDeliveryTime = from.m_minDeliveryTime;
            this.copyFieldState(from, 16);
        }

        if (!this.isLoaded(17) && from.isLoaded(17)) {
            this.m_maxDeliveryTime = from.m_maxDeliveryTime;
            this.copyFieldState(from, 17);
        }

        if (!this.isLoaded(18) && from.isLoaded(18)) {
            this.m_maxWeightLimit = from.m_maxWeightLimit;
            this.copyFieldState(from, 18);
        }

        if (!this.isLoaded(19) && from.isLoaded(19)) {
            this.m_maxWeightLimitUnits = from.m_maxWeightLimitUnits;
            this.copyFieldState(from, 19);
        }

        if (!this.isLoaded(20) && from.isLoaded(20)) {
            this.m_enabled = from.m_enabled;
            this.copyFieldState(from, 20);
        }

        if (!this.isLoaded(21) && from.isLoaded(21)) {
            this.m_connShipServiceName = from.m_connShipServiceName;
            this.copyFieldState(from, 21);
        }

        if (!this.isLoaded(22) && from.isLoaded(22)) {
            this.m_flags = from.m_flags;
            this.copyFieldState(from, 22);
        }

        if (!this.isLoaded(23) && from.isLoaded(23)) {
            this.m_trainIntroduced = from.m_trainIntroduced;
            this.copyFieldState(from, 23);
        }

        if (!this.isLoaded(24) && from.isLoaded(24)) {
            this.m_creationDate = copyDate(from.m_creationDate);
            this.copyFieldState(from, 24);
        }

        if (!this.isLoaded(25) && from.isLoaded(25)) {
            this.m_lastModifiedDate = copyDate(from.m_lastModifiedDate);
            this.copyFieldState(from, 25);
        }

        if (!this.isLoaded(26) && from.isLoaded(26)) {
            this.m_apiSoapServiceCode = from.m_apiSoapServiceCode;
            this.copyFieldState(from, 26);
        }

        if (!this.isLoaded(27) && from.isLoaded(27)) {
            this.m_carrierServiceCode = from.m_carrierServiceCode;
            this.copyFieldState(from, 27);
        }

        if (!this.isLoaded(28) && from.isLoaded(28)) {
            this.m_areDimReqd = from.m_areDimReqd;
            this.copyFieldState(from, 28);
        }

        if (!this.isLoaded(29) && from.isLoaded(29)) {
            this.m_displayOrderCalcRate = from.m_displayOrderCalcRate;
            this.copyFieldState(from, 29);
        }

        if (!this.isLoaded(30) && from.isLoaded(30)) {
            this.m_validPackageTypeList = from.m_validPackageTypeList;
            this.copyFieldState(from, 30);
        }

        if (!this.isLoaded(31) && from.isLoaded(31)) {
            this.m_deprecateMsgStartDate = copyDate(from.m_deprecateMsgStartDate);
            this.copyFieldState(from, 31);
        }

        if (!this.isLoaded(32) && from.isLoaded(32)) {
            this.m_deprecateEffectiveDate = copyDate(from.m_deprecateEffectiveDate);
            this.copyFieldState(from, 32);
        }

        if (!this.isLoaded(33) && from.isLoaded(33)) {
            this.m_mappedToShippingServiceId = from.m_mappedToShippingServiceId;
            this.copyFieldState(from, 33);
        }

        if (!this.isLoaded(34) && from.isLoaded(34)) {
            this.m_deprecateMsgType = from.m_deprecateMsgType;
            this.copyFieldState(from, 34);
        }

        if (!this.isLoaded(35) && from.isLoaded(35)) {
            this.m_isWeightRequired = from.m_isWeightRequired;
            this.copyFieldState(from, 35);
        }

        if (!this.isLoaded(36) && from.isLoaded(36)) {
            this.m_costCapGroup = from.m_costCapGroup;
            this.copyFieldState(from, 36);
        }

        if (!this.isLoaded(37) && from.isLoaded(37)) {
            this.m_shippingServiceToken = from.m_shippingServiceToken;
            this.copyFieldState(from, 37);
        }

        if (!this.isLoaded(38) && from.isLoaded(38)) {
            this.m_sourceCountry = from.m_sourceCountry;
            this.copyFieldState(from, 38);
        }

        if (!this.isLoaded(39) && from.isLoaded(39)) {
            this.m_verifyPhoneNumber = from.m_verifyPhoneNumber;
            this.copyFieldState(from, 39);
        }

    }

    public void copyFieldsFrom(BaseDo2 copyFromObj) {
        super.copyFieldsFrom(copyFromObj);
        if (copyFromObj != null && copyFromObj instanceof ShippingServiceCodeGenDoImpl) {
            ShippingServiceCodeGenDoImpl from = (ShippingServiceCodeGenDoImpl)copyFromObj;
            this.copyFieldsFrom_Batch0(from);
        }

        this.makeFieldsNullAndLoaded();
    }

    private void makeFieldsNullAndLoaded_Batch0() {
        if (!this.isLoaded(0)) {
            this.setLoadedField(0);
            this.setNull(0);
        }

        if (!this.isLoaded(1)) {
            this.setLoadedField(1);
            this.setNull(1);
        }

        if (!this.isLoaded(2)) {
            this.setLoadedField(2);
            this.setNull(2);
        }

        if (!this.isLoaded(3)) {
            this.setLoadedField(3);
            this.setNull(3);
        }

        if (!this.isLoaded(4)) {
            this.setLoadedField(4);
            this.setNull(4);
        }

        if (!this.isLoaded(5)) {
            this.setLoadedField(5);
            this.setNull(5);
        }

        if (!this.isLoaded(6)) {
            this.setLoadedField(6);
            this.setNull(6);
        }

        if (!this.isLoaded(7)) {
            this.setLoadedField(7);
            this.setNull(7);
        }

        if (!this.isLoaded(8)) {
            this.setLoadedField(8);
            this.setNull(8);
        }

        if (!this.isLoaded(9)) {
            this.setLoadedField(9);
            this.setNull(9);
        }

        if (!this.isLoaded(10)) {
            this.setLoadedField(10);
            this.setNull(10);
        }

        if (!this.isLoaded(11)) {
            this.setLoadedField(11);
            this.setNull(11);
        }

        if (!this.isLoaded(12)) {
            this.setLoadedField(12);
            this.setNull(12);
        }

        if (!this.isLoaded(13)) {
            this.setLoadedField(13);
            this.setNull(13);
        }

        if (!this.isLoaded(14)) {
            this.setLoadedField(14);
            this.setNull(14);
        }

        if (!this.isLoaded(15)) {
            this.setLoadedField(15);
            this.setNull(15);
        }

        if (!this.isLoaded(16)) {
            this.setLoadedField(16);
            this.setNull(16);
        }

        if (!this.isLoaded(17)) {
            this.setLoadedField(17);
            this.setNull(17);
        }

        if (!this.isLoaded(18)) {
            this.setLoadedField(18);
            this.setNull(18);
        }

        if (!this.isLoaded(19)) {
            this.setLoadedField(19);
            this.setNull(19);
        }

        if (!this.isLoaded(20)) {
            this.setLoadedField(20);
            this.setNull(20);
        }

        if (!this.isLoaded(21)) {
            this.setLoadedField(21);
            this.setNull(21);
        }

        if (!this.isLoaded(22)) {
            this.setLoadedField(22);
            this.setNull(22);
        }

        if (!this.isLoaded(23)) {
            this.setLoadedField(23);
            this.setNull(23);
        }

        if (!this.isLoaded(24)) {
            this.setLoadedField(24);
            this.setNull(24);
        }

        if (!this.isLoaded(25)) {
            this.setLoadedField(25);
            this.setNull(25);
        }

        if (!this.isLoaded(26)) {
            this.setLoadedField(26);
            this.setNull(26);
        }

        if (!this.isLoaded(27)) {
            this.setLoadedField(27);
            this.setNull(27);
        }

        if (!this.isLoaded(28)) {
            this.setLoadedField(28);
            this.setNull(28);
        }

        if (!this.isLoaded(29)) {
            this.setLoadedField(29);
            this.setNull(29);
        }

        if (!this.isLoaded(30)) {
            this.setLoadedField(30);
            this.setNull(30);
        }

        if (!this.isLoaded(31)) {
            this.setLoadedField(31);
            this.setNull(31);
        }

        if (!this.isLoaded(32)) {
            this.setLoadedField(32);
            this.setNull(32);
        }

        if (!this.isLoaded(33)) {
            this.setLoadedField(33);
            this.setNull(33);
        }

        if (!this.isLoaded(34)) {
            this.setLoadedField(34);
            this.setNull(34);
        }

        if (!this.isLoaded(35)) {
            this.setLoadedField(35);
            this.setNull(35);
        }

        if (!this.isLoaded(36)) {
            this.setLoadedField(36);
            this.setNull(36);
        }

        if (!this.isLoaded(37)) {
            this.setLoadedField(37);
            this.setNull(37);
        }

        if (!this.isLoaded(38)) {
            this.setLoadedField(38);
            this.setNull(38);
        }

        if (!this.isLoaded(39)) {
            this.setLoadedField(39);
            this.setNull(39);
        }

    }

    private void makeFieldsNullAndLoaded() {
        this.makeFieldsNullAndLoaded_Batch0();
    }
}