package com.ebay.app.apisellingextsvc.service.dal.shippingcarrier;

import com.ebay.integ.dal.cache2.CacheLoader;
import com.ebay.integ.dal.cache2.CacheLoaderException;
import com.ebay.integ.dal.cache2.ExternalCacheEntryLoader;
import com.ebay.integ.dal.cache2.FullCacheException;
import com.ebay.integ.dal.cache2.MessageId;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.kernel.message.Message;

public class ShippingCarrierCacheLoader implements CacheLoader {
    public ShippingCarrierCacheLoader() {
    }

    public void refresh(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        externalCacheEntryLoader.flushCache();
        this.startup(externalCacheEntryLoader);
    }

    public void startup(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        String[] params;
        Message complaint;
        try {
            externalCacheEntryLoader.putInCacheFromList(ShippingCarrierDAO.getInstance().findAllDirect2DBSortedByShippingCarrier());
        } catch (FinderException | FullCacheException exception) {
            params = new String[]{this.getClass().getName(), exception.getMessage()};
            complaint = new Message(MessageId.CACHE_LOADER_FAILURE, params);
            throw new CacheLoaderException(complaint, exception);
        }
    }
}
