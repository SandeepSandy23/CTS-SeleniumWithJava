package com.ebay.app.apisellingextsvc.enums;


//This Enum Copy from com.ebay.maestro.shared.domain.HoldReleaseReasonEnum
public enum HoldReleaseReasonEnum {
    NONE,
    SELLER_IS_ON_BLACK_LIST,
    NEW_SELLER,
    CASUAL_SELLER,
    BELOW_STANDARD_SELLER,
    REINSTATEMENT_AFTER_SUSPENSION,
    EBP_CASE_OPEN,
    NEW_PAYPAL_ACCOUNT_ADDED,
    NOT_AVAILABLE,
    S2FHOLD_DFLT,
    NEW_SELLER_MP
}

