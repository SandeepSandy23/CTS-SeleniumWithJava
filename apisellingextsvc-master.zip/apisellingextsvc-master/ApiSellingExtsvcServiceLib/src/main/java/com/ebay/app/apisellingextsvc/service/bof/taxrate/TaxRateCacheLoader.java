package com.ebay.app.apisellingextsvc.service.bof.taxrate;

import com.ebay.integ.dal.cache2.*;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.kernel.message.Message;

public class TaxRateCacheLoader implements CacheLoader {
    private static final long serialVersionUID = -4802207618607786570L;

    public TaxRateCacheLoader() {
    }

    public void startup(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        this.load(externalCacheEntryLoader);
    }

    public void refresh(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        externalCacheEntryLoader.flushCache();
        this.load(externalCacheEntryLoader);
    }

    private void load(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        String[] params;
        Message complaint;
        try {
            externalCacheEntryLoader.putInCacheFromList(TaxRateDAO.getInstance().findAllDirect2DB());
        } catch (FinderException var5) {
            params = new String[]{this.getClass().getName(), var5.getMessage()};
            complaint = new Message(MessageId.CACHE_LOADER_FAILURE, params);
            throw new CacheLoaderException(complaint, var5);
        } catch (FullCacheException var6) {
            params = new String[]{this.getClass().getName(), var6.getMessage()};
            complaint = new Message(MessageId.CACHE_LOADER_FAILURE, params);
            throw new CacheLoaderException(complaint, var6);
        }
    }
}
