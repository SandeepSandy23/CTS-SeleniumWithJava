package com.ebay.app.apisellingextsvc.common.constant;

public final class TaxStateConstants {
    public static final String Australia = "AU";
    public static final String EuropeanUnion = "EU";
    public static final String UnitedKingdom = "UK";
    public static final String France = "FR";
    public static final String Norway = "NO";
    public static final String Kazakhstan = "KZ";
    public static final String Jersey = "JE";
    public static final String Belarus = "BY";
    public static final String Malaysia = "MY";
}
