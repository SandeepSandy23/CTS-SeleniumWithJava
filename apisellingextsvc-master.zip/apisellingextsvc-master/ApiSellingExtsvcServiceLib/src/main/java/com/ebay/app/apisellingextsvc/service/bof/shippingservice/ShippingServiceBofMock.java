package com.ebay.app.apisellingextsvc.service.bof.shippingservice;

import com.ebay.app.apisellingextsvc.service.dal.shippingservice.ShippingService;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import com.ebay.app.apisellingextsvc.test.TestMock;
import com.ebay.app.apisellingextsvc.test.TestMockHolder;

public class ShippingServiceBofMock implements IShippingServiceBof {
    public static final String SHIPPING_SERVICE_MOCK_NAME_PROFIX = "IShippingServiceBof";
    private final Map<Integer, ShippingService> shippingServiceMap;

    public ShippingServiceBofMock(TestMock mock) {
        ShippingServiceListMock shippingServiceListMock = TestMockHolder.getMock(mock, ShippingServiceListMock.class);
        shippingServiceMap = shippingServiceListMock.getShippingServiceDoMockList()
                .stream().collect(Collectors.toMap(item -> item.getShippingServiceId(), Function.identity()));
    }

    @Override
    public ShippingService findByServiceId(int serviceId) {
        return shippingServiceMap.getOrDefault(serviceId, null);
    }
}
