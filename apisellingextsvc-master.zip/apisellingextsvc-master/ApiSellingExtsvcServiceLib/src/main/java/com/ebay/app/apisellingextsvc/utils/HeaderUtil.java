package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;

import javax.annotation.Nonnull;
import javax.ws.rs.core.HttpHeaders;
import java.util.List;
import java.util.Locale;

public class HeaderUtil {

    public static String getHeader(@Nonnull HttpHeaders headers, String key) {
        List<String> strings = ObjectUtils.defaultIfNull(headers.getRequestHeaders().get(key),
                headers.getRequestHeaders().get(key.toLowerCase(Locale.US)));
        return CollectionUtils.isNotEmpty(strings) ? strings.get(0) : null;
    }

    public static String getCompatibilityLevel(HttpHeaders headers) {
        return HeaderUtil.getHeader(headers, ApiSellingExtSvcConstants.X_EBAY_API_COMPATIBILITY_LEVEL);
    }

    public static String getSiteId(HttpHeaders headers) {
        return HeaderUtil.getHeader(headers, ApiSellingExtSvcConstants.X_EBAY_API_SITE_ID);
    }

    public static String getEndUserCtx(@Nonnull String userName, @Nonnull String userId) {
        return "origUserId=origUserName%3D"
                + userName
                + "%2CorigAcctId%3D"
                + userId;
    }
}
