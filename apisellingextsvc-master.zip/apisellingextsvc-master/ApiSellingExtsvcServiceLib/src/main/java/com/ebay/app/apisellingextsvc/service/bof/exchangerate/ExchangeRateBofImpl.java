package com.ebay.app.apisellingextsvc.service.bof.exchangerate;

import com.ebay.app.apisellingextsvc.service.dal.exchangerate.ExchangeRate;
import com.ebay.app.apisellingextsvc.service.dal.exchangerate.ExchangeRateDAO;
import com.ebay.integ.dal.dao.ObjectNotFoundException;

import java.util.Optional;

public class ExchangeRateBofImpl implements IExchangeRateBof {

    @Override
    public Double findExchangeRateByCurrencyId(int currencyId) throws ObjectNotFoundException {
        return Optional.ofNullable(ExchangeRateDAO.getInstance().findExchangeRateByCurrencyId(currencyId)).map(ExchangeRate::getRate).orElse(null);
    }
}
