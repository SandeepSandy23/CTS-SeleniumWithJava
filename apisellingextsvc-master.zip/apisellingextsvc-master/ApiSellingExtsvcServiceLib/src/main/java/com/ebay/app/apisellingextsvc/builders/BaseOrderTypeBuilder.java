package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.mappers.CancelStatusMapper;
import com.ebay.app.apisellingextsvc.mappers.OrderStatusMapper;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.EiasTokenUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.OrderStateTypeCS;
import com.ebay.cosmos.OrderTotal;
import com.ebay.cosmos.UserCS;
import com.ebay.order.common.base.Amount;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public abstract class BaseOrderTypeBuilder extends BaseFacetBuilder<OrderType> {

    protected final int trxVersion;
    protected final ApiSellingExtSvcConfigValues configValues;
    protected final ContractResponseType contractResponse;

    public BaseOrderTypeBuilder(Task<?> task,
                                int trxVersion, ApiSellingExtSvcConfigValues configValues,
                                ContractResponseType contractResponse) {
        super(task);
        this.trxVersion = trxVersion;
        this.configValues = configValues;
        this.contractResponse = contractResponse;
    }


    protected static OrderStatusCodeType getOrderStatusCodeType(OrderStateTypeCS orderStateTypeCS) {
        return Optional.ofNullable(orderStateTypeCS)
                .map(OrderStateTypeCS::getOrderStatus)
                .map(status -> OrderStatusMapper.map(status, orderStateTypeCS.getFundingStatus()))
                .orElse(null);
    }

    protected static boolean isContainseBayPlusTransaction(TransactionArrayType transactionArrayType) {
        return Optional.ofNullable(transactionArrayType)
                .map(TransactionArrayType::getTransaction)
                .map(arry -> arry.stream().anyMatch(TransactionType::isEBayPlusTransaction))
                .orElse(false);
    }

    protected String getEiasToken(UserCS user) {
        return Optional.ofNullable(user).map(User::getUserIdentifier).map(UserIdentifier::getUserId)
                .map(EiasTokenUtil::encode).orElse(null);
    }

    protected String getSellerEiasToken(UserCS user) {
        return getEiasToken(user);
    }


    protected CancelStatusCodeType getCancelStatus(OrderStateTypeCS orderState) {

        //https://jirap.corp.ebay.com/browse/TRXAPI-2116
        if (VersionConstant.isGreaterEqualThan(trxVersion, ApiSellingExtSvcConstants.COMPATIBILITY_LEVEL_879)) {
            return Optional.ofNullable(orderState).map(OrderStateTypeCS::getCancelStatus)
                    .map(CancelStatusMapper::map).orElse(CancelStatusCodeType.NOT_APPLICABLE);
        }

        return null;
    }

    protected AmountType getAmountSaved(EntityTotal orderTotal, OrderTotal orderTotalSummary) {
        return Optional.ofNullable(orderTotal)
                .map(EntityTotal::getPriceLines)
                .map(Collection::stream)
                .flatMap(d -> d.filter(p -> PricelineTypeEnum.SHIPPING_DISCOUNT.equals(p.getType()))
                        .findFirst().map(PriceLine::getAmount))
                .map(AmountTypeUtil::getAmountType).orElseGet(() -> AmountTypeUtil.getDefaultZeroAmountType(orderTotalSummary));
    }

    /**
     * The Total amount shows the total cost for the order, including total item cost (shown in Subtotal field), shipping charges (shown in
     * ShippingServiceSelected.ShippingServiceCost field), and seller-applied sales tax (shown in SalesTax.SalesTaxAmount field).
     */
    protected AmountType getTotal(Amount amount, PaymentsType payments) {
        AmountType amountType = Optional.ofNullable(amount)
              .map(AmountTypeUtil::getAmountType).orElse(null);
        // for full refund
        if (amountType != null
              && amountType.getValue() > 0
                && PaymentUtil.hasTaxPartnerDistribution(payments)) {
            Optional<BigDecimal> taxAmount = PaymentUtil.getTaxAmount(payments);
            if (taxAmount.isPresent()) {
                BigDecimal bigDecimal = BigDecimal.valueOf(amountType.getValue())
                        .setScale(ApiSellingExtSvcConstants.SCALE_OF_DECIMAL, RoundingMode.HALF_UP);
                amountType.setValue(bigDecimal.subtract(taxAmount.get()).doubleValue());
            }
        }
        return amountType;
    }

    protected AmountType getSubtotal(List<PriceLine> priceLines) {
        AmountType itemCost = priceLines
                .stream()
                .filter(i -> i.getType().equals(PricelineTypeEnum.ITEM_COST))
                .findFirst()
                .map(PriceLine::getAmount)
                .map(AmountTypeUtil::getAmountType)
                .orElse(null);

        AmountType promotion = priceLines
                .stream()
                .filter(i -> i.getType().equals(PricelineTypeEnum.PROMOTION))
                .findFirst()
                .map(PriceLine::getAmount)
                .map(AmountTypeUtil::getAmountType)
                .orElse(null);

        if (itemCost != null && promotion != null) {
            return AmountTypeUtil.sum(itemCost, AmountTypeUtil.negate(promotion));
        }

        return itemCost;
    }
}
