package com.ebay.app.apisellingextsvc.audit.comparator.facet;

import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.fasterxml.jackson.databind.JsonNode;

public class ScheduledListArrayFacetComparator extends ActiveListArrayFacetComparator {

    public ScheduledListArrayFacetComparator(ExtensiveComparator comparator) {
        super(comparator);
    }

    @Override
    public boolean qualified(JsonNode org, JsonNode tar, String path) {
        return org.isArray() && tar.isArray()
                && path.contains("ScheduledList.ItemArray")
                && path.endsWith("Item");
    }
}
