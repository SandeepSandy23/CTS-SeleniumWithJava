package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.order.common.v1.DateTime;
import org.apache.commons.lang3.exception.ExceptionUtils;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Optional;
import java.util.TimeZone;

public class DateUtil {

    private static final String YYYY_MM_DD_DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
    private static final TimeZone TIMEZONE_UTC = TimeZone.getTimeZone("UTC");
    private static final String UTC = "UTC";
    private static DatatypeFactory DATATYPE_FACTORY = null;

    static {
        try {
            DATATYPE_FACTORY = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            CalLogger.error("DateUtil error", ExceptionUtils.getStackTrace(e));
        }
    }

    public static String convert(Calendar calendar) {
        String str = null;
        if (calendar != null) {
            // DateFormats are inherently unsafe for multithreaded use.
            SimpleDateFormat formatter = new SimpleDateFormat(YYYY_MM_DD_DATE_FORMATTER, Locale.US);
            formatter.setTimeZone(TIMEZONE_UTC);
            str = formatter.format(calendar.getTime());
        }
        return str;
    }

    public static Calendar convert(String dateString) {
        return convert(dateString, null);
    }

    public static Calendar convert(String dateString, String dateFormat) {
        Calendar cal = Calendar.getInstance();
        try {
            String format = (dateFormat != null) ? dateFormat : YYYY_MM_DD_DATE_FORMATTER;
            SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.US);
            formatter.setTimeZone(TIMEZONE_UTC);
            cal.setTime(formatter.parse(dateString));// all done
        } catch (ParseException e) {
            CalLogger.error("convert dateString error", "parsing date warning");
            return null;
        }
        return cal;
    }

    public static Calendar convertToCalendar(XMLGregorianCalendar from) {
        return Optional.ofNullable(from).map(XMLGregorianCalendar::toGregorianCalendar).orElse(null);
    }

    public static XMLGregorianCalendar calendarToXMLGregorian(Calendar calendar) {
        return convertToXMLGregorianCalendar(new DateTime(calendar.getTime()));
    }

    public static XMLGregorianCalendar convertToXMLGregorianCalendar(DateTime from) {
        if (from == null || from.getValue() == null) {
            return null;
        }
        GregorianCalendar c = new GregorianCalendar(TimeZone.getTimeZone(UTC));
        c.setTime(from.getValue());
        return DATATYPE_FACTORY.newXMLGregorianCalendar(c);
    }

    public static XMLGregorianCalendar convertToXMLGregorianCalendar(String dateStr) {
        Calendar convert = convert(dateStr);
        Date date = convert.getTime();
        GregorianCalendar c = new GregorianCalendar(TimeZone.getTimeZone(UTC));
        c.setTime(date);
        c.setTimeInMillis(convert.getTimeInMillis());
        return DATATYPE_FACTORY.newXMLGregorianCalendar(c);
    }

    public static XMLGregorianCalendar getDatetimeNow() {
        return DATATYPE_FACTORY.newXMLGregorianCalendar(new GregorianCalendar(TimeZone.getTimeZone(UTC)));
    }

    public static Calendar getCalendarNow() {
        return GregorianCalendar.from(ZonedDateTime.ofInstant(Instant.now(), ZoneId.of(UTC)));
    }

    public static Calendar getCalendarNow(TimeZone timeZone) {
        return GregorianCalendar.from(ZonedDateTime.ofInstant(Instant.now(), ZoneId.of(timeZone.getID())));
    }

    public static Calendar getDateWithOffset(int duration, TimeZone timeZone) {
        Calendar cal = Calendar.getInstance(timeZone);
        if (duration > 0 && !isMidnight(cal)) {
            --duration;
        }
        setToMidnight(cal);
        Calendar date = DateUtil.addDays(cal.getTime(), duration * -1, timeZone);
        return date;
    }

    public static void setToMidnight(Calendar cal) {
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.HOUR_OF_DAY, 0);
    }

    public static boolean isMidnight(Calendar cal) {
        return cal.get(Calendar.HOUR_OF_DAY) == 0
                && cal.get(Calendar.MINUTE) == 0
                && cal.get(Calendar.SECOND) == 0
                && cal.get(Calendar.MILLISECOND) == 0;
    }


    public static long getDaysBetween(long fromMillisecond, long toMillisecond) {
        return Duration.ofMillis(toMillisecond - fromMillisecond).toDays();
    }

    public static Calendar addDays(Date baseDate, int days) {
        Calendar timeTo = Calendar.getInstance(TIMEZONE_UTC);
        timeTo.setTime(baseDate);
        timeTo.add(Calendar.DATE, days);
        return timeTo;
    }

    public static Calendar addDays(Date baseDate, int days, TimeZone timeZone) {
        Calendar timeTo = Calendar.getInstance(timeZone);
        timeTo.setTime(baseDate);
        timeTo.add(Calendar.DATE, days);
        return timeTo;
    }

    public static LocalDate convertToLocalDate(Date dateToConvert) {
        return dateToConvert.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    /**
     * get diff of DateTime in days(>=0)
     *
     * @param start start of date time
     * @param end   end of date time
     * @return days from start to end. It must be >=0 days
     */
    public static int getDiffDateTimeInDays(DateTime start, DateTime end) {
        if (start != null && end != null && end.getValue().getTime() > start.getValue().getTime()) {
            return (int) ((end.getValue().getTime() - start.getValue().getTime())
                    / (1000 * 60 * 60 * 24));
        } else {
            return 0;
        }
    }

    public static XMLGregorianCalendar getLastModifiedTime(OrderCSXType order, ProformaOrderXType proformaOrder) {
        XMLGregorianCalendar calendar = null;
        if (order != null && order.getLastModifiedDate() != null) {
            // trading api use last modified date from checkoutBO -ebay checkout trans
            calendar = convertToXMLGregorianCalendar(order.getLastModifiedDate());
        } else if (proformaOrder != null && proformaOrder.getLastModifiedDate() != null) {
            // trading api use last modified date from checkoutBO -ebay checkout trans
            calendar = convertToXMLGregorianCalendar(proformaOrder.getLastModifiedDate());
        }
        return calendar;
    }

    public static XMLGregorianCalendar getXmlGregorianCalendar(Optional<LocalDateTime> localDateTime) {
        if (localDateTime.isPresent()) {
            ZoneId zoneId = ZoneId.of("UTC");
            GregorianCalendar gregorianCalendar = GregorianCalendar.from(localDateTime.get().atZone(zoneId));
            XMLGregorianCalendar xmlGregorianCalendar = null;
            try {
                xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
            } catch (DatatypeConfigurationException e) {
                CalLogger.warn("Unable to parse Listing Details end time", e.getMessage());
            }
            return xmlGregorianCalendar;
        }
        return null;
    }

    public static XMLGregorianCalendar convertToXMLGregorianCalendar(com.ebay.cos.type.v3.base.DateTime dateTime) {
        if (dateTime == null || dateTime.getValue() == null) {
            return null;
        }
        GregorianCalendar c = new GregorianCalendar(TimeZone.getTimeZone(UTC));
        c.setTime(dateTime.getValue());
        return DATATYPE_FACTORY.newXMLGregorianCalendar(c);
    }

    public static String convertToSimpleDateFormat(Date date) {
        if (date == null) {
            return null;
        }
        DateFormat dateFormat = new SimpleDateFormat(YYYY_MM_DD_DATE_FORMATTER);
        dateFormat.setTimeZone(TIMEZONE_UTC);
        return dateFormat.format(date);
    }
}
