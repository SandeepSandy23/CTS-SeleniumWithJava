package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.service.client.ApisellingioClient;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class ApisellingioServiceInvoker extends BaseServiceInvoker<String, String, String> {
    public static final String NAME = "ApisellingioServiceInvoker";
    private final int requestVersion;


    public ApisellingioServiceInvoker(TracerContext tracerContext, int requestVersion) {
        super( NAME, tracerContext);
        this.requestVersion = requestVersion;
    }

    @Override
    protected BaseGingerClient<String, String> getGingerClient(String s) {
        return new ApisellingioClient();
    }

    @Override
    protected GingerClientRequest<String> getGingerRequest(String apixoioRequest, HttpHeaders httpHeaders) {
        GingerClientRequest<String> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        updateRedirect(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(apixoioRequest);
        return gingerClientRequest;
    }

    private void updateRedirect(MultivaluedMap<String, Object> headers) {
        String opName = (String) headers.getFirst(ApiSellingExtSvcConstants.X_EBAY_SOA_OPERATION_NAME);
        String name = Character.toUpperCase(opName.charAt(0)) + opName.substring(1);
        headers.putSingle(ApiSellingExtSvcConstants.X_EBAY_SOA_OPERATION_NAME, name);
        String compatibilityLevel = (String) headers.getFirst(ApiSellingExtSvcConstants.X_EBAY_API_COMPATIBILITY_LEVEL);
        if (null == compatibilityLevel)
            headers.putSingle(ApiSellingExtSvcConstants.X_EBAY_API_COMPATIBILITY_LEVEL,requestVersion ) ;
        String callName = (String) headers.getFirst(ApiSellingExtSvcConstants.X_EBAY_API_CALL_NAME);
        if (null == callName)
            headers.putSingle(ApiSellingExtSvcConstants.X_EBAY_API_CALL_NAME,name) ;

    }
}
