package com.ebay.app.apisellingextsvc.service.client.model.UserReadClient;

import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Component
public class UserReadServiceClient extends BaseGingerClient<String, UserReadResponse> {

    private static Logger logger = LoggerFactory.getLogger(UserReadServiceClient.class);

    private static final String USERREAD_CLIENT = "identity.UserReadSvc";
    private static final String API_VERSION = "/v5";
    private static final String PATH = API_VERSION + "/query";

    public UserReadServiceClient() {
        super(UserReadResponse.class);
    }

    @Override
    public GingerClientResponse<UserReadResponse> getGingerResponse(GingerClientRequest<String> gingerClientRequest) {
        return processPostRequest(PATH, gingerClientRequest);
    }

    @Override
    public String getTargetBase() {
        return USERREAD_CLIENT;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
