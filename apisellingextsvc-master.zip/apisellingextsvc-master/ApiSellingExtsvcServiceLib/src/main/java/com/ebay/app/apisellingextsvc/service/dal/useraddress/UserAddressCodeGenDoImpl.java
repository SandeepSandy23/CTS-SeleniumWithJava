package com.ebay.app.apisellingextsvc.service.dal.useraddress;

import com.ebay.af.common.flag.FlagMask;
import com.ebay.integ.dal.BaseDo3;
import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.dal.map.GenericMap;
import com.ebay.persistence.DALVersion;

@DALVersion("3.0")
@SuppressWarnings({"PMD", "FindBugs"})
public class UserAddressCodeGenDoImpl extends BaseDo3 implements UserAddress {

    public static final int ID = 1;
    public static final int USERID = 2;
    public static final int FLAGS = 17;
    public static final int NUM_FIELDS = 28;

    public long m_id;
    public long m_flags;
    public long m_userId;

    public UserAddressCodeGenDoImpl() {
        super(UserAddressDAO.getInstance(), GenericMap.getInitializedMap(UserAddress.class));
    }

    public UserAddressCodeGenDoImpl(BaseDao2 dao, BaseMap2 map) {
        super(dao, map);
    }

    @Override
    protected long getDataValue(FlagMask flagMask) {
        return m_flags;
    }

    @Override
    public long getId() {
        loadValue(ID);
        return m_id;
    }

    @Override
    public void setId(long id) {
        this.m_id = id;
        setDirty(ID);
    }

    @Override
    public long getUserId() {
        loadValue(USERID);
        return m_userId;
    }

    @Override
    public void setUserId(long userId) {
        this.m_userId = userId;
        setDirty(USERID);
    }

    @Override
    public long getFlags() {
        loadValue(FLAGS);
        return m_flags;
    }

    @Override
    public void setFlags(long flags) {
        this.m_flags = flags;
        setDirty(FLAGS);
    }

    @Override
    public int getNumFields() {
        return NUM_FIELDS;
    }
}
