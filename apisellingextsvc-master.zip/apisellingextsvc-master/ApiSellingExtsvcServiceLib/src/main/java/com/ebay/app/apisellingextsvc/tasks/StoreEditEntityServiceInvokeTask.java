package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.service.client.model.StoreEditEntityClient.StoreEditEntityResponse;
import com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.UserReadResponse;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.app.apisellingextsvc.utils.UserUtil;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;

import javax.ws.rs.core.HttpHeaders;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class StoreEditEntityServiceInvokeTask implements Task<StoreEditEntityResponse>, ITaskResultInjectable {
    private Map<String, Object> resultMap = new HashMap<>();
    private final String STORE_OWNER = "IS_OWNS_STORE";
    private final IServiceInvoker<String, StoreEditEntityResponse> storeEditEntityServiceInvoker;
    private final List<ErrorType> errorList;
    private final HttpHeaders headers;
    private final User user;

    public StoreEditEntityServiceInvokeTask(
            IServiceInvoker<String, StoreEditEntityResponse> storeEditEntityServiceInvoker,
            List<ErrorType> errorList, HttpHeaders headers, User user) {
        this.storeEditEntityServiceInvoker = storeEditEntityServiceInvoker;
        this.errorList = errorList;
        this.headers = headers;
        this.user = user;
    }


    @Override
    public StoreEditEntityResponse call() throws Exception {
        UserReadResponse userReadResponse = (UserReadResponse) resultMap.get(UserReadResponse.class.getName());
        if (isStoreUser(userReadResponse)) {
            headers.getRequestHeaders().putSingle(ApiSellingExtSvcConstants.X_EBAY_C_ENDUSERCTX, HeaderUtil.getEndUserCtx(user.getUserName(), user.getUserId()));
            return this.storeEditEntityServiceInvoker.getResponse("", headers);
        }
        return new StoreEditEntityResponse();
    }

    private boolean isStoreUser(UserReadResponse userReadResponse) {
        return Optional.ofNullable(userReadResponse).map(UserReadResponse::getData)
                .map(com.ebay.app.apisellingextsvc.service.client.model.UserReadClient.User::getUser)
                .flatMap(userInfos -> (userInfos.stream().findFirst()))
                .map(userInfo -> UserUtil.getValueFromExtensions(userInfo, STORE_OWNER))
                .map(Boolean::valueOf)
                .orElse(Boolean.FALSE);
    }

    @Override
    public void addResult(Object result) {
       if (Objects.nonNull(result)) resultMap.put(result.getClass().getName(), result);
    }
}
