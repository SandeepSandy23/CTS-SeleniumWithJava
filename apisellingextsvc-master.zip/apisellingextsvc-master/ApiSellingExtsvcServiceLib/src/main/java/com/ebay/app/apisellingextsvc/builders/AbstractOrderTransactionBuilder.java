package com.ebay.app.apisellingextsvc.builders;


import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.constant.VersionConstant;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.app.apisellingextsvc.utils.SiteUtils;
import com.ebay.cosmos.LineItemLevelFlags;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.DateTime;
import com.ebay.order.common.v1.LogisticsPlan;
import com.ebay.order.common.v1.LogisticsStep;
import com.ebay.order.common.v1.LogisticsStepTypeEnumType;
import com.ebay.order.common.v1.ProgramEnumType;
import com.ebay.order.common.v1.ProgramType;
import com.ebay.order.common.v1.ShippingStepExtension;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.SiteCodeType;
import ebay.apis.eblbasecomponents.TransactionPlatformCodeType;
import ebay.apis.eblbasecomponents.TransactionType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nullable;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Base order transaction builder
 */
public abstract class AbstractOrderTransactionBuilder extends BaseFacetBuilder<TransactionType> {

    protected final int trxVersion;

    public AbstractOrderTransactionBuilder(Task<?> task,
                                           int trxVersion) {
        super(task);
        this.trxVersion = trxVersion;
    }

    @Override
    protected TransactionType doBuild() {
        TransactionType transaction = new TransactionType();
        transaction.setPlatform(getPlatform());
        return transaction;
    }

    @Nullable
    protected Boolean isGuaranteedShipping() {
        // https://developer.ebay.com/devzone/xml/Docs/Reference/ebay/types/TransactionType.html#GuaranteedDelivery
        // Note: This field is for future use, as the eBay Guaranteed Shipping feature has been put on hold. eBay Guaranteed Shipping should not be
        // confused with eBay Guaranteed Delivery, which is a completely different feature.
        // This field is returned as true if the seller chose to use eBay's Guaranteed Shipping feature at listing time. With eBay's Guaranteed
        // Shipping, the seller will never pay more for shipping than what is charged to the buyer. eBay recommends the shipping service option for
        // the seller to use based on the dimensions and weight of the shipping package.
        // TransactionGuaranteedShippingDataRetriever.retrieve
        if (VersionConstant.isGreaterEqualThan(trxVersion, VersionConstant.VERSION_GUARANTEED_SHIPPING)) {
            return false;
        }
        return null;
    }

    @Nullable
    protected Boolean isGuaranteedDelivery(LineItemLevelFlags lineItemLevelFlags) {
        if (VersionConstant.isGreaterEqualThan(trxVersion, VersionConstant.VERSION_GUARANTEED_DELIVERY)) {
            return Optional.of(lineItemLevelFlags).map(LineItemLevelFlags::getIsGuaranteedDelivery)
                    .orElse(false);
        }
        return null;
    }

    protected SiteCodeType getTransactionSiteId(List<Attribute> attributes, String attrName) {
        return AttributeUtil.findAttribute(attributes, attrName)
                .map(attribute -> SiteUtils.getSiteCode(attribute.getValue())).orElse(null);
    }

    protected boolean isEbayPlusTransaction(List<ProgramType> programTypes) {
        return programTypes.stream()
                .filter(Objects::nonNull)
                .anyMatch(a -> ProgramEnumType.EBAY_PLUS.name().equals(a.getName()));
    }

    protected TransactionPlatformCodeType getPlatform() {
        //https://developer.ebay.com/devzone/xml/Docs/Reference/ebay/types/TransactionType.html#Platform
        //Note: Currently, the only value that should be returned in this field is eBay, as the Half.com marketplace no longer exists.
        return TransactionPlatformCodeType.E_BAY;
    }

    protected XMLGregorianCalendar getCreatedDate(DateTime orderCreatedDate, List<Attribute> attributes) {
        return AttributeUtil.findAttribute(attributes, ApiSellingExtSvcConstants.ATTR_COMS_COMMITMENT_TIME)
                .map(Attribute::getValue)
                .map(DateUtil::convertToXMLGregorianCalendar)
                .orElse(DateUtil.convertToXMLGregorianCalendar(orderCreatedDate));
    }

    public static boolean getBestOfferStatus(List<Attribute> attributes) {
        return Optional.of(attributes)
                .map(attribute -> AttributeUtil.findAttributes(attributes, ApiSellingExtSvcConstants.ATTR_BEST_OFFER_ID))
                .map(Attribute::getValue)
                .map(StringUtils::isNotEmpty).orElse(false);
    }

    public static boolean isMultiLegShipping(List<? extends LogisticsPlan> logistics) {
        //If isIntermediated field is true then it should be multileg shipping

        return Optional.ofNullable(logistics)
                .flatMap(logisticsPlans -> logisticsPlans.stream().findFirst())
                .map(LogisticsPlan::getSteps).filter(CollectionUtils::isNotEmpty)
                .flatMap(steps -> steps.stream().filter(step -> step.getStepType() == LogisticsStepTypeEnumType.SHIPPING)
                        .findFirst())
                .map(LogisticsStep::getStepExtension)
                .map(LogisticsStep.StepExtension::getShippingStep).map(ShippingStepExtension::isIsIntermediated)
                .orElse(false);
    }
}
