package com.ebay.app.apisellingextsvc.test;

import java.util.List;

public class MultiValuedParam {
    private String name;
    private List<String> value;

    public MultiValuedParam() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getValue() {
        return this.value;
    }

    public void setValue(List<String> value) {
        this.value = value;
    }
}
