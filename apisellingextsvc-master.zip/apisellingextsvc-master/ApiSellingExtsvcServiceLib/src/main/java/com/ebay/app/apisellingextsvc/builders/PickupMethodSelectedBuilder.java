package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.mappers.PickupMethodMapper;
import com.ebay.app.apisellingextsvc.mappers.PickupStatusMapper;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.DateUtil;
import com.ebay.cos.raptor.service.annotations.Api;
import com.ebay.order.common.v1.*;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.PickupMethodSelectedType;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class PickupMethodSelectedBuilder extends BaseFacetBuilder<PickupMethodSelectedType> {
    final List<LogisticsPlan> logisticsList;

    public PickupMethodSelectedBuilder(Task<?> task, List<LogisticsPlan> logisticsList) {
        super(task);
        this.logisticsList = logisticsList;
    }


    @Override
    protected PickupMethodSelectedType doBuild() {

        Optional<LogisticsPlan> shippingPickUpPlan = getLogisticsPlan(LogisticsPlanType.SHIPPING_PICKUP);
        Optional<LogisticsPlan> storePicksUpPlan = getLogisticsPlan(LogisticsPlanType.STORE_PICKUP);
        Optional<LogisticsPlan> logisticsPlan = shippingPickUpPlan.isPresent() ? shippingPickUpPlan : storePicksUpPlan;

        LogisticsPlanType logisticsPlanType = logisticsPlan.map(LogisticsPlan::getPlanType).orElse(null);
        return logisticsPlan.map(LogisticsPlan::getSteps)
                .flatMap(logisticsStep -> logisticsStep.stream()
                        .filter(step -> LogisticsStepTypeEnumType.BUYER_PICKUP == step.getStepType()).findFirst())
                .map(LogisticsStep::getStepExtension)
                .map(LogisticsStep.StepExtension::getPickupStep)
                .map(pickupStep -> getPickupMethodSelectedType(logisticsPlanType, pickupStep, shippingPickUpPlan.isPresent()))
                .orElse(null);
    }

    private Optional<LogisticsPlan> getLogisticsPlan(LogisticsPlanType logisticsPlanType) {
        return Optional.ofNullable(logisticsList)
                .flatMap(logistics -> logistics.stream()
                        .filter(logisticsPlan -> logisticsPlanType == logisticsPlan.getPlanType())
                        .findFirst());
    }

    private PickupMethodSelectedType getPickupMethodSelectedType(LogisticsPlanType logisticsPlanType,
                                                                 PickupStepExtension pickupStep,
                                                                 boolean isShippingPickUp) {
        PickupMethodSelectedType pickup = new PickupMethodSelectedType();
        pickup.setPickupMethod(PickupMethodMapper.map(logisticsPlanType));

        if (!isShippingPickUp) {
            pickup.setMerchantPickupCode(pickupStep.getPickupCode().getValue());
        }

        pickup.setPickupLocationUUID(AttributeUtil.findAttributeValue(pickupStep.getAttributes(), ApiSellingExtSvcConstants.PICKUP_ATTR_LOCATION_UUID));
        pickup.setPickupStoreID(AttributeUtil.findAttributeValue(pickupStep.getAttributes(), ApiSellingExtSvcConstants.PICKUP_ATTR_STORE_ID));
        pickup.setPickupFulfillmentTime(DateUtil.convertToXMLGregorianCalendar(pickupStep.getPickupEstimates().getTimeEstimate().getMinDate()));
        pickup.setPickupStatus(
                Optional.ofNullable(pickupStep.getPackage()).flatMap(packages -> packages.stream().filter(
                                pac -> Objects.nonNull(pac) && Objects.nonNull(pac.getPackageExtn())
                                        && Objects.nonNull(pac.getPackageExtn().getPickupPackageExtn().getPickupStatus())).findFirst())
                        .map(PackageType::getPackageExtn)
                        .map(PackageType.PackageExtn::getPickupPackageExtn)
                        .map(PackageType.PackageExtn.PickupPackageExtn::getPickupStatus)
                        .map(PickupStatusMapper::map).orElse(null));
        return pickup;
    }
}
