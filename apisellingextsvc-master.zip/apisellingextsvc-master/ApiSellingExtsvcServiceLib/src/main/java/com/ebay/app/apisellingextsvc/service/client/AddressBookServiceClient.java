package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.tide.app.addressbook.request.BulkGetAddressRequest;
import com.ebay.tide.app.addressbook.response.BulkGetAddressResponse;
import com.google.common.collect.ImmutableList;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AddressBookServiceClient extends BaseGingerClient<BulkGetAddressRequest, BulkGetAddressResponse> {

    private static final Logger logger = LoggerFactory.getLogger(AddressBookServiceClient.class);

    //https://wiki.corp.ebay.com/display/IP/Bulk+Get+Address
    private static final String CLIENT_ID = "adrbksvc";

    private static final String ABS_BULK_GET_ADDRESS_URI = "/identity/address_book/v1/address/bulk_get_address";

    ImmutableList<Pair<String, Object>> queryParam = ImmutableList.of(
          ImmutablePair.of("fieldgroups", "FULL"));

    public AddressBookServiceClient() {
        super(BulkGetAddressResponse.class);
    }

    @Override
    public GingerClientResponse<BulkGetAddressResponse> getGingerResponse(GingerClientRequest<BulkGetAddressRequest> gingerRequest) {
        return processPostRequest(ABS_BULK_GET_ADDRESS_URI, gingerRequest.getHeaders(), queryParam, gingerRequest);
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
