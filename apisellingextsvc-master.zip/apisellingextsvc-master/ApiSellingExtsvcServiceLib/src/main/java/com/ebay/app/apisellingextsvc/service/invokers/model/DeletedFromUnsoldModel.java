package com.ebay.app.apisellingextsvc.service.invokers.model;

import ebay.apis.eblbasecomponents.PaginatedItemArrayType;

public class DeletedFromUnsoldModel extends ResponseModel {
    public DeletedFromUnsoldModel(PaginatedItemArrayType deletedUnsoldList) {
        super(deletedUnsoldList);
    }
}
