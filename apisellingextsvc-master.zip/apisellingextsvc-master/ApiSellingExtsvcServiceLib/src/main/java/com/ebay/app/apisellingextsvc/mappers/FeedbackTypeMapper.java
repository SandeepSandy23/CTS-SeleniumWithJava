package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.cosmos.typeenum.FeedbackTypeEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.CommentTypeCodeType;

public class FeedbackTypeMapper {
    private static final ImmutableMap<FeedbackTypeEnum, CommentTypeCodeType> mapName
            = new ImmutableMap.Builder<FeedbackTypeEnum, CommentTypeCodeType>()
            .put(FeedbackTypeEnum.FEEDBACK_POSITIVE, CommentTypeCodeType.POSITIVE)
            .put(FeedbackTypeEnum.FEEDBACK_NEGATIVE, CommentTypeCodeType.NEGATIVE)
            .put(FeedbackTypeEnum.FEEDBACK_NEUTRAL, CommentTypeCodeType.NEUTRAL)
            .put(FeedbackTypeEnum.FEEDBACK_DELETED, CommentTypeCodeType.WITHDRAWN)
            .put(FeedbackTypeEnum.FEEDBACK_UNKNOWN, CommentTypeCodeType.POSITIVE) // Current Prod is assuming Positive when Unknown
            .build();

    private FeedbackTypeMapper() {
    }

    public static CommentTypeCodeType map(FeedbackTypeEnum feedbackTypeEnum) {
        return mapName.getOrDefault(feedbackTypeEnum, CommentTypeCodeType.CUSTOM_CODE);
    }
}
