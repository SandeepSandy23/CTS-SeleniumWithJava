package com.ebay.app.apisellingextsvc.service.dal.saleaggregator;

import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.ToupleProviderRegistry;
import com.ebay.integ.dal.map.*;
import com.ebay.persistence.DALVersion;
import com.google.gson.Gson;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.service.dal.common.ReadSets;
import com.ebay.app.apisellingextsvc.service.dal.itemhost.ItemHostToupleProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@DALVersion("3.0")
public class SaleAggregatorDAO extends BaseDao2 {
    private static final String FIND_BY_PK = BaseMap2.PRIMARYKEYLOOKUP;
    private static final String FIND_BY_ITEM_IDS_IN = "FIND_BY_ITEM_IDS_IN";
    private static SaleAggregatorDAO instance = new SaleAggregatorDAO();
    private static final String EBAY_ITEMS = "EBAY_ITEMS";

    private static MappingIncludesAttribute[] ourDDRHints;

    private static final String ITEMID_FIELD = "m_itemId";

    private static final String HOSTID_FIELD = "m_hostId";

    public static SaleAggregatorDAO getInstance() {
        return instance;
    }


    public SaleAggregator findByPrimaryKey(long itemId, long sellerId) throws FinderException {
        SaleAggregatorCodeGenDoImpl protoDO = new SaleAggregatorCodeGenDoImpl();
        protoDO.setItemId(itemId);
        protoDO.setSellerId(sellerId);
        QueryEngine qe = new QueryEngine();
        protoDO.setLocalOnly(true);
        return (SaleAggregator) qe.readSingle(protoDO.getMap(), protoDO, FIND_BY_PK, ReadSets.FULL.getValue());
    }

    public List<SaleAggregator> findBySellerAndItemIds(List<Long> draftsIds, long sellerId)
            throws FinderException {

        final QueryEngine qe = new QueryEngine();
        List<SaleAggregatorCodeGenDoImpl> protoDos = new ArrayList<>(draftsIds.size());
        SaleAggregatorCodeGenDoImpl protoDo = null;
        for (int i = 0; i < draftsIds.size(); i++) {
            protoDo = new SaleAggregatorCodeGenDoImpl();
            protoDo.setItemId(draftsIds.get(i));
            protoDo.setSellerId(sellerId);
            protoDos.add(protoDo);
        }
        List result = new ArrayList();
        qe.readMultiple(result, protoDo.getMap(), protoDos,
                FIND_BY_ITEM_IDS_IN, ReadSets.FULL.getValue(),
                null, ourDDRHints);
        CalLogger.info("SaleAggregator", "findBySellerAndItemIds itemIds:" + new Gson().toJson(draftsIds) +
                " sellerId:" + sellerId + " result:" + new Gson().toJson(result));
        return result;

    }

    public void initMap() {

        GenericMap<SaleAggregator> map = GenericMap.getMap(SaleAggregator.class);
        map = Optional.ofNullable(map).orElse(new GenericMap<>(SaleAggregator.class));
        map.setDalVersion("3.0");

        ItemHostToupleProvider itemHostToupleProvider = new ItemHostToupleProvider(EBAY_ITEMS, ITEMID_FIELD, HOSTID_FIELD, false);
        ToupleProviderRegistry.getInstance().registerToupleProvider(EBAY_ITEMS, itemHostToupleProvider);

        initHintGroups(map);
        map.setQueries(getRawQueries(map));
        map.setReadSets(getReadSets(map));
        map.init();
    }

    public static void initHintGroups(@SuppressWarnings("unused") GenericMap<SaleAggregator> map) {
        ourDDRHints = new MappingIncludesAttribute[]{map.getLocalFieldMapping(SaleAggregatorCodeGenDoImpl.ITEMID),
                map.getLocalFieldMapping(SaleAggregatorCodeGenDoImpl.SELLERID)};
    }

    public static ReadSet[] getReadSets(@SuppressWarnings("unused") GenericMap<SaleAggregator> map) {
        return new ReadSet[]{new ReadSet(ReadSets.FULL.getValue(), null)};
    }

    private Query[] getRawQueries(@SuppressWarnings("unused") GenericMap<SaleAggregator> map) {
        return new Query[]{
                new SelectQuery(
                        FIND_BY_PK,
                        ourDDRHints,
                        new SelectStatement[]{new SelectStatement(
                                ReadSets.FULL.getValue(),
                                "SELECT  /*+  index(i)  index(d) */ /*<CALCOMMENT/>*/ <SELECTFIELDS/> " +
                                        "FROM <TABLES/> " +
                                        "WHERE e.id=:m_itemId and e.marketplace=0")}),
                new SelectQuery(
                        FIND_BY_ITEM_IDS_IN,
                        ourDDRHints,
                        new SelectStatement[]{new SelectStatement(
                                ReadSets.FULL.getValue(),
                                "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> " +
                                        "FROM <TABLES/> " +
                                        "WHERE e.seller = :m_sellerId " +
                                        "AND e.id IN <IN>:m_itemId</IN> " +
                                        "AND (<JOIN/>)")},
                        BaseMap2.USE_DEFAULT_FETCHSET_SIZE,
                        new SelectSetParms(50, 50, 500, new SaleAggregatorCodeGenDoImpl()) {
                        })
        };
    }
}
