package com.ebay.app.apisellingextsvc.builders;

import com.ebay.cos.type.v3.base.CurrencyCodeEnum;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.order.common.base.Amount;
import com.ebay.raptor.orchestrationv2.task.Task;
import com.google.common.collect.ImmutableSet;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.utils.AdjustmentHelper;
import com.ebay.app.apisellingextsvc.utils.AmountTypeUtil;
import com.ebay.app.apisellingextsvc.utils.PaymentUtil;
import ebay.apis.eblbasecomponents.AmountType;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.Set;

public class OrderAdjustmentAmountBuilder extends BaseFacetBuilder<AmountType> {

    private static final Set<String> SELLER_VIEW_EXCEPT = ImmutableSet.of(
            ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_TAX_PARTNER, ApiSellingExtSvcConstants.DISTRIBUTION_TYPE_AU_TAX_PARTNER);
    private final OrderCSXType order;


    public OrderAdjustmentAmountBuilder(Task task,
                                        @Nonnull OrderCSXType order) {
        super(task);
        this.order = order;
    }

    @Override
    protected AmountType doBuild() {

        if (!PaymentUtil.hasRefund(order)) {
            return AmountTypeUtil.getDefaultZeroAmountType(order);
        }

        Amount refundUnitRate = AdjustmentHelper.getRefundUnitRate(order);
        BigDecimal amount =
                AdjustmentHelper.sumRefundExcept(order.getAdjustmentsCS(), SELLER_VIEW_EXCEPT );
        CurrencyCodeEnum currency = refundUnitRate.getCurrency();
        return AmountTypeUtil.getAmountType(currency.name(), -amount.doubleValue());
    }

}