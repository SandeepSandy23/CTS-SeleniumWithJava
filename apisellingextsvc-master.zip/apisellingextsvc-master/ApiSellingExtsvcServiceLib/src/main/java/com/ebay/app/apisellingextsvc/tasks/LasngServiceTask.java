package com.ebay.app.apisellingextsvc.tasks;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.User;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.model.ListingActivitiesByIdsModel;
import com.ebay.app.apisellingextsvc.utils.HeaderUtil;
import com.ebay.app.apisellingextsvc.utils.ListingsActivityServiceUtil;
import com.ebay.cosmos.ContractResponse;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.cosmos.LineItemXType;
import com.ebay.cosmos.OrderCSXType;
import com.ebay.cosmos.ProformaOrderLineItemXType;
import com.ebay.cosmos.ProformaOrderXType;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsRequest;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsResponse;
import com.ebay.lib.lasng.model.ListingActivity;
import com.ebay.order.common.v1.LineItemSource;
import com.ebay.raptor.orchestrationv2.task.ITaskResultInjectable;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.ErrorType;
import org.springframework.util.CollectionUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <pre>
 * <a href="https://github.corp.ebay.com/Selling/lasng/blob/master/lasngService/src/main/resources/api/openapi.yaml">Selling lasng</a>
 * POST https://lasng.vip.qa.ebay.com/lasngsvc/v1/listing_activity/get_by_ids
 * Headers
 * 1. Authorization
 * 2. X-EBAY-C-ENDUSERCTX
 *
 * if user ctx is buyer, return 400
 * </pre>
 */
public class LasngServiceTask implements Task<ListingActivitiesByIdsModel>, ITaskResultInjectable {

    private Map<String, Object> resultMap = new HashMap<>();
    private final GetListingActivitiesByIdsRequest getListingActivitiesByIdsRequest;
    private final User user;
    private final IServiceInvoker<GetListingActivitiesByIdsRequest, GetListingActivitiesByIdsResponse> lasngServiceInvoker;
    private final List<ErrorType> errorList;
    private final HttpHeaders requestHeaders;

    public LasngServiceTask(
            IServiceInvoker<GetListingActivitiesByIdsRequest, GetListingActivitiesByIdsResponse> lasngServiceInvoker,
            List<ErrorType> errorList,
            HttpHeaders headers,
            GetListingActivitiesByIdsRequest getListingActivitiesByIdsRequest,
            User user) {
        this.lasngServiceInvoker = lasngServiceInvoker;
        this.getListingActivitiesByIdsRequest = getListingActivitiesByIdsRequest;
        this.errorList = errorList;
        this.user = user;
        this.requestHeaders = headers;
    }

    @Override
    public ListingActivitiesByIdsModel call() {
        ContractResponse contractResponse = (ContractResponse) resultMap.get(ContractResponse.class.getName());
        List<ContractResponseType> contractResponseTypeList = Optional.ofNullable(contractResponse)
                .map(ContractResponse::getMembers)
                .orElse(Collections.emptyList());
        if (CollectionUtils.isEmpty(contractResponseTypeList)) {
            return new ListingActivitiesByIdsModel(Collections.emptyMap());
        }
        GetListingActivitiesByIdsResponse getListingActivitiesByIdsResponse = this.lasngServiceInvoker.getResponse(buildGetListingActivitiesByIdsRequest(contractResponse),
                ListingsActivityServiceUtil.buildLASHeaders(requestHeaders, user.getUserName(), user.getUserId()));
        HashMap<Long, ListingActivity> itemIdListingActivityMap = new HashMap<>();
        if (getListingActivitiesByIdsResponse != null) {
            for (ListingActivity listingActivity : getListingActivitiesByIdsResponse.getMembers()) {
                itemIdListingActivityMap.put(listingActivity.getListingId(), listingActivity);
            }
        }
        return new ListingActivitiesByIdsModel(itemIdListingActivityMap);
    }

    private GetListingActivitiesByIdsRequest buildGetListingActivitiesByIdsRequest(ContractResponse contractResponse) {
        GetListingActivitiesByIdsRequest getListingActivitiesByIdsRequest = new GetListingActivitiesByIdsRequest();
        getListingActivitiesByIdsRequest.setListingIds(getItemsList(contractResponse));
        return getListingActivitiesByIdsRequest;
    }

    protected static List<String> getItemsList(ContractResponse contractResponse) {
        List<ContractResponseType> contractResponseTypeList = Optional.ofNullable(contractResponse).map(ContractResponse::getMembers)
                .orElse(Collections.emptyList());
        Set<String> itemsIdSet = new HashSet<>();
        for (ContractResponseType contractResponseType : contractResponseTypeList) {
            if (Optional.ofNullable(contractResponseType).map(ContractResponseType::getOrder).isPresent()) {
                itemsIdSet.addAll(Optional.of(contractResponseType.getOrder())
                        .map(OrderCSXType::getLineItemTypes).orElse(Collections.emptyList()).stream()
                        .map(LineItemXType::getSourceId).map(LineItemSource::getItemId)
                        .filter(Objects::nonNull).collect(Collectors.toSet()));

            } else if (Optional.ofNullable(contractResponseType).map(ContractResponseType::getProformaOrder).isPresent()) {
                itemsIdSet.addAll(Optional.of(contractResponseType.getProformaOrder())
                        .map(ProformaOrderXType::getLineItemTypes)
                        .orElse(Collections.emptyList()).stream()
                        .map(ProformaOrderLineItemXType::getSourceId).map(LineItemSource::getItemId)
                        .filter(Objects::nonNull).collect(Collectors.toSet()));
            }
        }
        return new ArrayList<>(itemsIdSet);
    }

    @Override
    public void addResult(Object result) {
        if(Objects.nonNull(result))  resultMap.put(result.getClass().getName(), result);
    }
}
