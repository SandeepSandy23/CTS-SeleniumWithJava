package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.application.common.request.GetSellerTransactionsRequest;
import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.exception.ApplicationException;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.bof.saleaggregator.SaleAggregatorBofImpl;
import com.ebay.app.apisellingextsvc.service.bof.sellerpref.SellerPrefBofImpl;
import com.ebay.app.apisellingextsvc.service.bof.taxrate.TaxRateBofImpl;
import com.ebay.app.apisellingextsvc.service.invokers.AddressBookServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.BulkUserReadServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.CosmosServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.FeedBackServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.GSTLasngServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.SVLSServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.StoreEditEntityServiceInvoker;
import com.ebay.app.apisellingextsvc.service.invokers.UserReadServiceInvoker;
import com.ebay.app.apisellingextsvc.tasks.BuildGetSellerTransactionsArrayTask;
import com.ebay.app.apisellingextsvc.tasks.BuildGetSellerTransactionsResponseTask;
import com.ebay.app.apisellingextsvc.tasks.BulkUserReadServiceInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.FeedBackServiceInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.GSTLasngServiceTask;
import com.ebay.app.apisellingextsvc.tasks.LoadGetSellerTransactionsDataTask;
import com.ebay.app.apisellingextsvc.tasks.LoadSellerPrefTask;
import com.ebay.app.apisellingextsvc.tasks.LoadSellerProdIdTask;
import com.ebay.app.apisellingextsvc.tasks.LoadUserAddressTask;
import com.ebay.app.apisellingextsvc.tasks.OutputSelectorTask;
import com.ebay.app.apisellingextsvc.tasks.SVLSInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.StoreEditEntityServiceInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.UserReadServiceInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.cosmos.CosmosInvokeTask;
import com.ebay.app.apisellingextsvc.tasks.cosmos.CosmosRequestTask;
import com.ebay.app.apisellingextsvc.tasks.filter.BasicRequestValidatorFilter;
import com.ebay.app.apisellingextsvc.tasks.filter.GetSellerTransactionsRequestFilter;
import com.ebay.app.apisellingextsvc.tasks.filter.IFilter;
import com.ebay.app.apisellingextsvc.utils.TaskOrchestrationUtil;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsRequest;
import com.ebay.raptor.orchestrationv2.task.TaskConfiguration;
import ebay.apis.eblbasecomponents.AckCodeType;
import ebay.apis.eblbasecomponents.ErrorType;
import io.opentelemetry.context.Scope;
import org.apache.commons.lang3.BooleanUtils;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Main handler class for orchestrating the service calls and building response
 */
public class GetSellerTransactionsHandler extends ApiSellingExtApplicationHandler<GetSellerTransactionsResponse> {

    private final GetSellerTransactionsRequest request;

    private Executor executor;

    public GetSellerTransactionsHandler(GetSellerTransactionsRequest request, Executor executor) {
        super(request.getHeaders());
        this.request = request;
        this.executor = executor;
    }

    public static GetSellerTransactionsResponse getResponse(GetSellerTransactionsRequest request, Executor executor) {
        GetSellerTransactionsHandler getSellerTransactionHandler =
                new GetSellerTransactionsHandler(request,executor);

        GetSellerTransactionsAuditHandler auditHandler = null;
        if (request.configValues.auditEnabled) {
            auditHandler = new  GetSellerTransactionsAuditHandler(request);
        }

        ApiSellingExtApplicationProcessor<GetSellerTransactionsResponse> apiSellingExtApplicationProcessor =
                new ApiSellingExtApplicationProcessor<GetSellerTransactionsResponse>(
                        request,
                        getSellerTransactionHandler,
                        auditHandler,
                        getFilters(request)
                );
        return apiSellingExtApplicationProcessor.handle().response;
    }

    private static List<IFilter> getFilters(GetSellerTransactionsRequest request) {
        return Arrays.asList(
                new BasicRequestValidatorFilter(request, request.contentResource, request.requestType.getErrorLanguage(), request.getConfigValues()),
                new GetSellerTransactionsRequestFilter(request.requestType, request.contentResource)
        );
    }

    @Override
    public GetSellerTransactionsResponse handle() {

        try (Scope scope = getOpenTeleSpan(); io.opentracing.Scope tracerScope = createTracerSpan()) {

            GetListingActivitiesByIdsRequest getListingActivitiesByIdsRequest = new GetListingActivitiesByIdsRequest();

            CosmosRequestTask cosmosRequestTask = new CosmosRequestTask(request.requestType, request.getHeaders(), this.request.getUser(), this.request.getConfigValues());
            CosmosInvokeTask cosmosInvokeTask = new CosmosInvokeTask(new CosmosServiceInvoker(this.request.getTracerContext()), request.getErrorList());
            UserReadServiceInvokeTask userReadServiceInvokeTask = new UserReadServiceInvokeTask(new UserReadServiceInvoker(this.request.getTracerContext()), request.getErrorList(), this.request.getHeaders(), this.request.getUser().getUserId(), this.request.contentResource);
            StoreEditEntityServiceInvokeTask storeEditEntityServiceInvokeTask = new StoreEditEntityServiceInvokeTask(new StoreEditEntityServiceInvoker(this.request.getTracerContext()),
                    request.getErrorList(), this.request.getHeaders(), this.request.getUser());
            GSTLasngServiceTask gstLasngServiceTask = new GSTLasngServiceTask(new GSTLasngServiceInvoker(this.request.getTracerContext()),request.getErrorList(),
                    this.request.getHeaders(),this.request.getUser());
            BulkUserReadServiceInvokeTask bulkUserReadServiceInvokeTask = new BulkUserReadServiceInvokeTask(new BulkUserReadServiceInvoker(this.request.getTracerContext()),
                    request.getErrorList(), this.request.getHeaders(), this.request.getConfigValues(), executor, false);
            //Todo: remove this line after test is done
            SVLSInvokeTask svlsInvokeTask = new SVLSInvokeTask(new SVLSServiceInvoker(this.request.getTracerContext()),
                    request.getErrorList(), this.request.getHeaders(), this.request.getConfigValues(), executor);


            LoadGetSellerTransactionsDataTask loadGetSellerTransactionDataTask = new LoadGetSellerTransactionsDataTask();
            FeedBackServiceInvokeTask feedBackServiceInvokeTask = new FeedBackServiceInvokeTask(new FeedBackServiceInvoker(this.request.getTracerContext()),this.request.getUser().getUserId(),
                    this.request.getErrorList(),this.request.getHeaders(),this.request.getConfigValues(),executor);
            fetchGetSellerTransactionsDataContext(this.request.getTracerContext(), cosmosInvokeTask, loadGetSellerTransactionDataTask);

            BuildGetSellerTransactionsArrayTask transactionArrayTask = new BuildGetSellerTransactionsArrayTask(request.trxVersion, request.getConfigValues(),
                                request.requestType.getDetailLevel(), new TaxRateBofImpl(), request.siteContext, this.request.contentResource, new SaleAggregatorBofImpl(),
                                BooleanUtils.isTrue(request.requestType.isIncludeFinalValueFee()), BooleanUtils.isTrue(request.requestType.isIncludeContainingOrder()));

            BuildGetSellerTransactionsResponseTask buildGetSellerTransactionResponseTask = new BuildGetSellerTransactionsResponseTask(request.getErrorList(),
                                                        request.siteContext, this.request.getUser(), request.trxVersion,request.getConfigValues(),
                                                        this.request.contentResource, this.request.getRequestType());

            TaskConfiguration storeUserReadConfig = TaskOrchestrationUtil.createTaskConfiguration(userReadServiceInvokeTask);
            TaskConfiguration cosmosInvokeConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosRequestTask);
            TaskConfiguration gstlasngConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask);
            TaskConfiguration bulkuserReadConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask);
            TaskConfiguration feedBackConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask);
            TaskConfiguration transactionArrayConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask, bulkUserReadServiceInvokeTask,loadGetSellerTransactionDataTask, gstLasngServiceTask,
                                                                                                    feedBackServiceInvokeTask);
            TaskConfiguration transactionResponseTaskConfig = TaskOrchestrationUtil.createTaskConfiguration(cosmosInvokeTask,transactionArrayTask,userReadServiceInvokeTask,storeEditEntityServiceInvokeTask,
                                                                loadGetSellerTransactionDataTask, feedBackServiceInvokeTask);

            request.orchestrator.execute(userReadServiceInvokeTask);
            request.orchestrator.execute(storeEditEntityServiceInvokeTask, storeUserReadConfig);
            request.orchestrator.execute(cosmosRequestTask);
            request.orchestrator.execute(cosmosInvokeTask, cosmosInvokeConfig);
            request.orchestrator.execute(gstLasngServiceTask, gstlasngConfig);
            request.orchestrator.execute(bulkUserReadServiceInvokeTask, bulkuserReadConfig);
            request.orchestrator.execute(feedBackServiceInvokeTask, feedBackConfig);
            request.orchestrator.execute(transactionArrayTask, transactionArrayConfig);

            CompletableFuture getSellerTransactionsResponseCompletableFuture = request.orchestrator.execute(buildGetSellerTransactionResponseTask, transactionResponseTaskConfig);
            GetSellerTransactionsResponse getSellerTransactionsResponse = (GetSellerTransactionsResponse) TaskOrchestrationUtil.safeGet(getSellerTransactionsResponseCompletableFuture);
            return (GetSellerTransactionsResponse) TaskOrchestrationUtil.safeGet(request.orchestrator.execute(new OutputSelectorTask(request.getRequestType(), getSellerTransactionsResponse)));
        } finally {
            this.request.getTracerContext().getOpenTeleParentSpan().end();
            this.request.getTracerContext().getOpenTracingParentSpan().finish();
        }

    }

    private void fetchGetSellerTransactionsDataContext(@Nonnull TracerContext tracerContext,
                                                       @Nonnull CosmosInvokeTask cosmosInvokeTask,
                                                       @Nonnull LoadGetSellerTransactionsDataTask loadGetSellerTransactionDataTask) {

        //load user address setting info
        LoadUserAddressTask loadUserAddressTask = new LoadUserAddressTask(request.headers, new AddressBookServiceInvoker(tracerContext));
        //load seller pref setting info.
        LoadSellerPrefTask loadSellerPrefTask = new LoadSellerPrefTask(new SellerPrefBofImpl(), request.user.userId);
        //load item sku
        LoadSellerProdIdTask loadSellerProdIdTask = new LoadSellerProdIdTask(new SaleAggregatorBofImpl());

        TaskConfiguration loadSellerTransactionsDataContextConfig = TaskConfiguration.create()
                .addDependency(loadSellerPrefTask)
                .addDependency(loadSellerProdIdTask);
        TaskConfiguration loadSellerPrefConfig = TaskConfiguration.create().addDependency(cosmosInvokeTask);
        TaskConfiguration loadSellerProdIdConfig = TaskConfiguration.create().addDependency(cosmosInvokeTask);
        TaskConfiguration loadUserAddressConfig = TaskConfiguration.create()
                .addDependency(cosmosInvokeTask)
                .addDependency(loadSellerPrefTask);

        request.orchestrator.execute(loadSellerProdIdTask,loadSellerProdIdConfig);
        request.orchestrator.execute(loadSellerPrefTask,loadSellerPrefConfig);
        request.orchestrator.execute(loadUserAddressTask, loadUserAddressConfig);
        request.orchestrator.execute(loadGetSellerTransactionDataTask, loadSellerTransactionsDataContextConfig);
    }

    private Scope getOpenTeleSpan() {
        return this.request.getTracerContext()
                           .getOpenTeleParentSpan()
                           .makeCurrent();
    }

    private io.opentracing.Scope createTracerSpan() {
        return this.request.getTracerContext()
                           .getOpenTracingTracer()
                           .scopeManager()
                           .activate(this.request.getTracerContext().getOpenTracingParentSpan(), true);
    }

    @Override
    protected GetSellerTransactionsResponse handleException(ApplicationException e) {
        GetSellerTransactionsResponse resp = new GetSellerTransactionsResponse();
        resp.setAck(AckCodeType.FAILURE);
        resp.getErrors().add((ErrorType) e.entity);
        resp.setBuild(ApiSellingExtSvcConstants.BUILD);
        return resp;
    }

}
