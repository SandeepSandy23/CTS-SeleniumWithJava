package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.order.common.v1.LogisticsPlanType;
import com.google.common.collect.ImmutableMap;

public class PickupMethodMapper {
    private static final ImmutableMap<LogisticsPlanType, String> mapName
            = new ImmutableMap.Builder<LogisticsPlanType, String>()
            .put(LogisticsPlanType.SHIPPING_PICKUP, ApiSellingExtSvcConstants.METHOD_CODE_PICKUP)
            .put(LogisticsPlanType.STORE_PICKUP, ApiSellingExtSvcConstants.METHOD_CODE_IN_STORE_PICKUP)
            .build();


    private PickupMethodMapper() {
    }

    public static String map(LogisticsPlanType logisticsPlanType) {
        return mapName.getOrDefault(logisticsPlanType, ApiSellingExtSvcConstants.METHOD_CODE_CUSTOM_CODE);
    }
}