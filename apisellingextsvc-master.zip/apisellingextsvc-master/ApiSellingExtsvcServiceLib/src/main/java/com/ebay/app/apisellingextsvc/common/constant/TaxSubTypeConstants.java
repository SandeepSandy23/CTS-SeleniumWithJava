package com.ebay.app.apisellingextsvc.common.constant;

public final class TaxSubTypeConstants {
    // special tax sub type we are using
    public static final String OSS = "OSS";
    public static final String IOSS = "IOSS";
    public static final String ABN = "ABN";
    public static final String IRD = "IRD";
    public static final String VOEC = "VOEC";
    public static final String GST = "GST";
    public static final String VAT_ID = "VAT_ID";

    // special format of tax number
    public static final String ABN_FORMAT = "ABN#";
    public static final String IRD_FORMAT = "IRD#";
    public static final String VOEC_FORMAT = "VOEC ";
    public static final String GST_FORMAT = "GST";
    public static final String IOSS_FORMAT = "IOSS";
}
