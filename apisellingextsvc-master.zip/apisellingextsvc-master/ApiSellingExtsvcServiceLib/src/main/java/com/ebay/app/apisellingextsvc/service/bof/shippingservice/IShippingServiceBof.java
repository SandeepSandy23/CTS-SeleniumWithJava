package com.ebay.app.apisellingextsvc.service.bof.shippingservice;

import com.ebay.app.apisellingextsvc.service.dal.shippingservice.ShippingService;

public interface IShippingServiceBof {
    ShippingService findByServiceId(int serviceId);
}
