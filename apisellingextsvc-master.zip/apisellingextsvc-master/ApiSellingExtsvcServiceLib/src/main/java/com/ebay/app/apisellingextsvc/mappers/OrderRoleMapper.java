package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.order.common.v1.OrderCreatorTypeEnumType;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.TradingRoleCodeType;

public class OrderRoleMapper {

    private static final ImmutableMap<OrderCreatorTypeEnumType, TradingRoleCodeType> mapName
            = new ImmutableMap.Builder<OrderCreatorTypeEnumType, TradingRoleCodeType>()
            .put(OrderCreatorTypeEnumType.BUYER, TradingRoleCodeType.BUYER)
            .put(OrderCreatorTypeEnumType.SELLER, TradingRoleCodeType.SELLER)
            .build();

    private OrderRoleMapper() {
    }

    public static TradingRoleCodeType map(OrderCreatorTypeEnumType orderCreatorType) {
        return mapName.getOrDefault(orderCreatorType, null);
    }

}
