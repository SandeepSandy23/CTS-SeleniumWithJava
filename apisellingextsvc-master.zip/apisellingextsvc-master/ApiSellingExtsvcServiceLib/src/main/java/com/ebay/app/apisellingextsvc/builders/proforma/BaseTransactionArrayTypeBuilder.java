package com.ebay.app.apisellingextsvc.builders.proforma;

import com.ebay.app.apisellingextsvc.builders.BaseFacetBuilder;
import com.ebay.cosmos.ContractIdentifier;
import com.ebay.cosmos.ContractResponseType;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.TransactionType;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Optional;


public abstract class BaseTransactionArrayTypeBuilder extends BaseFacetBuilder<List<TransactionType>> {
    private final String requestLookupKey;
    private final ContractResponseType contractResponseType;

    public BaseTransactionArrayTypeBuilder(Task<?> task,
                                           @Nonnull ContractResponseType contractResponseType) {
        super(task);
        this.requestLookupKey = Optional.of(contractResponseType).map(ContractResponseType::getIdentifier)
                .map(ContractIdentifier::getLookupKey)
                .orElse(null);
        this.contractResponseType = contractResponseType;
    }
}
