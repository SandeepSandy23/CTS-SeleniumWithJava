package com.ebay.app.apisellingextsvc.tasks.GMES;

import com.ebay.app.apisellingextsvc.application.common.request.GetMyeBaySellingRequest;
import ebay.apis.eblbasecomponents.DetailLevelCodeType;
import java.util.List;
import java.util.concurrent.Executor;

public class GMESDeletedUnsoldContainerTask extends GMESUnsoldAndDeletedUnsoldContainerTask {

    public GMESDeletedUnsoldContainerTask(GetMyeBaySellingRequest request, Executor executor, List<DetailLevelCodeType> detailLevels) {
        super(request, executor, detailLevels, true);
    }
}
