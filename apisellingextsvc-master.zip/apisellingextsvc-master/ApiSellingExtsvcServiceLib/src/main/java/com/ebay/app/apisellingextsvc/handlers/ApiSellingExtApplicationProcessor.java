package com.ebay.app.apisellingextsvc.handlers;

import com.ebay.app.apisellingextsvc.application.common.request.BaseApplicationRequest;
import com.ebay.app.apisellingextsvc.application.common.response.IServiceResponse;
import com.ebay.app.apisellingextsvc.application.common.response.ServiceResponse;
import com.ebay.app.apisellingextsvc.common.exception.ApplicationException;
import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.common.log.CalLogger;
import com.ebay.app.apisellingextsvc.content.ContentHelper;
import com.ebay.app.apisellingextsvc.content.IContentManager;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import com.ebay.app.apisellingextsvc.mappers.ErrorLanguageSiteIdMapper;
import com.ebay.app.apisellingextsvc.service.invokers.ApisellingioServiceInvoker;
import com.ebay.app.apisellingextsvc.tasks.filter.IFilter;
import com.ebay.app.apisellingextsvc.utils.Headers;
import ebay.apis.eblbasecomponents.ErrorType;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;

public class ApiSellingExtApplicationProcessor<T extends IServiceResponse> {

    private final BaseApplicationRequest request;
    private final ApiSellingExtApplicationHandler<T> applicationHandler;
    private final IAuditHandler<T> auditHandler;
    private final List<IFilter> filters;


    public ApiSellingExtApplicationProcessor(BaseApplicationRequest request, ApiSellingExtApplicationHandler<T> handler, ApiSellingExtAuditHandler<T> auditHandler, List<IFilter> filters){
        this.request = request;
        this.applicationHandler = handler;
        this.auditHandler = auditHandler;
        this.filters = filters;
    }

    public ServiceResponse<T> handle() {

        Headers responseHeaders = null;
        T rval = null;


        try {
            filters.forEach(IFilter::doFilter);
            if (auditHandler != null) {
                this.auditHandler.preAction(new ApisellingioServiceInvoker(request.getTracerContext(), request.trxVersion));
            }
            rval = this.applicationHandler.handle();

            if (auditHandler != null) {
                this.auditHandler.doAudit(rval);
            }


        } catch(ApplicationException t) {
            return handleExceptionResponse(t);
        } catch(Exception t) {
            CalLogger.error("Unexpect Exception", ExceptionUtils.getStackTrace(t));
            IContentManager contentManager;
            if (request.getContentResource().contentHelper == null) {
                ContentHelper contentHelper = new ContentHelper(request.getContentBuilderFactory(), request.getRequestSiteId(), getErrorLanguageSiteId(),
                        30000L, 10);
                contentManager = contentHelper.getErrorContentManager();
            } else {
                contentManager = request.getContentResource().contentHelper.getErrorContentManager();
            }
            ApplicationException appError = ExceptionHandler.getException(ApplicationError.SYSTEM_ERROR, contentManager);
            return handleExceptionResponse(appError);
        }

        return new ServiceResponse<>(rval, responseHeaders);
    }

    private ServiceResponse<T> handleExceptionResponse(ApplicationException appError) {
        // collect response contexts so diagnostics can be included in error response
        logApplicationExceptionResponse((ErrorType) appError.entity);
        return new ServiceResponse<>(this.applicationHandler.handleException(appError), this.request.getHeaders());
    }

    private static void logApplicationExceptionResponse(ErrorType entity) {
        CalLogger.warn(ApiSellingExtSvcConstants.APPLICATION_EXCEPTION, entity.getShortMessage()!=null ? entity.getShortMessage() : "Error");
    }

    private int getErrorLanguageSiteId() {
        Integer errorLangId = ApiSellingExtSvcConstants.DEFAULT_SITE_ID;
        if (request.getErrorLanguage() != null) {
            errorLangId = ErrorLanguageSiteIdMapper.map(request.getErrorLanguage());
        }

        return errorLangId;
    }
}
