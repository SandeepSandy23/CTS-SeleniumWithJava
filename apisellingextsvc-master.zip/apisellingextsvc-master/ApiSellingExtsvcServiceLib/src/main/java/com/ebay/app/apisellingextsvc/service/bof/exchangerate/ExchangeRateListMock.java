package com.ebay.app.apisellingextsvc.service.bof.exchangerate;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import java.util.List;

public class ExchangeRateListMock {

    private List<ExchangeRate> exchangeRates;

    public List<ExchangeRate> getExchangeRates() {
        return exchangeRates;
    }

    public void setExchangeRates(List<ExchangeRate> exchangeRates) {
        this.exchangeRates = exchangeRates;
    }


    public static class ExchangeRate implements com.ebay.app.apisellingextsvc.service.dal.exchangerate.ExchangeRate {

        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "UTC")
        private Date dayOfRate;
        private int fromCurrency;
        private double rate;

        @Override
        public Date getDayOfRate() {
            return dayOfRate;
        }

        @Override
        public void setDayOfRate(Date dayOfRate) {
            this.dayOfRate = dayOfRate;
        }

        @Override
        public int getFromCurrency() {
            return fromCurrency;
        }

        @Override
        public void setFromCurrency(int fromCurrency) {
            this.fromCurrency = fromCurrency;
        }

        @Override
        public double getRate() {
            return rate;
        }

        @Override
        public void setRate(double rate) {
            this.rate = rate;
        }
    }
}
