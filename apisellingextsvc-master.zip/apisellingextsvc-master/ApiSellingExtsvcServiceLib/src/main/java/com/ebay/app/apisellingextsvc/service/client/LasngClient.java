package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsRequest;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LasngClient extends BaseGingerClient<GetListingActivitiesByIdsRequest, GetListingActivitiesByIdsResponse> {

    private static final Logger logger = LoggerFactory.getLogger(LasngClient.class);

    private static final String CLIENT_ID = "lasng.lasngClient";

    private static final String PATH = "/lasngsvc/v1/listing_activity/get_by_ids";

    public LasngClient() {
        super(GetListingActivitiesByIdsResponse.class);
    }

    @Override
    public GingerClientResponse<GetListingActivitiesByIdsResponse> getGingerResponse(GingerClientRequest<GetListingActivitiesByIdsRequest> gingerRequest) {
        return processPostRequestWithRetry(PATH, gingerRequest.getHeaders(), gingerRequest, false);
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
