package com.ebay.app.apisellingextsvc.mappers;

import com.ebay.app.apisellingextsvc.enums.RemedyActionEnum;
import com.google.common.collect.ImmutableMap;
import ebay.apis.eblbasecomponents.RequiredSellerActionCodeType;

public class PaymentHoldReleaseActionMapper {

    // todo proforma order mapping
    // checkout trans payment method
    private static final ImmutableMap<String, RequiredSellerActionCodeType> mapName
            = new ImmutableMap.Builder<String, RequiredSellerActionCodeType>()
            .put(RemedyActionEnum.MARK_AS_SHIPPED.name(), RequiredSellerActionCodeType.MARK_AS_SHIPPED)
            .put(RemedyActionEnum.RESOLVE_EBP_CASE.name(), RequiredSellerActionCodeType.RESOLVEE_BP_CASE)
            .put(RemedyActionEnum.RESOLVE_PPPI_CASE.name(), RequiredSellerActionCodeType.RESOLVE_PPP_ICASE)
            .put(RemedyActionEnum.UPLOAD_TRACKING_INFO.name(), RequiredSellerActionCodeType.UPLOAD_TRACKING_INFO)
            .put(RemedyActionEnum.RESOLVE_EBP_CONTACT_INR.name(), RequiredSellerActionCodeType.RESOLVEE_BP_CASE)
            .put(RemedyActionEnum.RESOLVE_EBP_CONTACT_SNAD.name(), RequiredSellerActionCodeType.RESOLVE_BUYER_MESSAGE_SNAD)
            .put(RemedyActionEnum.RESOLVE_RETURN.name(), RequiredSellerActionCodeType.RESOLVE_RETURN)
            .put(RemedyActionEnum.WMM_SETUP_PAYOUT_METHOD.name(), RequiredSellerActionCodeType.SETUP_PAYOUT_METHOD)
            .put(RemedyActionEnum.WMM_UPDATE_PAYOUT_METHOD.name(), RequiredSellerActionCodeType.UPDATE_PAYOUT_METHOD)
            .build();

    private PaymentHoldReleaseActionMapper() {
    }

    public static RequiredSellerActionCodeType map(String key) {
        return mapName.getOrDefault(key, RequiredSellerActionCodeType.CUSTOM_CODE);
    }

}
