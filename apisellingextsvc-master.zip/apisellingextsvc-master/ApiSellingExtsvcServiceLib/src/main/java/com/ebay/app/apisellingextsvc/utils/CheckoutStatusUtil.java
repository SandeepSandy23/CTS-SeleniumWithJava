package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.cosmos.OrderStateTypeCS;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.FundingStatusTypeEnum;
import com.ebay.order.common.v1.OrderStateType;
import ebay.apis.eblbasecomponents.CheckoutStatusCodeType;
import ebay.apis.eblbasecomponents.CompleteStatusCodeType;

import java.util.List;

public class CheckoutStatusUtil {

    /**
     * Incomplete if
     *  Payment is not funded and order status is not INITIALIZED
     * Pending if
     *  Order status is in INITIZLAIZED state.
     * Complete if
     *  Order payment is funded.
     */
    public static CompleteStatusCodeType orderCheckoutStatus(OrderStateTypeCS orderStates, List<Attribute> orderAttributes) {
        CompleteStatusCodeType status;
        if (OrderStateType.CREATED == orderStates.getOrderStatus()
                && FundingStatusTypeEnum.NOT_FUNDED == orderStates.getFundingStatus()
                && isInflightOrder(orderAttributes)) {
            status = CompleteStatusCodeType.PENDING;
        } else if (FundingStatusTypeEnum.FUNDED == orderStates.getFundingStatus()) {
            status = CompleteStatusCodeType.COMPLETE;
        } else {
            status = CompleteStatusCodeType.INCOMPLETE;
        }
        return status;
    }

    public static CheckoutStatusCodeType checkoutStatusCode(CompleteStatusCodeType checkoutStatus) {
        //todo mapping other code
        if (checkoutStatus == CompleteStatusCodeType.COMPLETE) {
            return CheckoutStatusCodeType.CHECKOUT_COMPLETE;
        }
        return null;
    }

    /*
    *   1, complete - if funded
    *   2, pending - if checkout in progress
    *   3, Incomplete - others
    * */
    public static CompleteStatusCodeType proformaOrderCheckoutStatus(OrderStateTypeCS orderState) {

        if (orderState.getFundingStatus() == FundingStatusTypeEnum.FUNDED) {
            return CompleteStatusCodeType.COMPLETE;
        }

        if (orderState.getOrderStatus() == OrderStateType.CHECKOUT_IN_PROCESS) {
            return CompleteStatusCodeType.PENDING;
        }

        return CompleteStatusCodeType.INCOMPLETE;
    }

    private static boolean isInflightOrder(List<Attribute> attributeList) {
        return AttributeUtil.findAttribute(attributeList, ApiSellingExtSvcConstants.ATTR_IS_INFLIGHT_ORDER)
                .map(Attribute::getValue).map(Boolean::valueOf).orElse(Boolean.FALSE);
    }

}
