package com.ebay.app.apisellingextsvc.tasks.audit;

import com.ebay.app.apisellingextsvc.application.common.response.GetMyeBaySellingResponse;
import com.ebay.app.apisellingextsvc.audit.comparator.ExtensiveComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.api.GetMyeBaySellingComparator;
import com.ebay.app.apisellingextsvc.audit.es.ESResponse;
import com.ebay.app.apisellingextsvc.audit.es.Report;
import com.ebay.app.apisellingextsvc.audit.es.Request;
import com.ebay.app.apisellingextsvc.audit.es.Response;
import com.ebay.app.apisellingextsvc.audit.reporter.BaseAuditReporter;
import com.ebay.app.apisellingextsvc.audit.reporter.GetMyeBaySellingReporter;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.enums.APITypeEnum;
import com.ebay.app.apisellingextsvc.enums.ESAuditIndexEnum;
import com.ebay.app.apisellingextsvc.service.invokers.IServiceInvoker;
import com.ebay.app.apisellingextsvc.utils.XmlUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.gson.Gson;
import ebay.apis.eblbasecomponents.GetMyeBaySellingRequestType;
import org.apache.commons.lang3.StringUtils;

import javax.ws.rs.core.HttpHeaders;
import java.util.Calendar;

public class GetMyeBaySellingAuditTask extends BaseApiSellingExtAuditTask{
        private static final String REQUEST_PATH = "tradingApi/GetMyeBaySelling";
        private final GetMyeBaySellingRequestType request;

        public GetMyeBaySellingAuditTask(
                GetMyeBaySellingResponse oldTradingApi,
                GetMyeBaySellingResponse newTradingApi,
                GetMyeBaySellingRequestType request,
                IServiceInvoker<Report, ESResponse> esServiceInvoker,
                HttpHeaders headers,
                ApiSellingExtSvcConfigValues configValue) {
            super(oldTradingApi, newTradingApi, esServiceInvoker, headers, configValue);
            this.request = request;
        }

        protected void populateRequest(Report report) {
                if (StringUtils.isNotBlank(getPayload())) {
                        report.setRequest(new Request(Calendar.getInstance().getTime(), getESDocName(), getPayload(),
                                                      null, headers.getRequestHeaders().toString()));
                }
        }

        public void populateResponse(JsonNode org, JsonNode tar,Object orgStr, Object tarStr, Report report) {
                report.setResponse(new Response(null, null, new Gson().toJson(orgStr), new Gson().toJson(tarStr)));
        }

        @Override
        protected ExtensiveComparator getResponseComparator() {
        return new GetMyeBaySellingComparator(true, false, configValue.getMyeBaySellingAuditExcludeFields);
        }

        @Override
        protected BaseAuditReporter getAuditReporter() {
        return new GetMyeBaySellingReporter();
        }

        @Override
        protected String getUrl() {
        return REQUEST_PATH;
        }

        @Override
        protected String getPayload() {
        return XmlUtil.writeRequestAsString(request, APITypeEnum.GetMyeBaySelling);
        }

        protected String getESDocName() {
        return ESAuditIndexEnum.GET_MYEBAY_SELLING.getIndexName();
        }
    }


