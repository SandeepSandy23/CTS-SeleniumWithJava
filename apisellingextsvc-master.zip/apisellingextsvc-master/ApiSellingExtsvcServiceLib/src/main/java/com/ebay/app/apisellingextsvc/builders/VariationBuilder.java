package com.ebay.app.apisellingextsvc.builders;

import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.config.ApiSellingExtSvcConfigValues;
import com.ebay.app.apisellingextsvc.utils.AttributeUtil;
import com.ebay.app.apisellingextsvc.utils.ItemTitleUtil;
import com.ebay.app.apisellingextsvc.utils.NameValueListTypeUtil;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.order.common.v1.Attribute;
import com.ebay.order.common.v1.InventorySKUInfo;
import com.ebay.raptor.orchestrationv2.task.Task;
import ebay.apis.eblbasecomponents.NameValueListArrayType;
import ebay.apis.eblbasecomponents.NameValueListType;
import ebay.apis.eblbasecomponents.VariationType;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

public class VariationBuilder extends BaseFacetBuilder<VariationType> {

    private final ApiSellingExtSvcConfigValues configValues;
    private final List<Attribute> itemSkuDetails;
    private final InventorySKUInfo inventorySKUInfo;
    private final List<Attribute> lineAttributes;
    private final Text title;


    public VariationBuilder(Task<?> task,
                            ApiSellingExtSvcConfigValues configValues,
                            List<Attribute> itemSkuDetails,
                            InventorySKUInfo inventorySKUInfo,
                            List<Attribute> lineAttributes,
                            Text title) {
        super(task);
        this.inventorySKUInfo = inventorySKUInfo;
        this.itemSkuDetails = itemSkuDetails;
        this.lineAttributes = lineAttributes;
        this.title = title;
        this.configValues = configValues;
    }

    @Override
    protected VariationType doBuild() {
        VariationType variation = null;
        if (CollectionUtils.isNotEmpty(itemSkuDetails)) {
            variation = new VariationType();
            variation.setVariationSpecifics(getVariationSpecifics(itemSkuDetails));
            if (inventorySKUInfo != null) {
                variation.setSKU(inventorySKUInfo.getSellerProvidedSKUId());
            }
            variation.setVariationTitle(ItemTitleUtil.getVariationTitle(configValues, itemSkuDetails, title));
            variation.setVariationViewItemURL(getVariationViewItemURL(lineAttributes));
        }
        // check apixoio logic to know when should not return variation
        return variation;
    }

    private NameValueListArrayType getVariationSpecifics(List<Attribute> attributes) {
        NameValueListArrayType arrayType = null;
        if (CollectionUtils.isNotEmpty(attributes)) {
            arrayType = new NameValueListArrayType();
            List<NameValueListType> list = new ArrayList<>();
            attributes.forEach(a -> list.add(NameValueListTypeUtil.getNameValueListType(a.getName(), a.getValue())));
            arrayType.getNameValueList().addAll(list);
        }
        return arrayType;
    }

    private String getVariationViewItemURL(List<Attribute> attributes) {
        // trading api use variation name in url, cosmos use variation id
        // we may need to investigate if we directly use cosmos variation id is a problem
        return AttributeUtil.findAttribute(attributes, ApiSellingExtSvcConstants.LISTING_URL).map(Attribute::getValue).orElse(null);
    }
}
