package com.ebay.app.apisellingextsvc.audit.reporter;

public class GetSellerTransactionsReporter extends BaseAuditReporter {

        // TODO: CHANGE THIS
        private static final String PATTERN_PATH = "audit/report/mismatch_grouping_getSellerTransactions.pattern";

        public GetSellerTransactionsReporter() {
            super(PATTERN_PATH);

        }
}
