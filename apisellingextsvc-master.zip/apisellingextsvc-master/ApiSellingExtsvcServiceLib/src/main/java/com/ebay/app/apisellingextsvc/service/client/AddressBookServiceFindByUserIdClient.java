package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.tide.app.addressbook.request.BulkFindAddressesByUserIdRequest;
import com.ebay.tide.app.addressbook.response.BulkFindAddressesByUserIdResponse;
import com.google.common.collect.ImmutableList;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AddressBookServiceFindByUserIdClient extends BaseGingerClient<BulkFindAddressesByUserIdRequest, BulkFindAddressesByUserIdResponse> {

    private static final Logger logger = LoggerFactory.getLogger(AddressBookServiceFindByUserIdClient.class);

    //https://wiki.corp.ebay.com/display/IP/Bulk+Find+Addresses+By+User+ID
    private static final String CLIENT_ID = "adrbksvc";

    private static final String ABS_BULK_FIND_ADDRESS_BY_USER_ID_URI =
          "/identity/address_book/v1/address/bulk_find_addresses_by_user_id";
    ImmutableList<Pair<String, Object>> queryParam = ImmutableList.of(
          ImmutablePair.of("fieldgroups", "MEDIUM"),
          ImmutablePair.of("filter", "preference:PRIMARY"),
          ImmutablePair.of("filter", "purpose:SHIPPING"));

    public AddressBookServiceFindByUserIdClient() {
        super(BulkFindAddressesByUserIdResponse.class);
    }


    @Override
    public GingerClientResponse<BulkFindAddressesByUserIdResponse> getGingerResponse(
          GingerClientRequest<BulkFindAddressesByUserIdRequest> gingerRequest) {
        return processPostRequest(ABS_BULK_FIND_ADDRESS_BY_USER_ID_URI, gingerRequest.getHeaders(), queryParam, gingerRequest);
    }


    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
