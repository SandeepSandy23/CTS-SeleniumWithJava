package com.ebay.app.apisellingextsvc.common.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DateHelper {
    private static final List<String> sdfStrs = (List)Stream.of("yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'").collect(Collectors.toList());

    public DateHelper() {
    }

    public static Date parseDateString(String str) {
        Iterator var1 = sdfStrs.iterator();

        while(var1.hasNext()) {
            String sdfStr = (String)var1.next();

            try {
                return (new SimpleDateFormat(sdfStr)).parse(str);
            } catch (ParseException var4) {
                System.out.println("try parsing date failed, falling back... " + var4.getMessage());
            }
        }

        throw new RuntimeException("Error parsing data: " + str);
    }
}