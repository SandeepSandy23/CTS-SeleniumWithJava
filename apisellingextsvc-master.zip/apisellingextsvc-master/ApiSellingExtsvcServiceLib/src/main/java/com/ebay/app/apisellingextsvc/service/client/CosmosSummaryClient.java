package com.ebay.app.apisellingextsvc.service.client;

import com.ebay.app.apisellingextsvc.context.FindContractV2RequestContext;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.cosmos.SummaryResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CosmosSummaryClient extends BaseGingerClient<FindContractV2RequestContext, SummaryResponse> {

    private static final Logger logger = LoggerFactory.getLogger(CosmosSummaryClient.class);

    private static final String CLIENT_ID = "cosmos.summary";

    public CosmosSummaryClient() {
        super(SummaryResponse.class);
    }

    @Override
    public GingerClientResponse<SummaryResponse> getGingerResponse(GingerClientRequest<FindContractV2RequestContext> gingerRequest) {
        return processGetRequest(gingerRequest.getRequest().getParamString(), null, gingerRequest.getHeaders());
    }

    @Override
    public String getTargetBase() {
        return CLIENT_ID;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}