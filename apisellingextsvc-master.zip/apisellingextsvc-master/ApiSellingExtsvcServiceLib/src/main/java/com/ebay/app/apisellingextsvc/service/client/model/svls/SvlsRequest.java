package com.ebay.app.apisellingextsvc.service.client.model.svls;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Objects;

@Data
@Builder
public class SvlsRequest {

    private String itemVersionId;

    private String itemId;

    private String variationId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SvlsRequest that = (SvlsRequest) o;
        return itemVersionId.equals(that.itemVersionId) && itemId.equals(that.itemId) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(itemVersionId, itemId);
    }

}
