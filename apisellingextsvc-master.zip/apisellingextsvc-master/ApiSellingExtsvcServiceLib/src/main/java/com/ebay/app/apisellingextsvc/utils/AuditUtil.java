package com.ebay.app.apisellingextsvc.utils;

import com.ebay.app.apisellingextsvc.application.common.response.GetMyeBaySellingResponse;
import com.ebay.app.apisellingextsvc.application.common.response.GetSellerTransactionsResponse;
import com.ebay.app.apisellingextsvc.enums.ApplicationError;
import com.google.common.collect.Sets;
import ebay.apis.eblbasecomponents.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.util.*;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;

public class AuditUtil {

    //provides a magic value greater than all current transaction ID strings to implement the nullLast effect
    private static final String LARGE_THAN_EVERY_ID = StringUtils.repeat('z', 100);

    private static final Set<String> AUDIT_IGNORE_ERROR_CODE = Sets.newHashSet(
            ApplicationError.INVALID_ORDER_LINE_IDS.getErrorCode()  //apisellingextsvc will always have valid line_ids
    );

    private static final Calendar CALENDAR_OF_ZERO = DateUtil.convert("1970-01-01T00:00:00.000Z");

    //sort ExternalTransactionType list by time, externalTransactionId, if it's null, move to last
    public static final Comparator<ExternalTransactionType> nullLastExternTransactionComparator =
            Comparator.comparing((ExternalTransactionType externaltransaction) ->
                            externaltransaction.getExternalTransactionTime() == null ? CALENDAR_OF_ZERO
                                    : DateUtil.convertToCalendar(externaltransaction.getExternalTransactionTime()))
                    .thenComparing((ExternalTransactionType externalTransactionType) ->
                            externalTransactionType.getExternalTransactionID() == null
                                    ? LARGE_THAN_EVERY_ID : externalTransactionType.getExternalTransactionID())
                    .thenComparing(transactionType -> transactionType.getPaymentOrRefundAmount().getValue());


    public static void sort(GetSellerTransactionsResponse apisellingioResponse) {
        List<TransactionType> transactionlist = Optional.ofNullable(apisellingioResponse).map(GetSellerTransactionsResponseType::getTransactionArray)
                .map(TransactionArrayType::getTransaction).orElse(null);
        if (CollectionUtils.isNotEmpty(transactionlist)) {
            transactionlist.sort(Comparator.comparing(TransactionType::getTransactionID)); //TODO Remove later
            transactionlist.sort(Comparator.comparing((TransactionType trans) -> trans.getItem().getItemID())
                    .thenComparing(TransactionType::getTransactionID));
            for (TransactionType transaction : transactionlist) {
                if (transaction == null) {
                    continue;
                }
                if (transaction != null) {
                    if (CollectionUtils.isNotEmpty(transaction.getExternalTransaction())
                            && transaction.getExternalTransaction().size() > 1) {
                        transaction.getExternalTransaction().sort(nullLastExternTransactionComparator);
                    }
                }
            }
        }
    }

    public static boolean hasOutputSelector(@Nonnull AbstractRequestType abstractRequest) {
        return Optional.of(abstractRequest).map(AbstractRequestType::getOutputSelector)
                .map(CollectionUtils::isNotEmpty).orElse(false);
    }

    public static boolean shouldSkipAudit(GetSellerTransactionsResponse apisellingioResponse, GetSellerTransactionsResponse response) {

            //check whether entry in ebay checkout trans is deleted
            if (isLegacyMissingTransaction(apisellingioResponse, response)) {
                return true;
            }

            return Optional.of(apisellingioResponse)
                    .map(GetSellerTransactionsResponse::getErrors)
                    .flatMap(errorTypes ->
                            errorTypes.stream()
                                    .map(ErrorType::getErrorCode)
                                    .map(AUDIT_IGNORE_ERROR_CODE::contains)
                                    .findFirst()
                    ).orElse(false);
    }

    public static boolean shouldSkipAuditForGMES(GetMyeBaySellingResponse apisellingioResponse,
            GetMyeBaySellingResponse response) {
        return false;
    }
    private static boolean isLegacyMissingTransaction(GetSellerTransactionsResponse apisellingioResponse, GetSellerTransactionsResponse response) {
        if (apisellingioResponse.getTransactionArray() == null || CollectionUtils.isEmpty(apisellingioResponse.getTransactionArray().getTransaction())) {
            return Optional.ofNullable(response).map(GetSellerTransactionsResponseType::getTransactionArray).map(TransactionArrayType::getTransaction).map(List::size)
                    .orElse(0).equals(1);
        }
        return false;
    }


}
