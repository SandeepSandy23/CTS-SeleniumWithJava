package com.ebay.app.apisellingextsvc.service.dal.shippingservice;

import com.ebay.integ.dal.cache2.CacheLoader;
import com.ebay.integ.dal.cache2.CacheLoaderException;
import com.ebay.integ.dal.cache2.ExternalCacheEntryLoader;
import com.ebay.integ.dal.cache2.FullCacheException;
import com.ebay.integ.dal.cache2.MessageId;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.kernel.message.Message;

import java.util.List;

public class ShippingServiceCacheLoader implements CacheLoader {
    private static final long serialVersionUID = 352882683156141050L;

    public ShippingServiceCacheLoader() {
    }

    public void startup(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        this.load(externalCacheEntryLoader);
    }

    public void refresh(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        externalCacheEntryLoader.flushCache();
        this.load(externalCacheEntryLoader);
    }

    private void load(ExternalCacheEntryLoader externalCacheEntryLoader) throws CacheLoaderException {
        List tmpList = null;

        String[] params;
        Message complaint;
        try {
            tmpList = ShippingServiceDAO.getInstance().findAllDirect2DB();
            externalCacheEntryLoader.putInCacheFromList(tmpList);
        } catch (FinderException var6) {
            params = new String[]{this.getClass().getName(), var6.getMessage()};
            complaint = new Message(MessageId.CACHE_LOADER_FAILURE, params);
            throw new CacheLoaderException(complaint, var6);
        } catch (FullCacheException var7) {
            params = new String[]{this.getClass().getName(), var7.getMessage()};
            complaint = new Message(MessageId.CACHE_LOADER_FAILURE, params);
            throw new CacheLoaderException(complaint, var7);
        }
    }
}