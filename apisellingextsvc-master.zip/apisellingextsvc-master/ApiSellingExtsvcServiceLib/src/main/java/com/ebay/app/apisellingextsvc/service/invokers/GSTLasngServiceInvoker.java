package com.ebay.app.apisellingextsvc.service.invokers;

import com.ebay.app.apisellingextsvc.context.ListingsContext;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.GetLasNgClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.lib.lasng.model.GetListingActivitiesByIdsResponse;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

public class GSTLasngServiceInvoker extends BaseServiceInvoker<ListingsContext, GetListingActivitiesByIdsResponse, ListingsContext> {

    // use for mock
    public static final String NAME = "GSTLasngServiceInvoker";

    public GSTLasngServiceInvoker(TracerContext tracerContext) {
        super( NAME, tracerContext);
    }

    @Override
    protected BaseGingerClient<ListingsContext, GetListingActivitiesByIdsResponse> getGingerClient(ListingsContext listingsContext) {
        return new GetLasNgClient();
    }

    @Override
    protected GingerClientRequest<ListingsContext> getGingerRequest(ListingsContext listingsContext, HttpHeaders httpHeaders) {
        GingerClientRequest<ListingsContext> gingerClientRequest = new GingerClientRequest<>();
        MultivaluedMap<String, Object> headers = transformHeaders(httpHeaders);
        addJsonHeaders(headers);
        gingerClientRequest.setHeaders(headers);
        gingerClientRequest.setRequest(listingsContext);
        return gingerClientRequest;
    }

}
