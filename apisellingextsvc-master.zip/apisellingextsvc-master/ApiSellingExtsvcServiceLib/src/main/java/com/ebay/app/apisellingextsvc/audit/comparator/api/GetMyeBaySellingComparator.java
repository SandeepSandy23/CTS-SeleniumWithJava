package com.ebay.app.apisellingextsvc.audit.comparator.api;

import com.ebay.app.apisellingextsvc.audit.comparator.CustomExtComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.facet.ActiveListArrayFacetComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.facet.BuyerFacetComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.facet.DeletedFromSoldOrderFacetComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.facet.ScheduledListArrayFacetComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.facet.SoldOrderFacetComparator;
import com.ebay.app.apisellingextsvc.audit.comparator.facet.UnsoldListArrayFacetComparator;

import java.util.Collections;
import java.util.List;

public class GetMyeBaySellingComparator extends CustomExtComparator {

    public static final String PATTERN_FILE = "audit/response/get_myebay_selling.json";
    public final List<String> excludeFieldList;

    public GetMyeBaySellingComparator(List<String> excludeFieldList) {
        this(false, false, excludeFieldList);
    }

    public GetMyeBaySellingComparator(boolean disablePatternFile, boolean disableExclusionFile, List<String> excludeFieldList) {
        super(PATTERN_FILE, disableExclusionFile ? Collections.emptyList() : excludeFieldList, disablePatternFile);
        this.excludeFieldList = excludeFieldList;
        registerExtendedComparators();
    }


    private void registerExtendedComparators() {
        addFacetComparators(new SoldOrderFacetComparator(this));
        addFacetComparators(new DeletedFromSoldOrderFacetComparator(this));
        addFacetComparators(new BuyerFacetComparator(this));
        addFacetComparators(new ActiveListArrayFacetComparator(this));
        addFacetComparators(new UnsoldListArrayFacetComparator(this));
        addFacetComparators(new ScheduledListArrayFacetComparator(this));
    }
}
