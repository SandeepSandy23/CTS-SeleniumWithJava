package com.ebay.app.apisellingextsvc.context;

import javax.ws.rs.core.HttpHeaders;

public class FindContractV2RequestContext {

    private final String paramString;
    private final HttpHeaders headers;

    private FindContractV2RequestContext(String paramString,
                                         HttpHeaders headers) {
        this.paramString = paramString;
        this.headers = headers;
    }

    public static FindContractV2RequestContext createGetRequestContext(String paramString, HttpHeaders headers) {
        return new FindContractV2RequestContext(paramString, headers);
    }

    public String getParamString() {
        return paramString;
    }

    public HttpHeaders getHeaders() {
        return headers;
    }

}
