package com.ebay.app.apisellingextsvc.service.invokers;


import com.ebay.app.apisellingextsvc.common.constant.ApiSellingExtSvcConstants;
import com.ebay.app.apisellingextsvc.context.TracerContext;
import com.ebay.app.apisellingextsvc.service.client.BaseGingerClient;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientRequest;
import com.ebay.app.apisellingextsvc.service.client.model.GingerClientResponse;
import com.ebay.app.apisellingextsvc.service.client.model.GingerResponseType;
import com.ebay.app.apisellingextsvc.utils.Headers;
import com.ebay.app.apisellingextsvc.utils.TracerUtil;
import com.ebay.raptor.opentracing.ParallelType;
import com.ebay.raptor.opentracing.Tags;
import com.google.common.collect.ImmutableSet;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;

import javax.annotation.Nonnull;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/*
   T - request context used in ginger call
   V - actual service response
   GR - if post/put call, then actual request pojo for the service call, if get call, then string
 */
public abstract class BaseServiceInvoker<T, V, R> implements IServiceInvoker<T, V> {

    private String name;

    private TracerContext tracerContext;
    private static final ImmutableSet<String> HEADER_EXCLUSIONS = ImmutableSet.of(
            ApiSellingExtSvcConstants.ACCEPT_ENCODING,    //avoid double encoding
            ApiSellingExtSvcConstants.EBAY_CLIENT_IP,      //avoid hystrix timeout
            ApiSellingExtSvcConstants.ACCEPT,             // remove application/xml
            ApiSellingExtSvcConstants.CONTENT_TYPE        // remove application/xml
    );

    public BaseServiceInvoker(String name, TracerContext tracerContext) {
        this.name = name;
        this.tracerContext = tracerContext;
    }

    @Override
    public V getResponse(T t, HttpHeaders httpHeaders) {
        Span openTeleChildSpan = TracerUtil.getOpenTeleChildSpan(this.name,tracerContext);
        io.opentracing.Span openTracerChildSpan = TracerUtil.getOpenTracerChildSpan(this.name,tracerContext);
        try(Scope scope = openTeleChildSpan.makeCurrent();
            io.opentracing.Scope tracerScope = tracerContext.getOpenTracingTracer().scopeManager().activate(openTracerChildSpan, true)) {
            BaseGingerClient<R, V> client = getGingerClient(t);
            GingerClientRequest<R> gingerRequest = getGingerRequest(t, filterHeaders(httpHeaders));
            GingerClientResponse<V> gingerResponse = client.getGingerResponse(gingerRequest);

            if (gingerResponse.getResponseType() == GingerResponseType.SUCCESS) {
                return mapGingerSuccessResponse(gingerResponse);
            } else if (gingerResponse.getResponseType() == GingerResponseType.TIMEOUT) {
                return mapGingerTimeoutResponse();
            } else { // FAILURE case
                return mapGingerFailureResponse();
            }
        } finally {
            openTeleChildSpan.end();
        }
    }
    protected abstract BaseGingerClient<R, V> getGingerClient(T t);

    protected abstract GingerClientRequest<R> getGingerRequest(T t, HttpHeaders httpHeaders);

    protected ImmutableSet<String> getHeaderExclusions() {
        return HEADER_EXCLUSIONS;
    }

    protected MultivaluedMap<String, Object> transformHeaders(HttpHeaders headers) {
        return new MultivaluedHashMap<String, Object>(headers.getRequestHeaders());
    }

    protected void addJsonHeaders(MultivaluedMap<String, Object> headers) {
        headers.putSingle(ApiSellingExtSvcConstants.ACCEPT, ApiSellingExtSvcConstants.CONTENT_TYPE_VALUE);
        headers.putSingle(ApiSellingExtSvcConstants.CONTENT_TYPE, ApiSellingExtSvcConstants.CONTENT_TYPE_VALUE);
    }

    protected void removeHeadersForUserReadSvc(MultivaluedMap<String, Object> headers) {
        headers.remove(ApiSellingExtSvcConstants.SOAP_ACTION);
        headers.remove(ApiSellingExtSvcConstants.CACHE_CONTROL);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_API_CALL_NAME);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_API_SITE_ID);
        headers.remove(ApiSellingExtSvcConstants.USER_AGENT);
        headers.remove(ApiSellingExtSvcConstants.HOST);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_SOA_OPERATION_NAME);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_C_ENDUSERCTX);
        headers.remove(ApiSellingExtSvcConstants.CONNECTION);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_SOA_MESSAGE_PROTOCOL);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_SOA_REQUEST_ID);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_SOA_USE_CASE_NAME);
        headers.remove(ApiSellingExtSvcConstants.POSTMAN_TOKEN);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_API_IAF_TOKEN);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_REQUEST_ID);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_C_REQUEST_ID);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_CONSUMER_ID);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_CLIENT_ID);
        headers.remove(ApiSellingExtSvcConstants.X_EBAY_TF_AUTHORIZATION);
    }

    protected V mapGingerSuccessResponse(@Nonnull GingerClientResponse<V> gingerResponse) {
        return gingerResponse.getResponse();
    }

    protected V mapGingerFailureResponse() {
        return null;
    }

    protected V mapGingerTimeoutResponse() {
        return null;
    }

    private HttpHeaders filterHeaders(HttpHeaders httpHeaders) {
        HttpHeaders filteredHeaders = new Headers();
        if (httpHeaders != null && httpHeaders.getRequestHeaders() != null && !httpHeaders.getRequestHeaders().isEmpty()) {
            ImmutableSet<String> headerExclusions = getHeaderExclusions();
            for (Map.Entry<String, List<String>> entry : httpHeaders.getRequestHeaders().entrySet()) {
                if (entry != null && !isExcludedHeader(headerExclusions, entry.getKey())) {
                    filteredHeaders.getRequestHeaders().put(entry.getKey(), entry.getValue());
                }

            }
        }
        return filteredHeaders;
    }


    private boolean isExcludedHeader(@Nonnull Set<String> exclusionSet, @Nonnull String inputKey) {
        return exclusionSet.contains(inputKey) || exclusionSet.contains(inputKey.toUpperCase(Locale.US))
                || exclusionSet.contains(inputKey.toLowerCase(Locale.US));
    }
}
