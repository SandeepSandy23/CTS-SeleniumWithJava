package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import com.ebay.integ.dal.map.*;
import com.ebay.kernel.util.JdkUtil;
import com.ebay.persistence.DALVersion;

@DALVersion("3.0")
public class ItemHostInfoCodeGenMap extends BaseMap2 {
    public static final TableDef m_item_hostTable = new TableDef("ITEM_HOST", "i");
    public static final TableDef m_item_host_rangeTable = new TableDef("ITEM_HOST_ITEM_ID_RANGE", "ir");
    public FullFieldMapping m_hostIdFm;
    public FullFieldMapping m_primaryHostNameFm;
    public FullFieldMapping m_readOnlyHostNameFm;
    public FullFieldMapping m_descriptionFm;
    public FullFieldMapping m_rangeStartFm;
    public FullFieldMapping m_rangeEndFm;
    public FullFieldMapping m_creationDateFm;
    public FullFieldMapping m_lastModifiedDateFm;
    public FullFieldMapping m__hostIdFm;
    public FullFieldMapping m__creationDateFm;
    public FullFieldMapping m__lastModifiedDateFm;
    public HintFieldMapping m_itemIdFm;
    protected final MappingIncludesAttribute[] m_ourDDRHints;
    private FieldMapping[] m_builtFieldMappings;
    private FieldMapping[] m_ourFieldMappings;
    private ReadSet[] m_builtReadSets;
    private UpdateSet[] m_builtUpdateSets;

    protected ItemHostInfoCodeGenMap() {
        this.m_hostIdFm = new FullFieldMapping("m_hostId", 0, m_item_hostTable, "HOST_ID");
        this.m_primaryHostNameFm = new FullFieldMapping("m_primaryHostName", 1, m_item_hostTable, "PRIMARY_HOST_NAME");
        this.m_readOnlyHostNameFm = new FullFieldMapping("m_readOnlyHostName", 2, m_item_hostTable, "READ_ONLY_HOST_NAME");
        this.m_descriptionFm = new FullFieldMapping("m_description", 3, m_item_hostTable, "DESCRIPTION");
        this.m_rangeStartFm = new FullFieldMapping("m_rangeStart", 4, m_item_host_rangeTable, "RANGE_START");
        this.m_rangeEndFm = new FullFieldMapping("m_rangeEnd", 5, m_item_host_rangeTable, "RANGE_END");
        this.m_creationDateFm = new FullFieldMapping("m_creationDate", 6, m_item_hostTable, "CREATION_DATE", (String) null, (String) null,
                "CREATION_DATE=CREATION_DATE", "sysdate", (FromDBRule) null, (ToDBRule) null);
        this.m_lastModifiedDateFm = new FullFieldMapping("m_lastModifiedDate", 7, m_item_hostTable, "LAST_MODIFIED_DATE", (String) null,
                (String) null, "LAST_MODIFIED_DATE=SYSDATE", "sysdate", (FromDBRule) null, (ToDBRule) null);
        this.m__hostIdFm = new FullFieldMapping("m__hostId", 8, m_item_host_rangeTable, "HOST_ID");
        this.m__creationDateFm = new FullFieldMapping("m__creationDate", 9, m_item_host_rangeTable, "CREATION_DATE", (String) null,
                (String) null, "CREATION_DATE=CREATION_DATE", "sysdate", (FromDBRule) null, (ToDBRule) null);
        this.m__lastModifiedDateFm = new FullFieldMapping("m__lastModifiedDate", 10, m_item_host_rangeTable, "LAST_MODIFIED_DATE",
                (String) null, (String) null, "LAST_MODIFIED_DATE=SYSDATE", "sysdate", (FromDBRule) null, (ToDBRule) null);
        this.m_itemIdFm = new HintFieldMapping("m_itemId", 11);
        this.m_ourDDRHints = new MappingIncludesAttribute[0];
        this.m_builtFieldMappings = null;
        this.m_ourFieldMappings = null;
        this.m_builtReadSets = null;
        this.m_builtUpdateSets = null;
    }

    protected Class getDOClassToMap() {
        return JdkUtil.forceInit(ItemHostInfoDoImpl.class);
    }

    public MappingIncludesAttribute[] getOurDDRHints() {
        return this.m_ourDDRHints;
    }

    protected TableDef[] getTableDefs() {
        TableDef[] tableDefs = new TableDef[]{m_item_hostTable, m_item_host_rangeTable};
        return tableDefs;
    }

    protected TableJoin[] getTableJoins() {
        TableJoin[] tableJoins = new TableJoin[]{new TableJoin(
                new TableDef[]{m_item_hostTable, m_item_host_rangeTable}, "i.host_id = ir.host_id")};
        return tableJoins;
    }


    protected void initFieldMappings() {
        super.initFieldMappings();
    }

    public FieldMapping[] getFieldMappings() {
        if (this.m_builtFieldMappings == null) {
            this.m_ourFieldMappings = new FieldMapping[]{this.m_hostIdFm, this.m_primaryHostNameFm, this.m_readOnlyHostNameFm, this.m_descriptionFm,
                    this.m_rangeStartFm, this.m_rangeEndFm, this.m_creationDateFm, this.m_lastModifiedDateFm, this.m__hostIdFm,
                    this.m__creationDateFm, this.m__lastModifiedDateFm, this.m_itemIdFm};
            this.m_builtFieldMappings = this.appendMappings(super.getFieldMappings(), this.m_ourFieldMappings);
        }

        return this.m_builtFieldMappings;
    }

    protected ReadSet[] getReadSets() {
        if (this.m_builtReadSets == null) {
            ReadSet[] readSets = new ReadSet[]{new ReadSet(-2, (ReadableMapping[]) null)};
            this.m_builtReadSets = this.appendReadSets(super.getReadSets(), super.getFieldMappings(), readSets, this.m_ourFieldMappings);
        }

        return this.m_builtReadSets;
    }

    protected UpdateSet[] getUpdateSets() {
        if (this.m_builtUpdateSets == null) {
            UpdateSet[] updateSets = new UpdateSet[]{new UpdateSet(-2, (UpdateableMapping[]) null)};
            this.m_builtUpdateSets = this.appendUpdateSets(super.getUpdateSets(), super.getFieldMappings(), updateSets, this.m_ourFieldMappings);
        }

        return this.m_builtUpdateSets;
    }

    protected Query[] getRawQueries() {
        Query[] queries = new Query[]{
                new SelectQuery("_PrimaryKeyLookup", this.m_ourDDRHints,
                        new SelectStatement[]{
                                new SelectStatement(-1,
                                        "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE <JOIN/> " +
                                                "AND i.HOST_ID = :m_hostId AND ir.RANGE_START = :m_rangeStart ")}),
                new SelectQuery("FIND_ALL", this.m_ourDDRHints,
                        new SelectStatement[]{
                                new SelectStatement(-1, "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE <JOIN/> ")}),
                new SelectQuery("FIND_ALL_BY_HOST_ID", this.m_ourDDRHints,
                        new SelectStatement[]{
                                new SelectStatement(-1, "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE <JOIN/> " +
                                        "AND i.HOST_ID = :m_hostId ")}),
        };
        queries = this.mergeQuerySets(super.getRawQueries(), queries);
        return queries;
    }
}
