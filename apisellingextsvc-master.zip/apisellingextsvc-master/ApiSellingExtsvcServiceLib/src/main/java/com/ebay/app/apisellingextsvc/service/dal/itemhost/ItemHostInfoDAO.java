package com.ebay.app.apisellingextsvc.service.dal.itemhost;

import com.ebay.integ.dal.dao.BaseDao2;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.dal.ddr.SimpleTableTouple;
import com.ebay.integ.dal.ddr.SimpleToupleProvider;
import com.ebay.integ.dal.ddr.ToupleProviderRegistry;
import com.ebay.integ.dal.map.*;
import com.ebay.persistence.DALVersion;
import com.ebay.app.apisellingextsvc.service.dal.common.ReadSets;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.ebay.app.apisellingextsvc.service.dal.itemhost.ItemHostInfoCodeGenMap.m_item_hostTable;
import static com.ebay.app.apisellingextsvc.service.dal.itemhost.ItemHostInfoCodeGenMap.m_item_host_rangeTable;

@DALVersion("3.0")
public class ItemHostInfoDAO extends BaseDao2 {

    private static final String ITEM_HOST_TABLE_NAME = "ITEM_HOST";
    private static final String ITEM_HOST_ITEM_ID_RANGE_TABLE_NAME = "ITEM_HOST_ITEM_ID_RANGE";
    private static final String PRIMARY_HOST = "lookuphostupdate";
    private static final String READ_ONLY_HOST = "lookuphost";

    private static ItemHostInfoDAO s_instance = new ItemHostInfoDAO();
    private static MappingIncludesAttribute[] m_ourDDRHints = new MappingIncludesAttribute[0];

    public static ItemHostInfoDAO getInstance() {
        return s_instance;
    }

    public List findAllDirect2DB() throws FinderException {
        QueryEngine qe = new QueryEngine();
        ItemHostInfoCodeGenDoImpl protoDO = new ItemHostInfoCodeGenDoImpl(getInstance(), GenericMap.getInitializedMap(ItemHostInfo.class));
        protoDO.setReadOnlyHint(true);
        List result = new ArrayList();
        qe.readMultiple(result, protoDO.getMap(), protoDO, "FIND_ALL", ReadSets.FULL.getValue());
        return result;
    }

    private Query[] getRawQueries() {
        return new Query[]{
                new SelectQuery("FIND_ALL",
                        this.m_ourDDRHints,
                        new SelectStatement[]{new SelectStatement(ReadSets.MATCHANY.getValue(),
                                "SELECT /*<CALCOMMENT/>*/ <SELECTFIELDS/> FROM <TABLES/> WHERE <JOIN/> ")}),
        };
    }


    public void initMap() {
        GenericMap<ItemHostInfo> map = GenericMap.getMap(ItemHostInfo.class);
        map = Optional.ofNullable(map).orElse(new GenericMap<>(ItemHostInfo.class));
        map.setDalVersion("3.0");

        ToupleProviderRegistry reg = ToupleProviderRegistry.getInstance();
        SimpleToupleProvider tp0 = new SimpleToupleProvider(new SimpleTableTouple(ITEM_HOST_TABLE_NAME, PRIMARY_HOST),
                new SimpleTableTouple(ITEM_HOST_TABLE_NAME, READ_ONLY_HOST));
        SimpleToupleProvider tp1 = new SimpleToupleProvider(new SimpleTableTouple(ITEM_HOST_ITEM_ID_RANGE_TABLE_NAME, PRIMARY_HOST),
                new SimpleTableTouple(ITEM_HOST_ITEM_ID_RANGE_TABLE_NAME, READ_ONLY_HOST));
        reg.registerToupleProvider(m_item_hostTable.getTable(), tp0);
        reg.registerToupleProvider(m_item_host_rangeTable.getTable(), tp1);
        map.setTableJoins(getTableJoins(map));
        map.setQueries(getRawQueries());
        map.setReadSets(getReadSets());
        map.init();
    }

    protected TableJoin[] getTableJoins(GenericMap<ItemHostInfo> map) {
        return new TableJoin[]{new TableJoin(new TableDef[]{map.getTableDef(ITEM_HOST_TABLE_NAME),
                map.getTableDef(ITEM_HOST_ITEM_ID_RANGE_TABLE_NAME)},
                "i.HOST_ID = ir.HOST_ID")};
    }

    public static ReadSet[] getReadSets() {
        return new ReadSet[]{new ReadSet(ReadSets.FULL.getValue(), null)};
    }
}
